package lli;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import common.bill.BillService;
import lli.Application.LLIApplication;
import lli.Application.LLIApplicationDeserializer;
import lli.Application.NewConnection.LLINewConnectionApplication;
import lli.Application.NewConnection.LLINewConnectionApplicationDeserializer;
import util.CurrentTimeFactory;
import util.ServiceDAOFactory;

public class LLISerializerTest {

	public static LLIConnectionInstance getTestConnection() {
		LLILocalLoop localLoop1 = new LLILocalLoop();
		localLoop1.setBtclDistance(1000);
		localLoop1.setClientDistance(2000);
		localLoop1.setOCDistance(1500);
		localLoop1.setOCID(1001);
		localLoop1.setVlanID(5000);
		
		LLILocalLoop localLoop2 = new LLILocalLoop();
		localLoop2.setBtclDistance(1000);
		localLoop2.setClientDistance(2000);
		localLoop2.setOCDistance(1500);
		localLoop2.setOCID(1001);
		localLoop2.setVlanID(5000);
		
		LLILocalLoop localLoop3 = new LLILocalLoop();
		localLoop3.setBtclDistance(1000);
		localLoop3.setClientDistance(2000);
		localLoop3.setOCDistance(1500);
		localLoop3.setOCID(1001);
		localLoop3.setVlanID(5000);
		
		LLILocalLoop localLoop4 = new LLILocalLoop();
		localLoop4.setBtclDistance(1000);
		localLoop4.setClientDistance(2000);
		localLoop4.setOCDistance(1500);
		localLoop4.setOCID(1001);
		localLoop4.setVlanID(5000);
		
		LLIOffice lliOffice1 = new LLIOffice();
		lliOffice1.setID(101);
		lliOffice1.setName("Office 1");
		List<LLILocalLoop> office1LocalLoopList = new ArrayList<>();
		office1LocalLoopList.add(localLoop1);
		office1LocalLoopList.add(localLoop2);
		lliOffice1.setLocalLoops(office1LocalLoopList);
		
		LLIOffice lliOffice2 = new LLIOffice();
		lliOffice2.setID(102);
		lliOffice2.setName("Office 2");
		List<LLILocalLoop> office2LocalLoopList = new ArrayList<>();
		office2LocalLoopList.add(localLoop3);
		office2LocalLoopList.add(localLoop4);
		lliOffice2.setLocalLoops(office2LocalLoopList);
		
		LLIConnectionInstance lliConnectionInstance = new LLIConnectionInstance();
		lliConnectionInstance.setClientID(10400);
		lliConnectionInstance.setBandwidth(40);
		lliConnectionInstance.setID(1);
		lliConnectionInstance.setName("Connection 1");
		lliConnectionInstance.setConnectionType(1);
		List<LLIOffice> lliOfficeList = new ArrayList<>();
		lliOfficeList.add(lliOffice1);
		lliOfficeList.add(lliOffice2);
		lliConnectionInstance.setLliOffices(lliOfficeList);
		/*
		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.registerTypeAdapter(LLIConnectionInstance.class, new LLIConnectionInstanceSerizalizer());
		gsonBuilder.registerTypeAdapter(LLIOffice.class, new LLIOfficeSerizalizer());
		gsonBuilder.registerTypeAdapter(LLILocalLoop.class, new LLILocalLoopSerizalizer());
		gsonBuilder.registerTypeAdapter(LLIConnectionInstance.class, new LLIConnectionDeserializer());
		gsonBuilder.registerTypeAdapter(LLIOffice.class, new LLIOfficeDeserializer());
		gsonBuilder.registerTypeAdapter(LLILocalLoop.class, new LLILocalLoopDeserializer());
		
		String json = gsonBuilder.create().toJson(lliConnectionInstance);
		System.out.println("JSON: " + json);
		LLIConnectionInstance deserializedFromJSON = gsonBuilder.create().fromJson(json, LLIConnectionInstance.class);
		*/
		
		return lliConnectionInstance;
	}
	
	public static void main(String args[]) throws Exception {
		/*
		String json = "{\"extendedApplicationID\":7001,\"bandwidth\":100,\"connectionType\":{\"ID\":5,\"label\":\"Regular\"},\"description\":\"Test Connection\",\"address\":\"Mohammadpur, Dhaka 1207\",\"loopProvider\":{\"ID\":1,\"label\":\"BTCL\"},\"duration\":0,\"suggestedDate\":1531850400000,\"applicationID\":8003,\"client\":{\"ID\":396002,\"label\":\"dhrubo_client\"},\"user\":{\"ID\":40131,\"label\":\"dhrubo_admin\"},\"submissionDate\":1530679312281,\"status\":{\"ID\":2,\"label\":\"Received\"},\"content\":\"{\\\"ID\\\":0,\\\"name\\\":\\\"Connection Name\\\",\\\"client\\\":{\\\"ID\\\":396002,\\\"label\\\":\\\"dhrubo_client\\\"},\\\"gbBandwidth\\\":0,\\\"mbBandwidth\\\":\\\"100\\\",\\\"connectionType\\\":{\\\"ID\\\":1,\\\"label\\\":\\\"Regular\\\"},\\\"officeList\\\":[{\\\"ID\\\":0,\\\"name\\\":\\\"Office Name\\\",\\\"address\\\":\\\"Mohammadpur, Dhaka 1207\\\",\\\"localLoopList\\\":[{\\\"ID\\\":0,\\\"vlanID\\\":\\\"13\\\",\\\"OCDistance\\\":\\\"13\\\",\\\"btclDistance\\\":\\\"13\\\",\\\"clientDistance\\\":\\\"13\\\",\\\"OCID\\\":\\\"13\\\"}]}],\\\"CONTENTTYPE\\\":\\\"connection\\\"}\",\"applicationType\":{\"ID\":1,\"label\":\"New Connection\"}}";
		
		
		JsonObject jsonObject = new JsonParser().parse(json).getAsJsonObject();
		System.out.println(jsonObject.get("connectionType"));
		jsonObject.addProperty("connectionType", jsonObject.getAsJsonObject("connectionType").get("ID").getAsInt());
		jsonObject.addProperty("status", jsonObject.getAsJsonObject("status").get("ID").getAsInt());
		jsonObject.addProperty("client", 1L);
		jsonObject.addProperty("loopProvider", 1);
		jsonObject.addProperty("applicationType", 1);
		jsonObject.addProperty("user", 1L);
		System.out.println(jsonObject.get("connectionType"));
		LLINewConnectionApplication lliNewConnectionApplication =
		new GsonBuilder()
		//.registerTypeAdapter(LLIApplication.class, new LLIApplicationDeserializer())
		//.registerTypeAdapter(LLINewConnectionApplication.class, new LLINewConnectionApplicationDeserializer())
		.create()
		.fromJson(jsonObject, LLINewConnectionApplication.class);
		;
		
		
		System.out.println(lliNewConnectionApplication);
		*/
		CurrentTimeFactory.initializeCurrentTimeFactory();
		BillService billService = ServiceDAOFactory.getService(BillService.class);
		billService.skipBillByBillID(254003L);
		
	}

}
