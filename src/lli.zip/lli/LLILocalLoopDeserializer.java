package lli;

import java.lang.reflect.Type;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

public class LLILocalLoopDeserializer implements JsonDeserializer<LLILocalLoop>{

	@Override
	public LLILocalLoop deserialize(JsonElement jsonElement, Type arg1, JsonDeserializationContext context)
			throws JsonParseException {
		LLILocalLoop lliLocalLoop = new LLILocalLoop();
		JsonObject jsonObject = jsonElement.getAsJsonObject();
		
		lliLocalLoop.setID(jsonObject.get("ID").getAsLong());
		
		lliLocalLoop.setClientDistance(jsonObject.get("clientDistance").getAsInt());
		lliLocalLoop.setBtclDistance(jsonObject.get("btclDistance").getAsInt());
		lliLocalLoop.setOCDistance(jsonObject.get("OCDistance").getAsInt());
		lliLocalLoop.setOCID( (null != jsonObject.get("OC")) ? jsonObject.get("OC").getAsJsonObject().get("ID").getAsLong() : null );
		lliLocalLoop.setVlanID(jsonObject.get("vlanID").getAsLong());
		lliLocalLoop.setOfcType(jsonObject.get("ofcType").getAsJsonObject().get("ID").getAsInt());
		
		return lliLocalLoop;
	}

}
