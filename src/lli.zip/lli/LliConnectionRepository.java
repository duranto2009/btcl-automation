package lli;

import static util.SqlGenerator.getAllObjectList;
import static util.SqlGenerator.getAllResultSetOfTable;
import static util.SqlGenerator.getLastModificationTimeColumnName;
import static util.SqlGenerator.populateObjectFromDB;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import connection.DatabaseConnection;
import lli.link.LliEndPointDTO;
import lli.link.LliFarEndDTO;
import lli.link.LliLinkDTO;
import lli.link.LliRedundantFarEndDTO;
import repository.Repository;
import repository.RepositoryManager;
import util.SqlGenerator;


/*
 * 
 * At first reload the subClasses (LliNearEndDTO, LliFarEndDTO, LliRedundantNearEndDTO, LliRedundantFarEndDTO)
 * Then reload the superClass (LliEndPointDTO)
 * */

public class LliConnectionRepository implements Repository{

	Logger logger = Logger.getLogger(LliConnectionRepository.class);
	
	static LliConnectionRepository instance = null;
	
	private HashMap<Long, LliFarEndDTO> mapOfLliFarEndToFarEndID;
	private HashMap<Long, LliFarEndDTO> mapOfLliFarEndToEndPointID;
	
	private HashMap<Long, LliEndPointDTO> endPointMapVsEndPointID;
	private HashMap<Long, LliRedundantFarEndDTO> redundantFarEndMapVsRedandantFarEndID;
	private HashMap<Long, Set<LliRedundantFarEndDTO> > redundantFarEndListMapVsEndPointID;
	private HashMap<Long, LliLinkDTO> mapOfLliLinkToLinkID;
	private HashMap<Long, Set<LliLinkDTO>> lliLinkListMapVsConnectionID;
	
	public LliRedundantFarEndDTO getLliRedundantFarEndByFarEndID(long farEndID){
		return redundantFarEndMapVsRedandantFarEndID.get(farEndID);
	}

	private LliConnectionRepository(){

		mapOfLliFarEndToEndPointID = new HashMap<Long, LliFarEndDTO>() ;
		mapOfLliFarEndToFarEndID = new HashMap<Long, LliFarEndDTO>() ;
		endPointMapVsEndPointID = new HashMap<Long, LliEndPointDTO>() ;
		redundantFarEndMapVsRedandantFarEndID = new HashMap<Long, LliRedundantFarEndDTO>() ;
		redundantFarEndListMapVsEndPointID = new HashMap<Long, Set<LliRedundantFarEndDTO> >() ;
		mapOfLliLinkToLinkID = new HashMap<Long, LliLinkDTO>();
		lliLinkListMapVsConnectionID = new HashMap<Long, Set<LliLinkDTO>>();
		RepositoryManager.getInstance().addRepository(this);
	}
	public synchronized  static LliConnectionRepository getInstance(){
		if(instance==null){
			instance = new LliConnectionRepository();
		}
		return instance;
	}
	public List<LliRedundantFarEndDTO> getLliRedundantFarEndListByLliLinkID(long lliLinkID){
		return null;
	}
	private void reloadLliLink(boolean firstReload,DatabaseConnection databaseConnection) throws Exception{
		String conditionString = (firstReload?"":" where "+SqlGenerator.getLastModificationTimeColumnName(LliLinkDTO.class)+" >= "+RepositoryManager.lastModifyTime);
		List<LliLinkDTO>  lliLinkDTOs = (List<LliLinkDTO>)SqlGenerator.getAllObjectList(LliLinkDTO.class, databaseConnection, conditionString);
		for(LliLinkDTO lliLinkDTO : lliLinkDTOs){
			mapOfLliLinkToLinkID.put(lliLinkDTO.getID(), lliLinkDTO);
		}
	}
	
	public LliLinkDTO getLliLinkByLliLinkID(long ID){
		return mapOfLliLinkToLinkID.get(ID);
	}
	
	public List<LliLinkDTO> getLliLinkByLliConnectionID(long ID){
		List<LliLinkDTO> lliLinkDTOs = new ArrayList<LliLinkDTO>();
		lliLinkDTOs.addAll(lliLinkListMapVsConnectionID.get(ID));
		return lliLinkDTOs;
		
	}
	
	public LliFarEndDTO getFarEndByFarEndID(long farEndID){
		return mapOfLliFarEndToFarEndID.get(farEndID);
	}
	
	public LliEndPointDTO getLliEndPointDTOByEndPointID(long ID){
		return endPointMapVsEndPointID.get(ID);
	}
	
	public LliFarEndDTO getFarEndDTOByEndPointID(long endPointID){
		return mapOfLliFarEndToEndPointID.get(endPointID);
	}

	private void reloadRedundantFarEnd(boolean firstReload,DatabaseConnection databaseConnection) throws Exception{
		
		String conditionString = (firstReload? "":" where "+SqlGenerator.getLastModificationTimeColumnName(LliRedundantFarEndDTO.class)+ ">=" + RepositoryManager.lastModifyTime);
		List<LliRedundantFarEndDTO> redundantFarEndDTOs = (List<LliRedundantFarEndDTO>)getAllObjectList(LliRedundantFarEndDTO.class, databaseConnection, conditionString);
		for(LliRedundantFarEndDTO redundantFarEndDTO: redundantFarEndDTOs){
			redundantFarEndMapVsRedandantFarEndID.put(redundantFarEndDTO.getLliEndPointID(), redundantFarEndDTO);
			if(!redundantFarEndListMapVsEndPointID.containsKey(redundantFarEndDTO.getID())){
				redundantFarEndListMapVsEndPointID.put(redundantFarEndDTO.getLliEndPointID(), new LinkedHashSet<LliRedundantFarEndDTO>());
			}
			redundantFarEndListMapVsEndPointID.get(redundantFarEndDTO.getLliEndPointID()).add(redundantFarEndDTO);
		}
	}
	
	private void reloadEndPoint(boolean firstReload,DatabaseConnection databaseConnection) throws Exception{
		
		String conditionString = (firstReload?"":" where "+getLastModificationTimeColumnName(LliEndPointDTO.class)+">="+RepositoryManager.lastModifyTime);
		
		ResultSet rs = getAllResultSetOfTable(LliEndPointDTO.class, databaseConnection, conditionString);
		
		while(rs.next()){
			
			LliEndPointDTO lliEndPointDTO = new LliEndPointDTO();
			populateObjectFromDB(lliEndPointDTO, rs, LliEndPointDTO.class);
			endPointMapVsEndPointID.put(lliEndPointDTO.getLliEndPointID(), lliEndPointDTO);
			
			long lliEndPointID = lliEndPointDTO.getLliEndPointID();
			if(mapOfLliFarEndToEndPointID.containsKey(lliEndPointID)){
				populateObjectFromDB(mapOfLliFarEndToEndPointID.get(lliEndPointID), rs, LliEndPointDTO.class);
			}
		}
	}
	
	private void reloadFarEnd(boolean firstReload,DatabaseConnection databaseConnection) throws Exception{
		
		String conditionString = firstReload?"":" where "+getLastModificationTimeColumnName(LliFarEndDTO.class)+" >= "+RepositoryManager.lastModifyTime;
		List<LliFarEndDTO> lliFarEndDTOs = (List<LliFarEndDTO>)getAllObjectList(LliFarEndDTO.class, databaseConnection,conditionString);
		for(LliFarEndDTO lliFarEndDTO: lliFarEndDTOs){
			mapOfLliFarEndToFarEndID.put(lliFarEndDTO.getID(), lliFarEndDTO);
			mapOfLliFarEndToEndPointID.put(lliFarEndDTO.getLliEndPointID(), lliFarEndDTO);
		}
		logger.debug("mapOfLliFarEndToEndPointID"+mapOfLliFarEndToEndPointID);
	}
	
	public void reload(boolean firstReload) {
		DatabaseConnection databaseConnection = new DatabaseConnection();

		try {
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			reloadFarEnd(firstReload, databaseConnection);
			reloadEndPoint(firstReload, databaseConnection);
			reloadLliLink(firstReload, databaseConnection);
			databaseConnection.dbTransationEnd();
			databaseConnection.dbClose();

		} catch (Exception ex) {
			logger.debug("Exception ", ex);
		}
	}
	
	private void populateRedundantFarEnd(LliRedundantFarEndDTO redundantFarEndDTO,ResultSet rs) throws Exception{
		populateObjectFromDB(redundantFarEndDTO, rs);
	}
	
	private void populateFarEndDTOIntoLocalMap(LliFarEndDTO lliFarEndDTO) throws Exception{
		mapOfLliFarEndToFarEndID.put(lliFarEndDTO.getID(), lliFarEndDTO);
		mapOfLliFarEndToEndPointID.put(lliFarEndDTO.getLliEndPointID(), lliFarEndDTO);
	}
	
	
	private void populateLliEndPoint(LliEndPointDTO lliEndPointDTO,ResultSet rs) throws Exception{
	    	populateObjectFromDB(lliEndPointDTO, rs);
	}


	@Override
	public String getTableName() {
		// TODO Auto-generated method stub
		return null;
	}

}
