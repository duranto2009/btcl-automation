package lli;

import annotation.ColumnName;
import annotation.PrimaryKey;
import annotation.TableName;

@TableName("at_lli_client_td_status")
public class LLIClientTDStatus {
	
	public static int TD = 1;
	public static int ACTIVE = 2;
	
	
	@PrimaryKey
	@ColumnName("client_td_status_id")
	long ID;
	@ColumnName("client_td_status_client_id")
	long clientID;
	@ColumnName("client_td_status_td_date")
	long TDDate;
	@ColumnName("client_td_status_td_status")
	int tdStatus;
	@ColumnName("client_td_status_is_deleted")
	boolean isDeleted;
	@ColumnName("client_td_status_last_modification_time")
	long lastModificationTime;
	public long getID() {
		return ID;
	}
	public void setID(long iD) {
		ID = iD;
	}
	public long getClientID() {
		return clientID;
	}
	public void setClientID(long clientID) {
		this.clientID = clientID;
	}
	public long getTDDate() {
		return TDDate;
	}
	public void setTDDate(long tDDate) {
		TDDate = tDDate;
	}
	public int getTdStatus() {
		return tdStatus;
	}
	public void setTdStatus(int tdStatus) {
		this.tdStatus = tdStatus;
	}
	public boolean isDeleted() {
		return isDeleted;
	}
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	public long getLastModificationTime() {
		return lastModificationTime;
	}
	public void setLastModificationTime(long lastModificationTime) {
		this.lastModificationTime = lastModificationTime;
	}
	
}
