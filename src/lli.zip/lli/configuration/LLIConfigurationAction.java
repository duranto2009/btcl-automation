package lli.configuration;

import annotation.ForwardedAction;
import annotation.JsonPost;
import requestMapping.AnnotatedRequestMappingAction;
import requestMapping.RequestParameter;
import requestMapping.Service;
import requestMapping.annotation.ActionRequestMapping;
import requestMapping.annotation.*;
@ActionRequestMapping("lli/configuration/")
public class LLIConfigurationAction extends AnnotatedRequestMappingAction{
	@Service
	LLICostConfigurationService lliCostConfigurationService;
	
	@ForwardedAction
	@RequestMapping(mapping="otc/get", requestMethod=RequestMethod.GET)
	public String getOTCCostConfigPage() {
		return "otc-cost-configuration";
	}
	
	@RequestMapping(mapping="otc/latest/view", requestMethod = RequestMethod.GET)
	public LLIOTCConfigurationDTO getLatestLLIOTCConfiguration() throws Exception {
		return lliCostConfigurationService.getCurrentActiveLLI_OTC_ConfigurationDTO();
	}
	
	@JsonPost
	@RequestMapping(mapping="otc/insert", requestMethod = RequestMethod.POST)
	public void insertLatestLLI_OTC_Configuration(@RequestParameter(isJsonBody=true, value="otc") LLIOTCConfigurationDTO otc) throws Exception {
		lliCostConfigurationService.insert(otc);
	}
}
