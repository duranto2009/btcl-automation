package lli.configuration;


import annotation.ColumnName;
import annotation.CurrentTime;
import annotation.PrimaryKey;
import annotation.TableName;

@TableName("at_lli_common_charge_config")
public class LLIOTCConfigurationDTO {
	@ColumnName("ID")
	@PrimaryKey
	public long id;
	
	@ColumnName("category_ID")
	public int categoryID = 1;
	
	@ColumnName("registration_charge")
	public double registrationCharge;
	
	@ColumnName("downgrade_charge")
	public double downgradeCharge;

	@ColumnName("port_charge")
	public double portCharge;
	
	@ColumnName("shifting_charge")
	public double shiftingCharge;
	
	@ColumnName("fiber_charge")
	public double fiberCharge;
	
	@ColumnName("instant_closing_charge")
	public double instantClosingCharge;
	
	@ColumnName("max_vat_percentage")
	public double maximumVatPercentage;
	
	@ColumnName("max_discount_percentage")
	public double maximumDiscountPercentage;
	
	@ColumnName("activationDate")
	public long activationDate;
	
	@CurrentTime
	@ColumnName("lastModificationTime")
	public long lastModificationTime;
	
	@ColumnName("isDeleted")
	public boolean isDeleted;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getCategoryID() {
		return categoryID;
	}

	public void setCategoryID(int categoryID) {
		this.categoryID = categoryID;
	}

	public double getRegistrationCharge() {
		return registrationCharge;
	}

	public void setRegistrationCharge(double registrationCharge) {
		this.registrationCharge = registrationCharge;
	}

	public double getDowngradeCharge() {
		return downgradeCharge;
	}

	public void setDowngradeCharge(double downgradeCharge) {
		this.downgradeCharge = downgradeCharge;
	}

	public double getPortCharge() {
		return portCharge;
	}

	public void setPortCharge(double portCharge) {
		this.portCharge = portCharge;
	}

	public double getShiftingCharge() {
		return shiftingCharge;
	}

	public void setShiftingCharge(double shiftingCharge) {
		this.shiftingCharge = shiftingCharge;
	}

	public double getFiberOTC() {
		return fiberCharge;
	}

	public void setFiberOTC(double fiberOTC) {
		this.fiberCharge = fiberOTC;
	}

	public double getInstantClosingOTC() {
		return instantClosingCharge;
	}

	public void setInstantClosingOTC(double instantClosingOTC) {
		this.instantClosingCharge = instantClosingOTC;
	}

	public double getMaximumVatPercentage() {
		return maximumVatPercentage;
	}

	public void setMaximumVatPercentage(double maximumVatPercentage) {
		this.maximumVatPercentage = maximumVatPercentage;
	}

	public double getMaximumDiscountPercentage() {
		return maximumDiscountPercentage;
	}

	public void setMaximumDiscountPercentage(double maximumDiscountPercentage) {
		this.maximumDiscountPercentage = maximumDiscountPercentage;
	}

	public long getActivationDate() {
		return activationDate;
	}

	public void setActivationDate(long activationDate) {
		this.activationDate = activationDate;
	}

	public long getLastModificationTime() {
		return lastModificationTime;
	}

	public void setLastModificationTime(long lastModificationTime) {
		this.lastModificationTime = lastModificationTime;
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
}
