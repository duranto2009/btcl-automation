package lli.configuration;

import java.util.List;

import org.apache.log4j.Logger;

import annotation.DAO;
import annotation.Transactional;
import common.RequestFailureException;
import util.TransactionType;

public class LLICostConfigurationService {
	public static Logger logger = Logger.getLogger(LLICostConfigurationService.class);
	
	@DAO
	LLICostConfigurationDAO lliCostConfigurationDAO;
	
	@Transactional
	public void insert (LLIOTCConfigurationDTO lliCommonChargeDTO ) throws Exception {
		LLIOTCConfigurationDTO currentOTC = getCurrentActiveLLI_OTC_ConfigurationDTO();
		currentOTC.setDeleted(true);
		lliCostConfigurationDAO.update(currentOTC);
		lliCostConfigurationDAO.insert(lliCommonChargeDTO);
	}
	
	@Transactional(transactionType=TransactionType.READONLY)
	public LLIOTCConfigurationDTO getCurrentActiveLLI_OTC_ConfigurationDTO() throws Exception {
		LLIOTCConfigurationDTO lliCommonChargeDTO = lliCostConfigurationDAO.getCurrentActiveLLI_OTC_ConfigurationDTO();
		if(lliCommonChargeDTO == null) {
			throw new RequestFailureException("No LLI OTC Charge Configuration Found");
		}
		return lliCommonChargeDTO;
	}
	
	@Transactional(transactionType=TransactionType.READONLY)
	public List<LLIOTCConfigurationDTO> getAllFutureLLI_OTC_ConfigurationDTOs() throws Exception {
		List<LLIOTCConfigurationDTO> lliCommonChargeDTOs = lliCostConfigurationDAO.getAllFutureLLI_OTC_ConfigurationDTOs();
		return lliCommonChargeDTOs;
	}

}