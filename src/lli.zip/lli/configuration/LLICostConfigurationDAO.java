package lli.configuration;

import java.util.List;

import org.apache.log4j.Logger;

import common.RequestFailureException;
import util.CurrentTimeFactory;
import util.ModifiedSqlGenerator;

public class LLICostConfigurationDAO {
	Logger logger = Logger.getLogger(getClass());
	Class<LLIOTCConfigurationDTO> classObject = LLIOTCConfigurationDTO.class;
	
	public List<LLIOTCConfigurationDTO> getCommonChargeDTOListByDateRange(long fromDate,long toDate) throws Exception{
		if(fromDate>toDate){
			throw new RequestFailureException("From date must be less than to date");
		}
		List<LLIOTCConfigurationDTO> lliCommonChargeDTOs = ModifiedSqlGenerator.getAllObjectList(classObject, 
				new LLIOTCConfigurationDTOConditionBuilder()
				.Where()
				.activationDateLessThanEquals(toDate)
				.activationDateGreaterThanEquals(fromDate)
				.isDeleted(false)
				.orderByactivationDateDesc()
				.limit(1)
				.getCondition());
		return lliCommonChargeDTOs;
		
	}
	public LLIOTCConfigurationDTO getCurrentActiveLLI_OTC_ConfigurationDTO() throws Exception {
		List<LLIOTCConfigurationDTO> lliCommonChargeDTOs = ModifiedSqlGenerator.getAllObjectList(classObject, 
				new LLIOTCConfigurationDTOConditionBuilder()
				.Where()
				.activationDateLessThanEquals(CurrentTimeFactory.getCurrentTime())
				.isDeleted(false)
				.orderByactivationDateDesc()
				.limit(1)
				.getCondition());
		return lliCommonChargeDTOs.isEmpty() ? null : lliCommonChargeDTOs.get(0);
	}

	public List<LLIOTCConfigurationDTO> getAllFutureLLI_OTC_ConfigurationDTOs() throws Exception {
		List<LLIOTCConfigurationDTO> futureCharge = ModifiedSqlGenerator.getAllObjectList( classObject, 
											new LLIOTCConfigurationDTOConditionBuilder()
											.Where()
											.activationDateGreaterThan(CurrentTimeFactory.getCurrentTime())
											.isDeleted(false)
											.getCondition()
											);

		return futureCharge;
	}

	public void insert(LLIOTCConfigurationDTO lliCommonChargeDTO) throws Exception {
		ModifiedSqlGenerator.insert(lliCommonChargeDTO);
	}
	public void update(LLIOTCConfigurationDTO currentOTC) throws Exception {
		ModifiedSqlGenerator.updateEntityByPropertyList(currentOTC, classObject, false, false, 
				new String[]{"isDeleted"}, CurrentTimeFactory.getCurrentTime());
	}
}
