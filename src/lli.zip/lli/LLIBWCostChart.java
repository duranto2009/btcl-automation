package lli;

public class LLIBWCostChart {
	public static final int LONG_TERM_AGREEMENT = 1;
	public static final int REGULAR_AGREEMENT = 2;
	public double getBWCostByAgreementTypeAndBW(int agreementType, double bandwidth ) throws Exception{
		return 25.0;
	}
}
