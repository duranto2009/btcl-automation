package lli.action;

import java.util.*;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.google.gson.GsonBuilder;

import common.BulkBillCreationSummary;
import common.ClientDTO;
import common.StringUtils;
import common.UniversalDTOService;
import dns.domain.DNSClientAdapter;
import lli.LliMonthlyBillProperty;
import lli.link.LliLinkService;
import requestMapping.AnnotatedRequestMappingAction;
import requestMapping.RequestParameter;
import requestMapping.Service;
import requestMapping.annotation.ActionRequestMapping;
import requestMapping.annotation.RequestMapping;
import requestMapping.annotation.RequestMethod;
import util.ServiceDAOFactory;
import util.TimeConverter;

@ActionRequestMapping("SchedulerLli/")
public class LliMonthlyBillAction extends AnnotatedRequestMappingAction{
	@Service
	LliLinkService lliLinkService;
	
	@Override
	public GsonBuilder getGsonBuilder() {
		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.registerTypeHierarchyAdapter(ClientDTO.class, new DNSClientAdapter());
		
		return gsonBuilder;
	}
	@RequestMapping(mapping = "", requestMethod = RequestMethod.POST)
	public void generateManualBillByBillID() throws Exception{
		
	}
	@RequestMapping(mapping = "generateMonthlyBill", requestMethod = RequestMethod.POST)
	public BulkBillCreationSummary generateManualBillByTimeRange(@RequestParameter("fromTime")String fromTimeString
			, @RequestParameter("toTime") String toTimeString,@RequestParameter("ids") String idListString) throws Exception{
		
		long fromTime = TimeConverter.getTimeInMilliSec(fromTimeString, "dd/MM/yyyy");
		long toTime =  TimeConverter.getTimeInMilliSec(toTimeString, "dd/MM/yyyy")-1;
		
		toTime += TimeConverter.MILLS_IN_A_DAY;
		
		if(StringUtils.isBlank(idListString)){
			return lliLinkService.generateLliMonthlyBill(fromTime, toTime);
		}else{
			
			List<Long> lliIDList = new ArrayList<>();
			for(String idString: idListString.split(",")){
				if(idString.trim().matches("[0-9]+")){
					lliIDList.add(Long.parseLong(idListString));
				}
			}
			
			return lliLinkService.generateLLIMonthlyBill(fromTime, toTime, lliIDList);
		}
	}
	@RequestMapping(mapping = "", requestMethod = RequestMethod.POST)
	public void cancelBillByBillID(long billID) throws Exception{
		
	}
	@RequestMapping(mapping = "cancelMonthlyBill", requestMethod = RequestMethod.POST)
	public void cancelBillByGenerationTimeRange(Date fromTime,Date toTime) throws Exception{
		
	}
	@RequestMapping(mapping="updateBillProperty", requestMethod = RequestMethod.POST)
	public ActionForward updateBillProperty(LliMonthlyBillProperty lliMonthlyBillProperty) throws Exception {
		UniversalDTOService lliBillUpdaterService = ServiceDAOFactory.getService(UniversalDTOService.class);
		lliBillUpdaterService.update(lliMonthlyBillProperty);
		ActionForward actionForward = new ActionForward();
		actionForward.setPath("getBillProperty.do");
		actionForward.setRedirect(true);
		return actionForward;
	}
	@RequestMapping(mapping="getBillProperty", requestMethod=RequestMethod.GET)
	public ActionForward getVpnMonthlyBillProperty(ActionMapping mapping) {
		return mapping.findForward("getBillProperty");
	}
	@RequestMapping(mapping="cancelMonthlyBillByIDs" , requestMethod=RequestMethod.POST)
	public void cancelMonthlyBillByBillIDs(@RequestParameter("ids") String ids) throws Exception{
		String [] IDs = StringUtils.isBlank(ids)?new String[0]:StringUtils.trim(ids).split(",", -1);
		
		List<Long> lliLinkIDList = new ArrayList<>();
		for(String id: IDs) {
			System.err.println(id);
			lliLinkIDList.add(Long.parseLong(id));
		}
		
		lliLinkService.cancellLLIBillByBillIDList(lliLinkIDList);
	}
	@RequestMapping(mapping="viewPayload", requestMethod=RequestMethod.GET)
	public Object getPayload(HttpServletRequest request) throws Exception{
		ClientDTO object = new ClientDTO();
		
		return object;
	}
	@RequestMapping(mapping="getMonthlyBill", requestMethod=RequestMethod.GET)
	public ActionForward getMonthlyBillFormPage(ActionMapping mapping, HttpServletRequest request) {
		request.setAttribute("title", "Monthly Bill");
		return mapping.findForward("getMonthlyBillForm");
	}
	@RequestMapping(mapping="cancelMonthlyBill", requestMethod=RequestMethod.GET)
	public ActionForward getCancelMonthlyBillFormPage(HttpServletRequest request, ActionMapping mapping) {
		request.setAttribute("title", "Cancel Bill");
		return mapping.findForward("getMonthlyBillForm");
	}
}
