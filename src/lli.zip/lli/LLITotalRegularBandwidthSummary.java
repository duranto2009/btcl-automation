package lli;

public class LLITotalRegularBandwidthSummary {
	public long fromDate;
	public long toDate;
	public double totalBandwidth;
	public LLITotalRegularBandwidthSummary(long fromDate,long toDate,double totalBandwidth){
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.totalBandwidth = totalBandwidth;
	}

}
