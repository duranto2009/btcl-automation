package lli.demandNote;

import java.util.*;

import annotation.AccountingLogic;
import annotation.ColumnName;
import annotation.ForeignKeyName;
import annotation.PrimaryKey;
import annotation.TableName;
import common.bill.BillDTO;
import util.JsonUtils;

@AccountingLogic(LLISingleConnectionDemandNoteBusinessLogic.class)
@ForeignKeyName("lli_common_dn_parent_bill_id")
@TableName("at_lli_common_dn")
public class LLISingleConnectionCommonDemandNote extends BillDTO{
	
	public LLISingleConnectionCommonDemandNote() {
		setClassName(this.getClass().getCanonicalName());
	}
	
	@PrimaryKey
	@ColumnName("lli_common_dn_id")
	long commonDemandNoteID;
	@ColumnName("lli_common_dn_sc_money")
	double securityMoney;
	@ColumnName("lli_common_dn_bw_charge")
	double bandwidthCharge;
	@ColumnName("lli_common_dn_advance_amount")
	double advancedAmount;
	@ColumnName("lli_common_dn_downgrade_charge")
	double downgradeCharge;
	@ColumnName("lli_common_dn_port_charge")
	double portCharge;
	@ColumnName("lli_common_dn_fibre_otc")
	double fibreOTC;
	@ColumnName("lli_common_dn_core_charge")
	double coreCharge;
	@ColumnName("lli_common_dn_first_x_ip_cost")
	double firstXIpCost;
	@ColumnName("lli_common_dn_next_y_ip_cost")
	double nextYIpCost;
	@ColumnName("lli_common_dn_shift_charge")
	double shiftCharge;
	@ColumnName("lli_common_dn_item_cost_content")
	String itemCostContent;
	List<ItemCost> itemCosts;
	
	public String getItemCostContent() {
		return itemCostContent;
	}
	public void setItemCostContent(String itemCostContent) {
		this.itemCostContent = itemCostContent;
	}
	public long getCommonDemandNoteID() {
		return commonDemandNoteID;
	}
	public void setCommonDemandNoteID(long commonDemandNoteID) {
		this.commonDemandNoteID = commonDemandNoteID;
	}
	public double getSecurityMoney() {
		return securityMoney;
	}
	public void setSecurityMoney(double securityMoney) {
		this.securityMoney = securityMoney;
	}
	public double getBandwidthCharge() {
		return bandwidthCharge;
	}
	public void setBandwidthCharge(double bandwidthCharge) {
		this.bandwidthCharge = bandwidthCharge;
	}
	public double getAdvancedAmount() {
		return advancedAmount;
	}
	public void setAdvancedAmount(double advancedAmount) {
		this.advancedAmount = advancedAmount;
	}
	public double getDowngradeCharge() {
		return downgradeCharge;
	}
	public void setDowngradeCharge(double downgradeCharge) {
		this.downgradeCharge = downgradeCharge;
	}
	public double getPortCharge() {
		return portCharge;
	}
	public void setPortCharge(double portCharge) {
		this.portCharge = portCharge;
	}
	public double getFibreOTC() {
		return fibreOTC;
	}
	public void setFibreOTC(double fibreOTC) {
		this.fibreOTC = fibreOTC;
	}
	public double getCoreCharge() {
		return coreCharge;
	}
	public void setCoreCharge(double coreCharge) {
		this.coreCharge = coreCharge;
	}
	public double getFirstXIpCost() {
		return firstXIpCost;
	}
	public void setFirstXIpCost(double firstXIpCost) {
		this.firstXIpCost = firstXIpCost;
	}
	public double getNextYIpCost() {
		return nextYIpCost;
	}
	public void setNextYIpCost(double nextYIpCost) {
		this.nextYIpCost = nextYIpCost;
	}
	public double getShiftCharge() {
		return shiftCharge;
	}
	public void setShiftCharge(double shiftCharge) {
		this.shiftCharge = shiftCharge;
	}
	
	public double getTotalItemCost(){
		double totalItemCost = 0;
		for(ItemCost itemCost: getItemCosts()){
			totalItemCost+=itemCost.cost; 
		}
		return totalItemCost;
	}
	public List<ItemCost> getItemCosts() {
		
		if(itemCosts == null){
			itemCosts = JsonUtils.getObjectListByJsonString(this.itemCostContent, ItemCost.class);
		}
		
		return itemCosts;
	}
	public void setItemCosts(List<ItemCost> itemCosts) {
		this.itemCosts = itemCosts;
	}
	
	
}
