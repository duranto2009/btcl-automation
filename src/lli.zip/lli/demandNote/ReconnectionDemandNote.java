package lli.demandNote;

public class ReconnectionDemandNote {
	double reconnectionCharge;
	double bandwidthCharge;
	double otherCosts;
}
