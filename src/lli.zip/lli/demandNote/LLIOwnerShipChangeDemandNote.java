package lli.demandNote;

import annotation.AccountingLogic;
import annotation.ColumnName;
import annotation.ForeignKeyName;
import annotation.PrimaryKey;
import annotation.TableName;
import common.bill.BillDTO;

@AccountingLogic(OwnerShipChagenDemandNoteBusinessLogic.class)
@TableName("")
@ForeignKeyName("")
public class LLIOwnerShipChangeDemandNote extends BillDTO{
	@PrimaryKey
	long ownerShipChangeDemanNoteID;
	@ColumnName("")
	double ownerShipChangeCharge;
	@ColumnName("")
	double otherCosts;
	public long getOwnerShipChangeDemanNoteID() {
		return ownerShipChangeDemanNoteID;
	}
	public void setOwnerShipChangeDemanNoteID(long ownerShipChangeDemanNoteID) {
		this.ownerShipChangeDemanNoteID = ownerShipChangeDemanNoteID;
	}
	public double getOwnerShipChangeCharge() {
		return ownerShipChangeCharge;
	}
	public void setOwnerShipChangeCharge(double ownerShipChangeCharge) {
		this.ownerShipChangeCharge = ownerShipChangeCharge;
	}
	public double getOtherCosts() {
		return otherCosts;
	}
	public void setOtherCosts(double otherCosts) {
		this.otherCosts = otherCosts;
	}
	
}
