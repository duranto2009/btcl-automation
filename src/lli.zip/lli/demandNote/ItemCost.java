package lli.demandNote;

public class ItemCost {
	public String item;
	public double cost;
}
