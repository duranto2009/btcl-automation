package lli.demandNote;

import annotation.AccountingLogic;
import annotation.ColumnName;
import annotation.ForeignKeyName;
import annotation.PrimaryKey;
import annotation.TableName;
import common.bill.BillDTO;

@AccountingLogic(ClosingDemandNoteBusinessLogic.class)
@TableName("at_lli_closing_dn")
@ForeignKeyName("lli_closing_dn_parent_bill_id")
public class LLICloseConnectionDemandNote extends BillDTO{
	@PrimaryKey
	@ColumnName("lli_closing_dn_id")
	long closingDemandNoteID;
	@ColumnName("lli_closing_dn_otc")
	double closingOTC;
	@ColumnName("lli_closing_dn_other")
	double otherCost;
	public LLICloseConnectionDemandNote() {
		setClassName(getClass().getCanonicalName());
	}
	
	public long getClosingDemandNoteID() {
		return closingDemandNoteID;
	}
	public void setClosingDemandNoteID(long closingDemandNoteID) {
		this.closingDemandNoteID = closingDemandNoteID;
	}
	public double getClosingOTC() {
		return closingOTC;
	}
	public void setClosingOTC(double closingOTC) {
		this.closingOTC = closingOTC;
	}
	public double getOtherCost() {
		return otherCost;
	}
	public void setOtherCost(double otherCost) {
		this.otherCost = otherCost;
	}
	
}
