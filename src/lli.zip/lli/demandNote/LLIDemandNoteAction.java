package lli.demandNote;

import java.lang.reflect.Method;
import java.util.List;

import org.apache.log4j.Logger;

import annotation.ForwardedAction;
import annotation.JsonPost;
import common.RequestFailureException;
import common.bill.BillDTO;
import common.bill.BillService;
import lli.LLIActionButton;
import lli.Application.LLIApplication;
import lli.Application.LLIApplicationService;
import lli.connection.LLIConnectionConstants;
import login.LoginDTO;
import requestMapping.AnnotatedRequestMappingAction;
import requestMapping.RequestParameter;
import requestMapping.Service;
import requestMapping.annotation.ActionRequestMapping;
import requestMapping.annotation.RequestMapping;
import requestMapping.annotation.RequestMethod;


@ActionRequestMapping("lli/dn/")
public class LLIDemandNoteAction extends AnnotatedRequestMappingAction {
	public static final Logger logger = Logger.getLogger(LLIDemandNoteAction.class);
	@Service
	LLIDemandNoteService lliDemandNoteService;
	@Service
	LLIApplicationService lliApplicationService;
	@Service
	BillService billService;
	
	@RequestMapping(mapping="new", requestMethod=RequestMethod.GET) 
	@ForwardedAction
	public String getGenerateDNPage(@RequestParameter("id") long appId) throws Exception {
		int applicationType = lliApplicationService.getApplicationTypeByApplicationID(appId);
		return getAppropriateViewName(applicationType);
	}
	
	@JsonPost
	@RequestMapping(mapping="new-connection/generate", requestMethod=RequestMethod.POST) 
	public void generateDNNewConnection(
			@RequestParameter(isJsonBody=true, value="dn") LLINewConnectionDemandNote newConnectionDN, 
			@RequestParameter(isJsonBody=true, value="appId") long appId) throws Exception {
		lliDemandNoteService.insertNewConnectionDN(newConnectionDN, appId);
	}
	
	@JsonPost
	@RequestMapping(mapping="close/generate", requestMethod=RequestMethod.POST) 
	public void generateDNClosing(
			@RequestParameter(isJsonBody=true, value="dn") LLICloseConnectionDemandNote closeConnectionDN,
			@RequestParameter(isJsonBody=true, value="appId") long appId) throws Exception {
		lliDemandNoteService.insertCloseConnectionDN(closeConnectionDN, appId);
	}
	
	@JsonPost
	@RequestMapping(mapping="common/generate", requestMethod=RequestMethod.POST) 
	public void generateDNCommon(
			@RequestParameter(isJsonBody=true, value="dn") LLISingleConnectionCommonDemandNote commonConnectionDN,
			@RequestParameter(isJsonBody=true, value="appId") long appId) throws Exception {
		lliDemandNoteService.insertCommonConnectionDN(commonConnectionDN, appId);
	}
	@JsonPost
	@RequestMapping(mapping="short-bill/generate", requestMethod=RequestMethod.POST) 
	public void generateSBLongTerm(
			@RequestParameter(isJsonBody=true, value="dn") LLIBreakLongTermDemandNote breakLongTermDN,
			@RequestParameter(isJsonBody=true, value="appId") long appId) throws Exception {
		lliDemandNoteService.insertLongTermSB(breakLongTermDN, appId);
	}
	@JsonPost
	@RequestMapping(mapping="skip", requestMethod=RequestMethod.POST) 
	public void skipDN(@RequestParameter(isJsonBody=true, value="billID") long billID) throws Exception {
		billService.skipBillByBillID(billID);
	}
	
	@JsonPost
	@RequestMapping(mapping="unSkip", requestMethod=RequestMethod.POST) 
	public void unSkipDN(@RequestParameter(isJsonBody=true, value="billID") long billID) throws Exception {
		billService.unskipBillByBillID(billID);
	}
	
	@JsonPost
	@RequestMapping(mapping="cancel", requestMethod=RequestMethod.POST) 
	public void cancelDN(@RequestParameter(isJsonBody=true, value="billID") long billID) throws Exception {
		billService.cancelBillByBillID(billID);
	}
	
	@RequestMapping(mapping="new-connection/autofill", requestMethod=RequestMethod.GET) 
	public LLINewConnectionDemandNote getNewConnectionDNAutoFillData(@RequestParameter("appId") long applicationID) throws Exception {
		return lliDemandNoteService.getAutoFillDataNewConnection(applicationID);
	}
	
	@RequestMapping(mapping="close/autofill", requestMethod=RequestMethod.GET) 
	public LLICloseConnectionDemandNote getCloseConnectionDNAutoFillData(@RequestParameter("appId") long applicationID) throws Exception {
		return lliDemandNoteService.getAutoFillDataCloseConnection(applicationID);
	}
	
	@RequestMapping(mapping="common/autofill", requestMethod=RequestMethod.GET) 
	public LLISingleConnectionCommonDemandNote getCommonConnectionDNAutoFillData(@RequestParameter("appId") long applicationID) throws Exception {
		return lliDemandNoteService.getAutoFillDataCommonConnection(applicationID);
	}
	@RequestMapping(mapping="break-long-term/autofill", requestMethod=RequestMethod.GET) 
	public LLIBreakLongTermDemandNote getBreakLongTermDNAutoFillData(@RequestParameter("appId") long applicationID) throws Exception {
		return lliDemandNoteService.getAutoFillDataBreakLongTerm(applicationID);
	}
	
//	@RequestMapping(mapping="btn/status/check", requestMethod=RequestMethod.GET) 
//	public BillButtonStatus getBillButtonStatus(@RequestParameter("billID") long billID) throws Exception {
//		BillButtonStatus billButtonStatus = billService.getBillButtonStatus(billID);
//		return billButtonStatus;
//	}
	
	@RequestMapping(mapping="getBill", requestMethod=RequestMethod.GET) 
	public BillDTO getBill(@RequestParameter("id") long billID) throws Exception {
		BillDTO billDTO = billService.getBillByBillID(billID);
		if(billDTO == null) {
			throw new RequestFailureException("No Bill Found with ID " + billID);
		}
		try {
			Method method = billDTO.getClass().getDeclaredMethod("getItemCosts");
			if(method != null) {
				method.invoke(billDTO);
			}
		}catch(Exception e) {
			logger.debug(e.getMessage(), e);
		}
		return billDTO;
	}
	
	
	@ForwardedAction
	@RequestMapping(mapping="view", requestMethod=RequestMethod.GET)
	public String getDNView(@RequestParameter("id") long billID) throws Exception {
		LLIApplication lliApplication =  lliApplicationService.getLLIApplicationByDemandNoteID(billID);
		if(lliApplication == null) {
			return "404";
		}
		int applicationType = lliApplication.getApplicationType();
		if(
				applicationType == LLIConnectionConstants.SHIFT_BANDWIDTH ||
				applicationType == LLIConnectionConstants.RECONNECT ||
				applicationType == LLIConnectionConstants.CHANGE_BILLING_ADDRESS
			) {
			return "404";
		} 
		return getAppropriateViewName(applicationType) + "-view";
	}
	
	@RequestMapping(mapping="get-actions", requestMethod=RequestMethod.GET)
	public List<LLIActionButton> getActions(@RequestParameter("id") long billID, LoginDTO loginDTO) throws Exception{
		return billService.getAvailableActions(billID, loginDTO);
	}
	@ForwardedAction
	@RequestMapping(mapping="pdf/get", requestMethod=RequestMethod.GET)
	public String getPdf(@RequestParameter("id") long billID) throws Exception{
		//
		return "pdf";
	}
	
	/***
	 * Private Methods
	 */
	private String getAppropriateViewName(int applicationType) {
		
		return "lli-dn-" + LLIConnectionConstants.applicationTypeHyphenSeperatedMap.get(applicationType);
	}

}
