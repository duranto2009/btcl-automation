package lli.demandNote;

import java.util.*;

import accounting.LLINewConnectionDemandNoteBusinessLogic;
import annotation.AccountingLogic;
import annotation.ColumnName;
import annotation.ForeignKeyName;
import annotation.PrimaryKey;
import annotation.TableName;
import common.bill.BillDTO;
import lli.demandNote.ItemCost;
import util.JsonUtils;

@AccountingLogic(LLINewConnectionDemandNoteBusinessLogic.class)
@TableName("at_lli_new_connection_dn")
@ForeignKeyName("lli_nc_dn_parent_bill_id")
public class LLINewConnectionDemandNote extends BillDTO{
	
	public LLINewConnectionDemandNote() {
		setClassName(getClass().getCanonicalName());
	}
	
	@ColumnName("lli_nc_dn_id")
	@PrimaryKey
	long newConnectionDemandNoteID;
	
	@ColumnName("lli_nc_dn_sc_money")
	double securityMoney;
	
	@ColumnName("lli_nc_dn_reg_fee")
	double registrationFee;
	
	@ColumnName("lli_nc_dn_bw_mrc")
	double bwMRC;
	List<ItemCost> itemCosts;
	
	@ColumnName("lli_nc_dn_item_cost_content")
	String itemCostContent;
	
	@ColumnName("lli_nc_dn_fibre_otc")
	double fibreOTC;
	
	@ColumnName("lli_nc_dn_local_loop_charge")
	double localLoopCharge;
	
	@ColumnName("lli_nc_dn_advance_adjustment")
	double advanceAdjustment;

	public long getNewConnectionDemandNoteID() {
		return newConnectionDemandNoteID;
	}
	public void setNewConnectionDemandNoteID(long newConnectionDemandNoteID) {
		this.newConnectionDemandNoteID = newConnectionDemandNoteID;
	}
	public double getSecurityMoney() {
		return securityMoney;///1.15;
	}
	public void setSecurityMoney(double securityMoney) {
		this.securityMoney = securityMoney;
	}
	public double getRegistrationFee() {
		return registrationFee;
	}
	public void setRegistrationFee(double registrationFee) {
		this.registrationFee = registrationFee;
	}
	public double getBwMRC() {
		return bwMRC;///1.15;
	}
	public void setBwMRC(double bwMRC) {
		this.bwMRC = bwMRC;
	}
	public String getItemCostContent() {
		return itemCostContent;
	}
	public void setItemCostContent(String itemCostContent) {
		this.itemCostContent = itemCostContent;
	}
	public double getFibreOTC() {
		return fibreOTC;
	}
	public void setFibreOTC(double fibreOTC) {
		this.fibreOTC = fibreOTC;
	}
	public double getLocalLoopCharge() {
		return localLoopCharge;
	}
	public void setLocalLoopCharge(double localLoopCharge) {
		this.localLoopCharge = localLoopCharge;
	}
	public double getAdvanceAdjustment() {
		return advanceAdjustment;///1.15;
	}
	public void setAdvanceAdjustment(double advanceAdjustment) {
		this.advanceAdjustment = advanceAdjustment;
	}

	
	public double getTotalItemCost(){
		double totalItemCost = 0;
		for(ItemCost itemCost: getItemCosts()){
			totalItemCost+=itemCost.cost;
		}
		return totalItemCost;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(advanceAdjustment);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(bwMRC);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		
		temp = Double.doubleToLongBits(fibreOTC);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((itemCostContent == null) ? 0 : itemCostContent.hashCode());
		temp = Double.doubleToLongBits(localLoopCharge);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + (int) (newConnectionDemandNoteID ^ (newConnectionDemandNoteID >>> 32));
		temp = Double.doubleToLongBits(registrationFee);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(securityMoney);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LLINewConnectionDemandNote other = (LLINewConnectionDemandNote) obj;
		if (Double.doubleToLongBits(advanceAdjustment) != Double.doubleToLongBits(other.advanceAdjustment))
			return false;
		if (Double.doubleToLongBits(bwMRC) != Double.doubleToLongBits(other.bwMRC))
			return false;
		if (Double.doubleToLongBits(fibreOTC) != Double.doubleToLongBits(other.fibreOTC))
			return false;
		if (itemCostContent == null) {
			if (other.itemCostContent != null)
				return false;
		} else if (!itemCostContent.equals(other.itemCostContent))
			return false;
		if (Double.doubleToLongBits(localLoopCharge) != Double.doubleToLongBits(other.localLoopCharge))
			return false;
		if (newConnectionDemandNoteID != other.newConnectionDemandNoteID)
			return false;
		if (Double.doubleToLongBits(registrationFee) != Double.doubleToLongBits(other.registrationFee))
			return false;
		if (Double.doubleToLongBits(securityMoney) != Double.doubleToLongBits(other.securityMoney))
			return false;
		return true;
	}
	public List<ItemCost> getItemCosts() {
		
		if(itemCosts==null){
			itemCosts = JsonUtils.getObjectListByJsonString(this.itemCostContent, ItemCost.class);
		}
		
		return itemCosts;
	}
	public void setItemCosts(List<ItemCost> itemCosts) {
		this.itemCosts = itemCosts;
	}

	@Override
	public double getVAT(){
		return super.getVAT();//+(this.bwMRC+this.advanceAdjustment+this.securityMoney)*.15/1.15;
	}
	
	
	
	
	/***
	 * super.VAT = ( registrationFee + bwMRC) * super.VATPercentage
	 * super.grandTotal = security + registrationFee + bwMRC
	 * super.totalPayable = super.grandTotal + super.VAT
	 * super.netPayable = super.totalPayable +/- super.discount
	 * super.entityID = LLI connection ID
	 * super.entityTypeID = NewConnectionDN
	 * super.requestID = null
	 * super.ClassName = this ? Done
	 * super.discount = ? from UI
	 * super.paymentID = ? 
	 * super.paymentStatus = ?
	 * super.activationFrom = ? current Time
	 * super.activationTo = ? expiration time ui theke
	 * super.billFilePath = ? bill generate hoye jekhane thakbe
	 * super.billReqType = null
	 * super.lateFee = ? null
	 * super.paymentGatewayType = ? payment hobar pore
	 * super.adjustmentAmount = 0 ui theke ashbe
	 * super.billGenerationTime = ? purapuri current time jokhon insert hobe.
	 * super.billLastModificationTime = ? no tension
	 * super.isDeleted = 0
	 * super.billType = pre-paid (0)
	 * super.lastPaymentDate = ? dn valid last date
	 * super.month = ? null
	 * super.year = ? null
	 * super.clientID = ?
	 * super.description = ?
	 * super.ID = auto generated
	 */
	
	
}
