package lli.demandNote;

import static util.ModifiedSqlGenerator.insert;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;

import annotation.Transactional;
import common.RequestFailureException;
import common.bill.BillService;
import lli.LLIConnectionInstance;
import lli.LLIConnectionService;
import lli.Application.LLIApplication;
import lli.Application.LLIApplicationService;
import lli.configuration.LLICostConfigurationService;
import lli.configuration.LLIOTCConfigurationDTO;
import lli.connection.LLIConnectionConstants;
import requestMapping.Service;
import util.TransactionType;
public class LLIDemandNoteService {
	@Service
	LLIApplicationService lliApplicationService;
	@Service 
	BillService billService;
	@Service
	LLICostConfigurationService lliCostConfigurationService;
	
	@Service
	LLIConnectionService lliConnectionService;
	

	@Transactional
	public void insertNewConnectionDN(LLINewConnectionDemandNote newConnectionDN, long appId) throws Exception {
		
		
		LLIApplication lliApplication = lliApplicationService.getLLIApplicationByApplicationID(appId);
		if(lliApplication == null){
			throw new RequestFailureException("No application found with applicaton ID "+appId);
		}
		
		if(lliApplication.getApplicationType() != LLIConnectionConstants.NEW_CONNECTION){
			throw new RequestFailureException("The application for this demand note is not a new connection application");
		}
		
		
		newConnectionDN.setClientID(lliApplication.getClientID());
		
		
		double vatCalculable = newConnectionDN.getRegistrationFee() 
				+ newConnectionDN.getBwMRC() 
				+ newConnectionDN.getTotalItemCost()
				+ newConnectionDN.getFibreOTC() 
				+ newConnectionDN.getLocalLoopCharge();
		double vat = vatCalculable * newConnectionDN.getVatPercentage()/100.0;
		double grandTotal = vatCalculable + newConnectionDN.getSecurityMoney() + newConnectionDN.getAdvanceAdjustment();
		double discount = grandTotal * newConnectionDN.getDiscountPercentage()/100.0;
		
		
		double totalPayable = grandTotal - discount;
		double netPayable = totalPayable + vat;
		
		
		newConnectionDN.setVAT(vat);
		newConnectionDN.setDiscount(discount);
		
		newConnectionDN.setGrandTotal(grandTotal);
		newConnectionDN.setTotalPayable(totalPayable);
		newConnectionDN.setNetPayable(netPayable);
		newConnectionDN.setEntityTypeID(LLIConnectionConstants.ENTITY_TYPE);
		List<ItemCost> itemCosts = newConnectionDN.getItemCosts();
		if(itemCosts == null) {
			itemCosts = new ArrayList<>();
		}
		String itemCostContent = new Gson().toJson(newConnectionDN.getItemCosts());
		newConnectionDN.setItemCostContent(itemCostContent);
		
		billService.insertBill(newConnectionDN);
		long demandNoteID = newConnectionDN.getID();
		
		
		lliApplicationService.setDemandNoteIDInLLIApplicationByDemandNoteIDAndApplicationID(demandNoteID, appId);
		
	}
	public void insertLongTermSB(LLIBreakLongTermDemandNote lliBreakLongTermDemandNote, long appId) throws Exception {
		LLIApplication lliApplication = lliApplicationService.getLLIApplicationByApplicationID(appId);
		if(lliApplication == null){
			throw new RequestFailureException("No application found with applicaton ID "+appId);
		}
		
		if(lliApplication.getApplicationType() != LLIConnectionConstants.BREAK_LONG_TERM){
			throw new RequestFailureException("The application for this short bill is not break long term application");
		}
		
		
		lliBreakLongTermDemandNote.setClientID(lliApplication.getClientID());
		
		
		double vatCalculable = lliBreakLongTermDemandNote.getContractBreakingFine() + lliBreakLongTermDemandNote.getOtherCost();
		double vat = vatCalculable * lliBreakLongTermDemandNote.getVatPercentage()/100.0;
		double grandTotal = vatCalculable;
		double discount = grandTotal * lliBreakLongTermDemandNote.getDiscountPercentage()/100.0;
		
		
		double totalPayable = grandTotal - discount;
		double netPayable = totalPayable + vat;
		
		
		lliBreakLongTermDemandNote.setVAT(vat);
		lliBreakLongTermDemandNote.setDiscount(discount);
		
		lliBreakLongTermDemandNote.setGrandTotal(grandTotal);
		lliBreakLongTermDemandNote.setTotalPayable(totalPayable);
		lliBreakLongTermDemandNote.setNetPayable(netPayable);
		lliBreakLongTermDemandNote.setEntityTypeID(LLIConnectionConstants.ENTITY_TYPE);
		
		billService.insertBill(lliBreakLongTermDemandNote);
		long demandNoteID = lliBreakLongTermDemandNote.getID();
		
		
		lliApplicationService.setDemandNoteIDInLLIApplicationByDemandNoteIDAndApplicationID(demandNoteID, appId);
	}
	
	@Transactional
	public void insertCloseConnectionDN(LLICloseConnectionDemandNote closeConnectionDN, long appId) throws Exception {
		

		LLIApplication lliApplication = lliApplicationService.getLLIApplicationByApplicationID(appId);
		if(lliApplication == null){
			throw new RequestFailureException("No application found with applicaton ID "+appId);
		}
		
		if(lliApplication.getApplicationType() != LLIConnectionConstants.CLOSE_CONNECTION){
			throw new RequestFailureException("The application for this demand note is not a close connection application");
		}
		
		
		closeConnectionDN.setClientID(lliApplication.getClientID());
		
		
		double vatCalculable = closeConnectionDN.getClosingOTC()+ closeConnectionDN.getOtherCost();
		double vat = vatCalculable * closeConnectionDN.getVatPercentage() /100.0;
		double grandTotal = vatCalculable;
		double discount = grandTotal * closeConnectionDN.getDiscountPercentage() / 100.0;
		double totalPayable = grandTotal - discount;
		double netPayable = totalPayable + vat;
		closeConnectionDN.setVAT(vat);
		closeConnectionDN.setGrandTotal(grandTotal);
		closeConnectionDN.setTotalPayable(totalPayable);
		closeConnectionDN.setNetPayable(netPayable);
		closeConnectionDN.setEntityTypeID(LLIConnectionConstants.ENTITY_TYPE);
		
		insert(closeConnectionDN);
		long demandNoteID = closeConnectionDN.getID();
		lliApplicationService.setDemandNoteIDInLLIApplicationByDemandNoteIDAndApplicationID(demandNoteID, appId);
	}
	
	@Transactional
	public void insertCommonConnectionDN(LLISingleConnectionCommonDemandNote commonConnectionDN, long appId) throws Exception {
		LLIApplication lliApplication = lliApplicationService.getLLIApplicationByApplicationID(appId);
		if(lliApplication == null){
			throw new RequestFailureException("No application found with applicaton ID "+appId);
		}
		int lliApplicationType = lliApplication.getApplicationType();
		if( ! (lliApplicationType == LLIConnectionConstants.UPGRADE_BANDWIDTH
				|| lliApplicationType == LLIConnectionConstants.DOWNGRADE_BANDWIDTH
				|| lliApplicationType == LLIConnectionConstants.TEMPORARY_UPGRADE_BANDWIDTH
				|| lliApplicationType == LLIConnectionConstants.ADDITIONAL_PORT
				|| lliApplicationType == LLIConnectionConstants.ADDITIONAL_LOCAL_LOOP
				|| lliApplicationType == LLIConnectionConstants.ADDITIONAL_CONNECTION_ADDRESS
				|| lliApplicationType == LLIConnectionConstants.SHIFT_CONNECTION_ADDRESS
				|| lliApplicationType == LLIConnectionConstants.SHIFT_POP
				|| lliApplicationType == LLIConnectionConstants.ADDITIONAL_IP
				)){
			throw new RequestFailureException("The application for this demand note is not a Revise Connection Application");
		}
		
		
		commonConnectionDN.setClientID(lliApplication.getClientID());
		List<ItemCost> itemCosts = commonConnectionDN.getItemCosts();
		if(itemCosts == null) {
			itemCosts = new ArrayList<>();
		}
		String itemCostContent = new Gson().toJson(commonConnectionDN.getItemCosts());
		commonConnectionDN.setItemCostContent(itemCostContent);
		
		double vatCalculable = commonConnectionDN.getBandwidthCharge() 
				+ commonConnectionDN.getDowngradeCharge() 
				+ commonConnectionDN.getPortCharge()
				+ commonConnectionDN.getFibreOTC() 
				+ commonConnectionDN.getCoreCharge()
				+ commonConnectionDN.getTotalItemCost()
				+ commonConnectionDN.getFirstXIpCost()
				+ commonConnectionDN.getNextYIpCost()
				+ commonConnectionDN.getShiftCharge();
		
		double vat = vatCalculable * commonConnectionDN.getVatPercentage()/100.0;
		double grandTotal = vatCalculable + commonConnectionDN.getSecurityMoney() + commonConnectionDN.getAdvancedAmount();
		double discount = grandTotal * commonConnectionDN.getDiscountPercentage()/100.0;
		double totalPayable = grandTotal - discount;
		double netPayable = totalPayable + vat;
		
		commonConnectionDN.setVAT(vat);
		commonConnectionDN.setGrandTotal(grandTotal);
		commonConnectionDN.setTotalPayable(totalPayable);
		commonConnectionDN.setNetPayable(netPayable);
		commonConnectionDN.setEntityTypeID(LLIConnectionConstants.ENTITY_TYPE);
		commonConnectionDN.setDiscount(discount);
		insert(commonConnectionDN);
		long demandNoteID = commonConnectionDN.getID();
		lliApplicationService.setDemandNoteIDInLLIApplicationByDemandNoteIDAndApplicationID(demandNoteID, appId);
	}
	
	@Transactional(transactionType=TransactionType.READONLY)
	public LLINewConnectionDemandNote getAutoFillDataNewConnection(long applicationID) throws Exception{
		
		LLIApplication lliApplication = lliApplicationService.getLLIApplicationByApplicationID(applicationID);
		if(lliApplication == null) {
			throw new RequestFailureException("No such application found with application ID " + applicationID);
		}
		
		LLIConnectionInstance lliApplicationConnection = LLIApplicationService.getLLIConnectionFromApplicationContent(lliApplication);
		if(lliApplicationConnection == null) {
			throw new RequestFailureException ("No Connection Instance Found with application ID" + applicationID);
		}
		LLIOTCConfigurationDTO lliotcConfigurationDTO = lliCostConfigurationService.getCurrentActiveLLI_OTC_ConfigurationDTO();
		
		int numberOfBTCLProvidedFiberCount = lliConnectionService.getBTCLProvidedLocalLoopCount(lliApplicationConnection);
		
		//dummyData
		LLINewConnectionDemandNote lliNewConnectionDemandNote = new LLINewConnectionDemandNote();
		lliNewConnectionDemandNote.setClientID(lliApplication.getClientID());
		lliNewConnectionDemandNote.setAdvanceAdjustment(0);
		lliNewConnectionDemandNote.setBwMRC(10000);
		lliNewConnectionDemandNote.setDescription("Demand Note of application ID " + applicationID);
		lliNewConnectionDemandNote.setFibreOTC(numberOfBTCLProvidedFiberCount* lliotcConfigurationDTO.getFiberOTC());
		lliNewConnectionDemandNote.setItemCostContent("item : 100");
		lliNewConnectionDemandNote.setLocalLoopCharge(1000);
		lliNewConnectionDemandNote.setRegistrationFee(lliotcConfigurationDTO.getRegistrationCharge());
		lliNewConnectionDemandNote.setSecurityMoney(10000);
		lliNewConnectionDemandNote.setVatPercentage(lliotcConfigurationDTO.getMaximumVatPercentage());
		lliNewConnectionDemandNote.setDiscountPercentage(lliotcConfigurationDTO.getMaximumDiscountPercentage());
		
		
		return lliNewConnectionDemandNote;
	}
	
	@Transactional(transactionType=TransactionType.READONLY)
	public LLICloseConnectionDemandNote getAutoFillDataCloseConnection(long applicationID) throws Exception{
		

		LLIApplication lliApplication = lliApplicationService.getLLIApplicationByApplicationID(applicationID);
		if(lliApplication == null){
			throw new RequestFailureException("No application found with applicaton ID "+applicationID);
		}
		
		if(lliApplication.getApplicationType() != LLIConnectionConstants.CLOSE_CONNECTION){
			throw new RequestFailureException("The application for this demand note is no a new connection application");
		}
		
		
		
		LLIOTCConfigurationDTO lliotcConfigurationDTO = lliCostConfigurationService.getCurrentActiveLLI_OTC_ConfigurationDTO();
		//dummyData
		LLICloseConnectionDemandNote lliCloseConnectionDemandNote = new LLICloseConnectionDemandNote();
		
		
		lliCloseConnectionDemandNote.setClientID(lliApplication.getClientID());
		lliCloseConnectionDemandNote.setClosingOTC(lliotcConfigurationDTO.getInstantClosingOTC());
		lliCloseConnectionDemandNote.setOtherCost(0);
		lliCloseConnectionDemandNote.setDescription("Demand Note of application ID " + applicationID);
		lliCloseConnectionDemandNote.setVatPercentage(lliotcConfigurationDTO.getMaximumVatPercentage());
		lliCloseConnectionDemandNote.setDiscountPercentage(lliotcConfigurationDTO.getMaximumDiscountPercentage());
		return lliCloseConnectionDemandNote;
	}
	
	@Transactional(transactionType=TransactionType.READONLY)
	public LLISingleConnectionCommonDemandNote getAutoFillDataCommonConnection(long applicationID) throws Exception{
		
		
		LLIApplication lliApplication = lliApplicationService.getLLIApplicationByApplicationID(applicationID);
		if(lliApplication == null){
			throw new RequestFailureException("No application found with applicaton ID "+applicationID);
		}
		int lliApplicationType = lliApplication.getApplicationType();
		if( ! (lliApplicationType == LLIConnectionConstants.UPGRADE_BANDWIDTH
				|| lliApplicationType == LLIConnectionConstants.DOWNGRADE_BANDWIDTH
				|| lliApplicationType == LLIConnectionConstants.TEMPORARY_UPGRADE_BANDWIDTH
				|| lliApplicationType == LLIConnectionConstants.ADDITIONAL_PORT
				|| lliApplicationType == LLIConnectionConstants.ADDITIONAL_LOCAL_LOOP
				|| lliApplicationType == LLIConnectionConstants.ADDITIONAL_CONNECTION_ADDRESS
				|| lliApplicationType == LLIConnectionConstants.SHIFT_CONNECTION_ADDRESS
				|| lliApplicationType == LLIConnectionConstants.SHIFT_POP
				|| lliApplicationType == LLIConnectionConstants.ADDITIONAL_IP
				)){
			throw new RequestFailureException("The application for this demand note is not a single demand note application");
		}
		LLIConnectionInstance lliApplicationConnection = LLIApplicationService.getLLIConnectionFromApplicationContent(lliApplication);
		if(lliApplicationConnection == null) {
			throw new RequestFailureException ("No Connection Instance Found with application ID" + applicationID);
		}
		LLIOTCConfigurationDTO lliotcConfigurationDTO = lliCostConfigurationService.getCurrentActiveLLI_OTC_ConfigurationDTO();
		int numberOfBTCLProvidedFiberCount = lliConnectionService.getBTCLProvidedLocalLoopCount(lliApplicationConnection);
		LLISingleConnectionCommonDemandNote lliCommonConnectionDemandNote = new LLISingleConnectionCommonDemandNote();
			
		lliCommonConnectionDemandNote.setClientID(lliApplication.getClientID());
		lliCommonConnectionDemandNote.setSecurityMoney(10000);
		lliCommonConnectionDemandNote.setBandwidthCharge(100);
		lliCommonConnectionDemandNote.setAdvancedAmount(0);
		lliCommonConnectionDemandNote.setDowngradeCharge(
				lliApplicationType == LLIConnectionConstants.DOWNGRADE_BANDWIDTH ? 
						lliotcConfigurationDTO.getDowngradeCharge() : 0
				);
		lliCommonConnectionDemandNote.setPortCharge(lliotcConfigurationDTO.getPortCharge());
		lliCommonConnectionDemandNote.setFibreOTC(numberOfBTCLProvidedFiberCount * lliotcConfigurationDTO.getFiberOTC());
		lliCommonConnectionDemandNote.setCoreCharge(100);
		lliCommonConnectionDemandNote.setFirstXIpCost(0);
		lliCommonConnectionDemandNote.setNextYIpCost(0);
		lliCommonConnectionDemandNote.setShiftCharge(lliotcConfigurationDTO.getShiftingCharge());
		
		lliCommonConnectionDemandNote.setDescription("Demand Note of application ID " + applicationID);
		lliCommonConnectionDemandNote.setVatPercentage(lliotcConfigurationDTO.getMaximumVatPercentage());
		lliCommonConnectionDemandNote.setDiscountPercentage(lliotcConfigurationDTO.getMaximumDiscountPercentage());
		return lliCommonConnectionDemandNote;
	}
	@Transactional(transactionType=TransactionType.READONLY)
	public LLIBreakLongTermDemandNote getAutoFillDataBreakLongTerm(long applicationID) throws Exception{
		LLIApplication lliApplication = lliApplicationService.getLLIApplicationByApplicationID(applicationID);
		if(lliApplication == null){
			throw new RequestFailureException("No application found with applicaton ID "+applicationID);
		}
		LLIOTCConfigurationDTO lliotcConfigurationDTO = lliCostConfigurationService.getCurrentActiveLLI_OTC_ConfigurationDTO();
		
		LLIBreakLongTermDemandNote lliBreakLongTermDemandNote = new LLIBreakLongTermDemandNote();
		lliBreakLongTermDemandNote.setVatPercentage(lliotcConfigurationDTO.getMaximumVatPercentage());
		lliBreakLongTermDemandNote.setDiscountPercentage(lliotcConfigurationDTO.getMaximumDiscountPercentage());
		lliBreakLongTermDemandNote.setOtherCost(0);
		lliBreakLongTermDemandNote.setContractBreakingFine(0);
		return lliBreakLongTermDemandNote;
	}

	
	
}
