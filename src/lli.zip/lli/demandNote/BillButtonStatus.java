package lli.demandNote;

public class BillButtonStatus {
	public boolean skippable;
	public boolean unSkippable;
	public boolean cancellable;
}
