package lli.demandNote;


import annotation.AccountingLogic;
import annotation.ColumnName;
import annotation.ForeignKeyName;
import annotation.PrimaryKey;
import annotation.TableName;
import common.bill.BillDTO;

@AccountingLogic(LLIBreakLongTermDemandNoteBusinessLogic.class)
@TableName("at_lli_break_lt_dn")
@ForeignKeyName("lli_break_lt_dn_parent_bill_id")
public class LLIBreakLongTermDemandNote extends BillDTO{
	
	public LLIBreakLongTermDemandNote () {
		setClassName(this.getClass().getCanonicalName());
	}
	@PrimaryKey
	@ColumnName("lli_break_lt_dn_id")
	long shortBillID;
	
	@ColumnName("lli_break_lt_dn_fine")
	double contractBreakingFine;

	@ColumnName("lli_break_lt_dn_other")
	double otherCost;
	
	public long getShortBillID() {
		return shortBillID;
	}

	public void setShortBillID(long shortBillID) {
		this.shortBillID = shortBillID;
	}

	public double getContractBreakingFine() {
		return contractBreakingFine;
	}

	public void setContractBreakingFine(double contractBreakingFine) {
		this.contractBreakingFine = contractBreakingFine;
	}

	public double getOtherCost() {
		return otherCost;
	}

	public void setOtherCost(double otherCost) {
		this.otherCost = otherCost;
	}
	
	
	
}
