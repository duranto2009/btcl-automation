package lli.Options;

import java.util.ArrayList;
import java.util.List;

import inventory.InventoryItem;
import inventory.InventoryService;
import lli.LLIDropdownPair;
import lli.LLILongTermContract;
import lli.LLILongTermService;
import requestMapping.Service;
import util.TimeConverter;

public class LLIOptionsService {
	
	@Service
	LLILongTermService lliLongTermService;
	
	@Service
	InventoryService inventoryService;
	
	public List<LLIDropdownPair> getLongTermContractListDropDownPairListByClientID(long clientID) throws Exception{
		List<LLIDropdownPair> list = new ArrayList<>();
		List<LLILongTermContract> longTermContractList = lliLongTermService.getActiveLLILongTermContractListByClientID(clientID);
		
		for(LLILongTermContract lliLongTermContract : longTermContractList) {
			
			String startDate = TimeConverter.getDateTimeStringByMillisecAndDateFormat(lliLongTermContract.getContractStartDate(), "dd/MM/yyyy");
			String endDate = TimeConverter.getDateTimeStringByMillisecAndDateFormat(lliLongTermContract.getContractEndDate(), "dd/MM/yyyy");
			
			list.add(new LLIDropdownPair(
					lliLongTermContract.getID(), 
					lliLongTermContract.getBandwidth() + " Mbps (" + startDate + " - " + endDate +")" 
					));
		}
		
		return list;
	}
	
	
	public List<LLIDropdownPair> getInventoryItemListByNameAndCategoryIDAndParentID(String query, int categoryID, Long parentID) throws Exception{
		List<LLIDropdownPair> list = new ArrayList<>();
		List<InventoryItem> inventoryItemList = inventoryService.getInventoryItemListByItemNameCategoryIDParentID(query, categoryID, parentID);
		
		for(InventoryItem inventoryItem : inventoryItemList) {
			list.add(new LLIDropdownPair(inventoryItem.getID(), inventoryItem.getName()));
		}
		
		return list;
	}
	
	
}
