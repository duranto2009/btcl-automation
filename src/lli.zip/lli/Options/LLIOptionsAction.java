package lli.Options;

import java.util.ArrayList;
import java.util.List;

import client.RegistrantTypeConstants;
import common.ModuleConstants;
import common.repository.AllClientRepository;
import lli.LLIDropdownPair;
import login.LoginDTO;
import requestMapping.AnnotatedRequestMappingAction;
import requestMapping.annotation.ActionRequestMapping;
import requestMapping.annotation.RequestMapping;
import requestMapping.annotation.RequestMethod;
import vpn.client.ClientDetailsDTO;

@ActionRequestMapping("lli/options")
public class LLIOptionsAction extends AnnotatedRequestMappingAction{
	
	@RequestMapping(mapping="/connection-type", requestMethod=RequestMethod.All)
	public List<LLIDropdownPair> getConnectionTypeOptions(LoginDTO loginDTO) throws Exception{
		List<LLIDropdownPair> connectionTypeOptions = new ArrayList<LLIDropdownPair>();
		
		connectionTypeOptions.add(new LLIDropdownPair(1, "Regular"));
		connectionTypeOptions.add(new LLIDropdownPair(2, "Temporary"));
		connectionTypeOptions.add(new LLIDropdownPair(3, "Cache"));
		
		if(loginDTO.getIsAdmin()) {
			connectionTypeOptions.add(new LLIDropdownPair(4, "Regular + Long Term Contract"));
		} else {
			ClientDetailsDTO clientDetailsDTO = AllClientRepository.getInstance().getModuleClientByClientIDAndModuleID(loginDTO.getAccountID(), ModuleConstants.Module_ID_LLI);
			if(clientDetailsDTO.getRegistrantType() == RegistrantTypeConstants.GOVT) {
				connectionTypeOptions.add(new LLIDropdownPair(4, "Regular + Long Term Contract"));
			}
		}
		
		return connectionTypeOptions;
	}
}
