package lli.pdf;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.stream.Stream;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import common.bill.BillConstants;
import requestMapping.AnnotatedRequestMappingAction;
import requestMapping.RequestParameter;
import requestMapping.Service;
import requestMapping.annotation.ActionRequestMapping;
import requestMapping.annotation.RequestMapping;
import requestMapping.annotation.RequestMethod;
@ActionRequestMapping("lli/pdf/")
public class LLIPdfAction extends AnnotatedRequestMappingAction {
	@Service
	LLIPdfService lliPdfService;
	
	@RequestMapping(mapping="demand-note", requestMethod=RequestMethod.GET)
	public ActionForward getDemandNotePDF(@RequestParameter("id") long billId, 
			HttpServletResponse response) throws Exception {
		
		
		InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(BillConstants.LLI_DEMAND_NOTE_NEW_CONNECTION_TEMPLATE);
		OutputStream outputStream = response.getOutputStream();
		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "inline; filename=demand-note-"+billId+".pdf"); 
		response.setCharacterEncoding("UTF8");
		
		lliPdfService.createPdf(billId, inputStream, outputStream);
		
		IOUtils.closeQuietly(inputStream);
		IOUtils.closeQuietly(outputStream);
		return null;
	}
	
}
