package lli.pdf;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import annotation.Transactional;
import common.EntityDTO;
import common.EntityTypeConstant;
import common.ModuleConstants;
import common.RequestFailureException;
import common.bill.BillDTO;
import common.bill.BillService;
import common.repository.AllClientRepository;
import connection.DatabaseConnection;
import file.FileDTO;
import file.FileService;
import file.FileTypeConstants;
import lli.LLIConnectionInstance;
import lli.Application.LLIApplication;
import lli.Application.LLIApplicationService;
import lli.Application.NewConnection.LLINewConnectionApplication;
import lli.demandNote.LLIBreakLongTermDemandNote;
import lli.demandNote.LLICloseConnectionDemandNote;
import lli.demandNote.LLINewConnectionDemandNote;
import lli.demandNote.LLISingleConnectionCommonDemandNote;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;
import requestMapping.Service;
import util.TimeConverter;
import util.TransactionType;
import vpn.ClientContactDetailsDTO;
import vpn.client.ClientDetailsDTO;
import vpn.client.ClientService;

public class LLIPdfService {
	public static final Logger logger = Logger.getLogger(LLIPdfService.class);
	
	@Service
	BillService billService;
	
	@Service
	ClientService clientService;
	
	@Service
	LLIApplicationService lliApplicationService;
	
	@Transactional(transactionType=TransactionType.READONLY)
	public void createPdf(long billId, InputStream inputStream, OutputStream outputStream) throws Exception {
		BillDTO billDTO = billService.getBillByBillID(billId);
		if(billDTO == null) {
			throw new RequestFailureException("No Bill Found with ID " + billId);
		}
		writePdfToStream(billDTO, inputStream, outputStream);
//		writeDomainPdfFileAndLogInDatabase( domainDTO, billDTO, Long.toString( billDTO.getID() ) );
		
		
	}
	private void writePdfToStream(BillDTO billDTO, InputStream inputStream, OutputStream outputStream) throws Exception {
		logger.debug( "Pdf file writing starts" );
		JasperReport jasperReport = (JasperReport)JRLoader.loadObject( inputStream );
		Map<String, Object> params = getPdfParameters(billDTO);
		JRBeanCollectionDataSource jrBeanCollectionDataSource = new JRBeanCollectionDataSource( Arrays.asList( billDTO ), false );
		JasperPrint jasperPrint = JasperFillManager.fillReport( jasperReport, params, jrBeanCollectionDataSource );
		JasperExportManager.exportReportToPdfStream( jasperPrint, outputStream );
		logger.debug( "Pdf file writing ends" );
	}
	private Map<String, Object> getPdfParameters(BillDTO billDTO) throws Exception {
		logger.debug("Parameter collection");
		Map<String, Object> params = new HashMap<>();
		
		ClientDetailsDTO clientDetailsDTO = AllClientRepository.getInstance().
				getVpnClientByClientID( billDTO.getClientID(), ModuleConstants.Module_ID_LLI );
		if(clientDetailsDTO == null) {
			throw new RequestFailureException("No Client Details Found with client id "+ billDTO.getClientID());
		}
		List<ClientContactDetailsDTO> clientContactDetailsDTOs =  clientService.getVpnContactDetailsListByClientID( clientDetailsDTO.getId() );
		
		if(clientContactDetailsDTOs == null || clientContactDetailsDTOs.isEmpty()) {
			throw new RequestFailureException("No Client Contact Details Found with client id "+ billDTO.getClientID());
		}	
		ClientContactDetailsDTO contactDetailsDTO = clientContactDetailsDTOs.get(0);
		
		LLIApplication lliApplication = lliApplicationService.getLLIApplicationByDemandNoteID(billDTO.getID());
		if(lliApplication == null) {
			throw new RequestFailureException("No lli Application found with demand note id " + billDTO.getID());
		}
		LLIConnectionInstance lliConnectionInstance = LLIApplicationService.getLLIConnectionFromApplicationContent(lliApplication);
		
		getCommonInformation(params);
		getClientInformation(params, contactDetailsDTO, clientDetailsDTO);
		getBillSpecificInformation(params, billDTO);
		getConnectionSpecificInformation(params, lliConnectionInstance, lliApplication );
		return params;
		
	}
	
	private void getCommonInformation(Map<String, Object> params) {
		params.put("logo", "../../images/common/btcl_logo_heading.png");
		params.put("footerLeft", "Powered By <font color=blue>Reve Systems</font>");
		params.put("footerRight", "Bangladesh Telecommunications Company Limited");
		params.put("NB", "NB: ( Client will arrange and maintain local loops from BTCL switch to his offices on his own ).");
	}
	private void getClientInformation(Map<String, Object> params, ClientContactDetailsDTO contactDetailsDTO, ClientDetailsDTO clientDetailsDTO) {
		params.put( "clientFullName", contactDetailsDTO.getRegistrantsName() + " " + contactDetailsDTO.getRegistrantsLastName());
		params.put( "clientAddress", contactDetailsDTO.getAddress() );
		params.put( "clientEmail", contactDetailsDTO.getEmail() !=null ?contactDetailsDTO.getEmail():"N/A");
		params.put( "clientLoginName", clientDetailsDTO.getLoginName() );
	}
	
	private void getConnectionSpecificInformation(Map<String, Object> params, LLIConnectionInstance lliConnectionInstance, LLIApplication lliApplication) throws Exception {
		params.put("connectionName", lliConnectionInstance.getName());
		params.put("applicationSuggestedBW", lliConnectionInstance.getBandwidth());
		params.put("applicationSuggestedDate", lliConnectionInstance.getStartDate());
		LLINewConnectionApplication lliNewConnectionApplication = (LLINewConnectionApplication)lliApplication;
		params.put("applicationSuggestedConnectionAddress", lliNewConnectionApplication.getAddress());
		
	}
	
	private void getBillSpecificInformation(Map<String, Object> params, BillDTO billDTO) {
		params.put("billGenerationDate", TimeConverter.getDateTimeStringByMillisecAndDateFormat(billDTO.getGenerationTime(), "dd/MM/yyyy"));
		params.put("billLastPaymentDate", TimeConverter.getDateTimeStringByMillisecAndDateFormat(billDTO.getLastPaymentDate(), "dd/MM/yyyy"));
		
		if(billDTO instanceof LLINewConnectionDemandNote) {
		}else if(billDTO instanceof LLISingleConnectionCommonDemandNote) {
			
		}else if(billDTO instanceof LLIBreakLongTermDemandNote) {
			
		}else if(billDTO instanceof LLICloseConnectionDemandNote) {
			
		}else {
			throw new RequestFailureException("This bill does not have a pdf template");
		}
	}
	private void writeDomainPdfFileAndLogInDatabase(EntityDTO entityDTO, BillDTO billDTO, String fileName) throws Exception {
		DatabaseConnection databaseConnection = new DatabaseConnection();
		try {
			databaseConnection.dbOpen();
			writeDomainPdfFileAndLogInDatabase( entityDTO, billDTO, fileName, System.currentTimeMillis(), databaseConnection );
		}
		catch( Exception e ) {
			
			e.printStackTrace();
			throw e;
		}
		finally {
			
			databaseConnection.dbClose();
		}
		
	}
	private static void writeDomainPdfFileAndLogInDatabase(EntityDTO entityDTO, BillDTO billDTO, String fileName,
			long currentTimeMillis, DatabaseConnection databaseConnection) throws Exception {
		FileDTO fileDTO = new FileDTO();
		
		fileDTO.setDocOwner( entityDTO.getClientID() );
		fileDTO.setDocEntityTypeID( EntityTypeConstant.DOMAIN);
		fileDTO.setDocEntityID( entityDTO.getEntityID() );
		fileDTO.setLastModificationTime( currentTimeMillis );
		
		StringBuilder sb = new StringBuilder();
		
		sb.append( FileTypeConstants.BASE_PATH );
		sb.append( FileTypeConstants.DOMAIN_BILL_DIRECTORY );
		sb.append( billDTO.getYear() + "/" + billDTO.getMonth() + "/" );
		
		String finalFileName = fileName + ".pdf";
		
		File dir = new File( sb.toString() );
		
     	if (!dir.exists()) {
            if (dir.mkdirs()) {
            	
            	logger.debug("dir: "+ sb.toString() +" is created successfully.");
            } else {
            	
            	logger.debug("dir: "+ sb.toString() +" is not created.");
            	throw new Exception( "Directory for bill pdf can't be created" );
            }
     	}
		
     	fileDTO.setDocTypeID( FileTypeConstants.GLOBAL.BILL + "" );
		fileDTO.setDocActualFileName( finalFileName );
		fileDTO.setDocLocalFileName( finalFileName );
		fileDTO.setDocSize( -1 );
		fileDTO.setDocDirectoryPath( dir.getPath() );
		
		new FileService().insert(fileDTO, databaseConnection);
		
//		writeDomainBillToPdfFile( fileDTO.getDocDirectoryPath() + File.separatorChar + fileDTO.getDocActualFileName(), billDTO );
		
	}

}
