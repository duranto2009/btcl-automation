package lli;

import java.util.Calendar;
import java.util.Collection;
import java.util.Hashtable;
import java.util.List;

import annotation.DAO;
import annotation.Transactional;
import common.RequestFailureException;
import login.LoginDTO;
import requestMapping.Service;
import util.NavigationService;
import util.TransactionType;

public class LLIClientTDService implements NavigationService {

	@DAO
	LLIClientTDDAO lliClientTDDAO;
	
	@Service
	LLIConnectionService lliConnectionService;
	
	@Transactional(transactionType = TransactionType.READONLY)
	@Override
	public Collection getIDs(LoginDTO loginDTO, Object... objects) throws Exception {
		return getIDsWithSearchCriteria(new Hashtable<>(), loginDTO, objects);
	}
	@Transactional(transactionType = TransactionType.READONLY)
	@Override
	public Collection getIDsWithSearchCriteria(Hashtable searchCriteria, LoginDTO loginDTO, Object... objects)
			throws Exception {
		List <LLIClientTDStatus> list = lliClientTDDAO.getIDsWithSearchCriteria(searchCriteria, loginDTO);
		return list;
	}

	@Transactional(transactionType = TransactionType.READONLY)
	@Override
	public Collection getDTOs(Collection recordIDs, Object... objects) throws Exception {
		return lliClientTDDAO.getDTOListByIDList((List<Long>) recordIDs);
	}
	@Transactional
	public void tempDisconnectClientByClientID(long clientID) throws Exception{
		
		lliConnectionService.tdLLIConnectionByClientID(clientID);
		
		LLIClientTDStatus lliClientTDStatus = lliClientTDDAO.getLLIClientTDStatusByClientID(clientID);
		if(lliClientTDStatus == null|| lliClientTDStatus.isDeleted()){
			throw new RequestFailureException("No client TD status found.Data inconsistency");
		}
		
		lliClientTDStatus.setTdStatus(LLIClientTDStatus.TD);
		
		lliClientTDDAO.updateClientTDStatus(lliClientTDStatus);
	}
	@Transactional
	public void insertNewClientStatusByClientID(long clientID,long TDDate) throws Exception{
		LLIClientTDStatus lliClientTDStatus = new LLIClientTDStatus();
		
		lliClientTDStatus.setClientID(clientID);
		lliClientTDStatus.setTDDate(TDDate);
		lliClientTDDAO.insertClientTDStatus(lliClientTDStatus);
	}
	@Transactional
	public void deleteClientTDStatus(long clientID) throws Exception{
		LLIClientTDStatus lliClientTDStatus = lliClientTDDAO.getLLIClientTDStatusByClientID(clientID);
		lliClientTDStatus.setDeleted(true);
		lliClientTDDAO.updateClientTDStatus(lliClientTDStatus);
	}
	@Transactional
	public void reconnectClientByClientID(long clientID) throws Exception{
		
		lliConnectionService.reconnectionConnectionByClientID(clientID);
		
		LLIClientTDStatus lliClientTDStatus = lliClientTDDAO.getLLIClientTDStatusByClientID(clientID);
		lliClientTDStatus.setTdStatus(LLIClientTDStatus.ACTIVE);
		lliClientTDDAO.updateClientTDStatus(lliClientTDStatus);
	}
	/*
	public static long getNextBillCycleByCurrentDate(long currentDate){
		
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(currentDate);
		calendar.set(Calendar.HOUR, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		int date = calendar.get(Calendar.DATE);
		if()
		
		return
	}
	*/
	
}
