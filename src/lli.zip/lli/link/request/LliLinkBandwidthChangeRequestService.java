package lli.link.request;

import annotation.Transactional;
import common.CommonDAO;
import common.EntityTypeConstant;
import common.PermissionHandler;
import lli.constants.LliRequestTypeConstants;
import lli.link.LliBandWidthChangeRequestDTO;
import lli.link.LliLinkDTO;
import login.LoginDTO;
import request.CommonRequestDTO;
import request.RequestActionStateRepository;
import util.ModifiedSqlGenerator;
import util.SqlGenerator;


public class LliLinkBandwidthChangeRequestService implements LliLinkRequestService{

	@Override
	public String getRequestPreviewActionURL(Long rootRequestID) throws Exception {
		CommonRequestDTO commonRequestDTO = requestUtilService.getRequestDTOByReqID(rootRequestID);
		LliBandWidthChangeRequestDTO lliBandWidthChangeRequestDTO = (LliBandWidthChangeRequestDTO) getRequestDTOByRootRequestID(commonRequestDTO.getReqID());
		return "LliBandwidthChange/preview.do?id=" + lliBandWidthChangeRequestDTO.getID();
	}
	
	@Override
	@Transactional(transactionType=util.TransactionType.READONLY)
	public Object getRequestDTOByRootRequestID(Long requestID) throws Exception {
		LliBandWidthChangeRequestDTO lliBandWidthChangeRequestDTO = ModifiedSqlGenerator.getAllObjectListFullyPopulated (LliBandWidthChangeRequestDTO.class, " where "+ SqlGenerator.getForeignKeyColumnName(LliBandWidthChangeRequestDTO.class)+" = " + requestID).get(0);
		return lliBandWidthChangeRequestDTO;
	}
	
	@Override
	@Transactional(transactionType=util.TransactionType.READONLY)
	public LliBandWidthChangeRequestDTO getRequestDTOByPrimaryKey(Long requestDTOID) throws Exception {
		LliBandWidthChangeRequestDTO lliBandWidthChangeRequestDTO = ModifiedSqlGenerator.getObjectFullyPopulatedByID(LliBandWidthChangeRequestDTO.class, requestDTOID);
		return lliBandWidthChangeRequestDTO;
	}
	
	private void updateLliLink(LliLinkDTO lliLinkDTO) throws Exception {
		Long currentTime = System.currentTimeMillis();
		
		Integer stateID = RequestActionStateRepository.getInstance().getActionStateDTOActionTypeID(LliRequestTypeConstants.REQUEST_UPGRADE.CLIENT_APPLY).getNextStateID();
		lliLinkDTO.setLatestStatus(stateID);			
		lliLinkDTO.setLastModificationTime(currentTime);
		
		ModifiedSqlGenerator.updateEntityByPropertyList(lliLinkDTO, LliLinkDTO.class, false, false, new String[] { "lastModificationTime", "latestStatus" }, currentTime);
	}
	
	@Transactional
	public void submitRequest(LliBandWidthChangeRequestDTO lliBandWidthChangeRequestDTO, LoginDTO loginDTO) throws Exception {
		
		LliLinkDTO lliLinkDTO = lliLinkService.getLliLinkByLliLinkID(lliBandWidthChangeRequestDTO.getLinkID());
		updateLliLink(lliLinkDTO);
		
		boolean isUpgradeRequest = isUpgradeRequest(lliBandWidthChangeRequestDTO, lliLinkDTO);
		lliBandWidthChangeRequestDTO.setRequestTypeID(isUpgradeRequest ? LliRequestTypeConstants.REQUEST_UPGRADE.CLIENT_APPLY : LliRequestTypeConstants.REQUEST_DOWNGRADE.CLIENT_APPLY);
		
		Long clientID = loginDTO.getAccountID() > 0 ? loginDTO.getAccountID() : lliBandWidthChangeRequestDTO.getClientID();
		lliBandWidthChangeRequestDTO.setClientID(clientID);
		
		lliBandWidthChangeRequestDTO = setCommonRequest(lliBandWidthChangeRequestDTO);
		
		lliBandWidthChangeRequestDTO.setDescription("Bandwidth Change from " + lliLinkDTO.getLliBandwidth() + EntityTypeConstant.linkBandwidthTypeMap.get(lliLinkDTO.getLliBandwidthType()) +
				" to " + lliBandWidthChangeRequestDTO.getNewBandwidth() + EntityTypeConstant.linkBandwidthTypeMap.get(lliBandWidthChangeRequestDTO.getNewBandwidthType()) + " is requested");
		
		PermissionHandler.handleClientPermissionByEntityIDAndEntityTypeID(loginDTO, clientID, lliBandWidthChangeRequestDTO.getLinkID(), EntityTypeConstant.LLI_LINK);

		if (!loginDTO.getIsAdmin()) {
			lliBandWidthChangeRequestDTO.setRequestByAccountID(loginDTO.getAccountID());
		} else {
			lliBandWidthChangeRequestDTO.setRequestByAccountID(-loginDTO.getUserID());
		}
		
		if (lliBandWidthChangeRequestDTO.getExpireTime() == 0) {
			long expireTime = new CommonDAO().getExpireTimeByRequestType(lliBandWidthChangeRequestDTO.getRequestTypeID());
			lliBandWidthChangeRequestDTO.setExpireTime(expireTime);
		}
		ModifiedSqlGenerator.insert(lliBandWidthChangeRequestDTO, LliBandWidthChangeRequestDTO.class, true);
	}

	private boolean isUpgradeRequest(LliBandWidthChangeRequestDTO lliBandWidthChangeRequestDTO, LliLinkDTO lliLinkDTO) {
		long newBandwidthInMegabit = (lliBandWidthChangeRequestDTO.getNewBandwidthType() == 1) ? lliBandWidthChangeRequestDTO.getNewBandwidth() : lliBandWidthChangeRequestDTO.getNewBandwidth() * 1024;
		long oldBandwidthInMegabit = (lliLinkDTO.getLliBandwidthType() == 1) ? (long)lliLinkDTO.getLliBandwidth() : (long)lliLinkDTO.getLliBandwidth() * 1024;
		return newBandwidthInMegabit >= oldBandwidthInMegabit;
	}

	@Override
	public LliBandWidthChangeRequestDTO setCommonRequest(CommonRequestDTO lliRequestDTO) {
		LliBandWidthChangeRequestDTO lliBandWidthChangeRequestDTO = (LliBandWidthChangeRequestDTO) lliRequestDTO;
		Long currentTime = System.currentTimeMillis();
		lliBandWidthChangeRequestDTO.setRequestTime(currentTime);
		lliBandWidthChangeRequestDTO.setLastModificationTime(currentTime);
		
		lliBandWidthChangeRequestDTO.setRequestTypeID(lliRequestDTO.getRequestTypeID());
		lliBandWidthChangeRequestDTO.setEntityTypeID(EntityTypeConstant.LLI_LINK);
		lliBandWidthChangeRequestDTO.setEntityID(lliBandWidthChangeRequestDTO.getLinkID());
		lliBandWidthChangeRequestDTO.setRootReqID(null);
		lliBandWidthChangeRequestDTO.setParentReqID(null);
		
		return lliBandWidthChangeRequestDTO;
	}


	@Override
	public void submit(Object lliRequestDTO, LoginDTO loginDTO) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Long getRequestIDByRootRequestID(Long requestID) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
