package lli.link.request;

import annotation.Transactional;
import common.CommonDAO;
import common.EntityTypeConstant;
import common.PermissionHandler;
import inventory.InventoryItemDetails;
import lli.constants.LliRequestTypeConstants;
import lli.link.LliFarEndDTO;
import lli.link.LliLinkCloseRequestDTO;
import lli.link.LliLinkDTO;
import login.LoginDTO;
import request.CommonRequestDTO;
import request.RequestActionStateRepository;
import util.ModifiedSqlGenerator;
import util.SqlGenerator;


public class LliLinkCloseRequestService implements LliLinkRequestService{

	@Override
	public String getRequestPreviewActionURL(Long rootRequestID) throws Exception {
		CommonRequestDTO commonRequestDTO = requestUtilService.getRequestDTOByReqID(rootRequestID);
		LliLinkCloseRequestDTO lliLinkCloseRequestDTO = (LliLinkCloseRequestDTO) getRequestDTOByRootRequestID(commonRequestDTO.getReqID());
		return "LliLinkClose/preview.do?id=" + lliLinkCloseRequestDTO.getID();
	}
	
	@Override
	@Transactional(transactionType=util.TransactionType.READONLY)
	public Object getRequestDTOByRootRequestID(Long requestID) throws Exception {
		LliLinkCloseRequestDTO lliLinkCloseRequestDTO = ModifiedSqlGenerator.getAllObjectListFullyPopulated (LliLinkCloseRequestDTO.class, " where "+ SqlGenerator.getForeignKeyColumnName(LliLinkCloseRequestDTO.class)+" = " + requestID).get(0);
		return lliLinkCloseRequestDTO;
	}
	
	@Override
	@Transactional(transactionType=util.TransactionType.READONLY)
	public LliLinkCloseRequestDTO getRequestDTOByPrimaryKey(Long requestDTOID) throws Exception {
		LliLinkCloseRequestDTO lliLinkCloseRequestDTO = ModifiedSqlGenerator.getObjectFullyPopulatedByID(LliLinkCloseRequestDTO.class, requestDTOID);
		return lliLinkCloseRequestDTO;
	}
	
	private void updateLliLink(LliLinkDTO lliLinkDTO) throws Exception {
		Long currentTime = System.currentTimeMillis();
		
		Integer stateID = RequestActionStateRepository.getInstance().getActionStateDTOActionTypeID(LliRequestTypeConstants.REQUEST_UPGRADE.CLIENT_APPLY).getNextStateID();
		lliLinkDTO.setLatestStatus(stateID);			
		lliLinkDTO.setLastModificationTime(currentTime);
		
		ModifiedSqlGenerator.updateEntityByPropertyList(lliLinkDTO, LliLinkDTO.class, false, false, new String[] { "lastModificationTime", "latestStatus" }, currentTime);
	}
	
	@Transactional
	public void submitRequest(LliLinkCloseRequestDTO lliLinkCloseRequestDTO, LoginDTO loginDTO) throws Exception {
		
		LliLinkDTO lliLinkDTO = lliLinkService.getLliLinkByLliLinkID(lliLinkCloseRequestDTO.getLliLinkID());
		updateLliLink(lliLinkDTO);
		
		Long clientID = loginDTO.getAccountID() > 0 ? loginDTO.getAccountID() : lliLinkCloseRequestDTO.getClientID();
		lliLinkCloseRequestDTO.setClientID(clientID);
		
		lliLinkCloseRequestDTO = setCommonRequest(lliLinkCloseRequestDTO);
		
		LliFarEndDTO lliFarEnd = lliLinkService.getFarEndByFarEndID(lliLinkDTO.getFarEndID());
		InventoryItemDetails farEndDetails = inventoryService.getInventoryItemDetailsByItemID(lliFarEnd.getPortID());
				
		
		lliLinkCloseRequestDTO.setDescription("Link Close is requested");
		
		PermissionHandler.handleClientPermissionByEntityIDAndEntityTypeID(loginDTO, clientID, lliLinkCloseRequestDTO.getLliLinkID(), EntityTypeConstant.LLI_LINK);

		if (!loginDTO.getIsAdmin()) {
			lliLinkCloseRequestDTO.setRequestByAccountID(loginDTO.getAccountID());
		} else {
			lliLinkCloseRequestDTO.setRequestByAccountID(-loginDTO.getUserID());
		}
		
		if (lliLinkCloseRequestDTO.getExpireTime() == 0) {
			long expireTime = new CommonDAO().getExpireTimeByRequestType(lliLinkCloseRequestDTO.getRequestTypeID());
			lliLinkCloseRequestDTO.setExpireTime(expireTime);
		}
		ModifiedSqlGenerator.insert(lliLinkCloseRequestDTO, LliLinkCloseRequestDTO.class, true);
	}

	@Override
	public LliLinkCloseRequestDTO setCommonRequest(CommonRequestDTO lliRequestDTO) {
		LliLinkCloseRequestDTO lliLinkCloseRequestDTO = (LliLinkCloseRequestDTO) lliRequestDTO;
		Long currentTime = System.currentTimeMillis();
		lliLinkCloseRequestDTO.setRequestTime(currentTime);
		lliLinkCloseRequestDTO.setLastModificationTime(currentTime);
		
		lliLinkCloseRequestDTO.setRequestTypeID(LliRequestTypeConstants.REQUEST_CONNECTION_CLOSE.CLIENT_APPLY);
		lliLinkCloseRequestDTO.setEntityTypeID(EntityTypeConstant.LLI_LINK);
		lliLinkCloseRequestDTO.setEntityID(lliLinkCloseRequestDTO.getLliLinkID());
		lliLinkCloseRequestDTO.setRootReqID(null);
		lliLinkCloseRequestDTO.setParentReqID(null);
		
		return lliLinkCloseRequestDTO;
	}

	@Override
	public void submit(Object lliRequestDTO, LoginDTO loginDTO) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Long getRequestIDByRootRequestID(Long requestID) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}



}
