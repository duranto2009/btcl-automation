package lli.link.request;

import java.util.List;
import java.util.Map;

import annotation.Transactional;
import common.CategoryConstants;
import common.EntityTypeConstant;
import inventory.InventoryItem;
import inventory.InventoryItemDetails;
import inventory.InventoryService;
import util.ModifiedSqlGenerator;
import util.ServiceDAOFactory;
import lli.constants.LliRequestTypeConstants;
import lli.link.LliFarEndDTO;
import lli.link.LliInternalFRDataLocation;
import lli.link.LliLinkDTO;
import lli.link.LliLinkService;

public class LliLinkUpdateService {

	InventoryService inventoryService = ServiceDAOFactory.getService(InventoryService.class);
	LliLinkService lliLinkService = ServiceDAOFactory.getService(LliLinkService.class);
	
	@Transactional
	public void updateLink(Map<String, String[]> parameterMap) throws Exception {
		LliLinkDTO lliLinkDTO = lliLinkService.getLliLinkByLliLinkID(Long.parseLong(parameterMap.get("lliLinkID")[0]));
		LliFarEndDTO lliFarEndDTO = lliLinkService.getFarEndByFarEndID(lliLinkDTO.getFarEndID());
		
		LliInternalFRDataLocation lliInternalFRDataLocation = lliLinkService.getInternalFRDataLocationForEdit(lliLinkDTO,lliFarEndDTO, LliRequestTypeConstants.REQUEST_NEW_LINK.UPDATE_APPLICATION);
	
		
		//Update lliFarEndDTO
		if (parameterMap.containsKey("fePortID") && lliInternalFRDataLocation.farEndPortInFRResponse) {
			Long farEndPortID = Long.parseLong(parameterMap.get("fePortID")[0]);
			InventoryItemDetails farEndPortDetails = inventoryService.getInventoryItemDetailsByItemID(farEndPortID);
			
			inventoryService.markInventoryItemAsUnused(lliFarEndDTO.getPortID());
			inventoryService.markInventoryItemAsUsed(farEndPortID, lliFarEndDTO.getID(), EntityTypeConstant.VPN_LINK_FAR_END, lliLinkDTO.getClientID());
			
			lliFarEndDTO.setPortID(farEndPortID);
			lliFarEndDTO.setPortType(farEndPortDetails.getValueByAttributeName("Port Type"));
			lliFarEndDTO.setPortCategoryType(farEndPortDetails.getValueByAttributeName("Port Type"));
			
			List<InventoryItem> farEndPortAncestors = inventoryService.getInventoryItemDetailsFromRootByItemID(farEndPortID);
			for(InventoryItem farEndPortAncestor : farEndPortAncestors) {
				if(farEndPortAncestor.getInventoryCatagoryTypeID().equals(CategoryConstants.CATEGORY_ID_ROUTER) && lliInternalFRDataLocation.farEndSlotInFRResponse) {
					lliFarEndDTO.setRouterID(farEndPortAncestor.getID());
				}
				if(farEndPortAncestor.getInventoryCatagoryTypeID().equals(CategoryConstants.CATEGORY_ID_POP) && lliInternalFRDataLocation.farEndPopInFRResponse) {
					lliFarEndDTO.setPopID(farEndPortAncestor.getID());
				}
			}
			ModifiedSqlGenerator.updateEntity(lliFarEndDTO, LliFarEndDTO.class, true, false);
		}
		
		
		
	}

}
