package lli.link.request;

import inventory.InventoryService;
import lli.link.LliLinkService;
import login.LoginDTO;
import request.CommonRequestDTO;
import request.RequestUtilService;

public interface LliLinkRequestService {
	RequestUtilService requestUtilService = new RequestUtilService();
	LliLinkService lliLinkService = new LliLinkService();
	InventoryService inventoryService = new InventoryService();
	
	public String getRequestPreviewActionURL(Long rootRequestID) throws Exception;
	
	public Object getRequestDTOByRootRequestID(Long requestID) throws Exception;
	
	Object getRequestDTOByPrimaryKey(Long requestDTOID) throws Exception;
	
	Object setCommonRequest(CommonRequestDTO lliRequestDTO) throws Exception;

	void submit(Object lliRequestDTO, LoginDTO loginDTO) throws Exception;

	Long getRequestIDByRootRequestID(Long requestID) throws Exception;
	
	
	
}
