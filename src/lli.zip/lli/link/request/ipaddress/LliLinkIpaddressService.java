package lli.link.request.ipaddress;

import java.util.Set;

import annotation.Transactional;
import common.CommonDAO;
import common.EntityTypeConstant;
import common.PermissionHandler;
import lli.constants.LliRequestTypeConstants;
import lli.link.LliLinkDTO;
import lli.link.request.LliLinkRequestService;
import login.LoginDTO;
import request.CommonRequestDTO;
import request.RequestActionStateRepository;
import request.RequestUtilDAO;
import util.CurrentTimeFactory;
import util.DatabaseConnectionFactory;
import util.ModifiedSqlGenerator;

public class LliLinkIpaddressService implements LliLinkRequestService{

	@Override
	public String getRequestPreviewActionURL(Long rootRequestID) throws Exception {
		LliLinkIpaddressRequestDTO lliLinkIpaddressRequestDTO = (LliLinkIpaddressRequestDTO) getRequestDTOByRootRequestID(rootRequestID);
		return "LliLinkIpaddress/preview.do?id=" + lliLinkIpaddressRequestDTO.getId();
	}

	@Override
	@Transactional(transactionType=util.TransactionType.READONLY)
	public Object getRequestDTOByRootRequestID(Long requestID) throws Exception {
		return ModifiedSqlGenerator.getAllObjectListFullyPopulated (LliLinkIpaddressRequestDTO.class, " where reqID = " + requestID).get(0);
	}
	
	@Override
	@Transactional(transactionType=util.TransactionType.READONLY)
	public Long getRequestIDByRootRequestID(Long requestID) throws Exception {
		LliLinkIpaddressRequestDTO lliLinkIpaddressRequestDTO = ModifiedSqlGenerator.getAllObjectListFullyPopulated (LliLinkIpaddressRequestDTO.class, " where reqID = " + requestID).get(0);
		return lliLinkIpaddressRequestDTO.getId();
	}

	@Override
	@Transactional(transactionType=util.TransactionType.READONLY)
	public Object getRequestDTOByPrimaryKey(Long requestDTOID) throws Exception {
		return ModifiedSqlGenerator.getObjectFullyPopulatedByID(LliLinkIpaddressRequestDTO.class, requestDTOID);
	}
	
	@Transactional(transactionType=util.TransactionType.READONLY)
	public Object getRequestDTOByEntity(long entityID, int entityTypeID) throws Exception {
		CommonRequestDTO commonRequestDTO = new CommonRequestDTO();
		commonRequestDTO.setEntityID(entityID);
		commonRequestDTO.setEntityTypeID(entityTypeID);

		Set<CommonRequestDTO> bottomRequestDTOSet = new RequestUtilDAO().getBottomRequestDTOsByEntity(commonRequestDTO, DatabaseConnectionFactory.getCurrentDatabaseConnection(), true, false, false);
		return ModifiedSqlGenerator.getAllObjectListFullyPopulated (LliLinkIpaddressRequestDTO.class, " where reqID = " + bottomRequestDTOSet.iterator().next().getRootReqID()).get(0);
	}

	@Override
	public LliLinkIpaddressRequestDTO setCommonRequest(CommonRequestDTO lliRequestDTO) throws Exception{
		LliLinkIpaddressRequestDTO liLliLinkIpaddressRequestDTO = (LliLinkIpaddressRequestDTO) lliRequestDTO;
		Long currentTime = System.currentTimeMillis();
		liLliLinkIpaddressRequestDTO.setRequestTime(currentTime);
		liLliLinkIpaddressRequestDTO.setLastModificationTime(currentTime);
		
		liLliLinkIpaddressRequestDTO.setRequestTypeID(LliRequestTypeConstants.REQUEST_IPADDRESS.CLIENT_APPLY);
		liLliLinkIpaddressRequestDTO.setEntityTypeID(EntityTypeConstant.LLI_LINK);
		liLliLinkIpaddressRequestDTO.setEntityID(liLliLinkIpaddressRequestDTO.getLinkID());
		liLliLinkIpaddressRequestDTO.setRootReqID(null);
		liLliLinkIpaddressRequestDTO.setParentReqID(null);
		
		liLliLinkIpaddressRequestDTO.setDescription("LLI Link Additional IP Addresses requested");
		
		return liLliLinkIpaddressRequestDTO;
	}

	@Override
	@Transactional
	public void submit(Object lliRequestDTO, LoginDTO loginDTO) throws Exception {
		LliLinkIpaddressRequestDTO lliLinkIpaddressRequestDTO = (LliLinkIpaddressRequestDTO) lliRequestDTO;
		
		LliLinkDTO lliLinkDTO = lliLinkService.getLliLinkByLliLinkID(lliLinkIpaddressRequestDTO.getLinkID());
		updateLliLink(lliLinkDTO);

		lliLinkIpaddressRequestDTO = setCommonRequest(lliLinkIpaddressRequestDTO);
		
		PermissionHandler.handleClientPermissionByEntityIDAndEntityTypeID(loginDTO, lliLinkIpaddressRequestDTO.getClientID(), lliLinkIpaddressRequestDTO.getLinkID(), EntityTypeConstant.LLI_LINK);

		if (!loginDTO.getIsAdmin()) {
			lliLinkIpaddressRequestDTO.setRequestByAccountID(loginDTO.getAccountID());
		} else {
			lliLinkIpaddressRequestDTO.setRequestByAccountID(-loginDTO.getUserID());
		}
		
		if (lliLinkIpaddressRequestDTO.getExpireTime() == 0) {
			long expireTime = new CommonDAO().getExpireTimeByRequestType(lliLinkIpaddressRequestDTO.getRequestTypeID());
			lliLinkIpaddressRequestDTO.setExpireTime(expireTime);
		}
		lliLinkIpaddressRequestDTO.setLastModificationTime(CurrentTimeFactory.getCurrentTime());
		ModifiedSqlGenerator.insert(lliLinkIpaddressRequestDTO, LliLinkIpaddressRequestDTO.class, true);
	}
	
	@Transactional
	private void updateLliLink(LliLinkDTO lliLinkDTO) throws Exception {
		Long currentTime = System.currentTimeMillis();
		
		Integer stateID = RequestActionStateRepository.getInstance().getActionStateDTOActionTypeID(LliRequestTypeConstants.REQUEST_IPADDRESS.CLIENT_APPLY).getNextStateID();
		lliLinkDTO.setLatestStatus(stateID);			
		lliLinkDTO.setLastModificationTime(currentTime);
		
		ModifiedSqlGenerator.updateEntityByPropertyList(lliLinkDTO, LliLinkDTO.class, false, false, new String[] { "lastModificationTime", "latestStatus" }, currentTime);
	}
	
	@Transactional
	public void submitInternalFR(LliLinkIpaddressRequestDTO lliLinkIpaddressRequestDTO, LoginDTO loginDTO) throws Exception {
		LliLinkIpaddressRequestDTO existingRequest = ModifiedSqlGenerator.getObjectFullyPopulatedByID(LliLinkIpaddressRequestDTO.class, lliLinkIpaddressRequestDTO.getId());
		
		/*existingRequest.setNewAdditionalFeasibleIpCount(lliLinkIpaddressRequestDTO.getNewAdditionalFeasibleIpCount());
		existingRequest.setAdditionalIPs(lliLinkIpaddressRequestDTO.getAdditionalIPs());
		ModifiedSqlGenerator.updateEntity(existingRequest);*/
	}
	
	

}
