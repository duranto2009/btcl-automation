package lli.link.request.ipaddress;

import annotation.ColumnName;
import annotation.ForeignKeyName;
import annotation.PrimaryKey;
import annotation.TableName;
import request.CommonRequestDTO;

@TableName("at_lli_req_ipaddress")
@ForeignKeyName("reqID")
public class LliLinkIpaddressRequestDTO extends CommonRequestDTO{
	
	private static final long serialVersionUID = 1L;

	@PrimaryKey
	@ColumnName("id")
	Long id;
	
	@ColumnName("lliLinkID")
	Long linkID;
	
	@ColumnName("newAdditionalRequestedIpCount")
	Integer newAdditionalRequestedIpCount;
	
	@ColumnName("isDeleted")
	boolean isDeleted;
	
	@ColumnName("lastModificationTime")
	long lastModificationTime;
	
	public long getLastModificationTime() {
		return lastModificationTime;
	}

	public void setLastModificationTime(long lastModificationTime) {
		super.setLastModificationTime(lastModificationTime);
		this.lastModificationTime = lastModificationTime;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	

	public Long getLinkID() {
		return linkID;
	}

	public void setLinkID(Long linkID) {
		this.linkID = linkID;
	}



	public Integer getNewAdditionalRequestedIpCount() {
		return newAdditionalRequestedIpCount;
	}

	public void setNewAdditionalRequestedIpCount(Integer newAdditionalRequestedIpCount) {
		this.newAdditionalRequestedIpCount = newAdditionalRequestedIpCount;
	}

	@Override
	public String toString() {
		return "LliLinkIpaddressRequestDTO [id=" + id + ", linkID=" + linkID + ", newAdditionalRequestedIpCount="
				+ newAdditionalRequestedIpCount + ", isDeleted=" + isDeleted + ", lastModificationTime="
				+ lastModificationTime + "]";
	}







	
	}
