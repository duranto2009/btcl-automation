package lli.link.request.ipaddress;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import common.CommonActionStatusDTO;
import common.EntityTypeConstant;
import lli.link.LliLinkService;
import login.LoginDTO;
import requestMapping.AnnotatedRequestMappingAction;
import requestMapping.Service;
import requestMapping.annotation.ActionRequestMapping;
import requestMapping.annotation.RequestMapping;
import requestMapping.annotation.RequestMethod;

@ActionRequestMapping("LliLinkIpaddress")
public class LliLinkIpaddressAction extends AnnotatedRequestMappingAction {
	
	@Service
	LliLinkService lliLinkService;
	@Service
	LliLinkIpaddressService lliLinkIpaddressService;
	
	
	@RequestMapping (mapping="/new", requestMethod = RequestMethod.GET)
	public ActionForward newIpaddressRequest(ActionMapping actionMapping) throws Exception{
		return actionMapping.findForward("new");
	}
	
	@RequestMapping (mapping="/submit", requestMethod = RequestMethod.POST)
	public ActionForward submitIpaddressRequest(LliLinkIpaddressRequestDTO lliLinkIpaddressRequestDTO, ActionMapping actionMapping
			, LoginDTO loginDTO, HttpServletRequest request) throws Exception{
		lliLinkIpaddressService.submit(lliLinkIpaddressRequestDTO, loginDTO);
		new CommonActionStatusDTO().setSuccessMessage("LLI Additional IP Address request is accepted successfully", false, request);
		
		ActionForward actionForward = new ActionForward();
		actionForward.setPath("/LliLinkAction.do?entityID="+lliLinkIpaddressRequestDTO.getLinkID()+"&entityTypeID=702");
		actionForward.setRedirect(true);
		return actionForward;
	}
	
	@RequestMapping (mapping="/preview", requestMethod = RequestMethod.GET)
	public ActionForward previewIpaddressRequest(ActionMapping actionMapping, HttpServletRequest request) throws Exception{
		LliLinkIpaddressRequestDTO lliLinkIpaddressRequestDTO = (LliLinkIpaddressRequestDTO) 
				lliLinkIpaddressService.getRequestDTOByPrimaryKey(Long.parseLong(request.getParameter("id")));
		request.setAttribute("ipAddressRequestDTO", lliLinkIpaddressRequestDTO);
		
		return actionMapping.findForward("preview");
	}
	
	@RequestMapping (mapping="/responseInternalFR", requestMethod = RequestMethod.GET)
	public ActionForward getResponseInternalFR(ActionMapping actionMapping) throws Exception{
		return actionMapping.findForward("responseInternalFR");
	}
	
	@RequestMapping (mapping="/responseInternalFR", requestMethod = RequestMethod.POST)
	public ActionForward postResponseInternalFR(LliLinkIpaddressRequestDTO lliLinkIpaddressRequestDTO, ActionMapping actionMapping, 
			LoginDTO loginDTO, HttpServletRequest request) throws Exception{
		lliLinkIpaddressService.submitInternalFR(lliLinkIpaddressRequestDTO, loginDTO);
		
		//Allocate IP Blocks
		//Entry in at_req
		//Update LLI Link Status
		
		ActionForward actionForward = new ActionForward("/LliLinkAction.do?entityID="+lliLinkIpaddressRequestDTO.getLinkID()+"&entityTypeID="+EntityTypeConstant.LLI_LINK);
		actionForward.setRedirect(true);
		return actionForward;
	}
	
}
