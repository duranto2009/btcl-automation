package lli.link.request;

import login.LoginDTO;
import request.CommonRequestDTO;

/**
 * @author dhrubo
 */
public class LliNewLinkRequestService implements LliLinkRequestService{

	@Override
	public String getRequestPreviewActionURL(Long rootRequestID) throws Exception {
		CommonRequestDTO commonRequestDTO = requestUtilService.getRequestDTOByReqID(rootRequestID);
		return "LliLinkAction.do?entityID=" + commonRequestDTO.getEntityID() + "&entityTypeID=" + commonRequestDTO.getEntityTypeID() + "&getMode=details";
	}

	@Override
	public Object getRequestDTOByRootRequestID(Long requestID) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getRequestDTOByPrimaryKey(Long requestDTOID) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object setCommonRequest(CommonRequestDTO lliRequestDTO) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void submit(Object lliRequestDTO, LoginDTO loginDTO) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Long getRequestIDByRootRequestID(Long requestID) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	
	
}
