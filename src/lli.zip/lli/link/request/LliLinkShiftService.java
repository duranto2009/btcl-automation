package lli.link.request;

import annotation.Transactional;
import common.CommonDAO;
import common.EntityTypeConstant;
import common.RequestFailureException;
import login.LoginDTO;
import request.CommonRequestDTO;
import request.RequestActionStateRepository;
import util.ModifiedSqlGenerator;
import lli.constants.LliRequestTypeConstants;
import lli.link.LliLinkDTO;
import lli.link.LliLinkService;
import lli.link.LliLinkShiftDAO;
import lli.link.LliLinkShiftDTO;

public class LliLinkShiftService implements LliLinkRequestService{
	LliLinkService lliLinkService = new LliLinkService();
	LliLinkShiftDAO lliLinkShiftDAO = new LliLinkShiftDAO();
	
	public void validateLinkShiftRequest(LliLinkShiftDTO lliLinkShiftDTO) throws Exception {
		if(!lliLinkService.doesClientOwnThisLink(lliLinkShiftDTO.getClientID(), lliLinkShiftDTO.getLliLinkID())) {
			throw new RequestFailureException("The client does not own the link");
		}
	}

	@Override
	public String getRequestPreviewActionURL(Long rootRequestID) throws Exception {
		CommonRequestDTO commonRequestDTO = requestUtilService.getRequestDTOByReqID(rootRequestID);
		LliLinkShiftDTO lliLinkShiftDTO = (LliLinkShiftDTO) getRequestDTOByRootRequestID(commonRequestDTO.getReqID());
		return "LLI/Link/Shift/Preview.do?id=" + lliLinkShiftDTO.getID();
	}
	
	@Override
	@Transactional(transactionType=util.TransactionType.READONLY)
	public Object getRequestDTOByRootRequestID(Long requestID) throws Exception {
		LliLinkShiftDTO lliLinkShiftDTO = ModifiedSqlGenerator.getAllObjectListFullyPopulated (LliLinkShiftDTO.class, " where reqID = " + requestID).get(0);
		return lliLinkShiftDTO;
	}

	@Override
	@Transactional(transactionType=util.TransactionType.READONLY)
	public LliLinkShiftDTO getRequestDTOByPrimaryKey(Long requestDTOID) throws Exception {
		LliLinkShiftDTO lliLinkShiftDTO = ModifiedSqlGenerator.getObjectFullyPopulatedByID(LliLinkShiftDTO.class, requestDTOID);
		return lliLinkShiftDTO;
	}

	@Override
	public Object setCommonRequest(CommonRequestDTO lliRequestDTO) {
		return null;
	}
	
	@Transactional
	public void submitRequest(LliLinkShiftDTO lliLinkShiftDTO, LoginDTO loginDTO) throws Exception {
		if(!lliLinkService.isLliLinkEstablished(lliLinkShiftDTO.getLliLinkID())) {
			throw new RequestFailureException("Link cannot be shifted");
		}
		
		LliLinkDTO lliLinkDTO = lliLinkService.getLliLinkByLliLinkID(lliLinkShiftDTO.getLliLinkID());			
		Long currentTime = System.currentTimeMillis();
		
		int stateID = RequestActionStateRepository.getInstance().getActionStateDTOActionTypeID(LliRequestTypeConstants.REQUEST_POP_CHANGE.CLIENT_APPLY).getNextStateID();
		lliLinkDTO.setLatestStatus(stateID);			
		lliLinkDTO.setLastModificationTime(currentTime);
		ModifiedSqlGenerator.updateEntityByPropertyList(lliLinkDTO, LliLinkDTO.class, false, false, new String[] { "lastModificationTime", "latestStatus" });
					
		lliLinkShiftDTO.setRequestTime(currentTime);
		lliLinkShiftDTO.setLastModificationTime(currentTime);
		lliLinkShiftDTO.setRequestTypeID(LliRequestTypeConstants.REQUEST_POP_CHANGE.CLIENT_APPLY);
		lliLinkShiftDTO.setEntityTypeID(EntityTypeConstant.LLI_LINK);
		lliLinkShiftDTO.setEntityID(lliLinkShiftDTO.getLliLinkID());
		lliLinkShiftDTO.setRootReqID(null);
		lliLinkShiftDTO.setParentReqID(null);
		lliLinkShiftDTO.setClientID(lliLinkDTO.getClientID());
		lliLinkShiftDTO.setShiftCompletionStatus(false);
			
		/* APATOTO APATOTO APATOTO*/
		lliLinkShiftDTO.setFeMandatoryVLanID("0");
		/* --APATOTO */
			
		if (!loginDTO.getIsAdmin()) {
			lliLinkShiftDTO.setRequestByAccountID(loginDTO.getAccountID());
		} else {
			lliLinkShiftDTO.setRequestByAccountID(-loginDTO.getUserID());
		}
			
		lliLinkShiftDTO.setDescription("LLI Link Shifting Request has been submitted");
		lliLinkShiftDTO.setExpireTime(new CommonDAO().getExpireTimeByRequestType(lliLinkShiftDTO.getRequestTypeID()));
		
		validateLinkShiftRequest(lliLinkShiftDTO);
			
		ModifiedSqlGenerator.insert(lliLinkShiftDTO, LliLinkShiftDTO.class, true);
	}

	@Override
	public void submit(Object lliRequestDTO, LoginDTO loginDTO) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Long getRequestIDByRootRequestID(Long requestID) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}



}
