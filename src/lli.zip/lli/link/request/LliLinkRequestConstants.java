package lli.link.request;

import java.util.HashMap;
import java.util.Map;

import lli.link.request.ipaddress.LliLinkIpaddressService;
import vpn.link.request.VpnLinkBandwidthChangeRequestService;
import vpn.link.request.VpnLinkCloseRequestService;
import vpn.link.request.VpnLinkDisableRequestService;
import vpn.link.request.VpnLinkShiftService;

public class LliLinkRequestConstants {
	@SuppressWarnings("rawtypes")
	public static Map<Integer, Class> requestTypeDistinguisherToRequestDTOClass = new HashMap<Integer, Class>();
	static {
		requestTypeDistinguisherToRequestDTOClass.put(1, LliNewLinkRequestService.class);
		requestTypeDistinguisherToRequestDTOClass.put(4, LliLinkIpaddressService.class);
		requestTypeDistinguisherToRequestDTOClass.put(9, LliLinkShiftService.class);
		requestTypeDistinguisherToRequestDTOClass.put(6, LliLinkCloseRequestService.class);
		requestTypeDistinguisherToRequestDTOClass.put(23, LliLinkDisableRequestService.class);
		requestTypeDistinguisherToRequestDTOClass.put(24, LliLinkDisableRequestService.class);
		requestTypeDistinguisherToRequestDTOClass.put(2, LliLinkBandwidthChangeRequestService.class);
		requestTypeDistinguisherToRequestDTOClass.put(3, LliLinkBandwidthChangeRequestService.class);
	}
}
