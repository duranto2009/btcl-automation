package lli.link.request;

import annotation.Transactional;
import common.CommonDAO;
import common.EntityTypeConstant;
import common.PermissionHandler;
import inventory.InventoryItemDetails;
import lli.constants.LliRequestTypeConstants;
import lli.link.LliFarEndDTO;
import lli.link.LliLinkDisableRequestDTO;
import lli.link.LliLinkDTO;
import login.LoginDTO;
import request.CommonRequestDTO;
import request.RequestActionStateRepository;
import util.ModifiedSqlGenerator;
import util.SqlGenerator;


public class LliLinkDisableRequestService implements LliLinkRequestService{

	@Override
	public String getRequestPreviewActionURL(Long rootRequestID) throws Exception {
		CommonRequestDTO commonRequestDTO = requestUtilService.getRequestDTOByReqID(rootRequestID);
		LliLinkDisableRequestDTO lliLinkDisableRequestDTO = (LliLinkDisableRequestDTO) getRequestDTOByRootRequestID(commonRequestDTO.getReqID());
		return "LliLinkDisable/preview.do?id=" + lliLinkDisableRequestDTO.getEntityID() + "&tdID=" + lliLinkDisableRequestDTO.getID();
	}
	
	@Override
	@Transactional(transactionType=util.TransactionType.READONLY)
	public Object getRequestDTOByRootRequestID(Long requestID) throws Exception {
		LliLinkDisableRequestDTO lliLinkDisableRequestDTO = ModifiedSqlGenerator.getAllObjectListFullyPopulated (LliLinkDisableRequestDTO.class, " where "+ SqlGenerator.getForeignKeyColumnName(LliLinkDisableRequestDTO.class)+" = " + requestID).get(0);
		return lliLinkDisableRequestDTO;
	}
	
	@Override
	@Transactional(transactionType=util.TransactionType.READONLY)
	public LliLinkDisableRequestDTO getRequestDTOByPrimaryKey(Long requestDTOID) throws Exception {
		LliLinkDisableRequestDTO lliLinkDisableRequestDTO = ModifiedSqlGenerator.getObjectFullyPopulatedByID(LliLinkDisableRequestDTO.class, requestDTOID);
		return lliLinkDisableRequestDTO;
	}
	
	private void updateLliLink(LliLinkDTO lliLinkDTO) throws Exception {
		Long currentTime = System.currentTimeMillis();
		
		Integer stateID = RequestActionStateRepository.getInstance().getActionStateDTOActionTypeID(LliRequestTypeConstants.REQUEST_UPGRADE.CLIENT_APPLY).getNextStateID();
		lliLinkDTO.setLatestStatus(stateID);			
		lliLinkDTO.setLastModificationTime(currentTime);
		
		ModifiedSqlGenerator.updateEntityByPropertyList(lliLinkDTO, LliLinkDTO.class, false, false, new String[] { "lastModificationTime", "latestStatus" }, currentTime);
	}
	
	@Transactional
	public void submitRequest(LliLinkDisableRequestDTO lliLinkDisableRequestDTO, LoginDTO loginDTO) throws Exception {
		
		LliLinkDTO lliLinkDTO = lliLinkService.getLliLinkByLliLinkID(lliLinkDisableRequestDTO.getLliLinkID());
		updateLliLink(lliLinkDTO);
		
		Long clientID = loginDTO.getAccountID() > 0 ? loginDTO.getAccountID() : lliLinkDisableRequestDTO.getClientID();
		lliLinkDisableRequestDTO.setClientID(clientID);
		
		lliLinkDisableRequestDTO = setCommonRequest(lliLinkDisableRequestDTO);
		
		LliFarEndDTO lliFarEnd = lliLinkService.getFarEndByFarEndID(lliLinkDTO.getFarEndID());
		InventoryItemDetails farEndDetails = inventoryService.getInventoryItemDetailsByItemID(lliFarEnd.getPortID());
				
		
		lliLinkDisableRequestDTO.setDescription("Link Close is requested");
		
		PermissionHandler.handleClientPermissionByEntityIDAndEntityTypeID(loginDTO, clientID, lliLinkDisableRequestDTO.getLliLinkID(), EntityTypeConstant.LLI_LINK);

		if (!loginDTO.getIsAdmin()) {
			lliLinkDisableRequestDTO.setRequestByAccountID(loginDTO.getAccountID());
		} else {
			lliLinkDisableRequestDTO.setRequestByAccountID(-loginDTO.getUserID());
		}
		
		if (lliLinkDisableRequestDTO.getExpireTime() == 0) {
			long expireTime = new CommonDAO().getExpireTimeByRequestType(lliLinkDisableRequestDTO.getRequestTypeID());
			lliLinkDisableRequestDTO.setExpireTime(expireTime);
		}
		ModifiedSqlGenerator.insert(lliLinkDisableRequestDTO, LliLinkDisableRequestDTO.class, true);
	}

	@Override
	public LliLinkDisableRequestDTO setCommonRequest(CommonRequestDTO lliRequestDTO) {
		LliLinkDisableRequestDTO lliLinkDisableRequestDTO = (LliLinkDisableRequestDTO) lliRequestDTO;
		Long currentTime = System.currentTimeMillis();
		lliLinkDisableRequestDTO.setRequestTime(currentTime);
		lliLinkDisableRequestDTO.setLastModificationTime(currentTime);
		
		lliLinkDisableRequestDTO.setRequestTypeID(LliRequestTypeConstants.REQUEST_CONNECTION_CLOSE.CLIENT_APPLY);
		lliLinkDisableRequestDTO.setEntityTypeID(EntityTypeConstant.LLI_LINK);
		lliLinkDisableRequestDTO.setEntityID(lliLinkDisableRequestDTO.getLliLinkID());
		lliLinkDisableRequestDTO.setRootReqID(null);
		lliLinkDisableRequestDTO.setParentReqID(null);
		
		return lliLinkDisableRequestDTO;
	}

	@Override
	public void submit(Object lliRequestDTO, LoginDTO loginDTO) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Long getRequestIDByRootRequestID(Long requestID) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}



}
