package lli.link;

import org.apache.struts.action.ActionForm;

public class LliLinkSearchDTO extends ActionForm {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int entityTypeID;
	long entityID;
	String name;
	String description;
	String fromDate;
	String toDate;
	public int getEntityTypeID() {
		return entityTypeID;
	}
	public void setEntityTypeID(int entityTypeID) {
		this.entityTypeID = entityTypeID;
	}
	public long getEntityID() {
		return entityID;
	}
	public void setEntityID(long entityID) {
		this.entityID = entityID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	@Override
	public String toString() {
		return "VpnLinkSearchDTO [entityTypeID=" + entityTypeID + ", entityID=" + entityID + ", name=" + name + ", description=" + description + ", fromDate=" + fromDate + ", toDate=" + toDate + "]";
	}
}
