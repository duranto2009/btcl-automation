package lli.link;

import request.CommonRequestDTO;
import annotation.ColumnName;
import annotation.ForeignKeyName;
import annotation.PrimaryKey;
import annotation.TableName;

@TableName("at_lli_req_lk_disable")
@ForeignKeyName("ReqID")
public class LliLinkDisableRequestDTO extends CommonRequestDTO{
	static final private String tableName = "at_lli_req_lk_disable";
	@PrimaryKey
	@ColumnName("ID")
	long ID;
	@ColumnName("lliLkID")
	long lliLinkID;
	@ColumnName("lastModificationTime")
	long lastModificationTime;
	@ColumnName("expireDate")
	long expirationDate;
	@ColumnName("isDeleted")
	boolean isDeleted;
	@ColumnName("lliTDStartDate")
	long tdStartDate;
	public long getTdStartDate() {
		return tdStartDate;
	}
	public void setTdStartDate(long tdStartDate) {
		this.tdStartDate = tdStartDate;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (ID ^ (ID >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LliLinkDisableRequestDTO other = (LliLinkDisableRequestDTO) obj;
		if (ID != other.ID)
			return false;
		return true;
	}

	public long getID() {
		return ID;
	}
	public void setID(long iD) {
		ID = iD;
	}

	public long getLastModificationTime() {
		return lastModificationTime;
	}
	public void setLastModificationTime(long lastModificationTime) {
		this.lastModificationTime = lastModificationTime;
	}
	public boolean isDeleted() {
		return isDeleted;
	}
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	
	
	public long getLliLinkID() {
		return lliLinkID;
	}
	public void setLliLinkID(long lliLinkID) {
		this.lliLinkID = lliLinkID;
	}
	public static String getTableName() {
		return tableName;
	}
	public long getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(long expirationDate) {
		this.expirationDate = expirationDate;
	}
	@Override
	public String toString() {
		return "LliLinkDisableRequestDTO [ID=" + ID + ", lliLinkID=" + lliLinkID + ", lastModificationTime="
				+ lastModificationTime + ", expirationDate=" + expirationDate + ", isDeleted=" + isDeleted + "]";
	}

	
}
