package lli.link;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import common.CommonDAO;
import common.bill.BillDTO;
import common.bill.BillService;
import common.note.CommonNote;
import common.note.CommonNoteService;
import connection.DatabaseConnection;
import inventory.InventoryService;
import lli.constants.LliRequestTypeConstants;
import request.CommonRequestDTO;
import util.SqlGenerator;

public class LinkUtils {
	private static InventoryService inventoryService = new InventoryService();
	
	public static Logger logger= Logger.getLogger(LinkUtils.class);

	private LinkUtils() {

	}
	
	public static void setFarEnddPointID(LliEndPointDetailsDTO customEndPoint, LliFarEndDTO endPoint) {
		customEndPoint.setID(endPoint.getID());
	}

	public static void setEndPointOtherIDs(LliEndPointDetailsDTO customEndPoint, LliEndPointDTO endPoint) {
		customEndPoint.setVepName(endPoint.getName());
		customEndPoint.setLliEndPointID(endPoint.getLliEndPointID());
		customEndPoint.setPortCategoryType(endPoint.getPortType());
		customEndPoint.setDistrictId(endPoint.getDistrictID());
		customEndPoint.setUpazilaId(endPoint.getUpazilaID());
		customEndPoint.setUnionId(endPoint.getUnionID());
		customEndPoint.setPopID(endPoint.getPopID());
		customEndPoint.setRouterID(endPoint.getRouterID());
		customEndPoint.setMandatoryVlanID(endPoint.getMandatoryVLanID());
		
		customEndPoint.setPortID(endPoint.getPortID());
		customEndPoint.setCoreType(endPoint.getCoreType());
		customEndPoint.setDistanceFromNearestPopInMeter(endPoint.getDistanceFromNearestPopInMeter());
		if(customEndPoint.getDistanceFromNearestPopInMeter()==0){
			customEndPoint.setLocalLoopDistance("N/A");
		}else{
			customEndPoint.setLocalLoopDistance(endPoint.getDistanceFromNearestPopInMeter() +" Meters");
		}
	}

	public static LliEndPointDetailsDTO getShortFarEndPointDTO(LliFarEndDTO endPoint) {
		LliEndPointDetailsDTO customEndPoint = new LliEndPointDetailsDTO();
		setFarEnddPointID(customEndPoint, endPoint);
		setEndPointOtherIDs(customEndPoint, endPoint);

		return customEndPoint;
	}
	public static LliEndPointDetailsDTO getEndPointDTODetails(LliEndPointDTO endPoint) {
		LliEndPointDetailsDTO customEndPoint = new LliEndPointDetailsDTO();
		setEndPointOtherIDs(customEndPoint, endPoint);
		setEndPointDetails(customEndPoint, endPoint);

		return customEndPoint;
	}
	public static void setEndPointDetails(LliEndPointDetailsDTO customEndPoint, LliEndPointDTO endPoint) {
		customEndPoint.setPopName(inventoryService.getInventoryItemByItemID(endPoint.getPopID()).getName());
		customEndPoint.setAddress(endPoint.getAddress());
		customEndPoint.setPortCategoryType(endPoint.getPortType());
		customEndPoint.setPortCateogryTypeName(endPoint.getPortType());
		
		customEndPoint.setDistrictId(endPoint.getDistrictID());
		customEndPoint.setDistrictName(inventoryService.getInventoryItemByItemID(endPoint.getDistrictID()).getName());
		
		customEndPoint.setUpazilaId(endPoint.getUpazilaID());
		customEndPoint.setUpazilaName(inventoryService.getInventoryItemByItemID(endPoint.getUpazilaID()).getName());
		
				
		if(endPoint.getUnionID() > 0)
		{
			customEndPoint.setUnionName(inventoryService.getInventoryItemByItemID(endPoint.getUnionID()).getName());
		}
		else
		{
			customEndPoint.setUnionName("N/A");
		}
 
		/*
		if(StringUtils.isNotEmpty(endPoint.getMandatoryVLanID())){
			customEndPoint.setPopName(inventoryService.getInventoryItemByItemID(endPoint.getPopID()).getName());
		}else{
			customEndPoint.setPopName("N/A");
		}
		*/

		if(endPoint.getRouterID()>0){
			customEndPoint.setRouterName(inventoryService.getInventoryItemByItemID(endPoint.getRouterID()).getName());
		}else{
			customEndPoint.setRouterName("N/A");
		}
		
		if(StringUtils.isNotEmpty(endPoint.getMandatoryVLanID())){
			customEndPoint.setMandatoryVlanName(inventoryService.getInventoryItemByItemID(Long.parseLong(endPoint.getMandatoryVLanID())).getName());
		}else{
			customEndPoint.setMandatoryVlanName("N/A");
		}
		
		if(StringUtils.isNotEmpty(endPoint.getAdditionalVLanID())){
			String [] IDs=endPoint.getAdditionalVLanID().split(",");
			String []names= new String[IDs.length];
			for(int i=0;i<IDs.length;i++){
				names[i]=inventoryService.getInventoryItemByItemID(Long.parseLong(StringUtils.trimToEmpty(IDs[i]))).getName();
			}
			customEndPoint.setAdditionalVlanNames( StringUtils.join(names,", "));
		}else{
			String [] names={"N/A"};
			customEndPoint.setAdditionalVlanNames( StringUtils.join(names,""));
		}
		
		if(endPoint.getPortID() > 0)
		{
			customEndPoint.setPortName(inventoryService.getInventoryItemByItemID(endPoint.getPortID()).getName());
		}
		else
		{
			customEndPoint.setPortName("N/A");
		}
		
		customEndPoint.setOfcProviderTypeID(endPoint.getOfcProviderTypeID());
		customEndPoint.setVepFibreType(endPoint.getFibreType());
		customEndPoint.setOfcProviderID(endPoint.getOfcProviderTypeID());
		customEndPoint.setTerminalDeviceProvider(endPoint.getTerminalDeviceProvider());
	}

	public static List<LliEndPointDetailsDTO> getLliFarListDetails(List<LliFarEndDTO> farEndList) {

		ArrayList<LliEndPointDetailsDTO> customList = new ArrayList<LliEndPointDetailsDTO>();

		for (LliFarEndDTO endPoint : farEndList) {
			LliEndPointDetailsDTO customEndPoint = new LliEndPointDetailsDTO();

			setFarEnddPointID(customEndPoint, endPoint);
			setEndPointOtherIDs(customEndPoint, endPoint);
			setEndPointDetails(customEndPoint, endPoint);

			customList.add(customEndPoint);
		}
		return customList;
	}
	
	public static BillDTO getLatestDemandNote( long rootReqID ){
		
		return new BillService().getBillByReqID( rootReqID );
	}
	
	public static CommonNote getLatestAdviceNote( long rootReqID ){

		String conditionString = " where arRootRequestID = " + rootReqID + " and arRequestTypeID = " 
				+ LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_REQUEST_ADVICE_NOTE + " order by arID desc limit 1";

		DatabaseConnection databaseConnection = new DatabaseConnection();

		try{
			databaseConnection.dbOpen();

			ArrayList<CommonRequestDTO> commonRequestDTOList = (ArrayList<CommonRequestDTO>)SqlGenerator.getAllObjectListFullyPopulated(CommonRequestDTO.class, databaseConnection, conditionString);

			if( commonRequestDTOList == null || commonRequestDTOList.size() == 0 )
				return null;

			CommonRequestDTO latestAdviceNoteDTO = commonRequestDTOList.get(0);

			CommonNote note = CommonNoteService.getNote( latestAdviceNoteDTO.getEntityTypeID(), latestAdviceNoteDTO.getEntityID(), latestAdviceNoteDTO.getReqID() );

			return note;
		}
		catch( Exception e ){

			logger.debug( "fata " + e.toString() );
		}
		finally{

			databaseConnection.dbClose();
		}
		return null;
	}
	
	public static ArrayList<LliFRResponseExternalDTO> getLatestExternalResponse( long rootReqID ){
		
		DatabaseConnection databaseConnection = new DatabaseConnection();
		
		try{
			
			databaseConnection.dbOpen();
			
			return new CommonDAO().getLatestExternalFR_LLI( rootReqID, databaseConnection );
		}
		catch(Exception e){
			
			logger.debug( "Fatal :" + e.toString() );
		}
		finally {
			databaseConnection.dbClose();
		}
		return null;
	}
	
	public static String getAdditionalVLanNames(String vlanIDs){
		
		if(StringUtils.isNotEmpty(vlanIDs)){
			
			String [] IDs=vlanIDs.split(",");
			String []names= new String[IDs.length];
			for(int i=0;i<IDs.length;i++){
				names[i]=inventoryService.getInventoryItemByItemID(Long.parseLong(StringUtils.trimToEmpty(IDs[i]))).getName();
			}
			return StringUtils.join(names,", ");
		}else{
			return "N/A";
		}
	}
	public static LliEndPointDetailsDTO getEndPointDTODetailsLLI( LliEndPointDTO endPoint ) {
		
		LliEndPointDetailsDTO customEndPoint = new LliEndPointDetailsDTO();
		setEndPointOtherIDs(customEndPoint, endPoint);
		setEndPointDetails(customEndPoint, endPoint);

		return customEndPoint;
	}

}
