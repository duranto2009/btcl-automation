package lli.link.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import requestMapping.AnnotatedRequestMappingAction;
import requestMapping.annotation.ActionRequestMapping;
import requestMapping.annotation.RequestMapping;
import requestMapping.annotation.RequestMethod;
@ActionRequestMapping("LliLinkDisable/")
public class LliLinkTDAction extends AnnotatedRequestMappingAction {
	@RequestMapping(mapping = "preview", requestMethod = RequestMethod.GET)
	public ActionForward getPreview(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("preview");
	} 
}

@ActionRequestMapping("LliLinkEnable/")
class LliLinkEnableAction extends AnnotatedRequestMappingAction {
	@RequestMapping(mapping = "preview", requestMethod = RequestMethod.GET)
	public ActionForward getPreview(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("preview");
	} 
}
