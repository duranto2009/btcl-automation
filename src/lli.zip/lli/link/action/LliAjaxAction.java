package lli.link.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.google.gson.Gson;

import common.StringUtils;
import lli.link.LliLinkService;
import login.LoginDTO;
import requestMapping.AnnotatedRequestMappingAction;
import requestMapping.annotation.ActionRequestMapping;
import sessionmanager.SessionConstants;

public class LliAjaxAction extends AnnotatedRequestMappingAction{
	
	Logger logger = Logger.getLogger(getClass());
	LoginDTO loginDTO = null;
	LliLinkService lliLinkService = new LliLinkService();
	
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		loginDTO = (login.LoginDTO) request.getSession(true).getAttribute(SessionConstants.USER_LOGIN);
		logger.debug(loginDTO);
		if (request.getMethod().equalsIgnoreCase("get")) {
			return handleGet(mapping, form, request, response);
		} else {
			return handlePost(mapping, form, request, response);
		}
	}

	private ActionForward handlePost(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		return null;
	}

	private ActionForward handleGet(ActionMapping mapping, ActionForm form, HttpServletRequest request,	HttpServletResponse response) throws NumberFormatException, Exception {
		String mode = request.getParameter("mode");
		loginDTO = (login.LoginDTO) request.getSession(true).getAttribute(SessionConstants.USER_LOGIN);
		
		if ("officeNameAvailability".equalsIgnoreCase(mode)){
			boolean isAvailable = lliLinkService.isRemoteEndOfficeNameAvailable(request.getParameter("officeName").trim(), request.getParameter("clientID"));
			response.getWriter().write(new Gson().toJson(isAvailable));
		} else if ("establishedLinkIDListByClientID".equalsIgnoreCase(mode)){
			
			if(request.getParameter("clientID") != null && request.getParameter("clientID").trim().length() > 0) {
				List<HashMap<String, String>> lliLinkIDListByClientID = lliLinkService.getLliLinkListByClientID(Long.parseLong(request.getParameter("clientID")), StringUtils.trim(request.getParameter("partialName")));
				response.getWriter().write(new Gson().toJson(lliLinkIDListByClientID));	
			}
			else {
				
				List<HashMap<String, String>> lliLinkIDListByClientID = lliLinkService.getLliLinkListByClientID( loginDTO.getAccountID(), request.getParameter("partialName"));
				response.getWriter().write(new Gson().toJson(lliLinkIDListByClientID));
			}
		} 
		else if ("disabledLinkIDListByClientID".equalsIgnoreCase(mode)){
			
			if(request.getParameter("clientID") != null && request.getParameter("clientID").trim().length() > 0) {
				List<HashMap<String, String>> lliLinkIDListByClientID = lliLinkService.getDisabledLliLinkListByClientID(Long.parseLong(request.getParameter("clientID")), request.getParameter("partialName"));
				response.getWriter().write(new Gson().toJson(lliLinkIDListByClientID));	
			}
			else {
				
				List<HashMap<String, String>> lliLinkIDListByClientID = lliLinkService.getDisabledLliLinkListByClientID( loginDTO.getAccountID(), request.getParameter("partialName"));
				response.getWriter().write(new Gson().toJson(lliLinkIDListByClientID));
			}
		}
		else if ("linkDetailsByLliLinkID".equalsIgnoreCase(mode)){
			HashMap<String, Map<String, String>> lliLinkDetails = lliLinkService.getLliLinkDetailsByLliLinkID(Long.parseLong(request.getParameter("lliLinkID")));
			response.getWriter().write(new Gson().toJson(lliLinkDetails));
		} else if ("bandwidthByLliLinkID".equalsIgnoreCase(mode)){
			Map<String, String> bandwidthByLliLinkID = lliLinkService.getBandwidthByLliLinkID(Long.parseLong(request.getParameter("lliLinkID")));
			response.getWriter().write(new Gson().toJson(bandwidthByLliLinkID));
		}

		return null;
	}
	
}
