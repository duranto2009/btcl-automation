package lli.link.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import lli.link.LliPOP;
import lli.link.LliPopService;


/*   

	public ActionForward execute(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response) throws Exception{
		String actionForwardName = "";
		if(request.getMethod().equalsIgnoreCase("get")){
			actionForwardName = handleGet(mapping, form, request, response);
		}else{
			actionForwardName = handlePost(mapping, form, request, response);
		}
		return mapping.findForward(actionForwardName);
	}
	private String handleGet(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response) throws Exception{
		return null;
	}
	private String handlePost(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response) throws Exception{
		return null;
	}

*/
public class PopAction extends Action{
	LliPopService popService = new LliPopService();
	
	public ActionForward execute(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response) throws Exception{
		String actionForwardName = "";
		if(request.getMethod().equalsIgnoreCase("get")){
			actionForwardName = handleGet(mapping, form, request, response);
		}else{
			actionForwardName = handlePost(mapping, form, request, response);
		}
		return mapping.findForward(actionForwardName);
	}
	private String handleGet(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response) throws Exception{
		String parameterValue = request.getParameter("id");
		if(parameterValue!=null&&!parameterValue.trim().equals("")){
			return viewPop(mapping, form, request, response);
		}else {
			return "formName";
		}
	}
	private String handlePost(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response) throws Exception{
		String modeValue = request.getParameter("mode");
		if(modeValue==null){
			throw new Exception("Invalid Request");
		}else if(modeValue.equalsIgnoreCase("add")){
			return addNewPop(mapping, form, request, response);
		}else if(modeValue.equalsIgnoreCase("update")){
			return updatePop(mapping,form,request,response);
		}else if(modeValue.equalsIgnoreCase("delete")){
			return deletePop(mapping,form,request,response);
		}else{
			throw new Exception("Invalid Request");
		}
	}
	private String addNewPop(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response) throws Exception{
		LliPOP lliPOP = (LliPOP)form;
		popService.addLliPop(lliPOP);
		return null;
	}
	private String updatePop(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response) throws Exception{
		LliPOP lliPOP = (LliPOP)form;
		popService.updateLliPop(lliPOP);
		return null;
	}
	private String viewPop(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response) throws Exception{
		long popID = Integer.parseInt(request.getParameter("id"));
		LliPOP lliPOP = (LliPOP)form;
		lliPOP = popService.getLliPop(popID);
		return null;
	}
	private String deletePop(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response) throws Exception{
		long popID = Integer.parseInt(request.getParameter("id"));
		LliPOP lliPOP = new LliPOP();
		lliPOP.setID(popID);
		popService.deleteLliPop(lliPOP);
		return null;
	}
}
