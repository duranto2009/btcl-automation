package lli.link.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import login.LoginDTO;
import login.LoginService;
import login.ServiceTypeAndCountPairDTO;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import permission.ActionStateFormDTO;
import permission.PermissionDAO;
import common.ClientDTO;
import common.CommonService;
import common.EntityTypeConstant;
import common.repository.AllClientRepository;

import com.google.gson.Gson;

import common.ClientRepository;
import connection.DatabaseConnection;
import inventory.InventoryCatagoryType;
import inventory.InventoryItem;
import inventory.InventoryService;
import inventory.repository.InventoryRepository;

import request.CommonRequestDTO;
import request.RequestUtilDAO;
import request.StateRepository;
import sessionmanager.SessionConstants;
import user.UserDTO;
import user.UserRepository;
import lli.LliLinkSearchDAO;
import lli.constants.EndPointConstants;
import lli.link.LinkUtils;
import lli.link.LliEndPointDTO;
import lli.link.LliEndPointDetailsDTO;
import lli.link.LliFarEndDTO;
import lli.link.LliLinkDTO;
import lli.link.LliLinkService;

public class FetchAutoLoadAction extends Action {

	LoginDTO loginDTO;
	CommonService commonService = new CommonService();
	PermissionDAO permissionDAO = new PermissionDAO();
	DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm a");
	Calendar calendar = Calendar.getInstance();
	public static Logger logger= Logger.getLogger(FetchAutoLoadAction.class);

	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		loginDTO = (login.LoginDTO) request.getSession(true).getAttribute(SessionConstants.USER_LOGIN);
		String mode = request.getParameter("mode");
		response.setContentType("application/json");

		if (mode.equalsIgnoreCase("loadHistory")) {
			processHistory(mapping, form, request, response);
		} else if (mode.equalsIgnoreCase("search")) {
			searchHistory(mapping, form, request, response);
		} /*else if (mode.equalsIgnoreCase("countRequest")) {
			getRequestCount(mapping, form, request, response);
		}*/ else if (mode.equalsIgnoreCase("serviceCount")) {
			getServiceCount(mapping, form, request, response);
		} else if (mode.equalsIgnoreCase("findEndByName")) {
			findEndByName(mapping, form, request, response);
		} else if (mode.equalsIgnoreCase("reloadCaptcha")) {
			reloadCaptcha(mapping, form, request, response);
		} else if (mode.equalsIgnoreCase("lliLinkDetails")) {
			getLliLinDetails(mapping, form, request, response);
		}
		return null;
	}

	

	private void getServiceCount(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		/*
		 * LoginService loginService = new LoginService();
		 * List<ServiceTypeAndCountPairDTO> serviceTypeAndCountPairDTOs =
		 * loginService.getServiceTypeCount(loginDTO);
		 * 
		 * String list = new Gson().toJson(serviceTypeAndCountPairDTOs);
		 * response.getWriter().write(list);
		 */

	}

	/*private void getRequestCount(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String moduleID = request.getParameter("moduleID");
		RequestUtilDAO requestUtilDAO = new RequestUtilDAO();

		CommonRequestDTO commonRequestDTO = new CommonRequestDTO();
		commonRequestDTO.setModuleID(Integer.parseInt(moduleID));

		DatabaseConnection databaseConnection = new DatabaseConnection();
		databaseConnection.dbOpen();
		int count = requestUtilDAO.getPendingRequestCounts(commonRequestDTO, loginDTO, databaseConnection);
		databaseConnection.dbClose();

		ArrayList<HashMap<String, String>> data = new ArrayList<HashMap<String, String>>();
		data = processJson(count, data);
		String list = new Gson().toJson(data);
		response.getWriter().write(list);

	}*/

	@SuppressWarnings({ "unchecked", "null" })
	private void findEndByName(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		LliLinkSearchDAO linkSearchDAO = new LliLinkSearchDAO();
		String name = request.getParameter("name");

		DatabaseConnection databaseConnection = new DatabaseConnection();
		databaseConnection.dbOpen();
		List<LliFarEndDTO> farList = null;
		List<LliEndPointDetailsDTO> list = new ArrayList<LliEndPointDetailsDTO>();
		long clientId = -1;
		if (StringUtils.isNotEmpty(request.getParameter("clientID"))
				&& StringUtils.isNumeric(request.getParameter("clientID")) && loginDTO.getIsAdmin()) {
			clientId = Long.parseLong((String) request.getParameter("clientID"));
		} else {
			clientId = loginDTO.getAccountID();
		}

		Object values[] = new Object[] { name, clientId };
		String columnNames[] = new String[] { "vepName", "clientID" };
		if ((EndPointConstants.FAR_END_TYPE + "").equals(request.getParameter("endType"))) {
			farList = linkSearchDAO.getLliFarEndByName(values, columnNames, databaseConnection);
			list.addAll(LinkUtils.getLliFarListDetails(farList));
		}else{
			farList = linkSearchDAO.getLliFarEndByName(values, columnNames, databaseConnection);
			list.addAll(LinkUtils.getLliFarListDetails(farList));
		}
		databaseConnection.dbClose();


		ArrayList<HashMap<String, String>> data = new ArrayList<HashMap<String, String>>();
		response.getWriter().write(new Gson().toJson(list));

	}

	private void searchHistory(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		String entityTypeID = request.getParameter("entityTypeID");
		int iEntityTypeID = Integer.parseInt(entityTypeID);
		String entityID = request.getParameter("entityID");
		long iEntityID = Long.parseLong(entityID);
		String name = request.getParameter("username");
		String description = request.getParameter("innerContent");
		String sFromDate = request.getParameter("fromDate");
		String sToDate = request.getParameter("toDate");
		String actionTypeID = request.getParameter("actionTypeID");
		int iActionTypeID = 0;
		if (actionTypeID != null && actionTypeID.length() > 0) {
			iActionTypeID = Integer.parseInt(actionTypeID);
		}
		String req = request.getParameter("req");
		boolean isReq = Boolean.parseBoolean(req);
		long fromDate = 0;
		long toDate = 0;
		if (sFromDate.length() > 0) {
			Date dateFrom = df.parse(sFromDate);
			fromDate = dateFrom.getTime();

		}
		if (sToDate.length() > 0) {
			Date dateTo = df.parse(sToDate);
			toDate = dateTo.getTime();
		}
		ArrayList<CommonRequestDTO> commonRequestDTOs = commonService.getHistoryForSearch(iEntityTypeID, iEntityID,
				name, description, fromDate, toDate, iActionTypeID, isReq, loginDTO);
		ArrayList<HashMap<String, String>> data = new ArrayList<HashMap<String, String>>();

		data = processJson(commonRequestDTOs, data);

		String list = new Gson().toJson(data);
		response.getWriter().write(list);
	}

	private void processHistory(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String start = request.getParameter("start");
		int iStart = Integer.parseInt(start) * 10;
		String entityTypeID = request.getParameter("entityTypeID");
		int iEntityTypeID = Integer.parseInt(entityTypeID);
		String entityID = request.getParameter("entityID");
		long iEntityID = Long.parseLong(entityID);
		String req = request.getParameter("req");
		boolean isReq = Boolean.parseBoolean(req);
		CommonRequestDTO comDTO = new CommonRequestDTO();
		if (isReq) {
			comDTO.setReqID(iEntityID);
		} else {
			comDTO.setEntityID(iEntityID);
			comDTO.setEntityTypeID(iEntityTypeID);
		}

		ArrayList<CommonRequestDTO> commonRequestDTOs = commonService.getHistory(iStart, comDTO, loginDTO);

		ArrayList<HashMap<String, String>> data = new ArrayList<HashMap<String, String>>();

		data = processJson(commonRequestDTOs, data);

		String list = new Gson().toJson(data);
		response.getWriter().write(list);
	}

	private ArrayList<HashMap<String, String>> processJson(ArrayList<CommonRequestDTO> commonRequestDTOs,
			ArrayList<HashMap<String, String>> data) {

		for (CommonRequestDTO commonRequestDTO : commonRequestDTOs) {
			HashMap<String, String> item = new HashMap<String, String>();
			String username = "";
			if (commonRequestDTO.getRequestByAccountID() > 0) {
				ClientDTO clientDTO = AllClientRepository.getInstance()
						.getClientByClientID(commonRequestDTO.getRequestByAccountID());// getClient(commonRequestDTO.getRequestByAccountID());
				username = clientDTO.getLoginName();
			} else {
				UserDTO userDTO = UserRepository.getInstance().getUserDTOByUserID(-commonRequestDTO.getRequestByAccountID());
				username = userDTO.getUsername();
			}
			calendar.setTimeInMillis(commonRequestDTO.getRequestTime());
			item.put("id", commonRequestDTO.getReqID() + "");
			item.put("description", commonRequestDTO.getDescription());
			item.put("username", username);
			item.put("userID", commonRequestDTO.getRequestByAccountID() + "");
			item.put("time", formatter.format(calendar.getTime()));

			data.add(item);
		}
		return data;

	}

	private ArrayList<HashMap<String, String>> processJson(int count, ArrayList<HashMap<String, String>> data) {
		HashMap<String, String> item = new HashMap<String, String>();
		item.put("totalCount", count + "");
		data.add(item);
		return data;
	}

	private void reloadCaptcha(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) {

	}

	private void getLliLinDetails(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		LliLinkSearchDAO linkSearchDAO = new LliLinkSearchDAO();
		LliLinkService lliLinkService = new LliLinkService();
		String linkName = request.getParameter("linkName");
		CommonService comService= new CommonService();
		
		DatabaseConnection databaseConnection = new DatabaseConnection();
		databaseConnection.dbOpen();
		long clientId = -1;
		if (StringUtils.isNotEmpty(request.getParameter("clientID"))
				&& StringUtils.isNumeric(request.getParameter("clientID")) && loginDTO.getIsAdmin()) {
			clientId = Long.parseLong((String) request.getParameter("clientID"));
		} else {
			clientId = loginDTO.getAccountID();
		}

		Object values[] = new Object[] { linkName, clientId };
		String columnNames[] = new String[] { "linkName", "clientID" };
		List<LliLinkDTO> list = lliLinkService.getLliLinkDTOByLinkNamePrefix(values, columnNames);
		databaseConnection.dbClose();

		System.out.println(list.toString());

		ArrayList<Object> linkList = new ArrayList<>();

		for (LliLinkDTO linkDTO : list) {
			if("active".equals(request.getParameter("status"))){
				/*int status=StateRepository.getInstance().getStateDTOByStateID(linkDTO.getCurrentStatus()).getActivationStatus();
				if(status!=EntityTypeConstant.STATUS_ACTIVE){
					continue;
				}*/
				if(!comService.isActiveAndNotInAFlow(EntityTypeConstant.LLI_LINK, linkDTO.getID())){
					continue;
				}
			}
			
			LliFarEndDTO lliFarEndDTO = lliLinkService.getFarEndByFarEndID(linkDTO.getFarEndID());

			logger.debug(lliFarEndDTO);
			
			HashMap<String, LliEndPointDetailsDTO> endPoints = new HashMap<>();
			endPoints.put("farEnd", LinkUtils.getShortFarEndPointDTO(lliFarEndDTO));

			HashMap<String, Object> linkObject = new HashMap<>();
			linkObject.put("data", linkDTO);
			linkObject.put("endPoints", endPoints);

			linkList.add(linkObject);
		}

		response.getWriter().write(new Gson().toJson(linkList));

	}


}
