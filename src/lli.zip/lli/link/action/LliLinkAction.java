package lli.link.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionRedirect;

import comment.CommentService;
import common.CommonActionStatusDTO;
import common.CommonRequestSearchService;
import common.CommonService;
import common.EntityDTO;
import common.EntityTypeConstant;
import common.repository.AllClientRepository;
import connection.DatabaseConnection;
import lli.link.LliBandWidthChangeRequestDTO;
import lli.link.LliFarEndDTO;
import lli.link.LliLinkDTO;
import lli.link.LliLinkService;
import lli.link.LliNewLinkCreateDTO;
import login.LoginDTO;
import permission.PermissionDAO;
import permission.StateActionDTO;
import request.CommonRequestDTO;
import request.RequestUtilDAO;
import requestMapping.AnnotatedRequestMappingAction;
import requestMapping.Service;
import sessionmanager.SessionConstants;
import util.RecordNavigationManager;

public class LliLinkAction extends AnnotatedRequestMappingAction {
	Logger logger = Logger.getLogger(getClass());
	CommonService commonService = new CommonService();
	@Service
	LliLinkService lliService;

	PermissionDAO permissionDAO = new PermissionDAO();
	LoginDTO loginDTO = null;

	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		loginDTO = (login.LoginDTO) request.getSession(true).getAttribute(SessionConstants.USER_LOGIN);
		logger.debug(loginDTO);
		if (request.getMethod().equalsIgnoreCase("get")) {
			return handleGet(mapping, form, request, response);
		} else {
			return handlePost(mapping, form, request, response);
		}
	}

	private ActionForward handleGet(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String parameterValue = request.getParameter("entityID");
		String currentTab = request.getParameter("currentTab");
		logger.debug("get called");

		if ("3".equals(currentTab)) {
			logger.debug("history search");
			return searchHistory(mapping, form, request, response);
		}
		if ("2".equals(currentTab)) {
			logger.debug("comment search POST");
			return searchComment(mapping, form, request, response);
		}

		if (parameterValue != null && !parameterValue.trim().equals("")) {
			logger.info("view lli link");
			return viewLink(mapping, form, request, response);
		} else {
			return searchLink(mapping, form, request, response);
		}
	}

	private ActionForward handlePost(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String modeValue = request.getParameter("mode");
		String currentTab = request.getParameter("currentTab");
		if ("3".equals(currentTab)) {
			logger.debug("history search POST");
			return searchHistory(mapping, form, request, response);
		}
		if ("2".equals(currentTab)) {
			logger.debug("history search POST");
			return searchComment(mapping, form, request, response);
		}
		logger.debug(modeValue);
		
		if (modeValue == null) {
			throw new Exception("Invalid Request");
		} else if (modeValue.equalsIgnoreCase("add")) {
			return addNewLink(mapping, form, request, response);
		} 
/*		else if (modeValue.equalsIgnoreCase("update")) {
			return updateLink(mapping, form, request, response);
		} */
		else if (modeValue.equalsIgnoreCase("delete")) {
			return deleteLink(mapping, form, request, response);
		} else if (modeValue.equals("search")) {
			return searchLink(mapping, form, request, response);
		} else if (modeValue.equals("edit")) {
			return editLink(mapping, form, request, response);
		}  else if (modeValue.equals("linkClose")) {			
			return lliService.closeLinkRequest(mapping, form, request, response, loginDTO);			
		} else if (modeValue.equals("linkTDClose")) {	//it may need to modify		
			return lliService.disableLinkRequest(mapping, form, request, response, loginDTO);
		}
		else if (modeValue.equals("linkEnable")) {	//it may need to modify		
			return lliService.disableLinkRequest(mapping, form, request, response, loginDTO);
		}else if (modeValue.equals("migratedLliUpdate")) {	//it may need to modify		
			return lliService.lliLinkMigration(mapping, form, request, response, loginDTO);
		}else if (modeValue.equals("shiftLink")) {			
			//return lliService.bandwidthChangeRequest(mapping, form, request, response, loginDTO);	
			return null;
		}else {
			throw new Exception("Invalid Request");
		}
	}

	private ActionForward editLink(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		CommonActionStatusDTO casDTO = new CommonActionStatusDTO();
		LliNewLinkCreateDTO lliNewLinkCreateDTO = (LliNewLinkCreateDTO) form;
		logger.debug(lliNewLinkCreateDTO);
		
		LliLinkService lliLinkService = new LliLinkService();
		LliLinkDTO lliLinkDTO = lliLinkService.getLliLinkByLliLinkID(lliNewLinkCreateDTO.getLinkID());
		logger.debug("lliLinkDTO " + lliLinkDTO);
		CommonActionStatusDTO commonActionStatusDTO = lliLinkService.processLinkUpdatePermission(lliLinkDTO, loginDTO, request);
		if(commonActionStatusDTO.getStatusCode() == CommonActionStatusDTO.ERROR_STATUS_CODE)
		{
			return mapping.findForward( "applicationRoot" );
		} 
		try {
			lliService.editLink(lliNewLinkCreateDTO, request, loginDTO);
			request.setAttribute("entityID", lliNewLinkCreateDTO.getLinkID());
			logger.debug("edit action called");
		} catch (Exception ex) {
			casDTO.setErrorMessage(ex.toString(), false, request);
			ActionRedirect forward = new ActionRedirect();
			forward.setPath("/LliLinkAction.do?entityID="+lliNewLinkCreateDTO.getLinkID()+"&getMode=edit");
			forward.setRedirect(true);
			return forward;
		}
		logger.debug("lli link edit is done");
		casDTO.setMessage("Link is edited successfully. ");
		casDTO.storeInSession(request, response);
	

		ActionRedirect forward = new ActionRedirect();
		forward.setPath("/LliLinkAction.do?entityID="+lliNewLinkCreateDTO.getLinkID()+"&entityTypeID="+EntityTypeConstant.LLI_LINK+"&getMode=details");
		forward.setRedirect(true);
		return forward;
	}

	private ActionForward searchLink(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		RecordNavigationManager rnManager = new RecordNavigationManager(SessionConstants.NAV_LLI_LINK, request,
				lliService, SessionConstants.VIEW_LLI_LINK, SessionConstants.SEARCH_LLI_LINK);
		rnManager.doJob(loginDTO);
		return mapping.findForward("success");
	}

	private ActionForward searchHistory(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		logger.debug("search called");
		int entityTypeID = Integer.parseInt((String) request.getParameter("entityTypeID"));
		long iEntityID = Long.parseLong((String) request.getParameter("entityID"));
		CommonRequestSearchService crsService = new CommonRequestSearchService(entityTypeID, iEntityID);
		RecordNavigationManager rnManager = new RecordNavigationManager(SessionConstants.NAV_COMMON_REQUEST, request,
				crsService, SessionConstants.VIEW_COMMON_REQUEST, SessionConstants.SEARCH_COMMON_REQUEST);
		rnManager.doJob(loginDTO);
		return mapping.findForward("view");
	}

	private ActionForward searchComment(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		logger.debug("comment search called: lliLink");
		int entityTypeID = Integer.parseInt((String) request.getParameter("entityTypeID"));
		long iEntityID = Long.parseLong((String) request.getParameter("entityID"));
		CommentService cmService = new CommentService(entityTypeID, iEntityID);
		
		if(!loginDTO.getIsAdmin()){
			EntityDTO entityDTO=cmService.getEntityDTOByEntityIDAndEntityTypeID(entityTypeID, iEntityID);
			if((entityDTO==null) ||  (entityDTO.getClientID()!=loginDTO.getAccountID())){
				new CommonActionStatusDTO().setErrorMessage("Permission Failure", false, request);
				return mapping.findForward("view");
			}
		}
		RecordNavigationManager rnManager = new RecordNavigationManager(SessionConstants.NAV_COMMENT, request,
				cmService, SessionConstants.VIEW_COMMENT, SessionConstants.SEARCH_COMMENT);
		rnManager.doJob(loginDTO);
		return mapping.findForward("view");
	}

	private ActionForward viewLink(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		long entityID = Integer.parseInt(request.getParameter("entityID"));
		long entityTypeID = Integer.parseInt(request.getParameter("entityTypeID"));
		
		String getMode = request.getParameter("getMode");
		logger.debug(entityID + " is the link id");
		
		LliLinkDTO lliLinkDTO = lliService.getLliLinkByLliLinkID(entityID);
		logger.debug(lliLinkDTO);
		
		LliFarEndDTO lliFarEndDTO = lliService.getFarEndByFarEndID(lliLinkDTO.getFarEndID());
		logger.debug(lliFarEndDTO);

		CommonRequestDTO commonRequestDTO = new CommonRequestDTO();
		commonRequestDTO.setEntityTypeID(EntityTypeConstant.LLI_LINK);
		commonRequestDTO.setEntityID(lliLinkDTO.getID());

		Long requestedTo = loginDTO.getAccountID();
		if (loginDTO.getUserID() > 0) {
			requestedTo = loginDTO.getUserID();
		}
		commonRequestDTO.setRequestToAccountID(requestedTo);
		commonRequestDTO.setClientID(lliLinkDTO.getClientID());
		ArrayList<StateActionDTO> stateActionDTOs = commonService.getAllNextAction(commonRequestDTO, loginDTO);

		request.setAttribute("clientID", lliLinkDTO.getClientID());
		request.setAttribute("clientName",
				AllClientRepository.getInstance().getClientByClientID(lliLinkDTO.getClientID()).getName());
		request.setAttribute("farEnd", lliFarEndDTO);
		request.setAttribute("stateActions", stateActionDTOs);
		request.setAttribute("lliLink", lliLinkDTO);
		request.setAttribute("lliFE", lliFarEndDTO);
		request.setAttribute("entityID", entityID);
		request.setAttribute("entityTypeID", entityTypeID);
		
		if (getMode != null) {
			LliNewLinkCreateDTO lliNewLinkDTOForm = (LliNewLinkCreateDTO) form;
			lliNewLinkDTOForm.setLinkID(lliLinkDTO.getID());
			lliNewLinkDTOForm.setLinkName(lliLinkDTO.getLinkName());
			lliNewLinkDTOForm.setLinkBandwidth(lliLinkDTO.getLliBandwidth());
			lliNewLinkDTOForm.setLinkBandwidthType(lliLinkDTO.getLliBandwidthType());
			//lliNewLinkDTOForm.setCoreType(lliLinkDTO.getCoreType());
			lliNewLinkDTOForm.setLanCounter(lliLinkDTO.getLanCounter());
			lliNewLinkDTOForm.setLayerType(lliLinkDTO.getLayerType());
			lliNewLinkDTOForm.setConnectionType(lliLinkDTO.getConnectionType());
			lliNewLinkDTOForm.setLoopDistance(lliLinkDTO.getLliLoopDistance());

			/*lliNewLinkDTOForm.setNeAddress(lliNearEndDTO.getAddress());
			lliNewLinkDTOForm.setNePopID(lliNearEndDTO.getPopID());
			lliNewLinkDTOForm.setNePortType(lliNearEndDTO.getPortType());
			lliNewLinkDTOForm.setNeLoopDistance(lliNearEndDTO.getDistanceFromNearestPopInMeter());*/

			lliNewLinkDTOForm.setFeAddress(lliFarEndDTO.getAddress());
			lliNewLinkDTOForm.setFePopID(lliFarEndDTO.getPopID());
			lliNewLinkDTOForm.setFePortType(lliFarEndDTO.getPortType());
			lliNewLinkDTOForm.setFeLoopDistance(lliFarEndDTO.getDistanceFromNearestPopInMeter());
			
			request.setAttribute("form", lliNewLinkDTOForm);

			logger.debug("mode: "+ getMode.equals("edit"));
			if (getMode.equals("edit")) {
				return mapping.findForward("edit");
			}else if("internalFrResponse".equals(getMode)){
				request.setAttribute("requestTypeID", request.getParameter("requestTypeID"));
				//request.setAttribute("mainRootReqID", request.getParameter("mainRootReqID"));
				logger.debug("request.getParameter(entityIDReplace) " + request.getParameter("entityIDReplace"));
				logger.debug("request.getParameter(entityTypeIDReplace) " + request.getParameter("entityTypeIDReplace"));
				/*if(request.getParameter("entityIDReplace") != null)
				{
					request.setAttribute("entityIDReplace", request.getParameter("entityIDReplace"));
				}
				if(request.getParameter("entityTypeIDReplace") != null)
				{
					request.setAttribute("entityTypeIDReplace", request.getParameter("entityTypeIDReplace"));
				}*/
				int requestTypeID = Integer.parseInt(request.getParameter("requestTypeID"));
				if((requestTypeID / EntityTypeConstant.MULTIPLIER2) % 100 == 2 || (requestTypeID / EntityTypeConstant.MULTIPLIER2) % 100 == 3) {
					LliBandWidthChangeRequestDTO lliBandWidthChangeRequestDTO = new LliBandWidthChangeRequestDTO();
					DatabaseConnection databaseConnection = new DatabaseConnection();
					try {
						databaseConnection.dbOpen();
						lliBandWidthChangeRequestDTO = new RequestUtilDAO().getExtendedRequestByRootReqID(LliBandWidthChangeRequestDTO.class, commonRequestDTO.getRootReqID(), databaseConnection);
					} catch (Exception ex) {
					} finally {
						databaseConnection.dbClose();
					}
					
					lliNewLinkDTOForm.setLinkBandwidth(lliBandWidthChangeRequestDTO.getNewBandwidth());
					lliNewLinkDTOForm.setLinkBandwidthType(lliBandWidthChangeRequestDTO.getNewBandwidthType());
					request.setAttribute("form", lliNewLinkDTOForm);
				}
				return mapping.findForward("internalFrResponse");
			} else {
				return mapping.findForward("details");
			}
		}
		return mapping.findForward("view");
	}

	private ActionForward addNewLink(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		LliNewLinkCreateDTO lliNewLinkCreateDTO = (LliNewLinkCreateDTO) form;
		logger.debug(lliNewLinkCreateDTO);
		CommonActionStatusDTO casDTO = new CommonActionStatusDTO();
		LliLinkDTO lliLinkDTO= new LliLinkDTO();
		
		try {
			lliLinkDTO=lliService.addLink(lliNewLinkCreateDTO, request, loginDTO);
		} catch (Exception ex) {
			casDTO.setErrorMessage(ex.toString(), false, request);
			return mapping.findForward("success");
		}
		
		casDTO.setMessage("Connection is created successfully.");
		casDTO.storeInSession(request, response);
		
		ActionRedirect forward = new ActionRedirect(mapping.findForward("view"));
		forward.setPath("LliLinkAction.do?entityID=" + lliLinkDTO.getID() +"&entityTypeID="+EntityTypeConstant.LLI_LINK);
		forward.setRedirect(true);
		return forward;

	}

	private ActionForward updateLink(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String action = request.getParameter("action");
		lliService.updateLink(form, loginDTO, action);
		return mapping.findForward("success");
	}

	private ActionForward deleteLink(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		long EntityID = Integer.parseInt(request.getParameter("entityID"));
		lliService.deleteLink(EntityID, loginDTO);
		return null;
	}
	
	@SuppressWarnings("unused")
	private ActionForward updateLinkBandwith(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("bandwidth");
	}

}
