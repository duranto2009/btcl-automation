package lli.link.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import common.EntityTypeConstant;
import common.PermissionHandler;
import login.PermissionConstants;
import requestMapping.AnnotatedRequestMappingAction;
import requestMapping.annotation.ActionRequestMapping;
import requestMapping.annotation.RequestMapping;
import requestMapping.annotation.RequestMethod;
import util.SOP;
import util.ServiceDAOFactory;
import lli.link.request.LliLinkUpdateService;

@ActionRequestMapping("LLI/Link/Update")
public class LliLinkUpdateAction extends AnnotatedRequestMappingAction{
	
	LliLinkUpdateService lliLinkUpdateService = ServiceDAOFactory.getService(LliLinkUpdateService.class);
	
	@RequestMapping (mapping="/Link", requestMethod = RequestMethod.GET)
	public ActionForward getUpdateLink(ActionMapping actionMapping, HttpServletResponse response) throws Exception{
		return actionMapping.findForward("getUpdateLink");
	}
	
	@RequestMapping (mapping="/Link", requestMethod = RequestMethod.POST)
	public ActionForward postUpdateLink(ActionMapping actionMapping, HttpServletRequest request, HttpServletResponse response) throws Exception{
		SOP.printParameterMap(request.getParameterMap());
		PermissionHandler.handleMenuPermission(request, response, PermissionConstants.LLI_LINK, PermissionConstants.LLI_LINK_ADD, PermissionConstants.PERMISSION_FULL);
		
		lliLinkUpdateService.updateLink(request.getParameterMap());
		
		ActionForward af = new ActionForward("/LliLinkAction.do?entityID="+request.getParameter("lliLinkID")+"&entityTypeID="+EntityTypeConstant.LLI_LINK+"&getMode=details");
		af.setRedirect(true);
		return af;
	}
}
