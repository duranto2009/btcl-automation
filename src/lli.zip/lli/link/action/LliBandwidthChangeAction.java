package lli.link.action;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import common.CommonActionStatusDTO;
import common.EntityTypeConstant;
import login.LoginDTO;
import requestMapping.AnnotatedRequestMappingAction;
import requestMapping.Service;
import requestMapping.annotation.ActionRequestMapping;
import requestMapping.annotation.RequestMapping;
import requestMapping.annotation.RequestMethod;
import sessionmanager.SessionConstants;
import lli.LliDAO;
import lli.constants.LliRequestTypeConstants;
import lli.link.LliBandWidthChangeRequestDTO;
import lli.link.LliLinkDTO;
import lli.link.LliLinkService;
import lli.link.request.LliLinkBandwidthChangeRequestService;

@ActionRequestMapping("LliBandwidthChange")
public class LliBandwidthChangeAction extends AnnotatedRequestMappingAction{
	public static Logger logger = Logger.getLogger(LliBandwidthChangeAction.class);
	
	LliLinkService lliLinkService = new LliLinkService();
	@Service
	LliLinkBandwidthChangeRequestService lliLinkBandwidthChangeRequestService;
	
	
	@RequestMapping (mapping="/new", requestMethod = RequestMethod.All)
	public ActionForward newBandwidthChangeRequest(ActionMapping actionMapping) throws Exception{
		return actionMapping.findForward("new");
	}
	
	@RequestMapping (mapping="/preview", requestMethod=RequestMethod.GET)
	public ActionForward previewBandwidthChangeRequest(ActionMapping actionMapping) throws Exception{
		return actionMapping.findForward("preview");
	}
	
	@RequestMapping (mapping="/submit", requestMethod=RequestMethod.POST)
	public ActionForward previewBandwidthChangeRequest(LliBandWidthChangeRequestDTO lliBandWidthChangeRequestDTO, ActionMapping actionMapping, HttpServletRequest request) throws Exception{
		LoginDTO loginDTO = (LoginDTO) request.getSession().getAttribute(SessionConstants.USER_LOGIN);
		lliLinkBandwidthChangeRequestService.submitRequest(lliBandWidthChangeRequestDTO, loginDTO);
		new CommonActionStatusDTO().setSuccessMessage("Bandwith Change request is accepted successfully", false, request);
		ActionForward actionForward = new ActionForward();
		actionForward.setPath("/LliLinkAction.do?entityID="+lliBandWidthChangeRequestDTO.getLinkID()+"&entityTypeID="+EntityTypeConstant.LLI_LINK);
		actionForward.setRedirect(true);
		return actionForward;
	}
}
