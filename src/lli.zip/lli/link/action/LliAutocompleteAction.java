package lli.link.action;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.google.gson.Gson;

import lli.link.LliLinkService;
import login.LoginDTO;
import sessionmanager.SessionConstants;

public class LliAutocompleteAction extends Action{
	Logger logger = Logger.getLogger(getClass());
	LliLinkService lliLinkService = new LliLinkService();
	LoginDTO loginDTO = null;
	
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		loginDTO = (login.LoginDTO) request.getSession(true).getAttribute(SessionConstants.USER_LOGIN);
		logger.debug(loginDTO);
		if (request.getMethod().equalsIgnoreCase("get")) {
			return handleGet(mapping, form, request, response);
		} else {
			return handlePost(mapping, form, request, response);
		}
	}

	private ActionForward handlePost(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		return null;
	}

	private ActionForward handleGet(ActionMapping mapping, ActionForm form, HttpServletRequest request,	HttpServletResponse response) throws IOException {
		boolean isAvailable = lliLinkService.isOfficeNameAvailable(request.getParameter("officeName").trim());
		response.getWriter().write(new Gson().toJson(isAvailable));
		return null;
	}
	
}
