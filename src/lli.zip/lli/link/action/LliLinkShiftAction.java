package lli.link.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import common.CommonActionStatusDTO;
import login.LoginDTO;
import requestMapping.AnnotatedRequestMappingAction;
import requestMapping.annotation.ActionRequestMapping;
import requestMapping.annotation.RequestMapping;
import requestMapping.annotation.RequestMethod;
import util.ServiceDAOFactory;
import lli.link.LliLinkService;
import lli.link.LliLinkShiftDTO;
import lli.link.request.LliLinkShiftService;

@ActionRequestMapping("LLI/Link/Shift")
public class LliLinkShiftAction extends AnnotatedRequestMappingAction {
	
	LliLinkService lliLinkService = ServiceDAOFactory.getService(LliLinkService.class);
	LliLinkShiftService lliLinkShiftService = ServiceDAOFactory.getService(LliLinkShiftService.class);

	@RequestMapping (mapping="/Preview", requestMethod = RequestMethod.GET)
	public ActionForward getPreview(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("preview");
	}
	
	@RequestMapping (mapping="/Add", requestMethod = RequestMethod.GET)
	public ActionForward getLliLinkShiftAdd(ActionMapping actionMapping) throws Exception{
		return actionMapping.findForward("add");
	}
	
	@RequestMapping (mapping="/Add", requestMethod = RequestMethod.POST)
	public ActionForward postLliLinkShiftAdd(LliLinkShiftDTO lliLinkShiftDTO, ActionMapping actionMapping, HttpServletRequest request, LoginDTO loginDTO) throws Exception{
		lliLinkShiftService.submitRequest(lliLinkShiftDTO, loginDTO);
		new CommonActionStatusDTO().setSuccessMessage("LLI Link Shifting Request has been submitted successfully", false, request);
		return actionMapping.findForward("add");
	}
	
}
