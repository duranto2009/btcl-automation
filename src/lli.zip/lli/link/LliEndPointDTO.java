package lli.link;

import annotation.ColumnName;
import annotation.PrimaryKey;
import annotation.TableName;
import common.EntityDTO;
import lli.constants.EndPointConstants;

@TableName("at_lli_ep")
public class LliEndPointDTO implements EntityDTO {

	@PrimaryKey
	@ColumnName("ID")
	long lliEndPointID;
	@ColumnName("name")
	String Name;
	@ColumnName("clientID")
	long clientID;
	@ColumnName("districtID")
	long districtID;
	@ColumnName("upozillaID")
	long upazilaID;
	@ColumnName("unionID")
	long unionID;
	@ColumnName("popId")
	long popID;
	@ColumnName("demandNoteCreated")
	boolean isDemandnoteCreated;
	@ColumnName("activationDate")
	Long activationDate;
	@ColumnName("disFromPopInMetre")
	double distanceFromNearestPopInMeter;
	@ColumnName("address")
	String address;
	@ColumnName("fibreID")
	long fibreID;
	@ColumnName("fibrePaymentType")
	int fibrePaymentType;
	@ColumnName("coreType")
	int coreType;
	@ColumnName("fibreCost")
	double fibreCost;
	@ColumnName("terDevPaymentID")
	long terminalDevicePaymentID;
	@ColumnName("terDevID")
	long terminalDeviceID;
	@ColumnName("portType")
	String portCategoryType;// FE or GE or 10GE
	@ColumnName("portID")
	long portID;
	@ColumnName("frStartDate")
	long FRStartDate;
	@ColumnName("rfreeBackDate")
	long FRFeedBackDate;
	@ColumnName("frResult")
	int FRResult;
	@ColumnName("frDeadLine")
	long FRDeadLine;
	@ColumnName("frContractorID")
	long FRContractorID;
	@ColumnName("conEngrID")
	long connectionEngrID;
	@ColumnName("lastModificationTime")
	long lastModificationTime;
	@ColumnName("isDeleted")
	boolean isDeleted;
	@ColumnName("connectionResult")
	int connectionResult;
	double terminalDeviceCost;
	@ColumnName("fibreType")
	int fibreType; //LLC or dark
	@ColumnName("ofcProviderTypeID")
	int ofcProviderTypeID;
	@ColumnName("ofcProviderID")
	long ofcProviderID;
	
	@ColumnName("terminalDeviceProvider")
	int terminalDeviceProvider;
	@ColumnName("isOpticalFibreRented")
	boolean isOpticalFibreRented;
	@ColumnName("ofcLaidBy")
	int OFCLaidBy;
	@ColumnName("isOpticalFibreMaintainedByBTCL")
	boolean isOpticalFibreMaintenedByBTCL;
	@ColumnName("isOpticalFibreLaidByBTCL")
	boolean isOpticalFibreLaidByBTCL;
	@ColumnName("parentEndPointID")
	long parentEndPointID;
	
	@ColumnName("routerID")
	long routerID;
	
	@ColumnName("currentStatus")
	int currentStatus;
	@ColumnName("latestStatus")
	int latestStatus;
	
	@ColumnName("mandatoryVLanID")
	String mandatoryVLanID;
	@ColumnName("additionalVLanID")
	String additionalVLanID;
	
	@ColumnName("loopDistanceBTCL")
	int loopDistanceBTCL;
	@ColumnName("loopDistanceOC")
	int loopDistanceOC;
	@ColumnName("loopDistanceCustomer")
	int loopDistanceCustomer;	
	@ColumnName("loopDistanceTotal")
	int loopDistanceTotal;
	
	
	
	
	
	
	public long getRouterID() {
		return routerID;
	}

	

	public void setRouterID(long routerID) {
		this.routerID = routerID;
	}

	public boolean isOFCProvidedByBTCL() {
		return ofcProviderTypeID == EndPointConstants.OFC_PROVIDER_BTCL;
	}

	public boolean isOpticalFibreLaidByBTCL() {
		return isOpticalFibreLaidByBTCL;
	}

	public void setOpticalFibreLaidByBTCL(boolean isOpticalFibreLaidByBTCL) {
		this.isOpticalFibreLaidByBTCL = isOpticalFibreLaidByBTCL;
	}

	public boolean isOpticalFibreMaintenedByBTCL() {
		return isOpticalFibreMaintenedByBTCL;
	}

	public void setOpticalFibreMaintenedByBTCL(boolean isOpticalFibreMaintenedByBTCL) {
		this.isOpticalFibreMaintenedByBTCL = isOpticalFibreMaintenedByBTCL;
	}

	public boolean isOpticalFibreRented() {
		return isOpticalFibreRented;
	}

	public void setOpticalFibreRented(boolean isOpticalFibreRented) {
		this.isOpticalFibreRented = isOpticalFibreRented;
	}

	public long getLliEndPointID() {
		return lliEndPointID;
	}

	public void setLliEndPointID(long lliEndPointID) {
		this.lliEndPointID = lliEndPointID;
	}

	public String getName() {
		return Name;
	}

	public void setName(String Name) {
		this.Name = Name;
	}

	public String getVepName() {
		return Name;
	}

	public void setVepName(String Name) {
		this.Name = Name;
	}

	public long getDistrictID() {
		return districtID;
	}

	public void setDistrictID(long districtID) {
		this.districtID = districtID;
	}

	public long getUpazilaID() {
		return upazilaID;
	}

	public void setUpazilaID(long upazilaID) {
		this.upazilaID = upazilaID;
	}

	public long getPopID() {
		return popID;
	}

	public void setPopID(long popID) {
		this.popID = popID;
	}

	public long getUnionID() {
		return unionID;
	}

	public void setUnionID(long unionID) {
		this.unionID = unionID;
	}

	public String getPortCategoryType() {
		return portCategoryType;
	}

	public void setPortCategoryType(String portCategoryType) {
		this.portCategoryType = portCategoryType;
	}

	public boolean isDemandnoteCreated() {
		return isDemandnoteCreated;
	}

	public void setDemandnoteCreated(boolean isDemandnoteCreated) {
		this.isDemandnoteCreated = isDemandnoteCreated;
	}

	public Long getActivationDate() {
		return activationDate;
	}

	public void setActivationDate(Long activationDate) {
		this.activationDate = activationDate;
	}

	public double getDistanceFromNearestPopInMeter() {
		return distanceFromNearestPopInMeter;
	}

	public void setDistanceFromNearestPopInMeter(double distanceFromNearestPopInMeter) {
		this.distanceFromNearestPopInMeter = distanceFromNearestPopInMeter;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getFibreID() {
		return fibreID;
	}

	public void setFibreID(long fibreID) {
		this.fibreID = fibreID;
	}

	public int getFibrePaymentType() {
		return fibrePaymentType;
	}

	public void setFibrePaymentType(int fibrePaymentType) {
		this.fibrePaymentType = fibrePaymentType;
	}

	public double getFibreCost() {
		return fibreCost;
	}

	public void setFibreCost(double fibreCost) {
		this.fibreCost = fibreCost;
	}

	public long getTerminalDevicePaymentID() {
		return terminalDevicePaymentID;
	}

	public void setTerminalDevicePaymentID(long terminalDevicePaymentID) {
		this.terminalDevicePaymentID = terminalDevicePaymentID;
	}

	public long getTerminalDeviceID() {
		return terminalDeviceID;
	}

	public void setTerminalDeviceID(long terminalDeviceID) {
		this.terminalDeviceID = terminalDeviceID;
	}

	public long getFRStartDate() {
		return FRStartDate;
	}

	public void setFRStartDate(long fRStartDate) {
		FRStartDate = fRStartDate;
	}

	public long getFRFeedBackDate() {
		return FRFeedBackDate;
	}

	public void setFRFeedBackDate(long fRFeedBackDate) {
		FRFeedBackDate = fRFeedBackDate;
	}

	public int getFRResult() {
		return FRResult;
	}

	public void setFRResult(int fRResult) {
		FRResult = fRResult;
	}

	public long getFRDeadLine() {
		return FRDeadLine;
	}

	public void setFRDeadLine(long fRDeadLine) {
		FRDeadLine = fRDeadLine;
	}

	public long getFRContractorID() {
		return FRContractorID;
	}

	public void setFRContractorID(long fRContractorID) {
		FRContractorID = fRContractorID;
	}

	public int getConnectionResult() {
		return connectionResult;
	}

	public void setConnectionResult(int connectionResult) {
		this.connectionResult = connectionResult;
	}

	public String getPortType() {
		return portCategoryType;
	}

	public void setPortType(String portType) {
		this.portCategoryType = portType;
	}

	public long getPortID() {
		return portID;
	}

	public void setPortID(long portID) {
		this.portID = portID;
	}

	public long getConnectionEngrID() {
		return connectionEngrID;
	}

	public void setConnectionEngrID(long connectionEngrID) {
		this.connectionEngrID = connectionEngrID;
	}

	public long getLastModificationTime() {
		return lastModificationTime;
	}

	public void setLastModificationTime(long lastModificationTime) {
		this.lastModificationTime = lastModificationTime;
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}


	public int getCoreType() {
		return coreType;
	}

	public void setCoreType(int coreType) {
		this.coreType = coreType;
	}

	public boolean isActivated() {
		return activationDate != 0;
	}

	public double getTerminalDeviceCost() {
		return terminalDeviceCost;
	}

	public void setTerminalDeviceCost(double terminalDeviceCost) {
		this.terminalDeviceCost = terminalDeviceCost;
	}

	public long getClientID() {
		return clientID;
	}

	public void setClientID(long clientID) {
		this.clientID = clientID;
	}

	public int getFibreType() {
		return fibreType;
	}

	public void setFibreType(int fibreType) {
		this.fibreType = fibreType;
	}

	public int getOFCLaidBy() {
		return OFCLaidBy;
	}

	public void setOFCLaidBy(int oFCLaidBy) {
		OFCLaidBy = oFCLaidBy;
	}
	public long getParentEndPointID() {
		return parentEndPointID;
	}

	public void setParentEndPointID(long parentEndPointID) {
		this.parentEndPointID = parentEndPointID;
	}


	public int getTerminalDeviceProvider() {
		return terminalDeviceProvider;
	}

	public void setTerminalDeviceProvider(int terminalDeviceProvider) {
		this.terminalDeviceProvider = terminalDeviceProvider;
	}	
	
	public String getMandatoryVLanID() {
		return mandatoryVLanID;
	}

	public void setMandatoryVLanID(String mandatoryVLanID) {
		this.mandatoryVLanID = mandatoryVLanID;
	}

	public String getAdditionalVLanID() {
		return additionalVLanID;
	}

	public void setAdditionalVLanID(String additionalVLanID) {
		this.additionalVLanID = additionalVLanID;
	}



	public int getLoopDistanceBTCL() {
		return loopDistanceBTCL;
	}

	public void setLoopDistanceBTCL(int loopDistanceBTCL) {
		this.loopDistanceBTCL = loopDistanceBTCL;
	}

	public int getLoopDistanceOC() {
		return loopDistanceOC;
	}

	public void setLoopDistanceOC(int loopDistanceOC) {
		this.loopDistanceOC = loopDistanceOC;
	}

	public int getLoopDistanceTotal() {
		return loopDistanceTotal;
	}

	public void setLoopDistanceTotal(int loopDistanceTotal) {
		this.loopDistanceTotal = loopDistanceTotal;
	}

	
	
	public int getLoopDistanceCustomer() {
		return loopDistanceCustomer;
	}

	public void setLoopDistanceCustomer(int loopDistanceCustomer) {
		this.loopDistanceCustomer = loopDistanceCustomer;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (lliEndPointID ^ (lliEndPointID >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LliEndPointDTO other = (LliEndPointDTO) obj;
		if (lliEndPointID != other.lliEndPointID)
			return false;
		return true;
	}



	@Override
	public String toString() {
		return "LliEndPointDTO [lliEndPointID=" + lliEndPointID + ", Name=" + Name + ", clientID=" + clientID
				+ ", districtID=" + districtID + ", upazilaID=" + upazilaID + ", unionID=" + unionID + ", popID="
				+ popID + ", isDemandnoteCreated=" + isDemandnoteCreated
				+ ", activationDate=" + activationDate + ", distanceFromNearestPopInMeter="
				+ distanceFromNearestPopInMeter + ", address=" + address + ", fibreID=" + fibreID
				+ ", fibrePaymentType=" + fibrePaymentType + ", coreType=" + coreType + ", fibreCost=" + fibreCost
				+ ", terminalDevicePaymentID=" + terminalDevicePaymentID + ", terminalDeviceID=" + terminalDeviceID
				+ ", portCategoryType=" + portCategoryType + ", portID=" + portID + ", FRStartDate=" + FRStartDate
				+ ", FRFeedBackDate=" + FRFeedBackDate + ", FRResult=" + FRResult + ", FRDeadLine=" + FRDeadLine
				+ ", FRContractorID=" + FRContractorID + ", connectionEngrID=" + connectionEngrID
				+ ", lastModificationTime=" + lastModificationTime + ", isDeleted=" + isDeleted + ", connectionResult="
				+ connectionResult + ", terminalDeviceCost=" + terminalDeviceCost + ", fibreType=" + fibreType
				+ ", ofcProviderTypeID=" + ofcProviderTypeID + ", ofcProviderID=" + ofcProviderID
				+ ", terminalDeviceProvider=" + terminalDeviceProvider + ", isOpticalFibreRented="
				+ isOpticalFibreRented + ", OFCLaidBy=" + OFCLaidBy + ",c isOpticalFibreMaintenedByBTCL="
				+ isOpticalFibreMaintenedByBTCL + ", isOpticalFibreLaidByBTCL=" + isOpticalFibreLaidByBTCL
				+ ", parentEndPointID=" + parentEndPointID
				+ ", mandatoryVLanID=" + mandatoryVLanID
				+ ", additionalVLanID=" + additionalVLanID + "]";
	}

	public int getOfcProviderTypeID() {
		return ofcProviderTypeID;
	}
	
	public int getOfcProvider(){
		return ofcProviderTypeID;
	}

	public void setOfcProviderTypeID(int ofcProviderTypeID) {
		this.ofcProviderTypeID = ofcProviderTypeID;
	}
	
	public void setOfcProvider(int ofcProviderTypeID){
		this.ofcProviderTypeID = ofcProviderTypeID;
	}

	public long getOfcProviderID() {
		return ofcProviderID;
	}

	public void setOfcProviderID(long ofcProviderID) {
		this.ofcProviderID = ofcProviderID;
	}

	@Override
	public int getCurrentStatus() {
		return currentStatus;
	}

	@Override
	public int getLatestStatus() {
		return latestStatus;
	}

	@Override
	public void setCurrentStatus(int currentStatus) {
		this.currentStatus = currentStatus;
		
	}

	@Override
	public void setLatestStatus(int latestStatus) {
		this.latestStatus = latestStatus;
	}

	@Override
	public long getEntityID() {
		return lliEndPointID;
	}

	@Override
	public double getBalance() {
		return 0;
	}

	@Override
	public void setBalance(double balance) {
		
	}
}