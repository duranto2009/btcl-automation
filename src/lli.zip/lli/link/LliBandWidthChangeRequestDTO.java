package lli.link;

import annotation.ColumnName;
import annotation.ForeignKeyName;
import annotation.PrimaryKey;
import annotation.TableName;
import request.CommonRequestDTO;

@TableName("at_lli_req_bw_change")
@ForeignKeyName("reqID")
public class LliBandWidthChangeRequestDTO extends CommonRequestDTO{
	
	private static final long serialVersionUID = 5842829470697158424L;
	
	@PrimaryKey
	@ColumnName("ID")
	long ID;
	@ColumnName("lliLkID")
	long linkID;
	
	@ColumnName("newBW")
	long newBandwidth;
	
	@ColumnName("newBWType")
	int newBandwidthType;
	
	@ColumnName("lastModificationTime")
	long lastModificationTime;
	@ColumnName("isDeleted")
	boolean isDeleted;

	@ColumnName("oldFarEndPortType")
	String oldFarPortType;
	@ColumnName("oldFarEndPortID")
	Long oldFarPortID;
	
	@ColumnName("newFarEndPortType")
	String newFarPortType;
	@ColumnName("newFarEndPortID")
	long newFarPortID;
	
	public long getID() {
		return ID;
	}
	public void setID(long iD) {
		ID = iD;
	}
	public long getLinkID() {
		return linkID;
	}
	public void setLinkID(long linkID) {
		this.linkID = linkID;
	}
	public long getNewBandwidth() {
		return newBandwidth;
	}
	public void setNewBandwidth(long newBandwidth) {
		this.newBandwidth = newBandwidth;
	}
	public long getLastModificationTime() {
		return lastModificationTime;
	}
	public void setLastModificationTime(long lastModificationTime) {
		this.lastModificationTime = lastModificationTime;
	}
	public boolean isDeleted() {
		return isDeleted;
	}
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	public String getOldFarPortType() {
		return oldFarPortType;
	}
	public void setOldFarPortType(String oldFarPortType) {
		this.oldFarPortType = oldFarPortType;
	}
	public long getOldFarPortID() {
		return oldFarPortID;
	}
	public void setOldFarPortID(long oldFarPortID) {
		this.oldFarPortID = oldFarPortID;
	}
	public String getNewFarPortType() {
		return newFarPortType;
	}
	public void setNewFarPortType(String newFarPortType) {
		this.newFarPortType = newFarPortType;
	}
	public Long getNewFarPortID() {
		return newFarPortID;
	}
	public void setNewFarPortID(long newFarPortID) {
		this.newFarPortID = newFarPortID;
	}
	public int getNewBandwidthType() {
		return newBandwidthType;
	}
	public void setNewBandwidthType(int newBandwidthType) {
		this.newBandwidthType = newBandwidthType;
	}
	
}
