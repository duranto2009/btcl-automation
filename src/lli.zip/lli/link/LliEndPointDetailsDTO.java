package lli.link;

public class LliEndPointDetailsDTO {
	long ID;
	long lliEndPointID;
	short endPointType;
	String vepName;
	long districtId;
	String districtName;
	long upazilaId;
	String upazilaName;
	long unionId;
	String unionName;
	long popID;
	String popName;
	long routerID;
	String routerName;
	String mandatoryVlanID;
	String mandatoryVlanName;
	String additionalVlanIDs;
	String additionalVlanNames;
	String portCategoryType;// FE or GE
	String portCateogryTypeName;
	long portID;
	String portName;
	
	int coreType;
	double distanceFromNearestPopInMeter;
	String localLoopDistance;
	String address;
	
	int vepFibreType;
	int ofcProviderTypeID;
	int ofcProviderID;
	int terminalDeviceProvider;

	public long getID() {
		return ID;
	}

	public void setID(long ID) {
		this.ID = ID;
	}

	public long getLliEndPointID() {
		return lliEndPointID;
	}

	public void setLliEndPointID(long lliEndPointID) {
		this.lliEndPointID = lliEndPointID;
	}

	public short getEndPointType() {
		return endPointType;
	}

	public void setEndPointType(short endPointType) {
		this.endPointType = endPointType;
	}

	public String getVepName() {
		return vepName;
	}

	public void setVepName(String vepName) {
		this.vepName = vepName;
	}

	public long getDistrictId() {
		return districtId;
	}

	public void setDistrictId(long districtId) {
		this.districtId = districtId;
	}

	public String getDistrictName() {
		return districtName;
	}

	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}

	public long getUpazilaId() {
		return upazilaId;
	}

	public void setUpazilaId(long upazilaId) {
		this.upazilaId = upazilaId;
	}

	public String getUpazilaName() {
		return upazilaName;
	}

	public void setUpazilaName(String upazilaName) {
		this.upazilaName = upazilaName;
	}

	public long getUnionId() {
		return unionId;
	}

	public void setUnionId(long unionId) {
		this.unionId = unionId;
	}

	public String getUnionName() {
		return unionName;
	}

	public void setUnionName(String unionName) {
		this.unionName = unionName;
	}

	public long getPopID() {
		return popID;
	}

	public void setPopID(long popID) {
		this.popID = popID;
	}

	public String getPopName() {
		return popName;
	}

	public void setPopName(String popName) {
		this.popName = popName;
	}

	public String getPortName() {
		return portName;
	}

	public void setPortName(String portName) {
		this.portName = portName;
	}

	public double getDistanceFromNearestPopInMeter() {
		return distanceFromNearestPopInMeter;
	}

	public void setDistanceFromNearestPopInMeter(double distanceFromNearestPopInMeter) {
		this.distanceFromNearestPopInMeter = distanceFromNearestPopInMeter;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPortCategoryType() {
		return portCategoryType;
	}

	public void setPortCategoryType(String portCategoryType) {
		this.portCategoryType = portCategoryType;
	}

	public String getPortCateogryTypeName() {
		return portCateogryTypeName;
	}

	public void setPortCateogryTypeName(String portCateogryTypeName) {
		this.portCateogryTypeName = portCateogryTypeName;
	}

	public int getVepFibreType() {
		return vepFibreType;
	}

	public void setVepFibreType(int vepFibreType) {
		this.vepFibreType = vepFibreType;
	}

	public int getOfcProviderTypeID() {
		return ofcProviderTypeID;
	}

	public void setOfcProviderTypeID(int ofcProviderTypeID) {
		this.ofcProviderTypeID = ofcProviderTypeID;
	}

	public int getOfcProviderID() {
		return ofcProviderID;
	}

	public void setOfcProviderID(int ofcProvider) {
		this.ofcProviderID = ofcProvider;
	}

	public int getTerminalDeviceProvider() {
		return terminalDeviceProvider;
	}

	public void setTerminalDeviceProvider(int terminalDeviceProvider) {
		this.terminalDeviceProvider = terminalDeviceProvider;
	}

	public int getCoreType() {
		return coreType;
	}

	public void setCoreType(int coreType) {
		this.coreType = coreType;
	}

	public String getLocalLoopDistance() {
		return localLoopDistance;
	}

	public void setLocalLoopDistance(String localLoopDistance) {
		this.localLoopDistance = localLoopDistance;
	}

	public long getPortID() {
		return portID;
	}

	public void setPortID(long portID) {
		this.portID = portID;
	}

	public long getRouterID() {
		return routerID;
	}

	public void setRouterID(long routerID) {
		this.routerID = routerID;
	}

	public String getRouterName() {
		return routerName;
	}

	public void setRouterName(String routerName) {
		this.routerName = routerName;
	}

	public String getMandatoryVlanID() {
		return mandatoryVlanID;
	}

	public void setMandatoryVlanID(String mandatoryVlanID) {
		this.mandatoryVlanID = mandatoryVlanID;
	}

	public String getMandatoryVlanName() {
		return mandatoryVlanName;
	}

	public void setMandatoryVlanName(String mandatoryVlanName) {
		this.mandatoryVlanName = mandatoryVlanName;
	}

	public String getAdditionalVlanIDs() {
		return additionalVlanIDs;
	}

	public void setAdditionalVlanIDs(String additionalVlanIDs) {
		this.additionalVlanIDs = additionalVlanIDs;
	}

	public String getAdditionalVlanNames() {
		return additionalVlanNames;
	}

	public void setAdditionalVlanNames(String additionalVlanNames) {
		this.additionalVlanNames = additionalVlanNames;
	}

	@Override
	public String toString() {
		return "LliEndPointDetailsDTO [ID=" + ID + ", lliEndPointID=" + lliEndPointID
				+ ", endPointType=" + endPointType + ", vepName=" + vepName + ", districtId=" + districtId
				+ ", districtName=" + districtName + ", upazilaId=" + upazilaId + ", upazilaName=" + upazilaName
				+ ", unionId=" + unionId + ", unionName=" + unionName + ", popID=" + popID + ", popName=" + popName
				+ ", routerID=" + routerID + ", routerName=" + routerName +", mandatoryVlanID=" + mandatoryVlanID + ", mandatoryVlanName=" + mandatoryVlanName
				+ ", additionalVlanIDs=" + additionalVlanIDs + ", additionalVlanNames=" + additionalVlanNames
				+ ", portCategoryType=" + portCategoryType + ", portCateogryTypeName=" + portCateogryTypeName
				+ ", portID=" + portID + ", coreType=" + coreType + ", distanceFromNearestPopInMeter="
				+ distanceFromNearestPopInMeter + ", localLoopDistance=" + localLoopDistance + ", address=" + address
				+ ", vepFibreType=" + vepFibreType + ", ofcProviderTypeID=" + ofcProviderTypeID + ", ofcProviderID="
				+ ofcProviderID + ", terminalDeviceProvider=" + terminalDeviceProvider + "]";
	}

}
