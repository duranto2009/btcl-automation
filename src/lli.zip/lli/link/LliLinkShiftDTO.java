package lli.link;

import annotation.ColumnName;
import annotation.ForeignKeyName;
import annotation.PrimaryKey;
import annotation.TableName;
import request.CommonRequestDTO;

@TableName("at_lli_req_shift")
@ForeignKeyName("reqID")
public class LliLinkShiftDTO extends CommonRequestDTO{

	private static final long serialVersionUID = 1L;
	@PrimaryKey
	@ColumnName("ID")
	private Long ID;
	@ColumnName("lliLinkID")
	private Long lliLinkID;
	@ColumnName("feShiftMode")
	private Integer feShiftMode;
	@ColumnName("feName")
	private String feName;
	@ColumnName("feID")
	private Long feID;
	@ColumnName("feEndPointID")
	private Long feEndPointID;
	@ColumnName("feDistrictID")
	private Long feDistrictID;
	@ColumnName("feUpazilaID")
	private Long feUpazilaID;
	@ColumnName("feUnionID")
	private Long feUnionID;
	@ColumnName("fePopID")
	private Long fePopID;
	@ColumnName("fePortType")
	private String fePortType;
	@ColumnName("feAddress")
	private String feAddress;
	@ColumnName("feCoreType")
	private Integer feCoreType;
	@ColumnName("feOfcProvider")
	private Integer feOfcProvider;
	@ColumnName("feTerminalDeviceProvider")
	private Integer feTerminalDeviceProvider;
	@ColumnName("feRouterID")
	private Long feRouterID;
	@ColumnName("fePortID")
	private Long fePortID;
	@ColumnName("feMandatoryVLanID")
	private String feMandatoryVLanID;
	@ColumnName("feAdditionalVLanID")
	private String feAdditionalVLanID;
	@ColumnName("shiftCompletionStatus")
	private Boolean shiftCompletionStatus;


	public Long getID() {
		return ID;
	}

	public void setID(Long iD) {
		ID = iD;
	}


	public Long getLliLinkID() {
		return lliLinkID;
	}


	public void setLliLinkID(Long lliLinkID) {
		this.lliLinkID = lliLinkID;
	}


	public Integer getFeShiftMode() {
		return feShiftMode;
	}


	public void setFeShiftMode(Integer feShiftMode) {
		this.feShiftMode = feShiftMode;
	}


	public String getFeName() {
		return feName;
	}


	public void setFeName(String feName) {
		this.feName = feName;
	}


	public Long getFeID() {
		return feID;
	}


	public void setFeID(Long feID) {
		this.feID = feID;
	}


	public Long getFeEndPointID() {
		return feEndPointID;
	}


	public void setFeEndPointID(Long feEndPointID) {
		this.feEndPointID = feEndPointID;
	}


	public Long getFeDistrictID() {
		return feDistrictID;
	}


	public void setFeDistrictID(Long feDistrictID) {
		this.feDistrictID = feDistrictID;
	}


	public Long getFeUpazilaID() {
		return feUpazilaID;
	}


	public void setFeUpazilaID(Long feUpazilaID) {
		this.feUpazilaID = feUpazilaID;
	}


	public Long getFeUnionID() {
		return feUnionID;
	}


	public void setFeUnionID(Long feUnionID) {
		this.feUnionID = feUnionID;
	}


	public Long getFePopID() {
		return fePopID;
	}


	public void setFePopID(Long fePopID) {
		this.fePopID = fePopID;
	}


	public String getFePortType() {
		return fePortType;
	}


	public void setFePortType(String fePortType) {
		this.fePortType = fePortType;
	}


	public String getFeAddress() {
		return feAddress;
	}


	public void setFeAddress(String feAddress) {
		this.feAddress = feAddress;
	}


	public Integer getFeCoreType() {
		return feCoreType;
	}


	public void setFeCoreType(Integer feCoreType) {
		this.feCoreType = feCoreType;
	}


	public Integer getFeOfcProvider() {
		return feOfcProvider;
	}


	public void setFeOfcProvider(Integer feOfcProvider) {
		this.feOfcProvider = feOfcProvider;
	}


	public Integer getFeTerminalDeviceProvider() {
		return feTerminalDeviceProvider;
	}


	public void setFeTerminalDeviceProvider(Integer feTerminalDeviceProvider) {
		this.feTerminalDeviceProvider = feTerminalDeviceProvider;
	}


	public Long getFeRouterID() {
		return feRouterID;
	}


	public void setFeRouterID(Long feRouterID) {
		this.feRouterID = feRouterID;
	}


	public Long getFePortID() {
		return fePortID;
	}


	public void setFePortID(Long fePortID) {
		this.fePortID = fePortID;
	}


	public String getFeMandatoryVLanID() {
		return feMandatoryVLanID;
	}


	public void setFeMandatoryVLanID(String feMandatoryVLanID) {
		this.feMandatoryVLanID = feMandatoryVLanID;
	}


	public String getFeAdditionalVLanID() {
		return feAdditionalVLanID;
	}


	public void setFeAdditionalVLanID(String feAdditionalVLanID) {
		this.feAdditionalVLanID = feAdditionalVLanID;
	}


	public Boolean getShiftCompletionStatus() {
		return shiftCompletionStatus;
	}


	public void setShiftCompletionStatus(Boolean shiftCompletionStatus) {
		this.shiftCompletionStatus = shiftCompletionStatus;
	}
	
	
}
