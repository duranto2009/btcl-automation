package lli.link;

import org.apache.struts.action.ActionForm;

import annotation.ColumnName;
import annotation.TableName;

@TableName("at_lli_pop")
public class LliPOP extends ActionForm{
	@ColumnName("ID")
	long ID;
	@ColumnName("name")
	String name;
	@ColumnName("")
	int districtID;
	@ColumnName("address")
	String address;
	@ColumnName("")
	String officerInChageName;
	@ColumnName("")
	String officerDesignation;
	@ColumnName("lastModificationTime")
	long lastModificationTime;
	@ColumnName("isDeleted")
	boolean isDeleted;
	public long getID() {
		return ID;
	}
	public void setID(long iD) {
		ID = iD;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getLastModificationTime() {
		return lastModificationTime;
	}
	public void setLastModificationTime(long lastModificationTime) {
		this.lastModificationTime = lastModificationTime;
	}
	public boolean isDeleted() {
		return isDeleted;
	}
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	
	public int getDistrictID() {
		return districtID;
	}
	public void setDistrictID(int districtID) {
		this.districtID = districtID;
	}
	public String getOfficerInChageName() {
		return officerInChageName;
	}
	public void setOfficerInChageName(String officerInChageName) {
		this.officerInChageName = officerInChageName;
	}
	public String getOfficerDesignation() {
		return officerDesignation;
	}
	public void setOfficerDesignation(String officerDesignation) {
		this.officerDesignation = officerDesignation;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (ID ^ (ID >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LliPOP other = (LliPOP) obj;
		if (ID != other.ID)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "LliPOP [ID=" + ID + ", name=" + name + ", districtID="
				+ districtID + ", address=" + address + ", officerInChageName="
				+ officerInChageName + ", officerDesignation="
				+ officerDesignation + ", lastModificationTime="
				+ lastModificationTime + ", isDeleted=" + isDeleted + "]";
	}
	
}
