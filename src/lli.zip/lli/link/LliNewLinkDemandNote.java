package lli.link;

import org.apache.log4j.Logger;

import common.bill.BillDTO;
import connection.DatabaseConnection;

public class LliNewLinkDemandNote extends BillDTO {
	Logger logger = Logger.getLogger(getClass());
	
	public LliNewLinkDemandNote(){

		setClassName(LliNewLinkDemandNote.class.getName());

	}

	@Override
	public void payBill(DatabaseConnection databaseConnection, Object...objects ) throws Exception {
		
		long currentTime = System.currentTimeMillis();
		/*
		 * 
		 * Change link state to paid
		 */
	}
}
