package lli.link;

public class LliInternalFRDataLocation {

	public boolean clienntNameEditable = false;
	public boolean servicePurposeEditable = false;
	public boolean isMigratedEditable = false;
	public boolean bandwidthEditable = false;
	public boolean connectionTypeEditable = false;
	public boolean commentEditable = false;
	
	public boolean connectionNameEditable = false;
	public boolean farEndDistrictEditable = false;
	public boolean farEndUpazilaEditable = false;
	public boolean farEndUnionEditable = false;
	public boolean farEndAddressEditable = false;
	
	
	public boolean farEndPopInFRResponse = false;
	public boolean farEndPopInEndpointDTO = false;			
	public boolean farEndPortInFRResponse = false;
	public boolean farEndPortInEndpointDTO = false;
	public boolean farEndSlotInFRResponse = false;
	public boolean farEndSlotInEndpointDTO = false;
	
	public boolean mandatoryIPInFRResponse = false;
	public boolean mandatoryIPInEndpointDTO = false;
	
	public boolean additionalIPInFRResponse = false;
	public boolean additionalIPInEndpointDTO = false;
}
