package lli.link;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Savepoint;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionRedirect;

import com.uwyn.jhighlight.tools.ExceptionUtils;

import annotation.Transactional;
import client.ClientTypeService;
import common.BulkBillCreationSummary;
import common.CommonActionStatusDTO;
import common.CommonDAO;
import common.EntityTypeConstant;
import common.ModuleConstants;
import common.RegistrantTypeConstants;
import common.RequestFailureException;
import common.StringUtils;
import common.UniversalDTOService;
import common.bill.BillConstants;
import common.bill.BillDAO;
import common.bill.BillDTO;
import common.note.CommonNote;
import common.note.CommonNoteConstants;
import common.note.CommonNoteService;
import common.payment.PaymentDAO;
import common.repository.AllClientRepository;
import connection.DatabaseConnection;
import costConfig.CostConfigService;
import costConfig.TableDTO;
import file.FileDTO;
import file.FileService;
import inventory.InventoryItemDetails;
import inventory.InventoryService;
import ipaddress.IpAddressService;
import ipaddress.IpBlock;
import lli.LliConnectionRepository;
import lli.LliDAO;
import lli.LliLinkSearchDAO;
import lli.LliUtil;
import lli.bill.BillUtil;
import lli.bill.LliBillDTO;
import lli.configuration.LLICostConfigurationDAO;
import lli.configuration.LLIOTCConfigurationDTO;
import lli.constants.EndPointConstants;
import lli.constants.LliRequestTypeConstants;
import lli.link.request.LliLinkRequestConstants;
import lli.link.request.LliLinkRequestService;
import login.ColumnPermissionConstants;
import login.LoginDTO;
import notification.NotificationService;
import permission.PermissionService;
import request.CommonRequestDTO;
import request.CommonRequestStatusDTO;
import request.EntityActionGenerator;
import request.RequestActionStateRepository;
import request.RequestDAO;
import request.RequestStatus;
import request.RequestUtilDAO;
import request.RequestUtilService;
import request.StateDTO;
import request.StateRepository;
import requestMapping.Service;
import user.UserRepository;
import util.ActivityLogDAO;
import util.ActivityLogDTO;
import util.CurrentTimeFactory;
import util.DatabaseConnectionFactory;
import util.DateUtils;
import util.ModifiedSqlGenerator;
import util.NavigationService;
import util.ServiceDAOFactory;
import util.SqlGenerator;
import util.TimeConverter;
import util.TransactionType;
import util.UtilService;
import vpn.client.ClientDetailsDTO;
import vpn.constants.VpnRequestTypeConstants;


public class LliLinkService implements NavigationService {

	@Service
	UniversalDTOService universalDTOService;
	
	@Service
	CostConfigService costConfigService;
	
	@Service
	IpAddressService ipAddressService;
	
	static Logger logger = Logger.getLogger(LliLinkService.class);
	LliDAO lliDAO = new LliDAO();
	PaymentDAO paymentDAO = new PaymentDAO();
	LliLinkSearchDAO lliLinkDAO = new LliLinkSearchDAO();
	RequestDAO requestDAO = new RequestDAO();
	ActivityLogDAO activityLogDAO = new ActivityLogDAO();
	CommonDAO commonDAO = new CommonDAO();
	RequestUtilDAO requestUtilDAO = new RequestUtilDAO();
	// DemandNoteDAO demandNoteDAO = new DemandNoteDAO();
	ActivityLogDTO activityLogDTO;
	long currentTime;
	

	public void cancellLLIBillByBillIDList(List<Long> billIDList) throws Exception{
		// to be filled up by kayesh vai
	}
	
	
	
	
	public void generateDemandNoteForIpAddress(LliLinkDTO lliLinkDTO, LliBillDTO billDTO, long reqID, long expirationDate, int noOfAdditionalIp ) throws Exception {

		DatabaseConnection databaseConnection = new DatabaseConnection();
		
		try {
			
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			
			
			
			databaseConnection.dbTransationEnd();
		}
		catch( Exception e ) {
			
			e.printStackTrace();
			databaseConnection.dbTransationRollBack();
			throw e;
		}
		finally {
			
			databaseConnection.dbClose();
		}
	}
	
	public int getTotalLinkFromConnectionID(long connectionID) throws Exception {
		DatabaseConnection databaseConnection = new DatabaseConnection();
		int totalConnection = 0;
		try {
			databaseConnection.dbOpen();
			// databaseConnection.dbTransationStart();

		} catch (Exception ex) {
			try {
				logger.fatal("Fatal: ", ex);
				// databaseConnection.dbTransationRollBack();
			} catch (Exception ex2) {
				// throw ex;
			}
		} finally {
			databaseConnection.dbClose();
		}
		return totalConnection;
	}

	public LliLinkDTO addLink(LliNewLinkCreateDTO lliNewLinkCreateDTO,  HttpServletRequest request, LoginDTO loginDTO) throws Exception {
		
		DatabaseConnection databaseConnection = new DatabaseConnection();		
		LliUtil lliUtil = new LliUtil();
		LliLinkDTO lliLinkDTO = new LliLinkDTO();
		
		try {
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			currentTime = System.currentTimeMillis();
			
			// 1. Create Far End DTO
			LliFarEndDTO lliFarEndDTO = createLliFarEndDTO(lliNewLinkCreateDTO, loginDTO);
			addFarEnd(lliFarEndDTO, databaseConnection, loginDTO);
			
			// 2. Create LLI Link DTO
			lliLinkDTO = createLliLinkDTO(lliNewLinkCreateDTO, lliFarEndDTO.getID());
			lliLinkDTO.setClientID(!loginDTO.getIsAdmin() ? loginDTO.getAccountID() : lliNewLinkCreateDTO.getClientID());
			lliLinkDTO.setLinkName(lliFarEndDTO.getName());
			lliLinkDTO.setServicePurpose(lliNewLinkCreateDTO.getServicePurpose());
			lliDAO.addLliLink(lliLinkDTO, databaseConnection);
			
			// 3. Upload Documents
			if (lliLinkDTO.getDocuments() != null && lliLinkDTO.getDocuments().length>0) {
				uploadDocuments(lliLinkDTO, loginDTO,  databaseConnection);
			}

			CommonRequestDTO lliLinkReqDTO = lliUtil.prepareBasicLinkRequestDTO(lliLinkDTO, request, loginDTO);
			requestDAO.addLliLinkRequest(lliLinkReqDTO, databaseConnection);
			
			databaseConnection.dbTransationEnd();
			
		} catch (Exception ex) {
			try {
				databaseConnection.dbTransationRollBack();
			} catch (Exception ex2) {
				logger.fatal(ex2);
			}
			logger.fatal("Fatal: ", ex);
			new CommonActionStatusDTO(CommonActionStatusDTO.ERROR_STATUS_CODE, "Connection Request Could Not Be Submitted. Please try again after some time.");
		} finally {
			databaseConnection.dbClose();
		}
		
		return lliLinkDTO;
	}
	
	public LliInternalFRDataLocation getInternalFRDataLocationForEdit(LliLinkDTO lliLinkDTO, LliFarEndDTO lliFarEndDTO, int requestTypeID) {
		return lliDAO.getInternalFRDataLocationForEdit(lliLinkDTO,lliFarEndDTO, requestTypeID);
	}

	

	/*private void addNearEndRequest(LliNearEndDTO lliNearEndDTO, CommonRequestDTO lliLinkReqDTO, HttpServletRequest request, LoginDTO loginDTO,
			DatabaseConnection databaseConnection) throws Exception {
		CommonRequestDTO commonRequestDTO = new CommonRequestDTO();
		commonRequestDTO.setRequestTime(currentTime);
		commonRequestDTO.setRequestTypeID(LliRequestTypeConstants.REQUEST_NEW_LINK.CLIENT_APPLY_NEAR_END);
		commonRequestDTO.setEntityTypeID(EntityTypeConstant.LLI_LINK_NEAR_END);
		commonRequestDTO.setEntityID(lliNearEndDTO.getID());
		commonRequestDTO.setRootReqID(null);
		commonRequestDTO.setParentReqID(lliLinkReqDTO.getReqID());
		commonRequestDTO.setClientID(lliLinkReqDTO.getClientID());
		if (loginDTO.getIsAdmin()) {
			commonRequestDTO.setRequestByAccountID(-loginDTO.getUserID());
		} else {
			commonRequestDTO.setRequestByAccountID(loginDTO.getAccountID());
		}
		commonRequestDTO.setLastModificationTime(currentTime);
		commonRequestDTO.setIP(request.getRemoteAddr());
		commonRequestDTO.setDescription("Client requests for a Lli link near end.");
		requestDAO.addEndPointRequest(commonRequestDTO, databaseConnection);
	}*/

	public void editLink(LliNewLinkCreateDTO lliNewLinkCreateDTO, HttpServletRequest request, LoginDTO loginDTO) throws Exception {
		DatabaseConnection databaseConnection = new DatabaseConnection();
		CommonRequestStatusDTO commonRequestStatusDTO = new CommonRequestStatusDTO();
		LliUtil lliUtil = new LliUtil();
		boolean successful = false;
		CommonRequestDTO commonRequestDTO = null;
		try {
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			currentTime = System.currentTimeMillis();
			
			LliLinkDTO oldLliLinkDTO = this.getLliLinkByLliLinkID(lliNewLinkCreateDTO.getEntityID());

			LliFarEndDTO lliFarEndDTO = createLliFarEndDTO(lliNewLinkCreateDTO, loginDTO);
			lliFarEndDTO.setID(oldLliLinkDTO.getFarEndID());
			/*
			if(lliFarEndDTO.getID()>0 && oldLliLinkDTO.getFarEndID()!=lliFarEndDTO.getID()){
				lliFarEndDTO=getFarEndByFarEndID(lliFarEndDTO.getID());
				lliFarEndDTO.setLliEndPointID(lliNewLinkCreateDTO.getFarEndPointID());
				lliFarEndDTO.setID(oldLliLinkDTO.getFarEndID());
			}else if(oldLliLinkDTO.getFarEndID()==lliFarEndDTO.getID()){
				lliFarEndDTO=getFarEndByFarEndID(oldLliLinkDTO.getFarEndID());
			}else{
				lliFarEndDTO.setLliEndPointID(lliNewLinkCreateDTO.getFarEndPointID());
				lliFarEndDTO.setID(oldLliLinkDTO.getFarEndID());
			}
			*/
			
			lliDAO.updateLliFarEnd(lliFarEndDTO, databaseConnection);
			

			LliLinkDTO lliLinkDTO = createLliLinkDTO(lliNewLinkCreateDTO, lliFarEndDTO.getID());
			if (!loginDTO.getIsAdmin()) {
				lliLinkDTO.setClientID(loginDTO.getAccountID());
			} else {
				lliLinkDTO.setClientID(lliNewLinkCreateDTO.getClientID());
			}
			
			lliDAO.updateLliLink(lliLinkDTO, databaseConnection);			
			
			
			logger.info("before file upload");
			logger.debug(lliLinkDTO.getDocuments());
			if (lliLinkDTO.getDocuments() != null && lliLinkDTO.getDocuments().length>0) {
				// Upload logic for document
				uploadDocuments(lliLinkDTO, loginDTO,  databaseConnection);
			}
			
			commonRequestDTO = handleLinkUpdateRequest(lliLinkDTO, loginDTO, databaseConnection);
			
			databaseConnection.dbTransationEnd();
			successful = true;
			
		} catch (Exception ex) {
			logger.debug(ex);
			try {
				logger.fatal("Fatal: ", ex);
				databaseConnection.dbTransationRollBack();
			} catch (Exception ex2) {
				throw ex;
			}
			throw ex;
		} finally {
			databaseConnection.dbClose();
		}
		
		new NotificationService().sendNotification(commonRequestDTO);
	}

	public Boolean isLinkVerified(Long lliLinkID) {
		return !(getLliLinkByLliLinkID(lliLinkID).getCurrentStatus() == LliRequestTypeConstants.REQUEST_NEW_LINK.CLIENT_APPLY);
	}
	
	public CommonRequestDTO handleLinkUpdateRequest(LliLinkDTO lliLinkDTO, LoginDTO loginDTO,
			DatabaseConnection databaseConnection) throws Exception {
		int moduleID = ModuleConstants.Module_ID_LLI;
				
		CommonRequestDTO commonRequestDTO = new CommonRequestDTO();
	
		StateDTO latestStateDTO = StateRepository.getInstance().getStateDTOByStateID(lliLinkDTO.getLatestStatus());
		StateDTO currentStateDTO = StateRepository.getInstance().getStateDTOByStateID(lliLinkDTO.getCurrentStatus());
		boolean latestStatusActive = (latestStateDTO.getActivationStatus() == EntityTypeConstant.STATUS_ACTIVE);		
		boolean currentStatusActive = (currentStateDTO.getActivationStatus() == EntityTypeConstant.STATUS_ACTIVE);
		boolean inAFlow = (!currentStatusActive || (currentStatusActive && !latestStatusActive));
		int UPDATE_REQUEST = (moduleID * ModuleConstants.MULTIPLIER) + 102;
		if(inAFlow)
		{
			commonRequestDTO.setEntityID(lliLinkDTO.getID());
			commonRequestDTO.setEntityTypeID(EntityTypeConstant.LLI_LINK);
			Set<CommonRequestDTO> bottomSet = requestUtilDAO.getBottomRequestDTOsByEntity(commonRequestDTO, databaseConnection);
			commonRequestDTO = bottomSet.iterator().next();
			commonRequestDTO.setRootReqID(commonRequestDTO.getRootReqID() == null ? commonRequestDTO.getReqID() : commonRequestDTO.getRootReqID());
			requestUtilDAO.updateRequestByRequestID(commonRequestDTO.getReqID(), databaseConnection);
			
			commonRequestDTO.setRequestToAccountID(null);
			commonRequestDTO.setRequestByAccountID(loginDTO.getAccountID() > 0 ? loginDTO.getAccountID() : -loginDTO.getUserID());
			commonRequestDTO.setSourceRequestID(""+commonRequestDTO.getReqID());
			commonRequestDTO.setRequestTypeID(UPDATE_REQUEST);
			int nextState = RequestActionStateRepository.getInstance().getActionStateDTOActionTypeID(commonRequestDTO.getRequestTypeID()).getNextStateID();
			commonRequestDTO.setExpireTime(System.currentTimeMillis() +  StateRepository.getInstance().getStateDTOByStateID(nextState).getDurationInMillis());
			commonRequestDTO.setDescription("Client profile updated.");
			
		}
		else
		{
			commonRequestDTO = createCommonRequestDTO(lliLinkDTO, loginDTO);			
		}

		requestDAO.addRequest(commonRequestDTO, loginDTO.getLoginSourceIP(), databaseConnection);

		return commonRequestDTO;				
		
	}
	
	@Transactional
	public BulkBillCreationSummary generateLliMonthlyBill(long fromTime, long toTime) throws Exception{
		List<LliLinkDTO>  lliLinkDTOs = new LliLinkSearchDAO().getActiveLliLinks(DatabaseConnectionFactory.getCurrentDatabaseConnection());
		return generateLliMonthlyBillByLinkDTOList(fromTime, toTime, lliLinkDTOs);
	}
	
	
	@Transactional
	public BulkBillCreationSummary generateLLIMonthlyBill(long fromTime,long toTime,List<Long> linkIDList) throws Exception{
		
		List<LliLinkDTO> lliListDTOs = (List<LliLinkDTO>)lliLinkDAO.getLliLinkDTOs(linkIDList);
		
		return generateLliMonthlyBillByLinkDTOList(fromTime, toTime, lliListDTOs);
		
	}
	
	@Transactional(transactionType=TransactionType.INDIVIDUAL_TRANSACTION)
	public BulkBillCreationSummary generateLliMonthlyBillByLinkDTOList(long fromTime, long toTime, List<LliLinkDTO> lliLinkDTOs) throws Exception{
		
		if(lliLinkDTOs.isEmpty()){
			BulkBillCreationSummary billCreationSummary = new BulkBillCreationSummary();
			billCreationSummary.listOfEntityIDForFailedAttemp = Collections.emptyList();
			billCreationSummary.numberOfCreatedBill = 0;
			billCreationSummary.numberOfExpectedBill = 0;
			billCreationSummary.numberOfFailedAttemp = 0;
			
			return billCreationSummary;
		}
		
		
		Map<Long,LliFarEndDTO> mapOfLliFarEndDTOToFarEndID = new HashMap<>();
		List<LliFarEndDTO> lliFarEndDTOs = ModifiedSqlGenerator.getAllObjectListFullyPopulated(LliFarEndDTO.class, " where "+ModifiedSqlGenerator.getColumnName(LliFarEndDTO.class, "isDeleted")+"=0");
		for(LliFarEndDTO lliFarEndDTO: lliFarEndDTOs){
			mapOfLliFarEndDTOToFarEndID.put(lliFarEndDTO.getID(), lliFarEndDTO);
		}

		Calendar c = Calendar.getInstance();
		c.setTimeInMillis( fromTime );
		
		HashMap<Integer, List<TableDTO>> mapCostTablesByCategoryID = new HashMap<>();
		for(int i = 1; i <= 4; i++)
		{
			List<TableDTO> costTableDTOs = costConfigService.getActiveCostTableDTOByTimeRangeAndModuleIDAndCategoryID(fromTime, toTime,ModuleConstants.Module_ID_LLI, i);
			logger.debug("i= " + i + " costTableDTOs " + costTableDTOs);
			mapCostTablesByCategoryID.put(i, costTableDTOs);
		}
		
		logger.debug("mapCostTablesByCategoryID " + mapCostTablesByCategoryID);
		
		int numOfFailedAttemp = 0;
		int numOfSuccessfulAttemp = 0;
		StringBuilder stringBuilder = new StringBuilder();
		BulkBillCreationSummary billCreationSummary = new BulkBillCreationSummary();
		RequestDAO requestDAO = new RequestDAO();
		BillDAO billDAO = new BillDAO();
		DatabaseConnection databaseConnection = DatabaseConnectionFactory.getCurrentDatabaseConnection();
		String idStr = "(";
		int count = 0;
		for(LliLinkDTO lliLinkDTO: lliLinkDTOs)
		{			
			idStr += lliLinkDTO.getID();
			if(count < lliLinkDTOs.size() - 1)
			{
				idStr += ",";
			}
			count++;
		}
		idStr += ")";
		String conditionString = " where " + SqlGenerator.getColumnName(BillDTO.class, "entityID") + " in " + idStr 
				+ " and " + SqlGenerator.getColumnName(BillDTO.class, "entityTypeID") + " = " + EntityTypeConstant.LLI_LINK
				+ " and (" + SqlGenerator.getColumnName(BillDTO.class, "billType") + " = " + BillConstants.MONTHLY_BILL + " or " + SqlGenerator.getColumnName(BillDTO.class, "billType") + " = " + BillConstants.MONTHLY_BILL_ADVANCED + " )"  
				+ " and " + SqlGenerator.getColumnName(BillDTO.class, "isDeleted") + " = 0 and "
				+ " GREATEST("+SqlGenerator.getColumnName(BillDTO.class, "activationTimeFrom")+","+fromTime+") <= LEAST("+SqlGenerator.getColumnName(BillDTO.class, "activationTimeTo")+","+toTime+")";
		List<BillDTO> billList = SqlGenerator.getAllObjectList(BillDTO.class, databaseConnection, conditionString);
		Set<Long> entityIDToReject = new HashSet<Long>();
		for(BillDTO billDTO: billList)
		{
			entityIDToReject.add(billDTO.getEntityID());
		}
		List<LLIOTCConfigurationDTO> commonCharges = new LLICostConfigurationDAO().getCommonChargeDTOListByDateRange(fromTime, toTime);
		
		for(LliLinkDTO lliLinkDTO: lliLinkDTOs){
			Savepoint savepoint = null;
			try{
				if(entityIDToReject.contains(lliLinkDTO.getID())) 
				{	
					//insert into a reasonMap
					System.out.println("ignoring");
					continue;
				}
				databaseConnection.dbTransationStart();
				savepoint = databaseConnection.getSavePoint();

				int categoryID = new ClientTypeService().getClientCategoryByModuleIDAndClientID( ModuleConstants.Module_ID_LLI, lliLinkDTO.getClientID() );
				logger.debug("categoryID " + categoryID + " for client Id " + lliLinkDTO.getClientID());
				LliBillDTO lliBillDTO =  createLliBillDTO(lliLinkDTO, mapCostTablesByCategoryID.get(categoryID), mapOfLliFarEndDTOToFarEndID, fromTime, toTime,commonCharges);		
				CommonRequestDTO commonRequestDTO = createCommonRequestDTOForNewMonthlyBill(lliBillDTO);
				requestDAO.addRequest(commonRequestDTO, "", DatabaseConnectionFactory.getCurrentDatabaseConnection());
				lliBillDTO.setReqID(commonRequestDTO.getReqID());
				billDAO.insertBill(lliBillDTO, DatabaseConnectionFactory.getCurrentDatabaseConnection());
				
				numOfSuccessfulAttemp++;
				savepoint = null;
				DatabaseConnectionFactory.getCurrentDatabaseConnection().dbTransationEnd();
			}catch(Throwable th){
				logger.debug("Throwable", th);
				numOfFailedAttemp++;
				billCreationSummary.listOfEntityIDForFailedAttemp.add(lliLinkDTO.getID());
				try{
					if(savepoint != null){
						DatabaseConnectionFactory.getCurrentDatabaseConnection().rollBackSavePoint(savepoint);
					}
				}catch(Exception ex){}
				stringBuilder.append(ExceptionUtils.getExceptionStackTrace(th));
				// append stack trance
			}
		}
		billCreationSummary.numberOfCreatedBill = numOfSuccessfulAttemp;
		billCreationSummary.numberOfExpectedBill = lliLinkDTOs.size();
		billCreationSummary.numberOfFailedAttemp = numOfFailedAttemp;
		billCreationSummary.stackTrace = stringBuilder.toString();
		return billCreationSummary;
	}
	
	private CommonRequestDTO createCommonRequestDTOForNewMonthlyBill(BillDTO billDTO) {
		
		CommonRequestDTO commonRequestDTO = new CommonRequestDTO();
		commonRequestDTO.setRequestByAccountID(0);
		commonRequestDTO.setClientID(billDTO.getClientID());
		commonRequestDTO.setRequestTypeID(VpnRequestTypeConstants.REQUEST_COMMON.SYSTEM_GENERATE_MONTHLY_BILL);
		commonRequestDTO.setRequestToAccountID(billDTO.getClientID());
		commonRequestDTO.setCompletionStatus(RequestStatus.ALL_PROCESSED);
		commonRequestDTO.setEntityID(billDTO.getEntityID()); 
		commonRequestDTO.setEntityTypeID(billDTO.getEntityTypeID());
		commonRequestDTO.setExpireTime(billDTO.getActivationTimeTo() + 1 + BillConstants.NUMBER_OF_DAY_BEFORE_BILL_IS_EXPIRED_IN_MILLIS);
		commonRequestDTO.setLastModificationTime(System.currentTimeMillis());
		return commonRequestDTO;
	}
	
	
	private double getMultiplierForMonthlyCostByDateRange(long effectiveDateFrom,long effectiveDateTo) throws Exception{
		
		Calendar effectiveDateFromCalendar = Calendar.getInstance();
		effectiveDateFromCalendar.setTimeInMillis(effectiveDateFrom);
		
		Calendar effectiveDateToCalendar = Calendar.getInstance();
		effectiveDateToCalendar.setTimeInMillis(effectiveDateTo);

		int daysInMonth = DateUtils.getDaysInMonth(effectiveDateFromCalendar.get(Calendar.MONTH), effectiveDateFromCalendar.get(Calendar.YEAR));

		int diffInYear = effectiveDateToCalendar.get(Calendar.YEAR)-effectiveDateFromCalendar.get(Calendar.YEAR);
		effectiveDateFromCalendar.add(Calendar.YEAR, diffInYear);
		if(effectiveDateFromCalendar.getTimeInMillis()>effectiveDateToCalendar.getTimeInMillis()){
			diffInYear--;
			effectiveDateFromCalendar.add(Calendar.YEAR, -1);
		}
		int diffInMonth = (effectiveDateToCalendar.get(Calendar.MONTH)-effectiveDateFromCalendar.get(Calendar.MONTH)+12)%12;
		effectiveDateFromCalendar.add(Calendar.MONTH, diffInMonth);
		if(effectiveDateFromCalendar.getTimeInMillis()>effectiveDateToCalendar.getTimeInMillis()){
			diffInMonth--;
			effectiveDateFromCalendar.add(Calendar.MONTH, -1);
		}
		int diffInDays = 0;
		if(effectiveDateToCalendar.get(Calendar.DAY_OF_MONTH)>=effectiveDateFromCalendar.get(Calendar.DAY_OF_MONTH)){
			diffInDays = effectiveDateToCalendar.get(Calendar.DAY_OF_MONTH)-effectiveDateFromCalendar.get(Calendar.DAY_OF_MONTH);
		}else{
			diffInDays = daysInMonth-effectiveDateFromCalendar.get(Calendar.DAY_OF_MONTH)+effectiveDateToCalendar.get(Calendar.DAY_OF_MONTH);
		}
		logger.debug("diffInYear " + diffInYear + " diffInMonth " + diffInMonth + "diffInDays " + diffInDays);
		return (12*diffInYear+diffInMonth)+diffInDays*1.0/daysInMonth;
	}
	
	
	private LliBillDTO createLliBillDTO(LliLinkDTO lliLinkDTO, List<TableDTO> costTableDTOs, Map<Long, LliFarEndDTO> mapOfLliFarEndDTOToFarEndID
			,long fromTime ,long  toTime,List<LLIOTCConfigurationDTO> commonCharges) throws Exception {

		LliFarEndDTO lliFarEndDTO = mapOfLliFarEndDTOToFarEndID.get(lliLinkDTO.getFarEndID());

		int year = EndPointConstants.yearConnectionTypeMapping.get( lliLinkDTO.getConnectionType() );
		double bandwidth =  lliLinkDTO.getLliBandwidth();

		if( lliLinkDTO.getLliBandwidthType() == EntityTypeConstant.BANDWIDTH_TYPE_GB )
			bandwidth = bandwidth * 1024;
		
		int categoryID = new ClientTypeService().getClientCategoryByModuleIDAndClientID( EntityTypeConstant.LLI_LINK / EntityTypeConstant.MULTIPLIER2, lliLinkDTO.getClientID() );
		 
		double bandwidthCost = 0;
		if(costTableDTOs.isEmpty()){
			throw new Exception("No cost config found for Lli with date range ["+TimeConverter.getDateTimeStringFromDateTime(fromTime)
									+","+TimeConverter.getDateTimeStringFromDateTime(toTime)+"]");
		}
		
		for(int i = 0;i<costTableDTOs.size();i++){
			TableDTO tableDTO = costTableDTOs.get(i);
			logger.debug("tableDTO " + tableDTO);
			long effectiveDateFrom = (i==0?fromTime:tableDTO.getActivationDate());
			long effectiveDateTo = (i==(costTableDTOs.size()-1)?toTime+1:costTableDTOs.get(i+1).getActivationDate());

			//This cost is for the current cost chart
			double bandwidthCostPerMonth = tableDTO.getCostByRowValueAndColumnValue( bandwidth, year );
			logger.debug("bandwidthCostPerMonth " + bandwidthCostPerMonth);
			double multplierCostantForMonththlyBill = getMultiplierForMonthlyCostByDateRange( effectiveDateFrom, effectiveDateTo );
			
			logger.debug("effectiveDateFrom " + effectiveDateFrom + " effectiveDateTo " + effectiveDateTo + " multplierCostantForMonththlyBill " + multplierCostantForMonththlyBill);
			double bandwidthCostForThisTimeSlice = multplierCostantForMonththlyBill*bandwidthCostPerMonth;
			
			ClientDetailsDTO clientDetailsDTO = AllClientRepository.getInstance().getModuleClientByClientIDAndModuleID(lliLinkDTO.getClientID(), ModuleConstants.Module_ID_LLI); 
			
			if(clientDetailsDTO == null){
				throw new RequestFailureException("No Client details for client id "+lliLinkDTO.getClientID()+" and moduleID "+ModuleConstants.Module_ID_LLI);
			}
			
			if(lliLinkDTO.getConnectionType() == EndPointConstants.CONNECTION_TYPE_SHORT_TIME_ && 
					clientDetailsDTO.getRegistrantType() == client.RegistrantTypeConstants.GOVT){
					bandwidthCostForThisTimeSlice/=2;
			}
			
			bandwidthCost+= bandwidthCostForThisTimeSlice;
		}
		
		double ofcChargePerMeter = 0;
		
		
		for(int i=0;i<commonCharges.size();i++){
			long effectiveDateFrom = (i==0?fromTime:commonCharges.get(i).getActivationDate());
			long effectiveDateTo = (i==commonCharges.size()-1?toTime+1:commonCharges.get(i+1).getActivationDate());
			double muliplierConastant = getMultiplierForMonthlyCostByDateRange(effectiveDateFrom, effectiveDateTo);
			LLIOTCConfigurationDTO chargeDTO = commonCharges.get(i);
			ofcChargePerMeter += muliplierConastant*chargeDTO.getOFChargePerMeter();
		}
		
		
		LliBillDTO lliBillDTO = new LliLinkSearchDAO().generateMRCBill(lliLinkDTO, lliFarEndDTO
				,	fromTime, toTime, 0, ofcChargePerMeter, bandwidthCost) ;
		
		lliLinkDTO.setBalance(lliLinkDTO.getBalance()+lliBillDTO.getAdjustmentAmount());
		
		lliDAO.updateLliLink(lliLinkDTO, DatabaseConnectionFactory.getCurrentDatabaseConnection());
		
		return lliBillDTO;
	}
	
	private CommonRequestDTO createCommonRequestDTO(LliLinkDTO lliLinkDTO, LoginDTO loginDTO) {
		CommonRequestDTO commonRequestDTO = new CommonRequestDTO();
		commonRequestDTO.setRequestTypeID((ModuleConstants.Module_ID_LLI * ModuleConstants.MULTIPLIER) + 102);
		commonRequestDTO.setEntityID(lliLinkDTO.getID());
		commonRequestDTO.setEntityTypeID(EntityTypeConstant.LLI_LINK);
		commonRequestDTO.setRequestTime(System.currentTimeMillis());
		commonRequestDTO.setLastModificationTime(System.currentTimeMillis());
		commonRequestDTO.setClientID(lliLinkDTO.getClientID());
		commonRequestDTO.setCompletionStatus(RequestStatus.ALL_PROCESSED);
		if (!loginDTO.getIsAdmin())
			commonRequestDTO.setRequestByAccountID(loginDTO.getAccountID());
		else
			commonRequestDTO.setRequestByAccountID(-loginDTO.getUserID());

		commonRequestDTO.setDescription("");
		return commonRequestDTO;
	}
	
	private LliLinkDTO createLliLinkDTO(LliNewLinkCreateDTO lliNewLinkCreateDTO, long feID) throws Exception {
		
		LliLinkDTO lliLinkDTO = new LliLinkDTO();
		
		switch (lliNewLinkCreateDTO.getConnectionType()) {
		case EndPointConstants.CONNECTION_TYPE_PERMANENT_:
			break;
			
		case EndPointConstants.CONNECTION_TYPE_TEMPORARY_:
			lliLinkDTO.setTemporaryConnectionFromDate(lliNewLinkCreateDTO.getTemporaryConnectionFromDate());
			lliLinkDTO.setTemporaryConnectionRange(lliNewLinkCreateDTO.getTemporaryConnectionRange());
			break;

		case EndPointConstants.CONNECTION_TYPE_FIVE_YEARS_:
			double bandwidtch = (lliNewLinkCreateDTO.getLinkBandwidthType() == EntityTypeConstant.BANDWIDTH_TYPE_GB) ? lliNewLinkCreateDTO.getLinkBandwidth() * 1024 : lliNewLinkCreateDTO.getLinkBandwidth();
			double longTermBandwidtch = (lliNewLinkCreateDTO.getFiveYearBandwidthType() == EntityTypeConstant.BANDWIDTH_TYPE_GB) ? lliNewLinkCreateDTO.getFiveYearBandwidth() * 1024 : lliNewLinkCreateDTO.getFiveYearBandwidth();
			
			if( longTermBandwidtch == 0 || longTermBandwidtch > bandwidtch )
				throw new Exception( "Invalid value for five year bandwidth" );
			
			lliLinkDTO.setFiveYearBandwidth( lliNewLinkCreateDTO.getFiveYearBandwidth() );
			lliLinkDTO.setFiveYearBandwidthType( lliNewLinkCreateDTO.getFiveYearBandwidthType() );
			break;
		}
		
		lliLinkDTO.setID(lliNewLinkCreateDTO.entityID);
		lliLinkDTO.setLinkName(lliNewLinkCreateDTO.getLinkName());
		lliLinkDTO.setLinkDescription(lliNewLinkCreateDTO.getLinkDescription());
		lliLinkDTO.setLliBandwidth(lliNewLinkCreateDTO.getLinkBandwidth());
		lliLinkDTO.setLliLoopDistance(lliNewLinkCreateDTO.getLoopDistance());
		lliLinkDTO.setLanCounter(lliNewLinkCreateDTO.getLanCounter());
		lliLinkDTO.setLanIdNumbers(lliNewLinkCreateDTO.getLanIdNumbers());
		lliLinkDTO.setLliBandwidthType(lliNewLinkCreateDTO.getLinkBandwidthType());
		lliLinkDTO.setLanCounter(lliNewLinkCreateDTO.getLanCounter());
		lliLinkDTO.setLayerType(lliNewLinkCreateDTO.getLayerType());
		lliLinkDTO.setConnectionType(lliNewLinkCreateDTO.getConnectionType());
		lliLinkDTO.setServicePurpose(lliNewLinkCreateDTO.getServicePurpose());
		lliLinkDTO.setIsMigrated(lliNewLinkCreateDTO.getIsMigrated());
		lliLinkDTO.setLliLoopDistance(lliNewLinkCreateDTO.getLoopDistance());
		lliLinkDTO.setLastModificationTime(currentTime);
		lliLinkDTO.setFarEndID(feID);
		lliLinkDTO.setDocument(lliNewLinkCreateDTO.getDocument());
		lliLinkDTO.setDocuments(lliNewLinkCreateDTO.getDocuments());
		
		lliLinkDTO.setCurrentStatus(LliRequestTypeConstants.REQUEST_NEW_LINK.CLIENT_APPLY);
		lliLinkDTO.setLatestStatus(LliRequestTypeConstants.REQUEST_NEW_LINK.CLIENT_APPLY);
		
		return lliLinkDTO;
	}

	private LliFarEndDTO createLliFarEndDTO(LliNewLinkCreateDTO lliNewLinkCreateDTO, LoginDTO loginDTO) {
		LliFarEndDTO lliFarEndDTO = new LliFarEndDTO();
		lliFarEndDTO.setPortType(lliNewLinkCreateDTO.getFePortType());
		lliFarEndDTO.setID(lliNewLinkCreateDTO.feID);
		lliFarEndDTO.setName(lliNewLinkCreateDTO.getFeName());
		lliFarEndDTO.setLliEndPointID(lliNewLinkCreateDTO.getFarEndPointID());
		lliFarEndDTO.setDistrictID(lliNewLinkCreateDTO.getFeDistrictID());
		lliFarEndDTO.setUpazilaID(lliNewLinkCreateDTO.getFeUpazilaID());
		lliFarEndDTO.setUnionID(lliNewLinkCreateDTO.getFeUnionID());
		lliFarEndDTO.setPopID(lliNewLinkCreateDTO.getFePopID());
		lliFarEndDTO.setAddress(lliNewLinkCreateDTO.getFeAddress());
		lliFarEndDTO.setDistanceFromNearestPopInMeter(lliNewLinkCreateDTO.getFeLoopDistance());
		lliFarEndDTO.setLastModificationTime(currentTime);
		lliFarEndDTO.setFibreType(lliNewLinkCreateDTO.getFeFibreType());
		lliFarEndDTO.setOfcProvider(lliNewLinkCreateDTO.getFeOfcProvider());
		lliFarEndDTO.setTerminalDeviceProvider(lliNewLinkCreateDTO.getFeTerminalDeviceProvider());
		lliFarEndDTO.setCoreType(lliNewLinkCreateDTO.getFeCoreType());;
		
		if(lliFarEndDTO.getOfcProvider()==EndPointConstants.OFC_BTCL && lliNewLinkCreateDTO.getFeProviderServiceType()==EndPointConstants.SERVICE_PROVIDER_BUY){
			lliFarEndDTO.setOpticalFibreRented(true);
		}
		lliFarEndDTO.setOFCLaidBy(lliNewLinkCreateDTO.getFeOFCLaidBy());

		if (loginDTO.getAccountID() > 0) {
			lliFarEndDTO.setClientID(loginDTO.getAccountID());
		} else {
			lliFarEndDTO.setClientID(lliNewLinkCreateDTO.getClientID());
		}
		logger.debug("inside create" + lliFarEndDTO);
		return lliFarEndDTO;
	}

	public void updateLink(ActionForm form, LoginDTO loginDTO, String action) {
		DatabaseConnection databaseConnection = new DatabaseConnection();
		try {
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();

			currentTime = System.currentTimeMillis();
			if (action.equalsIgnoreCase("upgrade")) {
				LliBandWidthChangeRequestDTO lliBandWidthChangeRequestDTO = (LliBandWidthChangeRequestDTO) form;

				lliBandWidthChangeRequestDTO.setLastModificationTime(currentTime);
				lliBandWidthChangeRequestDTO.setRequestTime(currentTime);
				requestDAO.changeBandwidthLliLinkRequest(lliBandWidthChangeRequestDTO, databaseConnection);

				activityLogDTO = createActivityLogDTO(lliBandWidthChangeRequestDTO.getID(), loginDTO,
						LliRequestTypeConstants.REQUEST_UPGRADE.CLIENT_APPLY, EntityTypeConstant.LLI_LINK,
						lliBandWidthChangeRequestDTO.getID(),
						"Lli link bandwidth upgrade request submit for approval.");
				activityLogDAO.insert(activityLogDTO, databaseConnection);

			} else if (action.equalsIgnoreCase("downgrade")) {
				LliBandWidthChangeRequestDTO lliBandWidthChangeRequestDTO = (LliBandWidthChangeRequestDTO) form;

				lliBandWidthChangeRequestDTO.setLastModificationTime(currentTime);
				lliBandWidthChangeRequestDTO.setRequestTime(currentTime);
				requestDAO.changeBandwidthLliLinkRequest(lliBandWidthChangeRequestDTO, databaseConnection);

				activityLogDTO = createActivityLogDTO(lliBandWidthChangeRequestDTO.getID(), loginDTO,
						LliRequestTypeConstants.REQUEST_DOWNGRADE.CLIENT_APPLY, EntityTypeConstant.LLI_LINK,
						lliBandWidthChangeRequestDTO.getID(),
						"Lli link bandwidth downgrade request submit for approval.");
				activityLogDAO.insert(activityLogDTO, databaseConnection);

			} else if (action.equalsIgnoreCase("migration")) {

			} else if (action.equalsIgnoreCase("shift")) {

			} else if (action.equalsIgnoreCase("ownershipchange")) {

			} else if (action.equalsIgnoreCase("redundantne")) {

			} else if (action.equalsIgnoreCase("close")) {

			}

			// lliDAO.updateLliLink(lliLinkDTO, databaseConnection);

			databaseConnection.dbTransationEnd();
		} catch (Exception ex) {
			try {
				databaseConnection.dbTransationRollBack();
			} catch (Exception ex2) {
			}
		} finally {
			databaseConnection.dbClose();
		}

	}

	public void deleteLink(long lliLinkID, LoginDTO loginDTO) throws Exception {
		DatabaseConnection databaseConnection = new DatabaseConnection();
		try {
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();

			currentTime = System.currentTimeMillis();
			LliLinkDTO lliLinkDTO = LliConnectionRepository.getInstance().getLliLinkByLliLinkID(lliLinkID);

			lliDAO.deleteFarEnd(lliLinkDTO.getFarEndID(), databaseConnection);
			List<LliRedundantFarEndDTO> lliRedundantFarEndDTOs = LliConnectionRepository.getInstance().getLliRedundantFarEndListByLliLinkID(lliLinkID);
			for (int i = 0; i < lliRedundantFarEndDTOs.size(); i++) {
				lliDAO.deleteRedundantFarEnd(lliRedundantFarEndDTOs.get(i).getID(), databaseConnection);
			}

			lliDAO.deleteLliLink(lliLinkDTO, databaseConnection);

			// @Need to update
			// activityLogDTO = createActivityLogDTO(lliLinkDTO.getID(),
			// loginDTO, ActivityTypeConstant.DELETE_LLI_LINK, "A LLI link is
			// deleted");
			activityLogDAO.insert(activityLogDTO, databaseConnection);

			databaseConnection.dbTransationEnd();
		} catch (Exception ex) {
			try {
				databaseConnection.dbTransationRollBack();
			} catch (Exception ex2) {
				throw ex;
			}
		} finally {
			databaseConnection.dbClose();
		}

	}

	public void addFarEnd(LliFarEndDTO lliFarEndDTO, DatabaseConnection databaseConnection, LoginDTO loginDTO)
			throws Exception {

		currentTime = System.currentTimeMillis();
		lliDAO.createLliFarEnd(lliFarEndDTO, databaseConnection);
	}

	public void updateFarEnd(LliFarEndDTO lliFarEndDTO, LoginDTO loginDTO) {
		DatabaseConnection databaseConnection = new DatabaseConnection();
		try {
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();

			currentTime = System.currentTimeMillis();
			lliDAO.updateLliFarEnd(lliFarEndDTO, databaseConnection);

			activityLogDAO.insert(activityLogDTO, databaseConnection);

			databaseConnection.dbTransationEnd();
		} catch (Exception ex) {
			try {
				databaseConnection.dbTransationRollBack();
			} catch (Exception ex2) {
			}
		} finally {
			databaseConnection.dbClose();
		}

	}

	public void deleteFarEnd(long farEndID, LoginDTO loginDTO) throws Exception {
		DatabaseConnection databaseConnection = new DatabaseConnection();
		try {
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();

			currentTime = System.currentTimeMillis();
			lliDAO.deleteFarEnd(farEndID, databaseConnection);

			activityLogDAO.insert(activityLogDTO, databaseConnection);

			databaseConnection.dbTransationEnd();
		} catch (Exception ex) {
			try {
				databaseConnection.dbTransationRollBack();
			} catch (Exception ex2) {
				throw ex;
			}
		} finally {
			databaseConnection.dbClose();
		}

	}

	private ActivityLogDTO createActivityLogDTO(long entityID, LoginDTO loginDTO, int activityTypeID, int entityTypeID,
			long reqID, String description) {
		ActivityLogDTO activityLogDTO = new ActivityLogDTO();

		activityLogDTO.setEntityID(entityID);
		activityLogDTO.setEntityTypeID(entityTypeID);
		activityLogDTO.setActivityTypeID(activityTypeID);
		activityLogDTO.setDescription(description);
		activityLogDTO.setActivityTime(currentTime);
		activityLogDTO.setLastModificationTime(currentTime);
		long userID = 0;
		if (loginDTO.getIsAdmin()) {
			userID = -loginDTO.getUserID();
		} else {
			userID = loginDTO.getAccountID();
		}
		activityLogDTO.setUserAccountID(userID);
		activityLogDTO.setDeleted(false);

		return activityLogDTO;
	}
	
	
	
	
	@Override
	@Transactional(transactionType=util.TransactionType.READONLY)
	public Collection<Long> getIDs(LoginDTO loginDTO, Object...objects ) throws Exception {
		return getIDsWithSearchCriteria(new Hashtable<String, String>(), loginDTO , objects);
	}
	
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	@Transactional(transactionType=util.TransactionType.READONLY)
	public Collection<Long> getIDsWithSearchCriteria(Hashtable searchCriteria, LoginDTO loginDTO, Object...objects ) throws Exception {
		return lliLinkDAO.getLliLinkIDsFromSearchCriteria(searchCriteria, loginDTO);
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	@Transactional(transactionType=util.TransactionType.READONLY) 
	public Collection<LliLinkDTO> getDTOs (Collection recordIDs, Object...objects ) throws Exception {
		return lliLinkDAO.getLliLinkDTOs(recordIDs);
	}
	public LliLinkDTO getLliLinkByLliLinkID(long entityID){
		DatabaseConnection databaseConnection = new DatabaseConnection();
		LliLinkDTO lliLinkDTO = null;
		try {
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();

			lliLinkDTO = lliDAO.getLliLinkDTOByID(entityID, databaseConnection);

			databaseConnection.dbTransationEnd();
		} catch (Exception ex) {
			try {
				logger.debug("Error inside getDTOs method of lliLinkService", ex);
				databaseConnection.dbTransationRollBack();
			} catch (Exception ex2) {
				if(ex2 instanceof RequestFailureException){
					throw (RequestFailureException)ex2;
				}
				throw new RequestFailureException("Server Error");

			}
		} finally {
			databaseConnection.dbClose();
		}
		return lliLinkDTO;
	}
	
	public LliEndPointDTO getLliEndPointDTOByLliEndPointID(long endPointID){
		DatabaseConnection databaseConnection = new DatabaseConnection();
		LliEndPointDTO lliEndPointDTO = null;
		try {
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();

			lliEndPointDTO = lliDAO.getLliEndPointDTOByLliEndPointID(endPointID, databaseConnection);

			databaseConnection.dbTransationEnd();
		} catch (Exception ex) {
			try {
				logger.debug("Error inside getDTOs method of lliLinkService", ex);
				databaseConnection.dbTransationRollBack();
			} catch (Exception ex2) {
				if(ex2 instanceof RequestFailureException){
					throw (RequestFailureException)ex2;
				}
				throw new RequestFailureException("Server Error");

			}
		} finally {
			databaseConnection.dbClose();
		}
		return lliEndPointDTO;
	}

	public LliFarEndDTO getFarEndByFarEndID(long farEndID) throws Exception {
		DatabaseConnection databaseConnection = new DatabaseConnection();
		LliFarEndDTO lliFarEndDTO = null;
		try {
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();

			lliFarEndDTO = lliLinkDAO.getLliFarEndByID(farEndID, databaseConnection);

			databaseConnection.dbTransationEnd();
		} catch (Exception ex) {
			try {
				logger.debug("Error inside getDTOs method of lliLinkService", ex);
				databaseConnection.dbTransationRollBack();
			} catch (Exception ex2) {
				throw ex2;

			}
		} finally {
			databaseConnection.dbClose();
		}
		return lliFarEndDTO;
	}
	
	private void uploadDocuments(LliLinkDTO lliLinkDTO, LoginDTO loginDTO,  DatabaseConnection databaseConnection) throws Exception {
		FileService fileService = new FileService();

		int entityTypeID = EntityTypeConstant.LLI_LINK;
		long entityID = lliLinkDTO.getID();

		String []updatedFileNames= lliLinkDTO.getDocuments();
		ArrayList<String> newFileNames= new ArrayList<String>();
		ArrayList<String> commonFileNames= new ArrayList<String>();
		ArrayList<Long> removedDocIds=new ArrayList<Long>();
		
		ArrayList<FileDTO> existingFileDTOs=fileService.getFileByEntityTypeAndEntity(entityTypeID,entityID, databaseConnection);
		
		for(int i=0; i<updatedFileNames.length; i++){
			boolean isCommon=false;
			for(FileDTO dto: existingFileDTOs){
				if(updatedFileNames[i].trim().equals(dto.getDocLocalFileName().trim())){
					commonFileNames.add(dto.getDocLocalFileName().trim());
					isCommon=true;
				}
			}
			if(!isCommon){
				newFileNames.add(updatedFileNames[i].trim());
			}
		}
	
		logger.debug(newFileNames + commonFileNames.toString()+ removedDocIds);
		
		for (int i = 0; i < newFileNames.size(); i++) {
			FileDTO fileDTO = new FileDTO();
			fileDTO.setDocOwner(loginDTO.getAccountID()>0?loginDTO.getAccountID():(-loginDTO.getUserID()));
			fileDTO.setDocEntityTypeID(entityTypeID);
			fileDTO.setDocEntityID(entityID);
			fileDTO.setLastModificationTime(System.currentTimeMillis());

			fileDTO.createLocalFileFromNames(newFileNames.get(i));
			fileService.insert(fileDTO, databaseConnection);
		}
		for(FileDTO dto: existingFileDTOs){
			if(updatedFileNames.length>0){
				if(!commonFileNames.contains(dto.getDocLocalFileName().trim())){
					removedDocIds.add(dto.getDocID());
					dto.deleteFileFromDirectory();
				}
			}else{
				removedDocIds.add(dto.getDocID());
				dto.deleteFileFromDirectory();
			}
		}
		//delete the old files from databse
		if(removedDocIds.size()>0){
			fileService.removeFileByDocIDs(removedDocIds, databaseConnection);
		}
	}

	/**
	 * @return long This returns the ID of the inserted Demand Note.
	 **/

	public long issueDemanNoteForNewLink(CommonRequestDTO commonRequestDTO){

		// getLliLinkDTO
		// getNearEnd
		// getFarEnd
		// createDemandNote()
		// insert the demanNote
		// insert into activity log
		Long ID = null;
		DatabaseConnection databaseConnection = new DatabaseConnection();

		try {
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			ID = lliLinkDAO.issueDemanNoteForNewLink(commonRequestDTO, databaseConnection);
			databaseConnection.dbTransationEnd();

		} catch (Exception ex) {
			try {
				logger.debug("FATAL: ", ex);
				databaseConnection.dbTransationRollBack();
			} catch (Exception ex2) {

			}
		} finally {
			databaseConnection.dbClose();
		}
		return ID;
	}

	public void bandwidthChangeRequest(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response,
			LoginDTO loginDTO) throws Exception {
		DatabaseConnection databaseConnection = new DatabaseConnection();
		try 
		{
			LliBandWidthChangeRequestDTO lliBandWidthChangeRequestDTO = (LliBandWidthChangeRequestDTO) form;
			LliLinkDTO lliLinkDTO = null;
			InventoryService inventoryService = new InventoryService();
			long clientID = lliBandWidthChangeRequestDTO.getClientID();
			if(loginDTO.getAccountID() > 0) {
				clientID = loginDTO.getAccountID();
			}
			CommonActionStatusDTO casDTO = new CommonActionStatusDTO();

			long currentTime = System.currentTimeMillis();

			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			long linkID = lliBandWidthChangeRequestDTO.getLinkID();
			lliLinkDTO = lliDAO.getLliLink(linkID, databaseConnection);			

			int stateID = RequestActionStateRepository.getInstance()
					.getActionStateDTOActionTypeID(LliRequestTypeConstants.REQUEST_UPGRADE.CLIENT_APPLY)
					.getNextStateID();
			lliLinkDTO.setLatestStatus(stateID);			
			lliLinkDTO.setLastModificationTime(currentTime);
			SqlGenerator.updateEntityByPropertyList(lliLinkDTO, LliLinkDTO.class, databaseConnection, false, false, new String[] { "lastModificationTime", "latestStatus" });


			lliBandWidthChangeRequestDTO.setRequestTime(currentTime);
			lliBandWidthChangeRequestDTO.setLastModificationTime(currentTime);
			lliBandWidthChangeRequestDTO.setRequestTypeID(LliRequestTypeConstants.REQUEST_UPGRADE.CLIENT_APPLY);
			lliBandWidthChangeRequestDTO.setEntityTypeID(EntityTypeConstant.LLI_LINK);
			lliBandWidthChangeRequestDTO.setEntityID(linkID);
			lliBandWidthChangeRequestDTO.setRootReqID(null);
			lliBandWidthChangeRequestDTO.setParentReqID(null);
			lliBandWidthChangeRequestDTO.setClientID(clientID);
			lliBandWidthChangeRequestDTO.setLinkID(linkID);

			LliFarEndDTO lliFarEnd = getFarEndByFarEndID(lliLinkDTO.getFarEndID());
			InventoryItemDetails farEndDetails = inventoryService.getInventoryItemDetailsByItemID(lliFarEnd.getPortID());

			lliBandWidthChangeRequestDTO.setOldFarPortID(lliFarEnd.getPortID());
			lliBandWidthChangeRequestDTO.setOldFarPortType(farEndDetails.getValueByAttributeName("Port Type"));

			lliBandWidthChangeRequestDTO.setDescription("Bandwidth Change from " + lliLinkDTO.getLliBandwidth() + " " + EntityTypeConstant.linkBandwidthTypeMap.get(lliLinkDTO.getLliBandwidthType()) +
					" to " + lliBandWidthChangeRequestDTO.getNewBandwidth() + " " + EntityTypeConstant.linkBandwidthTypeMap.get(lliBandWidthChangeRequestDTO.getNewBandwidthType()) + " is requested");

			if (!loginDTO.getIsAdmin()) {
				lliBandWidthChangeRequestDTO.setRequestByAccountID(loginDTO.getAccountID());
			} else {
				lliBandWidthChangeRequestDTO.setRequestByAccountID(-loginDTO.getUserID());
			}


			if (lliBandWidthChangeRequestDTO.getExpireTime() == 0) {
				long expireTime = new CommonDAO().getExpireTimeByRequestType(lliBandWidthChangeRequestDTO.getRequestTypeID());
				lliBandWidthChangeRequestDTO.setExpireTime(expireTime);
			}
			//			SqlGenerator.insert(lliBandWidthChangeRequestDTO, CommonRequestDTO.class, databaseConnection, false);
			SqlGenerator.insert(lliBandWidthChangeRequestDTO, LliBandWidthChangeRequestDTO.class, databaseConnection, true);

			databaseConnection.dbTransationEnd();
			new CommonActionStatusDTO().setSuccessMessage("Bandwith Change request is  accepted successfully", false, request);
		} catch (Exception ex) {
			logger.fatal("Fatal", ex);
			try {
				databaseConnection.dbTransationRollBack();
			} catch (Exception ex2) {
			}
			if (ex instanceof RequestFailureException) {
				throw (RequestFailureException) ex;
			}
			throw new RequestFailureException("Bandwith Change request is not accepted");
		} finally {
			databaseConnection.dbClose();
		}		
	}
	@Transactional
	public ActionForward processInternalFrResponseIPAddress(ActionMapping mapping, CommonRequestDTO commonRequestDTO, CommonRequestDTO sourceRequestDTO, HttpServletRequest request, HttpServletResponse response,
			LoginDTO loginDTO) throws Exception {
//		DatabaseConnection databaseConnection = new DatabaseConnection();
		long lliLinkID=-1;
		lliDAO.processInternalFrResponseIPAddress(mapping, commonRequestDTO, sourceRequestDTO, request, response, loginDTO, DatabaseConnectionFactory.getCurrentDatabaseConnection());				
		ActionRedirect forward = new ActionRedirect();
		forward.setPath("LliLinkSearch.do/entityID="+lliLinkID+"&entityTypeID="+EntityTypeConstant.LLI_LINK);
		forward.setRedirect(true);
		
		return forward;
	}
	@Transactional
	public ActionForward processInternalFrResponse(ActionMapping mapping, CommonRequestDTO commonRequestDTO, CommonRequestDTO sourceRequestDTO, HttpServletRequest request, HttpServletResponse response,
			LoginDTO loginDTO) throws Exception {
		long lliLinkID=-1;
		lliDAO.processInternalFrResponse(mapping, commonRequestDTO, sourceRequestDTO, request, response, loginDTO, DatabaseConnectionFactory.getCurrentDatabaseConnection());

		ActionRedirect forward = new ActionRedirect();
		forward.setPath("LliLinkSearch.do/entityID="+lliLinkID+"&entityTypeID="+EntityTypeConstant.LLI_LINK);
		forward.setRedirect(true);

		return forward;
	}
	
	public LliFRResponseExternalDTO getLatestExternalFRForFarEnd(LliFarEndDTO farEndDTO) throws Exception
	{
		DatabaseConnection databaseConnection = new DatabaseConnection();
		LliFRResponseExternalDTO lliFRResponseExternalDTO = null;
		
		try {
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			lliFRResponseExternalDTO = lliDAO.getLatestExternalFRForFarEnd(farEndDTO, databaseConnection);
			databaseConnection.dbTransationEnd();
		} catch (Exception ex) {
			logger.fatal("Fatal", ex);
			try {
				databaseConnection.dbTransationRollBack();
			} catch (Exception ex2) {
			}
			if (ex instanceof RequestFailureException) {
				throw (RequestFailureException) ex;
			}
			throw ex;
		} finally {
			databaseConnection.dbClose();
		}	
		return lliFRResponseExternalDTO;
	}	
	public LliFRResponseExternalDTO getLatestExternalFRByEntityAndEntityTypeID(long entityID, int entityTypeID) throws Exception
	{			
		DatabaseConnection databaseConnection = new DatabaseConnection();
		LliFRResponseExternalDTO lliFRResponseExternalDTO = null;

		try {
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			lliFRResponseExternalDTO = lliDAO.getLatestExternalFRByEntityAndEntityTypeID(entityID, entityTypeID, databaseConnection);
			databaseConnection.dbTransationEnd();
		} catch (Exception ex) {
			logger.fatal("Fatal", ex);
			try {
				databaseConnection.dbTransationRollBack();
			} catch (Exception ex2) {
			}
			if (ex instanceof RequestFailureException) {
				throw (RequestFailureException) ex;
			}
			throw ex;
		} finally {
			databaseConnection.dbClose();
		}
		return lliFRResponseExternalDTO;
	}
	
	public LliBandWidthChangeRequestDTO getLatestBandwidthChangeRequestByEntityAndEntityTypeID(long entityID, int entityTypeID) throws Exception
	{			
		DatabaseConnection databaseConnection = new DatabaseConnection();
		LliBandWidthChangeRequestDTO lliBandWidthChangeRequestDTO = null;

		try {
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			lliBandWidthChangeRequestDTO = lliDAO.getLatestBandwidthChangeRequestByEntityAndEntityTypeID(entityID, entityTypeID, databaseConnection);
			databaseConnection.dbTransationEnd();
		} catch (Exception ex) {
			logger.fatal("Fatal", ex);
			try {
				databaseConnection.dbTransationRollBack();
			} catch (Exception ex2) {
			}
			if (ex instanceof RequestFailureException) {
				throw (RequestFailureException) ex;
			}
			throw ex;
		} finally {
			databaseConnection.dbClose();
		}
		return lliBandWidthChangeRequestDTO;
	}
	
	public LliFRResponseInternalDTO getLatestInternalFRByEntityAndEntityTypeID(long entityID, int entityTypeID) throws Exception
	{			
		DatabaseConnection databaseConnection = new DatabaseConnection();
		LliFRResponseInternalDTO lliFRResponseInternalDTO = null;

		try {
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			lliFRResponseInternalDTO = lliDAO.getLatestInternalFRByEntityAndEntityTypeID(entityID, entityTypeID, databaseConnection);
			databaseConnection.dbTransationEnd();
		} catch (Exception ex) {
			logger.fatal("Fatal", ex);
			try {
				databaseConnection.dbTransationRollBack();
			} catch (Exception ex2) {
			}
			if (ex instanceof RequestFailureException) {
				throw (RequestFailureException) ex;
			}
			throw ex;
		} finally {
			databaseConnection.dbClose();
		}
		return lliFRResponseInternalDTO;
	}
	

	public ActionForward closeLinkRequest(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response, LoginDTO loginDTO) throws Exception {
		DatabaseConnection databaseConnection = new DatabaseConnection();
		long currentTime = System.currentTimeMillis();
		try {
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			
			long lliLinkID = Long.parseLong(request.getParameter("linkID"));
			long clientID = loginDTO.getAccountID();
			if(clientID < 0)
			{
				clientID = Long.parseLong(request.getParameter("clientID"));
			}
			LliLinkDTO lliLinkDTO = lliDAO.getLliLink(lliLinkID, databaseConnection);			
			String []files = request.getParameterValues("documents");
			
			int stateID = RequestActionStateRepository.getInstance()
					.getActionStateDTOActionTypeID(LliRequestTypeConstants.REQUEST_LINK_CLOSE.CLIENT_APPLY)
					.getNextStateID();
			lliLinkDTO.setLatestStatus(stateID);			
			lliLinkDTO.setLastModificationTime(currentTime);
			SqlGenerator.updateEntityByPropertyList(lliLinkDTO, LliLinkDTO.class, databaseConnection, false, false, new String[] { "lastModificationTime", "latestStatus" });
			LliLinkCloseRequestDTO lliLinkCloseRequestDTO = new LliLinkCloseRequestDTO();
			
			lliLinkCloseRequestDTO.setRequestTime(currentTime);
			lliLinkCloseRequestDTO.setLastModificationTime(currentTime);
			lliLinkCloseRequestDTO.setRequestTypeID(LliRequestTypeConstants.REQUEST_LINK_CLOSE.CLIENT_APPLY);
			lliLinkCloseRequestDTO.setEntityTypeID(EntityTypeConstant.LLI_LINK);
			lliLinkCloseRequestDTO.setEntityID(lliLinkID);
			lliLinkCloseRequestDTO.setRootReqID(null);
			lliLinkCloseRequestDTO.setParentReqID(null);
			lliLinkCloseRequestDTO.setClientID(clientID);
			lliLinkCloseRequestDTO.setLliLinkID(lliLinkID);
			lliLinkCloseRequestDTO.setExpectedClosingDate(TimeConverter.getTimeFromString(request.getParameter("closeDate")));
			

			if (!loginDTO.getIsAdmin()) {
				lliLinkCloseRequestDTO.setRequestByAccountID(loginDTO.getAccountID());
			} else {
				lliLinkCloseRequestDTO.setRequestByAccountID(-loginDTO.getUserID());
			}
			String message="Link close request is accepted successfully";
			lliLinkCloseRequestDTO.setDescription(request.getParameter("linkDescription"));
			

			
			if (lliLinkCloseRequestDTO.getExpireTime() == 0) {
				long expireTime = new CommonDAO().getExpireTimeByRequestType(lliLinkCloseRequestDTO.getRequestTypeID());
				lliLinkCloseRequestDTO.setExpireTime(expireTime);
			}
//			SqlGenerator.insert(lliBandWidthChangeRequestDTO, CommonRequestDTO.class, databaseConnection, false);
			SqlGenerator.insert(lliLinkCloseRequestDTO, LliLinkCloseRequestDTO.class, databaseConnection, true);
			if(files != null ) {
				commonDAO.uploadDocument(files, loginDTO, lliLinkCloseRequestDTO, request, databaseConnection);
			}
			databaseConnection.dbTransationEnd();
			new CommonActionStatusDTO().setSuccessMessage(message, false, request);
			
			ActionForward actionForward = new ActionForward();
			lliLinkCloseRequestDTO.setActionName(EntityActionGenerator.getAction( lliLinkID, EntityTypeConstant.LLI_LINK ) );
			actionForward.setPath(lliLinkCloseRequestDTO.getActionName());
			actionForward.setRedirect(true);
			return actionForward;
			
		} catch (Exception ex) {
			new CommonActionStatusDTO().setErrorMessage("Link close request is not accepted successfully", false, request);
			logger.fatal("Fatal", ex);
			try {
				databaseConnection.dbTransationRollBack();
			} catch (Exception ex2) {
			}
			if (ex instanceof RequestFailureException) {
				throw (RequestFailureException) ex;
			}
			throw ex;
		} finally {
			databaseConnection.dbClose();
		}		
	}	
	
	public ActionForward disableLinkRequest(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response, LoginDTO loginDTO) throws Exception {
		DatabaseConnection databaseConnection = new DatabaseConnection();
		long currentTime = System.currentTimeMillis();
		String tdExpirationDate = request.getParameter("tdDate");
		String tdOrEnable = "TD";
		if(tdExpirationDate == null)
		{
			tdOrEnable = "enable";
		}
		
		try {
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			long lliLinkID = Long.parseLong(request.getParameter("linkID"));
			String tdLinkDescription = request.getParameter("linkDescription");
			String []files = request.getParameterValues("documents");
			String tdStartDate = request.getParameter("tdStartDate");
			
			long clientID = loginDTO.getAccountID();
			if(clientID < 0) {
				clientID = Long.parseLong(request.getParameter("clientID"));
			}
			updateLLILink(lliLinkID, currentTime, databaseConnection);
			LliLinkDisableRequestDTO lliLinkDisableRequestDTO = getLliLinkDisableRequestDTOFromRequest
					(loginDTO, currentTime, lliLinkID, clientID, tdStartDate, tdExpirationDate, tdLinkDescription);
			logger.debug("lliLinkDisableRequestDTO " + lliLinkDisableRequestDTO);
			SqlGenerator.insert(lliLinkDisableRequestDTO, LliLinkDisableRequestDTO.class, databaseConnection, true);
			if(files != null) {
				commonDAO.uploadDocument(files, loginDTO, lliLinkDisableRequestDTO, request, databaseConnection);
			}
			databaseConnection.dbTransationEnd();
			
			String message="Link "+tdOrEnable+" request is accepted successfully";
			new CommonActionStatusDTO().setSuccessMessage(message, false, request);
			
			ActionForward actionForward = new ActionForward();
			lliLinkDisableRequestDTO.setActionName( EntityActionGenerator.getAction( lliLinkID, EntityTypeConstant.LLI_LINK ) );
			actionForward.setPath(lliLinkDisableRequestDTO.getActionName());
			actionForward.setRedirect(true);
			return actionForward;
			
		} catch (Exception ex) {
			new CommonActionStatusDTO().setErrorMessage("Link "+tdOrEnable+" request is not accepted successfully", false, request);
			logger.fatal("Fatal", ex);
			try {
				databaseConnection.dbTransationRollBack();
			} catch (Exception ex2) {
			}
			if (ex instanceof RequestFailureException) {
				throw (RequestFailureException) ex;
			}
			throw ex;
		} finally {
			databaseConnection.dbClose();
		}		
	}	
	
	private LliLinkDisableRequestDTO getLliLinkDisableRequestDTOFromRequest(LoginDTO loginDTO, long currentTime,
			long lliLinkID, long clientID, String tdStartDate, String tdExpirationDate, String tdLinkDescription) {
		logger.debug("getLliLinkDisableRequestDTOFromRequest " + tdExpirationDate);
		LliLinkDisableRequestDTO lliLinkDisableRequestDTO = new LliLinkDisableRequestDTO();
		lliLinkDisableRequestDTO.setRequestTime(currentTime);
		lliLinkDisableRequestDTO.setLastModificationTime(currentTime);
		if(tdExpirationDate != null)
		{
			lliLinkDisableRequestDTO.setRequestTypeID(LliRequestTypeConstants.REQUEST_DISABLE_LINK.CLIENT_APPLY_FOR_DISABLE);
		}
		else
		{
			lliLinkDisableRequestDTO.setRequestTypeID(LliRequestTypeConstants.REQUEST_DISABLE_LINK.CLIENT_APPLY_FOR_ENABLE);
		}
		lliLinkDisableRequestDTO.setEntityTypeID(EntityTypeConstant.LLI_LINK);
		lliLinkDisableRequestDTO.setEntityID(lliLinkID);
		lliLinkDisableRequestDTO.setRootReqID(null);
		lliLinkDisableRequestDTO.setParentReqID(null);
		lliLinkDisableRequestDTO.setClientID(clientID);
		lliLinkDisableRequestDTO.setLliLinkID(lliLinkID);
		lliLinkDisableRequestDTO.setExpirationDate(tdExpirationDate != null ? TimeConverter.getTimeFromString(tdExpirationDate): 0);
		lliLinkDisableRequestDTO.setTdStartDate(TimeConverter.getTimeFromString(tdStartDate));
		if (!loginDTO.getIsAdmin()) {
			lliLinkDisableRequestDTO.setRequestByAccountID(loginDTO.getAccountID());
		} else {
			lliLinkDisableRequestDTO.setRequestByAccountID(-loginDTO.getUserID());
		}
		
		lliLinkDisableRequestDTO.setDescription(tdLinkDescription);
		if (lliLinkDisableRequestDTO.getExpireTime() == 0) {
			long expireTime = new CommonDAO().getExpireTimeByRequestType(lliLinkDisableRequestDTO.getRequestTypeID());
			lliLinkDisableRequestDTO.setExpireTime(expireTime);
		}
		logger.debug("lliLinkDisableRequestDTO " + lliLinkDisableRequestDTO);
		return lliLinkDisableRequestDTO;
	}
	
	
	private void updateLLILink(long lliLinkID, long currentTime, DatabaseConnection databaseConnection) throws Exception {
		LliLinkDTO lliLinkDTO = lliDAO.getLliLink(lliLinkID, databaseConnection);			
		int stateID = RequestActionStateRepository.getInstance()
				.getActionStateDTOActionTypeID(LliRequestTypeConstants.REQUEST_DISABLE_LINK.CLIENT_APPLY_FOR_DISABLE)
				.getNextStateID();
		lliLinkDTO.setLatestStatus(stateID);			
		lliLinkDTO.setLastModificationTime(currentTime);
		SqlGenerator.updateEntityByPropertyList(lliLinkDTO, LliLinkDTO.class, databaseConnection, false, false, new String[] { "lastModificationTime", "latestStatus" });
		
		
	}

	public ActionForward lliLinkMigration(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response, LoginDTO loginDTO) throws Exception {
		DatabaseConnection databaseConnection = new DatabaseConnection();
		try {
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			currentTime = System.currentTimeMillis();
			
			LliLinkDTO oldLliLinkDTO = this.getLliLinkByLliLinkID(Long.parseLong(request.getParameter("linkID")));

			LliFarEndDTO lliFarEndDTO =getFarEndByFarEndID(oldLliLinkDTO.getFarEndID());
			lliFarEndDTO.setDistanceFromNearestPopInMeter(Double.parseDouble(request.getParameter("feLoopDistance")));
			lliDAO.updateLliFarEnd(lliFarEndDTO, databaseConnection);
			
			oldLliLinkDTO.setSecurityMoney(Double.parseDouble(request.getParameter("securityMoney")));
			oldLliLinkDTO.setBalance(Double.parseDouble(request.getParameter("balance")));
			oldLliLinkDTO.setActivationDate(TimeConverter.getTimeFromString(request.getParameter("activationDate")));
			lliDAO.updateLliLink(oldLliLinkDTO, databaseConnection);
			
			new CommonActionStatusDTO().setSuccessMessage(oldLliLinkDTO.getLinkName()+"is migrated successfully", false, request);

			databaseConnection.dbTransationEnd();
		} catch (Exception ex) {
			new CommonActionStatusDTO().setErrorMessage("Link migration is  failed", false, request);
			logger.debug(ex);
			try {
				logger.fatal("Fatal: ", ex);
				databaseConnection.dbTransationRollBack();
			} catch (Exception ex2) {
				throw ex;
			}
			throw ex;
		} finally {
			databaseConnection.dbClose();
		}
		return mapping.findForward("migratedLliUpdate");
	}	
	
	public String createCommonNote(LliFRResponseInternalDTO lliFRResponseInternalDTO, CommonRequestDTO commonRequestDTO, HttpServletRequest request, DatabaseConnection databaseConnection) throws Exception{
		
		CommonNote noteDTO = new CommonNote();
		
		noteDTO.setEntityId( lliFRResponseInternalDTO.getEntityID() );
		noteDTO.setEntityTypeId( lliFRResponseInternalDTO.getEntityTypeID() );
		noteDTO.setNoteTypeId( CommonNoteConstants.FR_RESPONSE.get( commonRequestDTO.getRequestTypeID()) );
		
		
		String noteBody  =  "From '" + UserRepository.getInstance().getUserDTOByUserID(-lliFRResponseInternalDTO.getRequestByAccountID()).getUsername() + "' </strong> : " +
						"<strong>Internal FR Response Report</strong> <br/>";
		
		noteDTO.setNoteBody( noteBody );
		noteDTO.startDescription("Item", "Comments");
		String statusStr=lliFRResponseInternalDTO.isBandWidthIsAvailable()?" <span style='color: green'> Available </span>":" <span style='color: red'> Not Available </span>";
		noteDTO.addRow("Bandwidth", statusStr+"<br> Reason:"+lliFRResponseInternalDTO.getBandWidthComment());
		
		/*statusStr=lliFRResponseInternalDTO.isBandWidthIsAvailable()?" <span style='color: green'> Available </span>":" <span style='color: red'> Not Available </span>";
		noteDTO.addRow("Mandatory VLAN", statusStr+"<br> Reason: "+lliFRResponseInternalDTO.getMandatoryVLANComment());

		noteDTO.addRow("Additional VLAN", lliFRResponseInternalDTO.additionalVLANComment );*/

		noteDTO.startDescription("", "");
		
		new CommonNoteService().insert( noteDTO, databaseConnection );
		
		String noteHyperlink = "<br/><a href='" + request.getContextPath() + "/common/reports/internalFrResponseReport.jsp?id=" + noteDTO.getId() + "'>View Internal FR Response Report</a>";
		return noteHyperlink;
	}
	
	public static int getRemoteLoopDistance( LliLinkDTO lliLinkDTO ) throws Exception{
		
		DatabaseConnection databaseConnection = new DatabaseConnection();
		
		int farLoopDistance = -1;
		
		try {
			
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			
			farLoopDistance = BillUtil.getFarEndLoopDistance( lliLinkDTO, databaseConnection );
			
			databaseConnection.dbTransationEnd();
		}
		catch (Exception ex) {
			
			try {
				
				databaseConnection.dbTransationRollBack();
			} 
			catch (Exception ex2) {
			
			}
			if (ex instanceof RequestFailureException) {
				throw (RequestFailureException) ex;
			}
			throw ex;
		} 
		finally {
			databaseConnection.dbClose();
		}		
			
		return farLoopDistance;
	}
	
	public static double getRemoteLoopCharge( LliLinkDTO lliLinkDTO ) throws Exception{
		
		DatabaseConnection databaseConnection = new DatabaseConnection();
		
		double farLoopCharge = -1;
		
		try {
			
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			
			farLoopCharge = BillUtil.getFarEndLoopCharge( lliLinkDTO, databaseConnection );
			
			databaseConnection.dbTransationEnd();
		}
		catch (Exception ex) {
			
			try {
				
				databaseConnection.dbTransationRollBack();
			} 
			catch (Exception ex2) {
			
			}
			if (ex instanceof RequestFailureException) {
				throw (RequestFailureException) ex;
			}
			throw ex;
		} 
		finally {
			databaseConnection.dbClose();
		}		
			
		return farLoopCharge;
	}
	
	public List<LliLinkDTO> getLliLinkDTOByLinkNamePrefix(Object[] values, String[] columnNames) throws Exception {
		DatabaseConnection databaseConnection = new DatabaseConnection();
		List<LliLinkDTO> lliLinkDTOs = null;

		try {
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			lliLinkDTOs = lliDAO.getLliLinkDTOByLinkNamePrefix(values, columnNames, databaseConnection);
			databaseConnection.dbTransationEnd();
		} catch (Exception ex) {
			logger.fatal("Fatal", ex);
			try {
				databaseConnection.dbTransationRollBack();
			} catch (Exception ex2) {
			}
			if (ex instanceof RequestFailureException) {
				throw (RequestFailureException) ex;
			}
			throw ex;
		} finally {
			databaseConnection.dbClose();
		}
		return lliLinkDTOs;
	}

	public boolean isOfficeNameAvailable(String officeName) {
		DatabaseConnection databaseConnection = new DatabaseConnection();
		boolean isAvailable = false;
		if(officeName.length()>0) {
			try {
				databaseConnection.dbOpen();
				databaseConnection.dbTransationStart();
				isAvailable = lliDAO.isOfficeNameAvailable(officeName, databaseConnection);
				databaseConnection.dbTransationEnd();
			} catch (Exception ex) {
				logger.fatal("Fatal", ex);
				try {
					databaseConnection.dbTransationRollBack();
				} catch (Exception ex2) {
				}
			} finally {
				databaseConnection.dbClose();
			}
		}
		return isAvailable;
	}

	/**
	 * @author dhrubo
	 */
	@Transactional(transactionType=util.TransactionType.READONLY)
	public List<LliLinkDTO> getLinkDTOListByClientID(Long clientID, Boolean activeOnly) throws Exception {
		List<LliLinkDTO> activeLinkDTOListByClientID = new ArrayList<>();
		
		String activeCondition = activeOnly ? " and currentStatus%100 = 20 " : " ";
		
		activeLinkDTOListByClientID = ModifiedSqlGenerator.getAllObjectList(LliLinkDTO.class, 
				" where clientID = " + clientID + activeCondition);
		return activeLinkDTOListByClientID;
	}
	/**
	 * @author dhrubo
	 */
	/*@Transactional(transactionType=util.TransactionType.READONLY)
	public Map<String, String> getAdditionalIPByLinkID(Long lliLinkID) throws Exception {
		LliFarEndDTO lliFarEndDTO = getFarEndByFarEndID(getLliLinkByLliLinkID(lliLinkID).getFarEndID());
		return getAdditionalIPAddressDetails(lliFarEndDTO.getAdditionalIpAvailableBlockID());
	}*/
	/**
	 * @author dhrubo
	 */
	@SuppressWarnings("static-access")
	@Transactional(transactionType=util.TransactionType.READONLY)
	private Map<String, String> getAdditionalIPAddressDetails(long additionalIpAvailableBlockID) throws Exception {
		IpAddressService ipAddressService = ServiceDAOFactory.getService(IpAddressService.class);
		
		Map<String, String> additionalIPAddressDetails = new HashMap<>();
		IpBlock ipBlock = ModifiedSqlGenerator.getObjectByID(IpBlock.class, additionalIpAvailableBlockID);
		if(ipBlock != null) {
			additionalIPAddressDetails.put("size", String.valueOf(ipBlock.getBlockSize()));
			additionalIPAddressDetails.put("start", ipAddressService.getIp4AddressStringRepresentationByIpAddressLong(ipBlock.getStartingIpAddress()));
			additionalIPAddressDetails.put("end", ipAddressService.getIp4AddressStringRepresentationByIpAddressLong(ipBlock.getEndingIpAddress()));
		}
		return additionalIPAddressDetails;
	}	
	/**
	 * @author dhrubo
	 */
	@Transactional(transactionType=util.TransactionType.READONLY)
	public String generateRequestPreviewURL(Long rootRequestID, Integer requestTypeID) throws Exception {
		@SuppressWarnings("unchecked")
		LliLinkRequestService lliLinkRequestService = (LliLinkRequestService) ServiceDAOFactory.getService(LliLinkRequestConstants.requestTypeDistinguisherToRequestDTOClass.get(requestTypeID/100%100));
		return lliLinkRequestService.getRequestPreviewActionURL(rootRequestID);
	}
	/**
	 * @author dhrubo
	 */
	/*@Transactional(transactionType=util.TransactionType.READONLY)
	public Long getRequestDTOIDByRootRequestID(Long rootRequestID, Integer requestTypeID) throws Exception {
		@SuppressWarnings("unchecked")
		LliLinkRequestService lliLinkRequestService = (LliLinkRequestService) ServiceDAOFactory.getService(LliLinkRequestConstants.requestTypeDistinguisherToRequestDTOClass.get(requestTypeID/100%100));
		return lliLinkRequestService.getRequestDTOIDByRootRequestID(rootRequestID);
	}*/
	
	/**
	 * @author Dhrubo
	 */
	public List<HashMap<String, String>> getLliLinkListByClientID(long clientID, String partialName) throws Exception {
		List<HashMap<String, String>> lliLinkIDNameListByClientID = new ArrayList<>();
		List<LliLinkDTO> lliLinkDTOListByClientIDAndPartialName = new ArrayList<>();
		DatabaseConnection databaseConnection = new DatabaseConnection();
		try{
			
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			
			lliLinkDTOListByClientIDAndPartialName = lliDAO.getLliLinkDTOListByClientIDAndPartialName(clientID, partialName, databaseConnection);
			databaseConnection.dbTransationEnd();
		}
		catch(Exception e){
			logger.debug( "Fatal :" + e.toString() );
			databaseConnection.dbTransationRollBack();
			throw e;
		}
		finally {
			databaseConnection.dbClose();
		}
		
		for(LliLinkDTO lliLinkDTO : lliLinkDTOListByClientIDAndPartialName) {
			HashMap<String, String> linkNameIDPair = new HashMap<>();
			linkNameIDPair.put("name", lliLinkDTO.getLinkName());
			linkNameIDPair.put("id", lliLinkDTO.getID()+"");
			lliLinkIDNameListByClientID.add(linkNameIDPair);
		}
		
		return lliLinkIDNameListByClientID;
	}
	
	public List<HashMap<String, String>> getDisabledLliLinkListByClientID(long clientID, String partialName) throws Exception {
		List<HashMap<String, String>> lliLinkIDNameListByClientID = new ArrayList<>();
		List<LliLinkDTO> lliLinkDTOListByClientIDAndPartialName = new ArrayList<>();
		DatabaseConnection databaseConnection = new DatabaseConnection();
		try{
			
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			
			lliLinkDTOListByClientIDAndPartialName = lliDAO.getDisabledLliLinkDTOListByClientIDAndPartialName(clientID, partialName, databaseConnection);
			databaseConnection.dbTransationEnd();
		}
		catch(Exception e){
			logger.debug( "Fatal :" + e.toString() );
			databaseConnection.dbTransationRollBack();
			throw e;
		}
		finally {
			databaseConnection.dbClose();
		}
		
		for(LliLinkDTO lliLinkDTO : lliLinkDTOListByClientIDAndPartialName) {
			HashMap<String, String> linkNameIDPair = new HashMap<>();
			linkNameIDPair.put("name", lliLinkDTO.getLinkName());
			linkNameIDPair.put("id", lliLinkDTO.getID()+"");
			lliLinkIDNameListByClientID.add(linkNameIDPair);
		}
		
		return lliLinkIDNameListByClientID;
	}
	/**
	 * @author Dhrubo
	 */
	public Map<String, String> getBandwidthByLliLinkID(long lliLinkID) {
		Map<String, String> bandwidthDetails = new HashMap<String, String>(); 
		bandwidthDetails.put("bandwidth", String.valueOf(getLliLinkByLliLinkID(lliLinkID).getLliBandwidth()));
		bandwidthDetails.put("bandwidthType", (getLliLinkByLliLinkID(lliLinkID).getLliBandwidthType()==1)? "Mb" : "Gb");
		return bandwidthDetails;
	}
	
	/**
	 * @author Dhrubo
	 */
	public static Map<String, String> ConvertObjectToMap(Object obj) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Method[] methods = obj.getClass().getMethods();
		
		Map<String, String> map = new HashMap<String, String>();
		for (Method m : methods) {
		   if (m.getName().startsWith("get") && !m.getName().startsWith("getClass")){
	          Object value = (Object) m.invoke(obj);
	          map.put(m.getName().substring(3), String.valueOf((Object) value));
	       }
	    }
		return map;
	}
	
	/**
	 * @author Dhrubo
	 */
	public HashMap<String, Map<String, String>> getLliLinkDetailsByLliLinkID(long lliLinkID) throws Exception {
		HashMap<String, Map<String, String>> lliLinkDetails = new HashMap<>();
		
		LliLinkDTO lliLinkDTO = getLliLinkByLliLinkID(lliLinkID);
		LliFarEndDTO lliFarEndDTO = getFarEndByFarEndID(lliLinkDTO.getFarEndID());
		LliEndPointDetailsDTO farEndDetails = LinkUtils.getEndPointDTODetails(lliFarEndDTO);
		
		lliLinkDetails.put("lliLinkDTO", ConvertObjectToMap(lliLinkDTO));
		lliLinkDetails.put("lliFarEndDTO", ConvertObjectToMap(lliFarEndDTO));
		lliLinkDetails.put("farEndDetails", ConvertObjectToMap(farEndDetails));
		
		return lliLinkDetails;
	}
	
	/**
	 * @author Dhrubo
	 */
	public boolean isRemoteEndOfficeNameAvailable(String officeName, String clientID) {
		DatabaseConnection databaseConnection = new DatabaseConnection();
		boolean isAvailable = false;
		if(officeName.length()>0) {
			try {
				databaseConnection.dbOpen();
				databaseConnection.dbTransationStart();
				isAvailable = lliDAO.isRemoteEndOfficeNameAvailable(officeName, clientID, databaseConnection);
				databaseConnection.dbTransationEnd();
			} catch (Exception ex) {
				logger.fatal("Fatal", ex);
				try {
					databaseConnection.dbTransationRollBack();
				} catch (Exception ex2) {
				}
			} finally {
				databaseConnection.dbClose();
			}
		}
		return isAvailable;
	}

	/**
	 * @author Dhrubo
	 */
	public List<HashMap<String, String>> getChildEntityListByParentEntityIDAndEntityTypeID(Long entityID, Integer entityTypeID) {
		List<HashMap<String, String>> childEntityListByParentEntityIDAndEntityTypeID = new ArrayList<HashMap<String, String>>();
		switch (entityTypeID) {
		case EntityTypeConstant.LLI_LINK:
			LliLinkDTO lliLinkDTO = getLliLinkByLliLinkID(entityID);
			
			HashMap<String, String> linkDetails = new HashMap<String, String>();
			linkDetails.put("entityID", String.valueOf(lliLinkDTO.getID()));
			linkDetails.put("entityTypeID", String.valueOf(EntityTypeConstant.LLI_LINK));
			
			HashMap<String, String> remoteEndDetails = new HashMap<String, String>();
			remoteEndDetails.put("entityID", String.valueOf(lliLinkDTO.getFarEndID()));
			remoteEndDetails.put("entityTypeID", String.valueOf(EntityTypeConstant.LLI_LINK_FAR_END));
			
			childEntityListByParentEntityIDAndEntityTypeID.add(linkDetails);
			childEntityListByParentEntityIDAndEntityTypeID.add(remoteEndDetails);
			break;
			
		default:
			HashMap<String, String> genericEntityDetails = new HashMap<String, String>();
			genericEntityDetails.put("entityID", String.valueOf(entityID));
			genericEntityDetails.put("entityTypeID", String.valueOf(entityTypeID));
			childEntityListByParentEntityIDAndEntityTypeID.add(genericEntityDetails);
		}
		return childEntityListByParentEntityIDAndEntityTypeID;
	}
	
	/**
	 * @author dhrubo
	 */
	public static List<? extends Number> getCurrentStatusListForLLIFromActivationStatus(Integer activationStatus){
		return StateRepository.getInstance().getStatusListByModuleIDAndActivationStatus(ModuleConstants.Module_ID_LLI, activationStatus);
	}
	

	public boolean doesClientOwnThisLink(long clientID, Long lliLinkID) {
		if(getLliLinkByLliLinkID(lliLinkID).getClientID() == clientID) {
			return true;
		}
		return false;
	}
	
	/**
	 * @author Dhrubo
	 */
	public Boolean isLliLinkEstablished(Long lliLinkID) throws Exception {
		Boolean isLliLinkEstablished;
		DatabaseConnection databaseConnection = new DatabaseConnection();
		try{
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			
			isLliLinkEstablished = lliDAO.isLliLinkEstablished(lliLinkID, databaseConnection);
			databaseConnection.dbTransationEnd();
		}
		catch(Exception e){
			logger.debug( "Fatal :" + e.toString() );
			databaseConnection.dbTransationRollBack();
			throw e;
		}
		finally {
			databaseConnection.dbClose();
		}
		return isLliLinkEstablished;
	}
	
	public boolean processLinkUpdatePermission(long linkID, LoginDTO loginDTO, HttpServletRequest p_request) throws Exception
	{
		LliLinkDTO lliLinkDTO = getLliLinkByLliLinkID(linkID);
		CommonActionStatusDTO commonActionStatusDTO = processLinkUpdatePermission(lliLinkDTO, loginDTO, p_request);
		
		p_request.getSession().setAttribute("actionStatusDTO", null);
		
		if(commonActionStatusDTO.getStatusCode() == CommonActionStatusDTO.ERROR_STATUS_CODE)
			return false;
		else
			return true;
	}

	public CommonActionStatusDTO processLinkUpdatePermission(LliLinkDTO lliLinkDTO, LoginDTO loginDTO,
			HttpServletRequest p_request) throws Exception {
		CommonActionStatusDTO commonActionStatusDTO = new CommonActionStatusDTO();
		commonActionStatusDTO.setStatusCode(CommonActionStatusDTO.SUCCESS_STATUS_CODE);
		StateDTO currentStateDTO = StateRepository.getInstance().getStateDTOByStateID(lliLinkDTO.getCurrentStatus());
		if(loginDTO.getUserID() > 0) 
		{
			boolean isUserPermittedToUpdateLink = false;
			if(currentStateDTO.getActivationStatus() == EntityTypeConstant.STATUS_ACTIVE)
			{
				isUserPermittedToUpdateLink = loginDTO.getColumnPermission(ColumnPermissionConstants.LLI.LINK_UPDATE);								
			}
			else
			{
				CommonRequestDTO commonRequestDTO = new CommonRequestDTO();
				
				commonRequestDTO.setEntityID(lliLinkDTO.getID());
				commonRequestDTO.setClientID(lliLinkDTO.getClientID());
				commonRequestDTO.setEntityTypeID(EntityTypeConstant.LLI_LINK);
				commonRequestDTO.setRequestTypeID(LliRequestTypeConstants.REQUEST_NEW_LINK.UPDATE_APPLICATION);
				
				isUserPermittedToUpdateLink =  new PermissionService().hasPermission(commonRequestDTO, loginDTO);
			}
			if(!isUserPermittedToUpdateLink) {
				commonActionStatusDTO.setErrorMessage( "You do not have permission to update this link" , false, p_request );
			}
		}
		else if(loginDTO.getAccountID() > 0) {
			boolean isClientPermittedToUpdateLink = false;
			if( lliLinkDTO.getClientID() != loginDTO.getAccountID())	{
				commonActionStatusDTO.setErrorMessage( "You do not have permission to update this link" , false, p_request );
			}
			
			isClientPermittedToUpdateLink = (lliLinkDTO.getLatestStatus() == LliRequestTypeConstants.REQUEST_NEW_LINK.CLIENT_APPLY) || 
					(lliLinkDTO.getLatestStatus() == LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_REQUEST_FOR_CORRECTED_APPLICATION); 
			if(!isClientPermittedToUpdateLink) {
				commonActionStatusDTO.setErrorMessage( "You do not have permission to update this link" , false, p_request );
			}
		}
		
		return commonActionStatusDTO;
	}

	/**
	 * @author dhrubo
	 */
	public Long getParentEntityIDByEntityIDAndEntityTypeID(Long entityID, Integer entityTypeID) throws Exception {
		if(entityTypeID.equals(EntityTypeConstant.LLI_LINK_FAR_END)) {
			return (getLliLinkDTOByFarEndID(entityID) != null) ? getLliLinkDTOByFarEndID(entityID).getID() : null;
		}
		return entityID;
	}

	/**
	 * @author dhrubo
	 */
	private LliLinkDTO getLliLinkDTOByFarEndID(Long farEndID) {
		LliLinkDTO lliLinkDTO = new LliLinkDTO();
		
		DatabaseConnection databaseConnection = new DatabaseConnection();
		try{
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			
			lliLinkDTO = lliDAO.getLliLinkDTOByFarEndID(farEndID, databaseConnection);
			databaseConnection.dbTransationEnd();
		} catch(Exception e){
			logger.debug( "Fatal :" + e.toString() );
			try {
				databaseConnection.dbTransationRollBack();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		} finally {
			databaseConnection.dbClose();
		}
		return lliLinkDTO;
	}
	
	/**
	 * @author dhrubo
	 */
	public void rollbackRequestLLI(CommonRequestDTO commonRequestDTO, CommonRequestDTO sourceRequestDTO, DatabaseConnection databaseConnection) throws Exception {
		if((sourceRequestDTO.getRequestTypeID() % 100) == 42 || (sourceRequestDTO.getRequestTypeID() % 100) == 10){//rollback internal fr
			
			// 1. Release Used Items
			int rootRequestTypeID = RequestUtilService.getRequestDTOByRequestID(commonRequestDTO.getRootReqID()).getRequestTypeID();
			switch (rootRequestTypeID) {
			case LliRequestTypeConstants.REQUEST_NEW_LINK.CLIENT_APPLY:
				// 1.1.1 Release All IP Addresses Used By Connection
				ipAddressService.deallocateIpByLLIID(commonRequestDTO.getEntityID());
				// 1.1.2 Release Inventory Items (Port, Mandatory VLan and Additional VLan)
				unuseInventoryItemsUsedByLLILinkID(commonRequestDTO.getEntityID());
			case LliRequestTypeConstants.REQUEST_IPADDRESS.CLIENT_APPLY:
				// 1.2.1 Release Newly Requested Additional IP Addresses
				LliFRResponseInternalDTO lliFRResponseInternalDTO = requestUtilDAO.getExtendedRequestByRootReqID(LliFRResponseInternalDTO.class, commonRequestDTO.getReqID(), databaseConnection);
				ipAddressService.deallocateIpBlocksByIDs(StringUtils.getLongListFromCommaSeperatedString(lliFRResponseInternalDTO.getAdditionalIPs()));
			}
			
			
			
			// 2. Update Status
			LliLinkDTO lliLinkDTO = getLliLinkByLliLinkID(commonRequestDTO.getEntityID());
			LliFarEndDTO lliFarEndDTO = getFarEndByFarEndID(lliLinkDTO.getFarEndID());
			
			boolean resetStatus = false;
			if((sourceRequestDTO.getRequestTypeID() % 100) == 10) {
				if(lliFarEndDTO.getOfcProviderTypeID() == EndPointConstants.OFC_BTCL) {
					resetStatus = true;
				}
			}
			else if((sourceRequestDTO.getRequestTypeID() % 100) == 42) {
				resetStatus = true;
			}
			
			if(resetStatus)	{
				lliFarEndDTO.setCurrentStatus(0);
				if(UtilService.isCreativeRequest(sourceRequestDTO.getRequestTypeID())) {
					lliFarEndDTO.setLatestStatus(0);
				}
			}

			SqlGenerator.updateEntity(lliFarEndDTO, LliFarEndDTO.class, databaseConnection, true, false);
			
		}
	}



	/**
	 * @author dhrubo
	 */
	public void unuseInventoryItemsUsedByLLILinkID(long lliLinkID) throws Exception {
		// 1. Get Link Information 
		LliLinkDTO lliLinkDTO = getLliLinkByLliLinkID(lliLinkID);
		LliFarEndDTO lliFarEndDTO = getFarEndByFarEndID(lliLinkDTO.getFarEndID());
		
		// 2. Update Inventory Table
		InventoryService inventoryService = new InventoryService();
		inventoryService.markInventoryItemAsUnused(lliFarEndDTO.getPortID());
		if(lliFarEndDTO.getMandatoryVLanID() != null && lliFarEndDTO.getMandatoryVLanID().length() != 0) {
			inventoryService.markInventoryItemAsUnused(Long.parseLong(lliFarEndDTO.getMandatoryVLanID()));
		}
		if(lliFarEndDTO.getAdditionalVLanID() != null && lliFarEndDTO.getAdditionalVLanID().length() != 0) {
			for(String feAdditionalVlanId : lliFarEndDTO.getAdditionalVLanID().split(",")) {
				long feAdditionalVlanIdLong = Long.parseLong(feAdditionalVlanId.trim());
				inventoryService.markInventoryItemAsUnused(feAdditionalVlanIdLong);
			}
		}
		
		// 3. Update Link End Point Information
		lliFarEndDTO.setPortCategoryType(null);
		lliFarEndDTO.setPortID(0);
		lliFarEndDTO.setMandatoryVLanID(null);
		lliFarEndDTO.setAdditionalVLanID(null);
		
		
		DatabaseConnection databaseConnection = new DatabaseConnection();
		try {
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			
			SqlGenerator.updateEntity(lliFarEndDTO, LliFarEndDTO.class, databaseConnection, true, false);

			databaseConnection.dbTransationEnd();
		} catch (Exception ex) {
			try {
				databaseConnection.dbTransationRollBack();
			} catch (Exception ex2) {
			}
		} finally {
			databaseConnection.dbClose();
		}
	}


	public double getOFCCost(LliLinkDTO lliLinkDTO, LliEndPointDTO lliEndPointDTO, LLIOTCConfigurationDTO commonCharge) throws Exception
	{
		return lliDAO.getOFCCost(lliLinkDTO, lliEndPointDTO, commonCharge);
	}
	public boolean isClientEligibleToBeChargedLessInTemporaryConnection(LliLinkDTO lliLinkDTO, ClientDetailsDTO clientDetailsDTO, double bandwidth) throws Exception{
		boolean result = false;
		if(lliLinkDTO.getConnectionType() == EndPointConstants.CONNECTION_TYPE_TEMPORARY_){
			if( clientDetailsDTO.getRegistrantType() == RegistrantTypeConstants.REGISTRANT_TYPE_GOVT_COMMON || 
				clientDetailsDTO.getRegistrantType() == RegistrantTypeConstants.REGISTRANT_TYPE_MILITARY
			) {
				result = true;
			}else{
				double bw = getTotalActiveLliLinkBandwith(lliLinkDTO);
				if( bw > 300 ) {
					result = true;
				}
			}
		}
		return result;
	}
	private double getTotalActiveLliLinkBandwith(LliLinkDTO lliLinkDTO) throws Exception {
		List<LliLinkDTO> activeLliLinkDTOs = getLinkDTOListByClientID( lliLinkDTO.getClientID(), true);
		double bw = 0.0;
		for( LliLinkDTO link: activeLliLinkDTOs ){
			if( link.getLliBandwidthType() == EntityTypeConstant.BANDWIDTH_TYPE_GB ) {
				bw += link.getLliBandwidth() * 1024;
			}
			else {
				bw += link.getLliBandwidth();
			}
		}
		return bw;
	}




	public static void main(String args[]) throws Exception
	{
		long fromTime = 1512064800000L;
		long toTime = 1514743200000L - 1L;
		CurrentTimeFactory.initializeCurrentTimeFactory();
		BulkBillCreationSummary bulkBillCreationSummary = ServiceDAOFactory.getService(LliLinkService.class).generateLliMonthlyBill(fromTime, toTime);
		logger.debug("bulkBillCreationSummary " + bulkBillCreationSummary);
		System.exit(0);
	}
}
