package lli.link;

import annotation.ColumnName;
import annotation.ForeignKeyName;
import annotation.PrimaryKey;
import annotation.TableName;
import request.CommonRequestDTO;
 
@TableName("at_lli_req_new_link")
public class LliNewLinkRequest extends CommonRequestDTO{
	
	private static final long serialVersionUID = 1L;
	@PrimaryKey
	@ColumnName("ID")
	long ID;
	@ColumnName("linkID")
	long entityID;
	@ColumnName("isDeleted")
	boolean isDelted;
	@ColumnName("lastModificationTime")
	long lastModificationTime;
	public long getID() {
		return ID;
	}
	public void setID(long iD) {
		ID = iD;
	}
	public long getLinkID() {
		return entityID;
	}
	public void setLinkID(long entityID) {
		this.entityID = entityID;
	}
	public boolean isDelted() {
		return isDelted;
	}
	public void setDelted(boolean isDelted) {
		this.isDelted = isDelted;
	}
	public long getLastModificationTime() {
		return lastModificationTime;
	}
	public void setLastModificationTime(long lastModificationTime) {
		this.lastModificationTime = lastModificationTime;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (int) (ID ^ (ID >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		LliNewLinkRequest other = (LliNewLinkRequest) obj;
		if (ID != other.ID)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "LliNewLinkRequest [ID=" + ID + ", entityID=" + entityID
				+ ", isDelted=" + isDelted + ", lastModificationTime="
				+ lastModificationTime + "]";
	}
	
}
