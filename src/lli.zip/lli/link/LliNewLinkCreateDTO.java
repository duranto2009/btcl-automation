//This DTO serve data to LliLinkDTO, LliFarEndDTO,
package lli.link;

import java.util.Arrays;

import org.apache.struts.action.ActionForm;
import org.apache.struts.upload.FormFile;

public class LliNewLinkCreateDTO extends ActionForm {

	private static final long serialVersionUID = 1L;
	// link
	long entityID;
	long linkID;
	String linkName;
	String linkDescription;
	double linkBandwidth;
	int linkBandwidthType;
	double fiveYearBandwidth;
	int fiveYearBandwidthType;
	double loopDistance;
	long clientID;
	int connectionType;
	int lanCounter;
	String lanIdNumbers;
	int layerType;
	int servicePurpose;
	boolean isMigrated;
	
	long feID;
	String feName;
	int feDistrictID;
	int feUpazilaID;
	int feUnionID;
	long fePopID;
	String fePortType;
	String feAddress;
	double feLoopDistance;
	int isFELoopAlreadySetup;
	long feLoopSetupByWhome;
	int feFibreType;
	int feOfcProvider;
	int feProviderServiceType;
	int feOFCLaidBy;
	int feTerminalDeviceProvider;
	int feCoreType;
	long feTerminalDevices[];
	int additionalIPAddressCount;
	
	long nearEndPointID;
	long farEndPointID;
	

	
	String action;
	FormFile document;
	public String[] documents;

	
	// Temporary Connection Duration
	String temporaryConnectionFromDate;
	int temporaryConnectionRange;
	
	
	public String getTemporaryConnectionFromDate() {
		return temporaryConnectionFromDate;
	}
	public void setTemporaryConnectionFromDate(String temporaryConnectionFromDate) {
		this.temporaryConnectionFromDate = temporaryConnectionFromDate;
	}
	public int getTemporaryConnectionRange() {
		return temporaryConnectionRange;
	}
	public void setTemporaryConnectionRange(int temporaryConnectionRange) {
		this.temporaryConnectionRange = temporaryConnectionRange;
	}
	public double getFiveYearBandwidth() {
		return fiveYearBandwidth;
	}
	public void setFiveYearBandwidth(double fiveYearBandwidth) {
		this.fiveYearBandwidth = fiveYearBandwidth;
	}
	public int getFiveYearBandwidthType() {
		return fiveYearBandwidthType;
	}
	public void setFiveYearBandwidthType(int fiveYearBandwidthType) {
		this.fiveYearBandwidthType = fiveYearBandwidthType;
	}
	public long getEntityID() {
		return entityID;
	}
	public void setEntityID(long entityID) {
		this.entityID = entityID;
	}
	public long getLinkID() {
		return linkID;
	}
	public void setLinkID(long linkID) {
		this.linkID = linkID;
	}
	public int getAdditionalIPAddressCount() {
		return additionalIPAddressCount;
	}
	public void setAdditionalIPAddressCount(int additionalIPAddressCount) {
		this.additionalIPAddressCount = additionalIPAddressCount;
	}
	public String getLinkName() {
		return linkName;
	}
	public void setLinkName(String linkName) {
		this.linkName = linkName;
	}
	public String getLinkDescription() {
		return linkDescription;
	}
	public void setLinkDescription(String linkDescription) {
		this.linkDescription = linkDescription;
	}
	public double getLinkBandwidth() {
		return linkBandwidth;
	}
	public void setLinkBandwidth(double linkBandwidth) {
		this.linkBandwidth = linkBandwidth;
	}
	public int getLinkBandwidthType() {
		return linkBandwidthType;
	}
	public void setLinkBandwidthType(int linkBandwidthType) {
		this.linkBandwidthType = linkBandwidthType;
	}
	public double getLoopDistance() {
		return loopDistance;
	}
	public void setLoopDistance(double loopDistance) {
		this.loopDistance = loopDistance;
	}
	public long getClientID() {
		return clientID;
	}
	public void setClientID(long clientID) {
		this.clientID = clientID;
	}
	public int getConnectionType() {
		return connectionType;
	}
	public void setConnectionType(int connectionType) {
		this.connectionType = connectionType;
	}
	public int getLanCounter() {
		return lanCounter;
	}
	public void setLanCounter(int lanCounter) {
		this.lanCounter = lanCounter;
	}
	public String getLanIdNumbers() {
		return lanIdNumbers;
	}
	public void setLanIdNumbers(String lanIdNumbers) {
		this.lanIdNumbers = lanIdNumbers;
	}
	public int getLayerType() {
		return layerType;
	}
	public void setLayerType(int layerType) {
		this.layerType = layerType;
	}
	public long getFeID() {
		return feID;
	}
	public void setFeID(long feID) {
		this.feID = feID;
	}
	public String getFeName() {
		return feName;
	}
	public void setFeName(String feName) {
		this.feName = feName;
	}
	public int getFeDistrictID() {
		return feDistrictID;
	}
	public void setFeDistrictID(int feDistrictID) {
		this.feDistrictID = feDistrictID;
	}
	public int getFeUpazilaID() {
		return feUpazilaID;
	}
	public void setFeUpazilaID(int feUpazilaID) {
		this.feUpazilaID = feUpazilaID;
	}
	public int getFeUnionID() {
		return feUnionID;
	}
	public void setFeUnionID(int feUnionID) {
		this.feUnionID = feUnionID;
	}
	public long getFePopID() {
		return fePopID;
	}
	public void setFePopID(long fePopID) {
		this.fePopID = fePopID;
	}
	public String getFePortType() {
		return fePortType;
	}
	public void setFePortType(String fePortType) {
		this.fePortType = fePortType;
	}
	public String getFeAddress() {
		return feAddress;
	}
	public void setFeAddress(String feAddress) {
		this.feAddress = feAddress;
	}
	public double getFeLoopDistance() {
		return feLoopDistance;
	}
	public void setFeLoopDistance(double feLoopDistance) {
		this.feLoopDistance = feLoopDistance;
	}
	public int getIsFELoopAlreadySetup() {
		return isFELoopAlreadySetup;
	}
	public void setIsFELoopAlreadySetup(int isFELoopAlreadySetup) {
		this.isFELoopAlreadySetup = isFELoopAlreadySetup;
	}
	public long getFeLoopSetupByWhome() {
		return feLoopSetupByWhome;
	}
	public void setFeLoopSetupByWhome(long feLoopSetupByWhome) {
		this.feLoopSetupByWhome = feLoopSetupByWhome;
	}
	public int getFeFibreType() {
		return feFibreType;
	}
	public void setFeFibreType(int feFibreType) {
		this.feFibreType = feFibreType;
	}
	public int getFeOfcProvider() {
		return feOfcProvider;
	}
	public void setFeOfcProvider(int feOfcProvider) {
		this.feOfcProvider = feOfcProvider;
	}
	public int getFeProviderServiceType() {
		return feProviderServiceType;
	}
	public void setFeProviderServiceType(int feProviderServiceType) {
		this.feProviderServiceType = feProviderServiceType;
	}
	public int getFeOFCLaidBy() {
		return feOFCLaidBy;
	}
	public void setFeOFCLaidBy(int feOFCLaidBy) {
		this.feOFCLaidBy = feOFCLaidBy;
	}
	public int getFeTerminalDeviceProvider() {
		return feTerminalDeviceProvider;
	}
	public void setFeTerminalDeviceProvider(int feTerminalDeviceProvider) {
		this.feTerminalDeviceProvider = feTerminalDeviceProvider;
	}
	public int getFeCoreType() {
		return feCoreType;
	}
	public void setFeCoreType(int feCoreType) {
		this.feCoreType = feCoreType;
	}
	public long[] getFeTerminalDevices() {
		return feTerminalDevices;
	}
	public void setFeTerminalDevices(long[] feTerminalDevices) {
		this.feTerminalDevices = feTerminalDevices;
	}
	public long getNearEndPointID() {
		return nearEndPointID;
	}
	public void setNearEndPointID(long nearEndPointID) {
		this.nearEndPointID = nearEndPointID;
	}
	public long getFarEndPointID() {
		return farEndPointID;
	}
	public void setFarEndPointID(long farEndPointID) {
		this.farEndPointID = farEndPointID;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public FormFile getDocument() {
		return document;
	}
	public void setDocument(FormFile document) {
		this.document = document;
	}
	public String[] getDocuments() {
		return documents;
	}
	public void setDocuments(String[] documents) {
		this.documents = documents;
	}
	public int getServicePurpose() {
		return servicePurpose;
	}
	public void setServicePurpose(int servicePurpose) {
		this.servicePurpose = servicePurpose;
	}
	
	public boolean getIsMigrated() {
		return isMigrated;
	}
	public void setIsMigrated(boolean isMigrated) {
		this.isMigrated = isMigrated;
	}
	@Override
	public String toString() {
		return "LliNewLinkCreateDTO [entityID=" + entityID + ", linkID=" + linkID + ", linkName=" + linkName
				+ ", linkDescription=" + linkDescription + ", linkBandwidth="
				+ linkBandwidth + ", linkBandwidthType=" + linkBandwidthType + ", loopDistance=" + loopDistance
				+ ", clientID=" + clientID + ", connectionType=" + connectionType + ", lanCounter=" + lanCounter
				+ ", lanIdNumbers=" + lanIdNumbers + ", layerType=" + layerType + ", servicePurpose=" + servicePurpose
				+ ", isMigrated=" + isMigrated + ", feID=" + feID + ", feName=" + feName + ", feDistrictID="
				+ feDistrictID + ", feUpazilaID=" + feUpazilaID + ", feUnionID=" + feUnionID + ", fePopID=" + fePopID
				+ ", fePortType=" + fePortType + ", feAddress=" + feAddress + ", feLoopDistance=" + feLoopDistance
				+ ", isFELoopAlreadySetup=" + isFELoopAlreadySetup + ", feLoopSetupByWhome=" + feLoopSetupByWhome
				+ ", feFibreType=" + feFibreType + ", feOfcProvider=" + feOfcProvider + ", feProviderServiceType="
				+ feProviderServiceType + ", feOFCLaidBy=" + feOFCLaidBy + ", feTerminalDeviceProvider="
				+ feTerminalDeviceProvider + ", feCoreType=" + feCoreType + ", feTerminalDevices="
				+ Arrays.toString(feTerminalDevices) + ", additionalIPAddressCount=" + additionalIPAddressCount
				+ ", nearEndPointID=" + nearEndPointID + ", farEndPointID=" + farEndPointID + ", action=" + action
				+ ", document=" + document + ", documents=" + Arrays.toString(documents) + "]";
	}


	
	
	

}
