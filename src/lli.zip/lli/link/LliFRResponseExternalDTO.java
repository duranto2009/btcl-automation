package lli.link;
import request.CommonRequestDTO;
import annotation.ColumnName;
import annotation.ForeignKeyName;
import annotation.PrimaryKey;
import annotation.TableName;
 
@SuppressWarnings("serial")
@TableName("at_lli_res_fr_external")
@ForeignKeyName("ReqID")
public class LliFRResponseExternalDTO extends CommonRequestDTO {
	
	static final private String tableName = "at_lli_res_fr_external";
	
	@PrimaryKey
	@ColumnName("ID")
	long ID;
	@ColumnName("lastModificationTime")
	long lastModificationTime;
	@ColumnName("isDeleted")
	boolean isDeleted;
	@ColumnName("distanceTotal")
	int distanceTotal;
	@ColumnName("distanceBTCL")
	int distanceBTCL;
	@ColumnName("distanceOC")
	int distanceOC;
	@ColumnName("distanceCustomer")
	int distanceCustomer;
	@ColumnName("reportType")
	boolean reportType; // 1=positive, 0=negative
	@ColumnName("nearOrFarEndpointID")
	long nearOrFarEndPointID;

	@ColumnName("upazilaSelected")
	long upazilaIDSelected;

	@ColumnName("unionSelected")
	long unionIDSelected;
	
	@ColumnName("rootReqID")
	long rootReqIDInExtentedTable;
	
	@ColumnName("popIDSelected")
	long popIDSelected;
	
	@ColumnName("portTypeIDSelected")
	int portCategoryType;// FE or GE or 10GE
	
	@ColumnName("entityTypeID")
	long entityTypeID;
	
	@ColumnName("reportVersionID")
	int versionID;
	

	public int getVersionID() {
		return versionID;
	}

	public void setVersionID(int versionID) {
		this.versionID = versionID;
	}
	
	public long getID() {
		return ID;
	}
	public void setID(long iD) {
		ID = iD;
	}
	public long getLastModificationTime() {
		return lastModificationTime;
	}
	public void setLastModificationTime(long lastModificationTime) {
		this.lastModificationTime = lastModificationTime;
	}
	public boolean isDeleted() {
		return isDeleted;
	}
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	public int getDistanceTotal() {
		return distanceTotal;
	}
	public void setDistanceTotal(int distanceTotal) {
		this.distanceTotal = distanceTotal;
	}
	public int getDistanceBTCL() {
		return distanceBTCL;
	}
	public void setDistanceBTCL(int distanceBTCL) {
		this.distanceBTCL = distanceBTCL;
	}
	public int getDistanceOC() {
		return distanceOC;
	}
	public void setDistanceOC(int distanceOC) {
		this.distanceOC = distanceOC;
	}
	public int getDistanceCustomer() {
		return distanceCustomer;
	}
	public void setDistanceCustomer(int distanceCustomer) {
		this.distanceCustomer = distanceCustomer;
	}
	public boolean isReportType() {
		return reportType;
	}
	public void setReportType(boolean reportType) {
		this.reportType = reportType;
	}
	public long isNearOrFarEndPointID() {
		return nearOrFarEndPointID;
	}
	public void setNearOrFarEndPointID(long nearOrFarEndPointID) {
		this.nearOrFarEndPointID = nearOrFarEndPointID;
	}
	public static String getTablename() {
		return tableName;
	}
	public long getPopIDSelected() {
		return popIDSelected;
	}
	public void setPopIDSelected(long popIDSelected) {
		this.popIDSelected = popIDSelected;
	}
	
	public long getEntityTypeIDInExtentedTable() {
		return entityTypeID;
	}
	public void setEntityTypeIDInExtentedTable(long entityTypeID) {
		this.entityTypeID = entityTypeID;
	}
	/*public int getPortCategoryType() {
		return portCategoryType;
	}
	public void setPortCategoryType(int portCategoryType) {
		this.portCategoryType = portCategoryType;
	}*/
	public long getUpazilaIDSelected() {
		return upazilaIDSelected;
	}
	public void setUpazilaIDSelected(long upazilaIDSelected) {
		this.upazilaIDSelected = upazilaIDSelected;
	}
	public long getUnionIDSelected() {
		return unionIDSelected;
	}
	public void setUnionIDSelected(long unionIDSelected) {
		this.unionIDSelected = unionIDSelected;
	}
	
	
	public long getRootReqIDInExtentedTable() {
		return rootReqIDInExtentedTable;
	}
	public void setRootReqIDInExtentedTable(long rootReqIDInExtentedTable) {
		this.rootReqIDInExtentedTable = rootReqIDInExtentedTable;
	}
	@Override
	public String toString() {
		return "LliFRResponseExternalDTO [ID=" + ID + ", lastModificationTime=" + lastModificationTime + ", isDeleted="
				+ isDeleted + ", distanceTotal=" + distanceTotal + ", distanceBTCL=" + distanceBTCL + ", distanceOC="
				+ distanceOC + ", distanceCustomer=" + distanceCustomer + ", reportType=" + reportType
				+ ", nearOrFarEndPointID=" + nearOrFarEndPointID + ", upazilaIDSelected=" + upazilaIDSelected
				+ ", unionIDSelected=" + unionIDSelected + ", popIDSelected=" + popIDSelected + ", portCategoryType="
				+ portCategoryType + ", entityTypeID=" + entityTypeID + "]";
	}
	/**
	 * This method is used to initialize object from some value of common requestDTO
	 * More initialization field can be added later.
	 * @author Alam
	 * @param commonRequestDTO From which fields needed to be initialized
	 */
	public void setFromCommonRequestDTO(CommonRequestDTO commonRequestDTO) {
		
		this.setDescription( commonRequestDTO.getDescription() );
		this.setRequestToAccountID( commonRequestDTO.getRequestToAccountID() );
		this.setRequestByAccountID( commonRequestDTO.getRequestByAccountID() );;
		this.setExpireTime( commonRequestDTO.getExpireTime() );
		
		this.setRequestTypeID( commonRequestDTO.getRequestTypeID() );
		this.setEntityTypeID( commonRequestDTO.getEntityTypeID() );
		this.setEntityID( commonRequestDTO.getEntityID() );
		this.setClientID( commonRequestDTO.getClientID() );
		this.setSourceRequestID( commonRequestDTO.getSourceRequestID() );
		
	}

	
	
	
	

	
}
