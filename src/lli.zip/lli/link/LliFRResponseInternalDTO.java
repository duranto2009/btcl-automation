package lli.link;

import annotation.ColumnName;
import annotation.ForeignKeyName;
import annotation.PrimaryKey;
import annotation.TableName;
import request.CommonRequestDTO;

@TableName("at_lli_res_fr_internal")
@ForeignKeyName("reqID")
public class LliFRResponseInternalDTO extends CommonRequestDTO {

	private static final long serialVersionUID = -4814626062909769020L;
	
	static final private String tableName = "at_lli_res_fr_internal";
	@PrimaryKey
	@ColumnName("ID")
	long ID;

	@ColumnName("lastModificationTime")
	long lastModificationTime;
	@ColumnName("isDeleted")
	boolean isDeleted;

	@ColumnName("bandwidthIsAvailable")
	boolean bandWidthIsAvailable;
	@ColumnName("bandwidthComment")
	String bandWidthComment;
	
	public long fePopID;
	
	@ColumnName("feRouterID")
	public long feRouterID;

	@ColumnName("feSwitchID")
	public long feSwitchID;
	
	@ColumnName("feCardID")
	public long feCardID;
	
	@ColumnName("feSlotID")
	public long feSlotID;

	@ColumnName("feMandatoryVlanID")
	public String feMandatoryVlanID;
	
	@ColumnName("feMandatoryVlanComment")
	public String feMandatoryVlanComment;
	
	@ColumnName("feAdditionalVLANIsAvailable")
	public int feAdditionalVLANIsAvailable;
	
	@ColumnName("feAdditionalVlanIDs")
	public String feAdditionalVlanIDs;
	
	@ColumnName("feAdditionalVlanComment")
	public String feAdditionalVlanComment;
	
	@ColumnName("fePortID")
	public long fePortID;
	
	@ColumnName("fePortType")
	public String fePortTypeID;

	@ColumnName("fePortTypeComment")
	public String fePortTypeComment;

	@ColumnName("reportType")
	boolean reportType; // 1=positive, 0=negative

	@ColumnName("linkID")
	long linkID;
	
	@ColumnName("rootReqID")
	long rootReqIDInExtendedTable;
	
	@ColumnName("reportVersionID")
	long versionID;
	
	LliFRResponseExternalDTO lliFRResponseExternalDTO;
	
	@ColumnName("mandatoryIpUnavailabilityReason")
	String mandatoryIpUnavailabilityReason;
	@ColumnName("additionalIpUnavailabilityReason")
	String additionalIpUnavailabilityReason;
	
	@ColumnName("additionalIpAvailableCount")
	int additionalIpAvailableCount;
	
	@ColumnName("mandatoryIPs")
	String mandatoryIPs;
	@ColumnName("additionalIPs")
	String additionalIPs;
	
	int bandwidth;
	int bandwidthType;
	
	public String getMandatoryIPs() {
		return mandatoryIPs;
	}
	public void setMandatoryIPs(String mandatoryIPs) {
		this.mandatoryIPs = mandatoryIPs;
	}
	public String getAdditionalIPs() {
		return additionalIPs;
	}
	public void setAdditionalIPs(String additionalIPs) {
		this.additionalIPs = additionalIPs;
	}
	public long getID() {
		return ID;
	}
	public String getMandatoryIpUnavailabilityReason() {
		return mandatoryIpUnavailabilityReason;
	}
	public void setMandatoryIpUnavailabilityReason(String mandatoryIpUnavailabilityReason) {
		this.mandatoryIpUnavailabilityReason = mandatoryIpUnavailabilityReason;
	}
	public String getAdditionalIpUnavailabilityReason() {
		return additionalIpUnavailabilityReason;
	}

	public void setAdditionalIpUnavailabilityReason(String additionalIpUnavailabilityReason) {
		this.additionalIpUnavailabilityReason = additionalIpUnavailabilityReason;
	}

	

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public void setID(long iD) {
		ID = iD;
	}

	public long getLastModificationTime() {
		return lastModificationTime;
	}

	public void setLastModificationTime(long lastModificationTime) {
		this.lastModificationTime = lastModificationTime;
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public boolean isBandWidthIsAvailable() {
		return bandWidthIsAvailable;
	}

	public void setBandWidthIsAvailable(boolean bandWidthIsAvailable) {
		this.bandWidthIsAvailable = bandWidthIsAvailable;
	}

	public String getBandWidthComment() {
		return bandWidthComment;
	}

	public void setBandWidthComment(String bandWidthComment) {
		this.bandWidthComment = bandWidthComment;
	}

	public boolean isReportType() {
		return reportType;
	}

	public void setReportType(boolean reportType) {
		this.reportType = reportType;
	}

	public LliFRResponseExternalDTO getLliFRResponseExternalDTO() {
		return lliFRResponseExternalDTO;
	}

	public void setLliFRResponseExternalDTO(LliFRResponseExternalDTO lliFRResponseExternalDTO) {
		this.lliFRResponseExternalDTO = lliFRResponseExternalDTO;
	}

	public static String getTablename() {
		return tableName;
	}

	public String getFePortTypeComment() {
		return fePortTypeComment;
	}

	public void setFePortTypeComment(String fePortTypeComment) {
		this.fePortTypeComment = fePortTypeComment;
	}

	public String getFePortTypeID() {
		return fePortTypeID;
	}

	public void setFePortTypeID(String fePortTypeID) {
		this.fePortTypeID = fePortTypeID;
	}

	public long getFePopID() {
		return fePopID;
	}

	public void setFePopID(long fePopID) {
		this.fePopID = fePopID;
	}

	public long getLinkID() {
		return linkID;
	}

	public void setLinkID(long linkID) {
		this.linkID = linkID;
	}

	
	public long getRootReqIDInExtendedTable() {
		return rootReqIDInExtendedTable;
	}

	public void setRootReqIDInExtendedTable(long rootReqIDInExtendedTable) {
		this.rootReqIDInExtendedTable = rootReqIDInExtendedTable;
	}

	
	public long getVersionID() {
		return versionID;
	}

	public void setVersionID(long versionID) {
		this.versionID = versionID;
	}

	public long getFeRouterID() {
		return feRouterID;
	}

	public void setFeRouterID(long feRouterID) {
		this.feRouterID = feRouterID;
	}

	public long getFeSwitchID() {
		return feSwitchID;
	}

	public void setFeSwitchID(long feSwitchID) {
		this.feSwitchID = feSwitchID;
	}

	public long getFeCardID() {
		return feCardID;
	}

	public void setFeCardID(long feCardID) {
		this.feCardID = feCardID;
	}

	public long getFeSlotID() {
		return feSlotID;
	}

	public void setFeSlotID(long feSlotID) {
		this.feSlotID = feSlotID;
	}

	public String getFeMandatoryVlanID() {
		return feMandatoryVlanID;
	}

	public void setFeMandatoryVlanID(String feMandatoryVlanID) {
		this.feMandatoryVlanID = feMandatoryVlanID;
	}

	public String getFeAdditionalVlanIDs() {
		return feAdditionalVlanIDs;
	}

	public void setFeAdditionalVlanIDs(String feAdditionalVlanIDs) {
		this.feAdditionalVlanIDs = feAdditionalVlanIDs;
	}

	public String getFeMandatoryVlanComment() {
		return feMandatoryVlanComment;
	}

	public void setFeMandatoryVlanComment(String feMandatoryVlanComment) {
		this.feMandatoryVlanComment = feMandatoryVlanComment;
	}

	public int getFeAdditionalVLANIsAvailable() {
		return feAdditionalVLANIsAvailable;
	}

	public void setFeAdditionalVLANIsAvailable(int feAdditionalVLANIsAvailable) {
		this.feAdditionalVLANIsAvailable = feAdditionalVLANIsAvailable;
	}

	public String getFeAdditionalVlanComment() {
		return feAdditionalVlanComment;
	}

	public void setFeAdditionalVlanComment(String feAdditionalVlanComment) {
		this.feAdditionalVlanComment = feAdditionalVlanComment;
	}

	public long getFePortID() {
		return fePortID;
	}

	public void setFePortID(long fePortID) {
		this.fePortID = fePortID;
	}

	
	
	public int getBandwidth() {
		return bandwidth;
	}
	public void setBandwidth(int bandwidth) {
		this.bandwidth = bandwidth;
	}
	public int getBandwidthType() {
		return bandwidthType;
	}
	public void setBandwidthType(int bandwidthType) {
		this.bandwidthType = bandwidthType;
	}
	public int getAdditionalIpAvailableCount() {
		return additionalIpAvailableCount;
	}
	public void setAdditionalIpAvailableCount(int additionalIpAvailableCount) {
		this.additionalIpAvailableCount = additionalIpAvailableCount;
	}
	@Override
	public String toString() {
		return "LliFRResponseInternalDTO [ID=" + ID + ", lastModificationTime=" + lastModificationTime + ", isDeleted="
				+ isDeleted + ", bandWidthIsAvailable=" + bandWidthIsAvailable + ", bandWidthComment="
				+ bandWidthComment + ", fePopID=" + fePopID + ", feRouterID=" + feRouterID + ", feSwitchID="
				+ feSwitchID + ", feCardID=" + feCardID + ", feSlotID=" + feSlotID + ", feMandatoryVlanID="
				+ feMandatoryVlanID + ", feMandatoryVlanComment=" + feMandatoryVlanComment
				+ ", feAdditionalVLANIsAvailable=" + feAdditionalVLANIsAvailable + ", feAdditionalVlanIDs="
				+ feAdditionalVlanIDs + ", feAdditionalVlanComment=" + feAdditionalVlanComment + ", fePortID="
				+ fePortID + ", fePortTypeID=" + fePortTypeID + ", fePortTypeComment=" + fePortTypeComment
				+ ", reportType=" + reportType + ", linkID=" + linkID + ", rootReqIDInExtendedTable="
				+ rootReqIDInExtendedTable + ", versionID=" + versionID + ", lliFRResponseExternalDTO="
				+ lliFRResponseExternalDTO + ", mandatoryIpUnavailabilityReason=" + mandatoryIpUnavailabilityReason
				+ ", additionalIpUnavailabilityReason=" + additionalIpUnavailabilityReason + "]";
	}
}
