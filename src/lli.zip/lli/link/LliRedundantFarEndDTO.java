package lli.link;

public class LliRedundantFarEndDTO extends LliEndPointDTO{
	long ID;
	long lliLinkID;
	long lastModificationTime;
	boolean isDeleted;
	
	public long getID() {
		return ID;
	}

	public void setID(long ID) {
		this.ID = ID;
	}

	public long getLastModificationTime() {
		return lastModificationTime;
	}

	public void setLastModificationTime(long lastModificationTime) {
		this.lastModificationTime = lastModificationTime;
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public long getVpnLinkID() {
		return lliLinkID;
	}

	public void setVpnLinkID(long lliLinkID) {
		this.lliLinkID = lliLinkID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (int) (ID ^ (ID >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		LliRedundantFarEndDTO other = (LliRedundantFarEndDTO) obj;
		if (ID != other.ID)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "VpnRedundantFarEndDTO [ID=" + ID + ", lliLinkID=" + lliLinkID
				+ ", lastModificationTime=" + lastModificationTime
				+ ", isDeleted=" + isDeleted + ", lliEndPointID="
				+ lliEndPointID + ", popID=" + popID + ", isDemandnoteCreated="
				+ isDemandnoteCreated + ", activationDate=" + activationDate
				+ ", distanceFromNearestPopInMeter="
				+ distanceFromNearestPopInMeter + ", address=" + address
				+ ", fibreID=" + fibreID + ", fibrePaymentType="
				+ fibrePaymentType + ", coreType=" + coreType + ", fibreCost="
				+ fibreCost + ", terminalDevicePaymentID="
				+ terminalDevicePaymentID + ", terminalDeviceID="
				+ terminalDeviceID + ", portType=" + portCategoryType
				+ ", FRStartDate=" + FRStartDate + ", FRFeedBackDate="
				+ FRFeedBackDate + ", FRResult=" + FRResult + ", FRDeadLine="
				+ FRDeadLine + ", FRContractorID=" + FRContractorID
				+ ", connectionEngrID=" + connectionEngrID
				+ ", connectionResult=" + connectionResult + "]";
	}

}
