package lli.link;

public class LliLinkShiftDAO {
	
}
