package lli.link;

import annotation.ColumnName;
import annotation.ForeignKeyName;
import annotation.PrimaryKey;
import annotation.TableName;

@TableName("at_lli_fe")
@ForeignKeyName("lliEPID")
public class LliFarEndDTO extends LliEndPointDTO{
	@PrimaryKey
	@ColumnName("ID")
	long ID;
	@ColumnName("lastModificationTime")
	long lastModificationTime;
	@ColumnName("isDeleted")
	boolean isDeleted;
	
	public long getID() {
		return ID;
	}

	public void setID(long iD) {
		ID = iD;
	}

	public long getLastModificationTime() {
		return lastModificationTime;
	}

	public void setLastModificationTime(long lastModificationTime) {
		this.lastModificationTime = lastModificationTime;
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (int) (ID ^ (ID >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		LliFarEndDTO other = (LliFarEndDTO) obj;
		if (ID != other.ID)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "LliFarEndDTO [ID=" + ID + ", lastModificationTime=" + lastModificationTime + ", isDeleted=" + isDeleted
				+ ", lliEndPointID=" + lliEndPointID + ", popID=" + popID + ", isDemandnoteCreated=" + isDemandnoteCreated + ", activationDate=" + activationDate
				+ ", distanceFromNearestPopInMeter=" + distanceFromNearestPopInMeter + ", address=" + address
				+ ", fibreID=" + fibreID + ", fibrePaymentType=" + fibrePaymentType + ", coreType=" + coreType + ", fibreCost="
				+ fibreCost + ", terminalDevicePaymentID=" + terminalDevicePaymentID + ", terminalDeviceID="
				+ terminalDeviceID + ", portType=" + portCategoryType + ", FRStartDate=" + FRStartDate + ", FRFeedBackDate="
				+ FRFeedBackDate + ", FRResult=" + FRResult + ", FRDeadLine=" + FRDeadLine + ", FRContractorID="
				+ FRContractorID + ", connectionEngrID=" + connectionEngrID + ", connectionResult=" + connectionResult
				+ "]";
	}

}
