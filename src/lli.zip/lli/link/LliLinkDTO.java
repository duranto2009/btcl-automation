package lli.link;

import java.text.ParseException;
import java.util.Arrays;

import org.apache.struts.action.ActionForm;
import org.apache.struts.upload.FormFile;

import common.EntityDTO;
import common.ModuleConstants;
import report.DateConvertor;
import report.Display;
import report.ReportCriteria;
import report.StatusConverter;
import report.SubqueryBuilderForDate;
import report.SubqueryBuilderForStatus;
import util.TimeConverter;
import annotation.ColumnName;
import annotation.PrimaryKey;
import annotation.SearchFieldFromMethod;
import annotation.TableName;

@SuppressWarnings("serial")
@TableName("at_lli_link")
public class LliLinkDTO extends ActionForm implements EntityDTO{
	@ColumnName("ID")
	@PrimaryKey
	long ID;
	@ColumnName("name")
	String linkName;
	@ColumnName("serviceType")
	int servicePurpose;
	@ColumnName("description")
	String linkDescription;
	@ColumnName("lliFEID")
	long farEndID;
	@ColumnName("lliBW")
	double lliBandwidth;
	@ColumnName("lliBWT")
	int lliBandwidthType;
	
	@ColumnName("fiveYearBandwidth")
	double fiveYearBandwidth;
	@ColumnName("fiveYearBandwidthType")
	int fiveYearBandwidthType;
	
	@ColumnName("lliLD")
	double lliLoopDistance;
	@ColumnName("lastModificationTime")
	long lastModificationTime;
	@ColumnName("isDeleted")
	boolean isDeleted;
	@Display(DateConvertor.class)
	@ReportCriteria(value = SubqueryBuilderForDate.class, moduleID = 0)
	@ColumnName("activationDate")
	long activationDate;
	@ColumnName("clientID")
	long clientID;
	@ColumnName("lliCoreType")
	int coreType;
	@ColumnName("connectionType")
	int connectionType;
	@ColumnName("lanCounter")
	int lanCounter;
	@ColumnName("layerType")
	int layerType;
	@ColumnName("lanIdNumbers")
	String lanIdNumbers;
	@SearchFieldFromMethod(objectClass = LliLinkService.class, methodName = "getCurrentStatusListForLLIFromActivationStatus", parameterType = Integer.class)
	@Display(StatusConverter.class)
	@ReportCriteria(value = SubqueryBuilderForStatus.class, moduleID = ModuleConstants.Module_ID_LLI)
	@ColumnName("currentStatus")
	int currentStatus;
	@ColumnName("latestStatus")
	int latestStatus;	
	@ColumnName("balance")
	double balance;
	@ColumnName("securityMoney")
	double securityMoney;
	@ColumnName("isMigrated")
	boolean isMigrated;
	@ColumnName("additionalIPCount")
	int additionalIPCount;
	@ColumnName("percentageOfDiscountGiven")
	double percentageOfDiscountGiven;
	
	@ColumnName("temporaryConnectionFromDate")
	long temporaryConnectionFromDate;
	@ColumnName("temporaryConnectionRange")
	int temporaryConnectionRange;

	
	public int getCoreType() {
		return coreType;
	}

	public void setCoreType(int coreType) {
		this.coreType = coreType;
	}

	public long getTemporaryConnectionFromDate() {
		return temporaryConnectionFromDate;
	}

	public void setTemporaryConnectionFromDate(String temporaryConnectionFromDate) throws ParseException {
		this.temporaryConnectionFromDate = TimeConverter.getTimeInMilliSec(temporaryConnectionFromDate, "dd/MM/yyyy");
	}


	public int getTemporaryConnectionRange() {
		return temporaryConnectionRange;
	}

	public void setTemporaryConnectionRange(int temporaryConnectionRange) {
		this.temporaryConnectionRange = temporaryConnectionRange;
	}

	public double getPercentageOfDiscountGiven() {
		return percentageOfDiscountGiven;
	}

	public void setPercentageOfDiscountGiven(double percentageOfDiscountGiven) {
		this.percentageOfDiscountGiven = percentageOfDiscountGiven;
	}
	
	
	FormFile document;
	public String[] documents;
	
	long currentTime;
	
	
	public double getFiveYearBandwidth() {
		return fiveYearBandwidth;
	}

	public void setFiveYearBandwidth(double fiveYearBandwidth) {
		this.fiveYearBandwidth = fiveYearBandwidth;
	}

	public int getFiveYearBandwidthType() {
		return fiveYearBandwidthType;
	}

	public void setFiveYearBandwidthType(int fiveYearBandwidthType) {
		this.fiveYearBandwidthType = fiveYearBandwidthType;
	}

	public boolean getIsMigrated() {
		return isMigrated;
	}

	public void setID(long iD) {
		ID = iD;
	}

	public int getAdditionalIPCount() {
		return additionalIPCount;
	}

	public void setAdditionalIPCount(int additionalIPCount) {
		this.additionalIPCount = additionalIPCount;
	}

	public void setIsMigrated(boolean isMigrated) {
		this.isMigrated = isMigrated;
	}

	public FormFile getDocument() {
		return document;
	}

	public void setDocument(FormFile document) {
		this.document = document;
	}

	public String getName(){
		return linkName;
	}
	
	public Long getID() {
		return ID;
	}
	public void setID(Long ID) {
		this.ID = ID;
	}
	
	public long getClientID() {
		return clientID;
	}
	public void setClientID(long clientID) {
		this.clientID = clientID;
	}
	public long getFarEndID() {
		return farEndID;
	}
	public void setFarEndID(long farEndID) {
		this.farEndID = farEndID;
	}
	public double getLliBandwidth() {
		return lliBandwidth;
	}
	public double getLliLoopDistance() {
		return lliLoopDistance;
	}
	public void setLliLoopDistance(double lliLoopDistance) {
		this.lliLoopDistance = lliLoopDistance;
	}
	public void setLliBandwidth(double lliBandwidth) {
		this.lliBandwidth = lliBandwidth;
	}
	
	public int getLliBandwidthType() {
		return lliBandwidthType;
	}

	public void setLliBandwidthType(int lliBandwidthType) {
		this.lliBandwidthType = lliBandwidthType;
	}

	public long getLastModificationTime() {
		return lastModificationTime;
	}
	public void setLastModificationTime(long lastModificationTime) {
		this.lastModificationTime = lastModificationTime;
	}
	public boolean isDeleted() {
		return isDeleted;
	}
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	
	public String getLinkName() {
		return linkName;
	}
	public void setLinkName(String linkName) {
		this.linkName = linkName;
	}
	public String getLinkDescription() {
		return linkDescription;
	}
	public void setLinkDescription(String linkDescription) {
		this.linkDescription = linkDescription;
	}
	
	public long getCurrentTime() {
		return currentTime;
	}

	public void setCurrentTime(long currentTime) {
		this.currentTime = currentTime;
	}

	public String[] getDocuments() {
		return documents;
	}

	public void setDocuments(String[] documents) {
		this.documents = documents;
	}

	/*public int getCoreType() {
		return coreType;
	}

	public void setCoreType(int coreType) {
		this.coreType = coreType;
	}*/

	public int getConnectionType() {
		return connectionType;
	}

	public void setConnectionType(int connectionType) {
		this.connectionType = connectionType;
	}

	public int getLanCounter() {
		return lanCounter;
	}

	public void setLanCounter(int lanCounter) {
		this.lanCounter = lanCounter;
	}

	public String getLanIdNumbers() {
		return lanIdNumbers;
	}

	public void setLanIdNumbers(String lanIdNumbers) {
		this.lanIdNumbers = lanIdNumbers;
	}

	public int getLayerType() {
		return layerType;
	}

	public void setLayerType(int layerType) {
		this.layerType = layerType;
	}

	public int getServicePurpose() {
		return servicePurpose;
	}

	public void setServicePurpose(int servicePurpose) {
		this.servicePurpose = servicePurpose;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (ID ^ (ID >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LliLinkDTO other = (LliLinkDTO) obj;
		if (ID != other.ID)
			return false;
		return true;
	}
	
	public long getActivationDate() {
		return activationDate;
	}
	public void setActivationDate(long activationDate) {
		this.activationDate = activationDate;
	}
	

	@Override
	public boolean isActivated() {
		// TODO Auto-generated method stub
		return activationDate !=0;
	}


	@Override
	public int getCurrentStatus() {
		// TODO Auto-generated method stub
		return currentStatus;
	}
	@Override
	public int getLatestStatus() {
		// TODO Auto-generated method stub
		return latestStatus;
	}
	@Override
	public void setCurrentStatus(int currentStatus) {
		this.currentStatus = currentStatus;
		
	}
	@Override
	public void setLatestStatus(int latestStatus) {
		this.latestStatus = latestStatus;
		
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getSecurityMoney() {
		return securityMoney;
	}

	public void setSecurityMoney(double securityMoney) {
		this.securityMoney = securityMoney;
	}

	@Override
	public String toString() {
		return "LliLinkDTO [ID=" + ID + ", linkName=" + linkName + ", servicePurpose=" + servicePurpose
				+ ", linkDescription=" + linkDescription + ", farEndID=" + farEndID
				+ ", lliBandwidth=" + lliBandwidth + ", lliBandwidthType="
				+ lliBandwidthType + ", lliLoopDistance=" + lliLoopDistance + ", lastModificationTime="
				+ lastModificationTime + ", isDeleted=" + isDeleted + ", activationDate=" + activationDate
				+ ", clientID=" + clientID + ", coreType=" + coreType + ", connectionType=" + connectionType
				+ ", lanCounter=" + lanCounter + ", layerType=" + layerType + ", lanIdNumbers=" + lanIdNumbers
				+ ", currentStatus=" + currentStatus + ", latestStatus=" + latestStatus + ", balance=" + balance
				+ ", securityMoney=" + securityMoney + ", document=" + document + ", documents="
				+ Arrays.toString(documents) + ", currentTime=" + currentTime + "]";
	}

	@Override
	public long getEntityID() {
		return ID;
	}

}
