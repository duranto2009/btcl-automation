package lli.link;


import org.apache.struts.action.ActionForm;

import vpn.link.VpnBandWidthChangeRequestDTO;
 
public class LliLinkCommonForm extends ActionForm  {
	
	LliLinkDTO vpnLinkDTO;
	LliFarEndDTO vpnFarEndDTO;
	VpnBandWidthChangeRequestDTO vpnBandWidthChangeRequestDTO;
	public LliLinkDTO getVpnLinkDTO() {
		return vpnLinkDTO;
	}
	public void setVpnLinkDTO(LliLinkDTO vpnLinkDTO) {
		this.vpnLinkDTO = vpnLinkDTO;
	}
	public LliFarEndDTO getVpnFarEndDTO() {
		return vpnFarEndDTO;
	}
	public void setVpnFarEndDTO(LliFarEndDTO vpnFarEndDTO) {
		this.vpnFarEndDTO = vpnFarEndDTO;
	}
	public VpnBandWidthChangeRequestDTO getVpnBandWidthChangeRequestDTO() {
		return vpnBandWidthChangeRequestDTO;
	}
	public void setVpnBandWidthChangeRequestDTO(VpnBandWidthChangeRequestDTO vpnBandWidthChangeRequestDTO) {
		this.vpnBandWidthChangeRequestDTO = vpnBandWidthChangeRequestDTO;
	}
	@Override
	public String toString() {
		return "VpnLinkCommonForm [vpnLinkDTO=" + vpnLinkDTO + ", vpnFarEndDTO=" + vpnFarEndDTO + ", vpnBandWidthChangeRequestDTO=" + vpnBandWidthChangeRequestDTO
				+ "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((vpnBandWidthChangeRequestDTO == null) ? 0 : vpnBandWidthChangeRequestDTO.hashCode());
		result = prime * result + ((vpnFarEndDTO == null) ? 0 : vpnFarEndDTO.hashCode());
		result = prime * result + ((vpnLinkDTO == null) ? 0 : vpnLinkDTO.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LliLinkCommonForm other = (LliLinkCommonForm) obj;
		if (vpnBandWidthChangeRequestDTO == null) {
			if (other.vpnBandWidthChangeRequestDTO != null)
				return false;
		} else if (!vpnBandWidthChangeRequestDTO.equals(other.vpnBandWidthChangeRequestDTO))
			return false;
		if (vpnFarEndDTO == null) {
			if (other.vpnFarEndDTO != null)
				return false;
		} else if (!vpnFarEndDTO.equals(other.vpnFarEndDTO))
			return false;
		if (vpnLinkDTO == null) {
			if (other.vpnLinkDTO != null)
				return false;
		} else if (!vpnLinkDTO.equals(other.vpnLinkDTO))
			return false;
		return true;
	}
	

}
