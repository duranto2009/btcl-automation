package lli.link;

import lli.LliDAO;
import connection.DatabaseConnection;

public class LliPopService {
	LliDAO lliDAO = new LliDAO();
	public void addLliPop(LliPOP lliPOP){
		DatabaseConnection databaseConnection = new DatabaseConnection();
		try{
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			lliDAO.addPop(lliPOP, databaseConnection);
			databaseConnection.dbTransationEnd();
		}catch(Exception ex){
			try{
				databaseConnection.dbTransationRollBack();
			}catch(Exception ex2){}
		}finally{
			databaseConnection.dbClose();
		}
	}
	public void updateLliPop(LliPOP lliPOP){
		DatabaseConnection databaseConnection = new DatabaseConnection();
		try{
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			lliDAO.updatePop(lliPOP, databaseConnection);
			databaseConnection.dbTransationEnd();
		}catch(Exception ex){
			try{
				databaseConnection.dbTransationRollBack();
			}catch(Exception ex2){}
		}finally{
			databaseConnection.dbClose();
		}
	}
	public void deleteLliPop(LliPOP lliPop){
		DatabaseConnection databaseConnection = new DatabaseConnection();
		try{
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			lliDAO.deletePop(lliPop, databaseConnection);
			databaseConnection.dbTransationEnd();
		}catch(Exception ex){
			try{
				databaseConnection.dbTransationRollBack();
			}catch(Exception ex2){}
		}finally{
			databaseConnection.dbClose();
		}
	}
	public LliPOP getLliPop(long popID){
		LliPOP lliPop = null;
		DatabaseConnection databaseConnection = new DatabaseConnection();
		try{
			databaseConnection.dbOpen();
			databaseConnection.dbTransationStart();
			lliPop = lliDAO.getLliPopByPopID(popID, databaseConnection);
			databaseConnection.dbTransationEnd();
		}catch(Exception ex){
			try{
				databaseConnection.dbTransationRollBack();
			}catch(Exception ex2){}
		}finally{
			databaseConnection.dbClose();			
		}
		return lliPop;
	}
}
