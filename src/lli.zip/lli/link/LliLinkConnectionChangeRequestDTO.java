package lli.link;

import request.CommonRequestDTO;
import annotation.PrimaryKey;
import annotation.TableName;
 
@TableName("at_vpn_req_lk_con_change")
public class LliLinkConnectionChangeRequestDTO extends CommonRequestDTO{
	@PrimaryKey
	long ID;
	long vpnLinkID;
	long newConnectionID;
	long lastModificatoinTime;
	boolean isDeleted;
	@Override
	public String toString() {
		return "VpnLinkOwnerChangeRequestDTO [ID="
				+ ID + ", vpnLinkID=" + vpnLinkID + ", newConnectionID="
				+ newConnectionID + ", lastModificatoinTime=" + lastModificatoinTime
				+ ", isDeleted=" + isDeleted + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (ID ^ (ID >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LliLinkConnectionChangeRequestDTO other = (LliLinkConnectionChangeRequestDTO) obj;
		if (ID != other.ID)
			return false;
		return true;
	}
	public long getID() {
		return ID;
	}
	public void setID(long iD) {
		ID = iD;
	}
	public long getVpnLinkID() {
		return vpnLinkID;
	}
	public void setVpnLinkID(long vpnLinkID) {
		this.vpnLinkID = vpnLinkID;
	}
	public long getLastModificatoinTime() {
		return lastModificatoinTime;
	}
	public void setLastModificatoinTime(long lastModificatoinTime) {
		this.lastModificatoinTime = lastModificatoinTime;
	}
	public boolean isDeleted() {
		return isDeleted;
	}
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
}	
