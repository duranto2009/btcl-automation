package lli;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;

import annotation.DAO;
import annotation.Transactional;
import common.EntityTypeConstant;
import common.bill.BillDAO;
import lli.bill.LLIMonthlyBillDTO;
import requestMapping.Service;
import util.DateRange;
import util.DateUtils;
import util.ServiceDAOFactory;
import util.TimeConverter;
public class LLIMonthlyBillService {
	@DAO
	BillDAO billDAO;
	@Service
	LLIConnectionService lliConnectionService;
	Logger logger = Logger.getLogger(LLIMonthlyBillService.class);
	
	
	
	public double getLLIMontlyBillByClientIDAndTime(long clientID,long date) throws Exception{
		return 1000.0;
	}
	
	
	
	@Transactional(transactionType=util.TransactionType.READONLY)
	public void createMonthlyBillByClientIDAndDateRange(long clientID,long fromDate,long toDate) throws Exception{
		/***
		 * main method for creating monthly bill given client Id, DateRange. 
		 * It will call its sister method passed another parameter which determines 
		 * whether we consider previous month usage or not. 
		 * By Default it will assume we will consider previous month usage.
		 */
		createMonthlyBillByClientIDAndDateRange(clientID, fromDate, toDate, true);
	}	
	public void createMonthlyBillByClientIDAndDateRange(long clientID,long fromDate,long toDate, boolean considerPreviousMonthUsage) throws Exception{
		/***
		 * this is sister method, considering previous month usage.
		 * produces a LLIMonthlyBillDTO by breaking the dateRange into multiple bill cycle 
		 * and produce lliMonthlyBillUnits for all single bill cycles combine everything to produce
		 * a single LLIMOnthlyDTO. So eventually we will get several bill DTOs each for every Date ranges.
		 */
		
		Map<Long,List<LLIConnectionInstance>> mapOfLLIConnectionInstanceListByConnectionID = 
				lliConnectionService.getMapOfLLIConnectionInstanceListByConnectionIDOfAClient(clientID, fromDate, toDate);
		int billCycleDate = getBillingCycleOfAMonthByTime(fromDate);
		/*** temporary testing purpose***/
		fromDate = getStartTimeOfBillCycleDateOfPrevMonthByFromDate(fromDate, getBillingCycleOfAMonthByTime(fromDate));
		/***/
		// split the fromDate and to toDate by bill cycle date and store in a list
		List<DateRange> billStartDates = getDateRangeListBySplittingADateRangeWithDayOfAMonth(fromDate, toDate, billCycleDate);
		for(int i=0;i<billStartDates.size();i++){
			DateRange dateRange = billStartDates.get(i);
			if(i==0 && considerPreviousMonthUsage) {
				considerPreviousMonthUsage = matchesWithBillCycleStartDate(dateRange.fromDate);
			} else {
				considerPreviousMonthUsage = false;
			}
			LLIMonthlyBillDTO lliMonthlyBillDTO = createMonthlyBillWithinSingleBillCycle(clientID,dateRange.fromDate,
					dateRange.toDate,considerPreviousMonthUsage, mapOfLLIConnectionInstanceListByConnectionID);
			logger.debug("----------------------");
			logger.debug(dateRange.toString());
			logger.debug(lliMonthlyBillDTO);
			logger.debug("----------------------");
		}		
	}
	
	
	private LLIMonthlyBillDTO createMonthlyBillWithinSingleBillCycle(long clientID, long queryFromDate, 
			long queryToDate,boolean considerPreviousMonthsUsage, Map<Long, List<LLIConnectionInstance>> mapOfLLIConnectionInstanceListByConnectionID ) throws Exception {
		/***
		 * This is a method for calculating monthly bill for individual/single bill cycle. 
		 * its from and to date are not the same as the main methods from and to date. 
		 * Rather it is a part of the main date range. i.e. 
		 * main -> from, to January - December
		 * this -> from, to January - February, February - March, March - April etc... Nov - Dec.
		 * 
		 * 
		 * We will first find out which bills of a given time period has been created before.
		 * Then we will exclude those because we need to generate bills for those periods which do not have a bill.
		 * After getting the time ranges for which we need to generate a bill we will call a method which will return 
		 * lliMonthly bill units for those periods.
		 * Finally we will make a LLIMonthlyBillDTO by those bill units.
		 */
		
		List<DateRange> dateRangesOfAlreadyCreatedMonthlyBills = 
				billDAO.getDateRangesOfAlreadyCreatedMonthlyBills(clientID, EntityTypeConstant.LLI_LINK, queryFromDate, queryToDate);
				//getDummyRanges(
				//clientID, EntityTypeConstant.LLI_LINK, queryFromDate, queryToDate); //
		List<DateRange> dateRangesOfMustBeCreatedMonthlyBills = getDateRangesOfMustBeCreatedMonthlyBill(queryFromDate, queryToDate, 
				dateRangesOfAlreadyCreatedMonthlyBills);
		List<LLIMonthlyBillUnit> lliMonthlyBillUnits = getLLIMonthlyBillUnitsInASingleBillCycle(clientID, queryFromDate, queryToDate, 
				considerPreviousMonthsUsage, dateRangesOfMustBeCreatedMonthlyBills, mapOfLLIConnectionInstanceListByConnectionID);
		for(LLIMonthlyBillUnit lliMonthlyBillUnit: lliMonthlyBillUnits) {
			logger.debug(lliMonthlyBillUnit.toString());
		}
//		JasperTestingLLI.getJasper(lliMonthlyBillUnits);
		return getLLIMonthlyBillDTOByBillUnits(lliMonthlyBillUnits);
 	}
	
	
	private List<LLIMonthlyBillUnit> getLLIMonthlyBillUnitsInASingleBillCycle(long clientID, long queryFromDate,
			long queryToDate, boolean considerPreviousMonthsUsage, List<DateRange> dateRangesOfMustBeCreatedMonthlyBills, 
			Map<Long, List<LLIConnectionInstance>> mapOfLLIConnectionInstanceListByConnectionID) throws Exception {
		List<LLIMonthlyBillUnit> lliMonthlyBillUnits = new ArrayList<>();
		if(considerPreviousMonthsUsage) {
			considerPreviousMonthsUsage(lliMonthlyBillUnits, mapOfLLIConnectionInstanceListByConnectionID, queryFromDate);
		}
		List<LLIConnectionInstance> instanceList = lliConnectionService.getLLIConnectionInstanceListByClientIDAndDateRange(clientID, queryFromDate, queryToDate);
		for(DateRange mustBeCreatedDateRange:dateRangesOfMustBeCreatedMonthlyBills) {
			lliMonthlyBillUnits.addAll( 
					getLLIMonthlyBillUnitListByConnectionInstanceList(instanceList,mustBeCreatedDateRange.fromDate, mustBeCreatedDateRange.toDate)
				); 
		}
		return lliMonthlyBillUnits;
	}
	private void considerPreviousMonthsUsage(List<LLIMonthlyBillUnit> lliMonthlyBillUnits, 
			Map<Long, List<LLIConnectionInstance>> mapOfLLIConnectionInstanceListByConnectionID, long queryFromDate) throws Exception {
		for(List<LLIConnectionInstance> connectionInstanceList:mapOfLLIConnectionInstanceListByConnectionID.values()) {
			long billcycleDateOfPreviousMonth = getStartTimeOfBillCycleDateOfPrevMonthByFromDate(queryFromDate, getBillingCycleOfAMonthByTime(queryFromDate));
			LLIConnectionInstance lliConnectionInstance = connectionInstanceList
													.stream()
													.filter((instance) -> instance.getActiveFrom() <= billcycleDateOfPreviousMonth 
																			&& billcycleDateOfPreviousMonth <instance.getActiveTo()
													).findFirst()
													.orElse(null);
			if(lliConnectionInstance==null) {
				return; // no connectionInstance found which undergoes a change after the prev months bill cycle date.
			}
			long fromTimeOfPrevMonthUsage = TimeConverter.getStartTimeOfTheDay(lliConnectionInstance.getActiveTo());
			if(fromTimeOfPrevMonthUsage>=queryFromDate) {
				return;// no config change on previous month
			}
			long toTimeOfPrevMonthUsage = queryFromDate-1;
			List<LLIMonthlyBillUnit> previousMonthlyBillUnits = getLLIMonthlyBillUnitListByConnectionInstanceList(
					connectionInstanceList, fromTimeOfPrevMonthUsage, toTimeOfPrevMonthUsage);
			lliMonthlyBillUnits.addAll(previousMonthlyBillUnits);
		}
	}
	private LLIMonthlyBillDTO getLLIMonthlyBillDTOByBillUnits(List<LLIMonthlyBillUnit> lliMonthlyBillUnits) throws Exception {
		LLIMonthlyBillDTO lliMonthlyBillDTO  = new LLIMonthlyBillDTO ();
		lliMonthlyBillDTO.setSumOfBillUnits(lliMonthlyBillUnits
											.stream()
											.mapToDouble(bu->bu.getBandwidthCost() + bu.getCoreCost())
											.sum()
											);
		lliMonthlyBillDTO.setAdjustmentAmountOfPrevMonth(getPreviousBillingCycleAdjustmentMoney());
		lliMonthlyBillDTO.setLliMonthlyBillUnits(lliMonthlyBillUnits);
		
		return lliMonthlyBillDTO;
	}
	public List<LLIMonthlyBillUnit> getLLIMonthlyBillUnitListByConnectionInstanceList(
			List<LLIConnectionInstance> instanceList,long fromDate,long toDate) throws Exception{
		
		List<LLIMonthlyBillUnit> lliMonthlyBilllUnits = new ArrayList<>();
		for(int i = 0;i<instanceList.size();i++){
			LLIConnectionInstance connectionInstance = instanceList.get(i);
			if(i == 0){
				LLIMonthlyBillUnit lliMonthlyBilllUnit = createLLIMonthlyBillUnitByConnectionInstance(connectionInstance, fromDate, toDate);
				lliMonthlyBilllUnits.add(lliMonthlyBilllUnit);
			}else{
				LLIMonthlyBillUnit lliMonthlyBilllUnit = new LLIMonthlyBillUnit();
				if(differenceExists(instanceList.get(i), instanceList.get(i-1))){
					lliMonthlyBilllUnit = createLLIMonthlyBillUnitByConnectionInstance(connectionInstance, fromDate, toDate);
					LLIMonthlyBillUnit lastLliMonthlyBillUnit = lliMonthlyBilllUnits.get(lliMonthlyBilllUnits.size()-1);
					populateBWCostAndCoreCost(lliMonthlyBilllUnit);
					if(DateUtils.isOnSameDay(lastLliMonthlyBillUnit.getFromDate(), lliMonthlyBilllUnit.getFromDate())){
						lliMonthlyBilllUnits.set(lliMonthlyBilllUnits.size()-1, lliMonthlyBilllUnit);
					}else{
						lliMonthlyBilllUnits.add(lliMonthlyBilllUnit);
					}
				}else{
					LLIMonthlyBillUnit lastLLIMonthlyBillUnit = lliMonthlyBilllUnits.get(lliMonthlyBilllUnits.size()-1);
					lastLLIMonthlyBillUnit.setToDate(connectionInstance.getActiveTo());
					populateBWCostAndCoreCost(lastLLIMonthlyBillUnit);
				}
			}
		}
		return lliMonthlyBilllUnits;
	}
	
	private List<DateRange> getDateRangesOfMustBeCreatedMonthlyBill(long queryFromDate, long queryToDate,
			List<DateRange> dateRangesOfAlreadyCreatedMonthlyBills) throws Exception {
		List<DateRange> dateRangeList = new ArrayList<>();
		for(int i=1;i<dateRangesOfAlreadyCreatedMonthlyBills.size();i++) {
			DateRange dateRangeNext = dateRangesOfAlreadyCreatedMonthlyBills.get(i);
			DateRange dateRangePrev = dateRangesOfAlreadyCreatedMonthlyBills.get(i - 1);
			if(dateRangePrev.fromDate <= dateRangeNext.fromDate && dateRangeNext.fromDate <= dateRangePrev.toDate) {
				throw new Exception("Corrupt data in Bill, Activation Date of one bill collides with other bills activation date.");
			}
		}
		long pivot = queryFromDate;
		for(DateRange dateRange: dateRangesOfAlreadyCreatedMonthlyBills) {
			if(pivot<dateRange.fromDate) {
				dateRangeList.add(DateRange.getDateRangeByFromToDate(pivot, Math.min(dateRange.fromDate-1,queryToDate)));
			}
			pivot = Math.max(dateRange.toDate+1, queryFromDate);
			if(pivot>=queryToDate) {
				break;
			}
		}
		if(dateRangeList.isEmpty()) {
			dateRangeList.add(DateRange.getDateRangeByFromToDate(queryFromDate, queryToDate));
		}
		return dateRangeList;
	}
	public int getBillingCycleOfAMonthByTime(long time) {
		return 1;
	}
	
	private boolean matchesWithBillCycleStartDate(long fromDate) {
		// to be filled
		return true;
	}
	private void populateBWCostAndCoreCost(LLIMonthlyBillUnit lliMonthlyBilllUnit){
		/// filled up by raihan
	}
	
	
	@SuppressWarnings("unused")
	private double getPreviousBillingCycleAdjustmentMoney() throws Exception{
		// filled up by  raihan
		return 0.0;
	}
	
	
	private long getStartTimeOfBillCycleDateOfPrevMonthByFromDate(long fromDate, int billCycleDate) {
		Calendar calendar = DateUtils.getCalendarByMillis(fromDate);
		calendar.add(Calendar.MONTH, -1);
		calendar.set(Calendar.DATE, billCycleDate);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTimeInMillis();
	}
	
	
	private LLIMonthlyBillUnit createLLIMonthlyBillUnitByConnectionInstance(LLIConnectionInstance connectionInstance, long fromDate, long toDate) throws Exception{
		LLIMonthlyBillUnit lliMonthlyBilllUnit = new LLIMonthlyBillUnit();
		lliMonthlyBilllUnit.setBandwidth(connectionInstance.getBandwidth());
		lliMonthlyBilllUnit.setBandwidthMRC(getBwMRC(fromDate, getBillingCycleOfAMonthByTime(fromDate)));
		lliMonthlyBilllUnit.setConnectionID(connectionInstance.getID());
		lliMonthlyBilllUnit.setCoreMRC(getCoreMRC(connectionInstance));
		lliMonthlyBilllUnit.setFromDate(fromDate);
								
		lliMonthlyBilllUnit.setNumberOfCores(connectionInstance.getLliOffices()
				.stream()
				.map(office -> office.getLocalLoops())
				.flatMap(List::stream)
				.mapToInt(LLILocalLoop::getNumOfCore)
				.sum());
												
		lliMonthlyBilllUnit.setToDate(toDate);
		lliMonthlyBilllUnit.setTotalCoreDistance(connectionInstance.getLliOffices()
				.stream()
				.map(office -> office.getLocalLoops())
				.flatMap(List::stream)
				.mapToDouble(loop -> loop.btclDistance + loop.OCDistance)
				.sum());
												
		return lliMonthlyBilllUnit;
	}
	private double getCoreMRC(LLIConnectionInstance connectionInstance) throws Exception {
		List<LLIOffice> lliOffices = connectionInstance.getLliOffices();
		int sumOfCore = 0;
		int sumOfDistances = 0;
		for(LLIOffice office : lliOffices) {
			List<LLILocalLoop> lliLocalLoops = office.getLocalLoops();
			for(LLILocalLoop localLoop: lliLocalLoops) {
				sumOfDistances += (localLoop.getBtclDistance() + localLoop.getOCDistance());
				sumOfCore += localLoop.getNumOfCore();
			}
		}
		return new LLICoreCostChart().getCoreCostByNumberOfCoreAndDistance(sumOfCore, sumOfDistances);
	}
	private double getBwMRC(long fromDate, int billingCycleDate) throws Exception {
		long billingCycleFromTime = getStartTimeOfBillCycleDateOfPrevMonthByFromDate(fromDate, billingCycleDate);
		LLIBWCostChart llibwCostChart = getLLIBWCostChart(billingCycleFromTime);
		return llibwCostChart.getBWCostByAgreementTypeAndBW(LLIBWCostChart.REGULAR_AGREEMENT, 25.0);
	}
	
	private LLIBWCostChart getLLIBWCostChart(long billingCycleFromTime) throws Exception {
		LLIBWCostChart llibwCostChart = new LLIBWCostChart();
		return llibwCostChart;
	}
	
	private List<DateRange> getDateRangeListBySplittingADateRangeWithDayOfAMonth (long fromDate, long toDate, int dayOfAMonth)throws Exception {
		if(dayOfAMonth > 28 || dayOfAMonth < 1) {
			throw new Exception("Requested date should be in range of 1-28");
		}
		Calendar fromCalendar = Calendar.getInstance();
		Calendar toCalendar = Calendar.getInstance();
		Calendar pivotCalendar = Calendar.getInstance();
		populateNecessaryCalendars(fromCalendar, toCalendar, pivotCalendar, fromDate, toDate, dayOfAMonth);
		return getDateRangeListByCalendars(fromCalendar, toCalendar, pivotCalendar);
	}
	
	private void populateNecessaryCalendars(Calendar fromCalendar, Calendar toCalendar, Calendar pivotCalendar, 
			long fromDate, long toDate, int dayOfAMonth) throws Exception{
		fromCalendar.setTimeInMillis(TimeConverter.getStartTimeOfTheDay(fromDate));
		toCalendar.setTimeInMillis(TimeConverter.getStartTimeOfTheNextNthDay(toDate, 1)-1);
		pivotCalendar.setLenient(false);
		try {
			if(fromCalendar.get(Calendar.DATE) < dayOfAMonth) {
				pivotCalendar.set(fromCalendar.get(Calendar.YEAR), fromCalendar.get(Calendar.MONTH), dayOfAMonth, 0, 0, 0);
				pivotCalendar.set(Calendar.MILLISECOND, 0);
			}else {
				pivotCalendar.set(fromCalendar.get(Calendar.YEAR), fromCalendar.get(Calendar.MONTH) + 1, dayOfAMonth, 0, 0, 0);
				pivotCalendar.set(Calendar.MILLISECOND, 0);
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
			throw new Exception("Error in creating calendar instance");
		}
	}
	private List<DateRange> getDateRangeListByCalendars(Calendar fromCalendar, Calendar toCalendar, Calendar pivotCalendar) {
		List<DateRange> listOfSplittedDateRange = new ArrayList<>();
		DateRange dateRange = DateRange.getDateRangeByFromToDate(fromCalendar.getTimeInMillis(), pivotCalendar.getTimeInMillis()-1);
		listOfSplittedDateRange.add(dateRange);
		while(pivotCalendar.before(toCalendar)) {
			long from = pivotCalendar.getTimeInMillis(), to;
			pivotCalendar.add(Calendar.MONTH, 1);
			if(pivotCalendar.before(toCalendar)) {
				to = pivotCalendar.getTimeInMillis() - 1;
			}else {
				to = toCalendar.getTimeInMillis();
			}
			DateRange dateRange2 = DateRange.getDateRangeByFromToDate(from, to);
			listOfSplittedDateRange.add(dateRange2);
		}
		return listOfSplittedDateRange;
	}
	public static boolean differenceExists(LLIConnectionInstance instance1,LLIConnectionInstance instance2){
		return !instance1.equals(instance2);
	}
	public static void main(String []args) throws Exception {
		
		
		
		
		
		
		
		
		
		
		
		
		LLIMonthlyBillService lliMonthlyBillService = ServiceDAOFactory.getService(LLIMonthlyBillService.class);
//		lliMonthlyBillService.getDateRangeListBySplittingADateRangeWithDayOfAMonth(1525063447000L, 1535085847000L, 20);
//		lliMonthlyBillService.getDateRangeListBySplittingADateRangeWithDayOfAMonth(1525063447000L, 1535085847000L, 24);
//		lliMonthlyBillService.getDateRangeListBySplittingADateRangeWithDayOfAMonth(1525063447000L, 1535085847000L, 26);
		long fromDate = TimeConverter.getTimeInMilliSec("12/12/2017", "dd/MM/yyyy");
		long toDate = TimeConverter.getTimeInMilliSec("12/7/2018", "dd/MM/yyyy");
//		lliMonthlyBillService.createMonthlyBillByClientIDAndDateRange(53000L, fromDate, toDate);
		
		
		LLIConnectionService lliConnectionService = ServiceDAOFactory.getService(LLIConnectionService.class);
		lliConnectionService.getMapOfLLIConnectionInstanceListByConnectionIDOfAClient(53000L, fromDate, toDate);
		Map<Long, List<LLIConnectionInstance>> map = lliConnectionService.getMapOfLLIConnectionInstanceListByConnectionIDOfAClient(53000L, fromDate, toDate);
		for(Entry<Long, List<LLIConnectionInstance>> e : map.entrySet()) {
			Long connectionID = e.getKey();
			List<LLIConnectionInstance>list = lliConnectionService.getFilteredInstanceList(e.getValue());
			map.put(connectionID, list);
		}
		map.forEach((k,v) ->{
			System.out.println(k + " -> " + v);
		});
	}
}
