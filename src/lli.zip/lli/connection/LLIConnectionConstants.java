package lli.connection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lli.LLIActionButton;
import lli.Application.LLIApplication;
import lli.Application.AdditionalConnectionAddress.LLIAdditionalConnectionAddressApplication;
import lli.Application.AdditionalIP.LLIAdditionalIPApplication;
import lli.Application.AdditionalLocalLoop.LLIAdditionalLocalLoopApplication;
import lli.Application.AdditionalPort.LLIAdditionalPortApplication;
import lli.Application.BreakLongTerm.LLIBreakLongTermApplication;
import lli.Application.ChangeBillingAddress.LLIChangeBillingAddressApplication;
import lli.Application.ChangeOwnership.LLIChangeOwnershipApplication;
import lli.Application.CloseConnection.LLICloseConnectionApplication;
import lli.Application.DowngradeBandwidth.LLIDowngradeBandwidthApplication;
import lli.Application.NewConnection.LLINewConnectionApplication;
import lli.Application.NewLongTerm.LLINewLongTermApplication;
import lli.Application.Reconnect.LLIReconnectApplication;
import lli.Application.ReleaseConnectionAddress.LLIReleaseConnectionAddressApplication;
import lli.Application.ReleaseIP.LLIReleaseIPApplication;
import lli.Application.ReleaseLocalLoop.LLIReleaseLocalLoopApplication;
import lli.Application.ReleasePort.LLIReleasePortApplication;
import lli.Application.ShiftAddress.LLIShiftAddressApplication;
import lli.Application.ShiftBandwidth.LLIShiftBandwidthApplication;
import lli.Application.ShiftPop.LLIShiftPopApplication;
import lli.Application.TemporaryUpgradeBandwidth.LLITemporaryUpgradeBandwidthApplication;
import lli.Application.upgradeBandwidth.LLIUpgradeBandwidthApplication;

public class LLIConnectionConstants {
	/*EntityType*/
	public static final int ENTITY_TYPE = 702;
	
	/*Connection Status*/
	public static final int STATUS_ACTIVE = 1;
	public static final int STATUS_TD = 2;
	public static final int STATUS_CLOSED = 3;
	
	@SuppressWarnings({ "rawtypes", "unchecked", "serial" })
	public static Map<Integer, String> connectionStatusMap = new HashMap() {{
		put(STATUS_ACTIVE, "Active");
		put(STATUS_TD, "Temporarily Disconnected");
		put(STATUS_CLOSED, "Closed");
	}};
	/*Connection Status*/
	
	
	/*Connection Type*/
	public static final int CONNECTION_TYPE_REGULAR = 1;
	public static final int CONNECTION_TYPE_TEMPORARY = 2;
	public static final int CONNECTION_TYPE_CACHE = 3;
	public static final int CONNECTION_TYPE_REGULAR_LONG = 4;
	
	@SuppressWarnings({ "rawtypes", "unchecked", "serial" })
	public static Map<Integer, String> connectionTypeMap = new HashMap() {{
		put(CONNECTION_TYPE_REGULAR, "Regular");
		put(CONNECTION_TYPE_TEMPORARY, "Temporary");
		put(CONNECTION_TYPE_CACHE, "Transmission for Cache");
		put(CONNECTION_TYPE_REGULAR_LONG, "Regular with Long Term");
	}};
	/*Connection Type*/
	
	/*Loop Provider Type*/
	public static final int LOOP_PROVIDER_BTCL = 1;
	public static final int LOOP_PROVIDER_CLIENT = 2;
	
	@SuppressWarnings({ "rawtypes", "unchecked", "serial" })
	public static Map<Integer, String> loopProviderMap = new HashMap() {{
		put(LOOP_PROVIDER_BTCL, "BTCL");
		put(LOOP_PROVIDER_CLIENT, "Client");
	}};
	/*Loop Provider Type*/
	
	/*OFC Type*/
	public static final int OFC_TYPE_SINGLE = 1;
	public static final int OFC_TYPE_DUAL = 2;
	@SuppressWarnings({ "rawtypes", "unchecked", "serial" })
	public static Map<Integer, String> ofcTypeMap = new HashMap() {{
		put(OFC_TYPE_SINGLE, "Single");
		put(OFC_TYPE_DUAL, "Dual");
	}};
	/*OFC Type*/
	
	
	
	/*Application Status*/
	public static final int STATUS_APPLIED = 1;
	public static final int STATUS_VERIFIED = 2;
	public static final int STATUS_PROCESSED = 3;
	public static final int STATUS_FINALIZED = 4;
	public static final int STATUS_DEMAND_NOTE_GENERATED = 5;
	public static final int STATUS_PAYMENT_CLEARED = 6;
	public static final int STATUS_COMPLETED = 7;
	public static final int STATUS_REQUESTED_FOR_CORRECTION = 50;
	public static final int STATUS_REJECTED = 51;
	
	@SuppressWarnings({ "rawtypes", "unchecked", "serial" })
	public static Map<Integer, String> applicationStatusMap = new HashMap() {{
		put(STATUS_APPLIED, "Applied");
		put(STATUS_VERIFIED, "Verified");
		put(STATUS_PROCESSED, "Processed");
		put(STATUS_FINALIZED, "Finalized");
		put(STATUS_DEMAND_NOTE_GENERATED, "Demand Note Generated");
		put(STATUS_PAYMENT_CLEARED, "Payment Cleared");
		put(STATUS_COMPLETED, "Completed");
		put(STATUS_REQUESTED_FOR_CORRECTION, "Requested For Correction");
		put(STATUS_REJECTED, "Rejected");
	}};
	/*Application Status*/
	
	/*Application Type*/
	public static final int NEW_CONNECTION = 1;
	public static final int UPGRADE_BANDWIDTH = 2;
	public static final int DOWNGRADE_BANDWIDTH = 3;
	public static final int TEMPORARY_UPGRADE_BANDWIDTH = 4;
	public static final int ADDITIONAL_PORT = 5;
	public static final int RELEASE_PORT = 6;
	public static final int ADDITIONAL_LOCAL_LOOP = 7;
	public static final int RELEASE_LOCAL_LOOP = 8;
	public static final int ADDITIONAL_IP = 9;
	public static final int RELEASE_IP = 10;
	public static final int ADDITIONAL_CONNECTION_ADDRESS = 11;
	public static final int SHIFT_CONNECTION_ADDRESS = 12;
	public static final int RELEASE_CONNECTION_ADDRESS = 13;
	public static final int SHIFT_POP = 14;
	public static final int NEW_LONG_TERM = 15;
	public static final int BREAK_LONG_TERM = 16;
	public static final int SHIFT_BANDWIDTH = 17;
	public static final int CHANGE_OWNERSHIP = 18;
	public static final int RECONNECT = 19;
	public static final int CHANGE_BILLING_ADDRESS = 20;
	public static final int CLOSE_CONNECTION = 21;
	
	
	@SuppressWarnings({ "rawtypes", "unchecked", "serial" })
	public static Map<Integer, String> applicationTypeNameMap = new HashMap() {{
		put(NEW_CONNECTION, "New Connection");
		put(UPGRADE_BANDWIDTH, "Upgrade Bandwidth");
		put(DOWNGRADE_BANDWIDTH, "Downgrade Bandwidth");
		put(TEMPORARY_UPGRADE_BANDWIDTH, "Temporary Upgrade Bandwidth");
		put(ADDITIONAL_PORT, "Additional Port");
		put(RELEASE_PORT, "Release Port");
		put(ADDITIONAL_LOCAL_LOOP, "Additional Local Loop");
		put(RELEASE_LOCAL_LOOP, "Release Local Loop");
		put(ADDITIONAL_IP, "Additional IP");
		put(RELEASE_IP, "Release IP");
		put(ADDITIONAL_CONNECTION_ADDRESS, "Additional Address");
		put(SHIFT_CONNECTION_ADDRESS, "Shift Address");
		put(RELEASE_CONNECTION_ADDRESS, "Release Address");
		put(SHIFT_POP, "Shift Pop");
		put(NEW_LONG_TERM, "New Long Term");
		put(BREAK_LONG_TERM, "Break Long Term");
		put(SHIFT_BANDWIDTH, "Shift Bandwidth");
		put(CHANGE_OWNERSHIP, "Change Ownership");
		put(RECONNECT, "Reconnect");
		put(CHANGE_BILLING_ADDRESS, "Change Billing Address");
		put(CLOSE_CONNECTION, "Close Connection");
	}};
	
	
	@SuppressWarnings({ "rawtypes", "unchecked", "serial" })
	public static Map<Integer, String> applicationTypeHyphenSeperatedMap = new HashMap() {{
		put(NEW_CONNECTION, "new-connection");
		put(UPGRADE_BANDWIDTH, "upgrade-bandwidth"); // REVISE
		put(DOWNGRADE_BANDWIDTH, "downgrade-bandwidth"); // REVISE
		put(TEMPORARY_UPGRADE_BANDWIDTH, "temporary-upgrade-bandwidth"); // REVISE
		put(ADDITIONAL_PORT, "additional-port"); // REVISE
		put(RELEASE_PORT, "release-port"); // REVISE
		put(ADDITIONAL_LOCAL_LOOP, "additional-local-loop"); // REVISE
		put(RELEASE_LOCAL_LOOP, "release-local-loop"); // REVISE
		put(ADDITIONAL_IP, "additional-ip"); // REVISE
		put(RELEASE_IP, "release-ip"); // REVISE
		put(ADDITIONAL_CONNECTION_ADDRESS, "additional-connection-address"); // REVISE
		put(SHIFT_CONNECTION_ADDRESS, "shift-address"); // REVISE
		put(RELEASE_CONNECTION_ADDRESS, "release-connection-address"); // REVISE
		put(SHIFT_POP, "shift-pop"); // REVISE
		put(NEW_LONG_TERM, "new-long-term"); 
		put(BREAK_LONG_TERM, "break-long-term");
		put(SHIFT_BANDWIDTH, "shift-bandwidth");
		put(CHANGE_OWNERSHIP, "change-ownership");
		put(RECONNECT, "reconnect");
		put(CHANGE_BILLING_ADDRESS, "change-billing-address");
		put(CLOSE_CONNECTION, "close-connection");
	}};
	
	
	@SuppressWarnings({ "rawtypes", "unchecked", "serial" })
	public static Map<Integer, Class<? extends LLIApplication>> applicationTypeClassnameMap = new HashMap() {{
		put(NEW_CONNECTION, LLINewConnectionApplication.class);
		put(UPGRADE_BANDWIDTH, LLIUpgradeBandwidthApplication.class);
		put(DOWNGRADE_BANDWIDTH, LLIDowngradeBandwidthApplication.class);
		put(TEMPORARY_UPGRADE_BANDWIDTH, LLITemporaryUpgradeBandwidthApplication.class);
		put(ADDITIONAL_PORT, LLIAdditionalPortApplication.class);
		put(RELEASE_PORT, LLIReleasePortApplication.class);
		put(ADDITIONAL_LOCAL_LOOP, LLIAdditionalLocalLoopApplication.class);
		put(RELEASE_LOCAL_LOOP, LLIReleaseLocalLoopApplication.class);
		put(ADDITIONAL_IP, LLIAdditionalIPApplication.class);
		put(RELEASE_IP, LLIReleaseIPApplication.class);
		put(ADDITIONAL_CONNECTION_ADDRESS, LLIAdditionalConnectionAddressApplication.class);
		put(SHIFT_CONNECTION_ADDRESS, LLIShiftAddressApplication.class);
		put(RELEASE_CONNECTION_ADDRESS, LLIReleaseConnectionAddressApplication.class);
		put(SHIFT_POP, LLIShiftPopApplication.class);
		put(NEW_LONG_TERM, LLINewLongTermApplication.class);
		put(BREAK_LONG_TERM, LLIBreakLongTermApplication.class);
		put(SHIFT_BANDWIDTH, LLIShiftBandwidthApplication.class);
		put(CHANGE_OWNERSHIP, LLIChangeOwnershipApplication.class);
		put(RECONNECT, LLIReconnectApplication.class);
		put(CHANGE_BILLING_ADDRESS, LLIChangeBillingAddressApplication.class);
		put(CLOSE_CONNECTION, LLICloseConnectionApplication.class);
	}};
	/*Application Type*/
	
	
	/*Actions on Application for specific Status */
	@SuppressWarnings({ "rawtypes", "unchecked", "serial" })
	public static Map<Integer, List<LLIActionButton>> applicationActionMap = new HashMap ( new HashMap() {{
		put(STATUS_APPLIED, new ArrayList( new ArrayList() {{
			add(new LLIActionButton("Verify", "lli/application/application-verify.do", false));
			add(new LLIActionButton("Request For Correction", "lli/application/application-request-for-correction.do", true));
			add(new LLIActionButton("Reject", "lli/application/application-reject.do", true));
		}}));
		put(STATUS_VERIFIED, new ArrayList( new ArrayList() {{
			add(new LLIActionButton("Process", "lli/application/application-process.do", true));
		}}));
		put(STATUS_PROCESSED, new ArrayList( new ArrayList() {{
			add(new LLIActionButton("Process", "lli/application/application-process.do", true));
			add(new LLIActionButton("Finalize", "lli/application/application-finalize.do", false));
		}}));
		put(STATUS_FINALIZED, new ArrayList( new ArrayList() {{
			//will be handled based on business logic in application service
		}}));
		put(STATUS_DEMAND_NOTE_GENERATED, new ArrayList( new ArrayList() {{
		}}));
		put(STATUS_PAYMENT_CLEARED, new ArrayList( new ArrayList() {{
			add(new LLIActionButton("Complete Request", "lli/application/application-complete-request.do", true));
		}}));
		put(STATUS_COMPLETED, new ArrayList( new ArrayList() {{
		}}));
		put(STATUS_REQUESTED_FOR_CORRECTION, new ArrayList( new ArrayList() {{
		}}));
		put(STATUS_REJECTED, new ArrayList( new ArrayList() {{
		}}));
	}});
	/*Actions on Application for specific Status */
}
