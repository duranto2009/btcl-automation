package lli;

import lli.Application.NewConnection.LLINewConnectionApplication;
import lli.demandNote.LLINewConnectionDemandNote;

public class LLITmpFile {
	
	
	
	public LLINewConnectionDemandNote createLLINewConnectionDemandNoteByApplication(LLINewConnectionApplication lliNewConnectionApplication) throws Exception{
		
		
		
		return
	}
	
}
