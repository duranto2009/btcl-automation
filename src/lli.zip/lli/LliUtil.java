package lli;

import javax.servlet.http.HttpServletRequest;

import common.EntityTypeConstant;
import connection.DatabaseConnection;
import file.FileDTO;
import file.FileService;
import lli.constants.LliRequestTypeConstants;
import lli.link.LliLinkDTO;
import login.LoginDTO;
import request.CommonRequestDTO;

public class LliUtil {
	public CommonRequestDTO prepareBasicLinkRequestDTO( LliLinkDTO lliLinkDTO, HttpServletRequest request, LoginDTO loginDTO) {
		CommonRequestDTO lliNewLinkRequest = new CommonRequestDTO();
		
		lliNewLinkRequest.setLastModificationTime(lliLinkDTO.getLastModificationTime());
		// parent class
		lliNewLinkRequest.setRequestTime(lliLinkDTO.getLastModificationTime());
		((CommonRequestDTO) lliNewLinkRequest).setLastModificationTime(lliLinkDTO.getLastModificationTime());
		lliNewLinkRequest.setRequestTypeID(LliRequestTypeConstants.REQUEST_NEW_LINK.CLIENT_APPLY);
		lliNewLinkRequest.setEntityTypeID(EntityTypeConstant.LLI_LINK);
		lliNewLinkRequest.setEntityID(lliLinkDTO.getID());
		lliNewLinkRequest.setRootReqID(null);
		lliNewLinkRequest.setParentReqID(null);
		lliNewLinkRequest.setClientID(lliLinkDTO.getClientID());
		if (!loginDTO.getIsAdmin()) {
			lliNewLinkRequest.setRequestByAccountID(loginDTO.getAccountID());
		} else {
			lliNewLinkRequest.setRequestByAccountID(-loginDTO.getUserID());
		}
		lliNewLinkRequest.setIP(request.getRemoteAddr());
		lliNewLinkRequest.setDescription("Client requests for a new lli Connection named " + lliLinkDTO.getLinkName());
		return lliNewLinkRequest;
	}
	
	public static void uploadDocument(String []documents, long entityID, LoginDTO loginDTO, DatabaseConnection databaseConnection) throws Exception {
		FileService fileService = new FileService();
		for(int i=0; i<documents.length;i++){
			FileDTO fileDTO = new FileDTO();
			if(loginDTO.getAccountID()>0){
				fileDTO.setDocOwner(loginDTO.getAccountID());
			}else{
				fileDTO.setDocOwner(-loginDTO.getUserID());
			}
			fileDTO.setDocEntityID(entityID);
			fileDTO.setDocEntityTypeID(EntityTypeConstant.LLI_LINK); 
			fileDTO.setLastModificationTime(System.currentTimeMillis());
			fileDTO.createLocalFileFromNames(documents[i]);
			fileService.insert(fileDTO, databaseConnection);
		}
	}
}
