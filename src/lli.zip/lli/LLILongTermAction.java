package lli;

import javax.servlet.http.HttpServletRequest;

import com.google.gson.GsonBuilder;

import annotation.ForwardedAction;
import annotation.JsonPost;
import lli.Options.LLIOptionsService;
import login.LoginDTO;
import requestMapping.AnnotatedRequestMappingAction;
import requestMapping.RequestParameter;
import requestMapping.Service;
import requestMapping.annotation.ActionRequestMapping;
import requestMapping.annotation.RequestMapping;
import requestMapping.annotation.RequestMethod;
import sessionmanager.SessionConstants;
import util.RecordNavigationManager;
import java.util.*;
@ActionRequestMapping("lli/longterm")
public class LLILongTermAction extends AnnotatedRequestMappingAction{
	
	@Service
	LLILongTermService lliLongTermService;
	@Service
	LLIOptionsService lliOptionsService;
	
	@Override
	public GsonBuilder getGsonBuilder(){
		GsonBuilder gsonBuilder = new GsonBuilder();
		//LLI Long Term
		gsonBuilder.registerTypeAdapter(LLILongTermContract.class, new LLILongTermSerializer());
		gsonBuilder.registerTypeAdapter(LLILongTermContract.class, new LLILongTermDeserializer());
		return gsonBuilder;
	}
	
	
	/*Long Term New Begins*/
	@ForwardedAction
	@RequestMapping(mapping="/new", requestMethod=RequestMethod.GET)
	public String getLongTermNew() throws Exception {
		return "lli-longterm-new";
	}
	@JsonPost
	@RequestMapping(mapping="/new", requestMethod=RequestMethod.POST)
	public void postLongTermNew(@RequestParameter(isJsonBody = true,value = "contract") LLILongTermContract lliLongTermContract) throws Exception{
		lliLongTermService.insertNewLongTermContract(lliLongTermContract);
	}
	/*Long Term New Ends*/
	
	/*Long Term Search Begins*/
	@ForwardedAction
	@RequestMapping(mapping = "/search", requestMethod = RequestMethod.All)
	public String searchLongTermContract(HttpServletRequest request) throws Exception{
		LoginDTO loginDTO = (login.LoginDTO) request.getSession(true).getAttribute(SessionConstants.USER_LOGIN);
        RecordNavigationManager rnManager = new RecordNavigationManager(
        			SessionConstants.NAV_LONG_LONG_TERM, request, lliLongTermService,
        			SessionConstants.VIEW_LONG_TERM,
        			SessionConstants.SEARCH_LONG_TERM
        );
        
        rnManager.doJob(loginDTO);
        return "lli-longterm-search";
	}
	/*Long Term Search Begins*/
	
	
	
	
	
	
	
	
	/*Long Term View Begins*/
	@ForwardedAction
	@RequestMapping(mapping="/view", requestMethod=RequestMethod.GET)
	public String getLongTermView() throws Exception {
		return "lli-longterm-view";
	}
	/*Long Term View Ends*/
	
	
	/*Long Term API Begins*/
	@RequestMapping(mapping="/get-longterm", requestMethod=RequestMethod.All)
	public LLILongTermContract getLongTermContract(@RequestParameter("id") long longTermContractID) throws Exception{
		return lliLongTermService.getLLILongTermContractByLongTermContractID(longTermContractID);
	}
	@RequestMapping(mapping = "/get-longterm-by-client-id", requestMethod = RequestMethod.GET)
	public List<LLIDropdownPair> getLLILongTermContractListByClientID(@RequestParameter("id") long clientID) throws Exception{
		return lliOptionsService.getLongTermContractListDropDownPairListByClientID(clientID);
	}
	@RequestMapping(mapping = "/get-contract-history-list-by-contract-id", requestMethod = RequestMethod.GET)
	public List<LLILongTermContract> getLLILongTermContractHistoryListByLongTermContractID(@RequestParameter("id") long contractID) throws Exception{
		return lliLongTermService.getLLILongTermHistoryByContractID(contractID);
	}
	@RequestMapping(mapping = "/get-contract-by-history-id", requestMethod = RequestMethod.GET)
	public LLILongTermContract getLLILongTermContractByHistoryID(@RequestParameter("id") long historyID) throws Exception{
		return lliLongTermService.getLLILongTermContractInstanceByContractHistoryID(historyID);
	}
	/*Long Term API Ends*/
}

