/**
 * 
 */
package lli.bill;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import annotation.AllowPdfGeneration;
import annotation.ColumnName;
import annotation.ForeignKeyName;
import annotation.PrimaryKey;
import annotation.TableName;
import common.EntityTypeConstant;
import common.ModuleConstants;
import common.RegistrantTypeConstants;
import common.bill.BillDTO;
import common.bill.BillService;
import common.bill.BillConstants.BillConfiguration;
import common.repository.AllClientRepository;
import connection.DatabaseConnection;
import lli.constants.LliRequestTypeConstants;
import lli.link.LliBandWidthChangeRequestDTO;
import lli.link.LliLinkDTO;
import lli.link.LliLinkService;
import vpn.ClientContactDetailsDTO;
import vpn.bill.BillConfigurationDTO;
import vpn.bill.VpnBillDTO;
import vpn.client.ClientDetailsDTO;
import vpn.client.ClientService;

@AllowPdfGeneration(billLocator = LliBillTemplateLocator.class)
@TableName("at_bill_lli")
@ForeignKeyName("billID")
public class LliBillDTO extends BillDTO{
	
	@PrimaryKey
	@ColumnName("ID")
	Long lliBillID;
	
	String linkName = "Link name";
	String customerName = "testCustomerName";
	String customerAddress = "Niketon, Gulshan, Dhaka - 1212, Bangladesh, Asia, World";
	
	long invoiceID = 11111L;
	
	@ColumnName("bwConnectionCharge")
	Double bwConnectionCharge = 0.0;
	@ColumnName("ofcInstallationCharge")
	Double ofcInstallationCharge = 0.0;
	@ColumnName("ofcLayingCost")	
	Double ofcLayingCost = 0.0;
	@ColumnName("establishmentCost")		
	Double establishmentCost = 0.0;
	@ColumnName("mediaConverterPrice")
	Double mediaConverterPrice = 0.0;
	@ColumnName("sfpModuleCost")
	Double sfpModuleCost = 0.0;
	@ColumnName("othersCost")
	Double others = 0.0;
	@ColumnName("securityCharge")
	Double securityCharge = 0.0;
	@ColumnName("ofcCost")
	Double ofcCharge = 0.0;
	
	@ColumnName("ofcChargeNearEndMonthly")
	Double localEndOFC = 0.0;
	@ColumnName("ofcChargeFarEndMonthly")
	Double remoteEndOFC = 0.0;
	
	@ColumnName("bwChargeMonthly")
	Double bwCharge = 0.0;
	
	@ColumnName("upgradationCharge")
	Double upgradationCharge = 0.0;
	
	@ColumnName("existingSecurityMoney")
	Double existingSecurityMoney = 0.0;
	
	@ColumnName("isMinimumOFCUsed")
	boolean isMinimumOFCUsed = false;
	
	@ColumnName("ipAddressCost")
	Double ipAddressCost;
	
	public boolean isMinimumOFCUsed() {
		return isMinimumOFCUsed;
	}

	public void setMinimumOFCUsed(boolean isMinimumOFCUsed) {
		this.isMinimumOFCUsed = isMinimumOFCUsed;
	}

	public Double getIpAddressCost() {
		return ipAddressCost;
	}

	public void setIpAddressCost(Double ipAddressCost) {
		setGrandTotal( getGrandTotal() + ipAddressCost );
		this.ipAddressCost = ipAddressCost;
	}

	public Double getExistingSecurityMoney() {
		return existingSecurityMoney;
	}

	public void setExistingSecurityMoney(Double existingSecurityMoney) {
		setGrandTotal( getGrandTotal() - existingSecurityMoney );
		this.existingSecurityMoney = existingSecurityMoney;
	}

	public Double getUpgradationCharge() {
		return upgradationCharge;
	}

	public void setUpgradationCharge(Double upgradationCharge) {
		setGrandTotal( getGrandTotal() + upgradationCharge );
		this.upgradationCharge = upgradationCharge;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public Double getOfcInstallationCharge() {
		return ofcInstallationCharge;
	}

	public void setOfcInstallationCharge(Double ofcInstallationCharge) {
		this.ofcInstallationCharge = ofcInstallationCharge;
		setGrandTotal( getGrandTotal() + ofcInstallationCharge );
	}

	public Double getOfcLayingCost() {
		return ofcLayingCost;
	}

	public void setOfcLayingCost(Double ofcLayingCost) {
		this.ofcLayingCost = ofcLayingCost;
		setGrandTotal( getGrandTotal() + ofcLayingCost );
	}

	public Double getEstablishmentCost() {
		return establishmentCost;
	}

	public void setEstablishmentCost(Double establishmentCost) {
		this.establishmentCost = establishmentCost;
		setGrandTotal( getGrandTotal() + establishmentCost );
	}

	public Double getMediaConverterPrice() {
		return mediaConverterPrice;
	}
	
	public void setMediaConverterPrice(Double mediaConverterPrice) {
		this.mediaConverterPrice = mediaConverterPrice;
		setGrandTotal( getGrandTotal() + mediaConverterPrice );
	}

	public Double getSfpModuleCost() {
		return sfpModuleCost;
	}

	public void setSfpModuleCost(Double sfpModuleCost) {
		this.sfpModuleCost = sfpModuleCost;
		setGrandTotal( getGrandTotal() + sfpModuleCost );
	}

	public Double getOthers() {
		return others;
	}

	public void setOthers(Double others) {
		this.others = others;
		setGrandTotal( getGrandTotal() + others );
	}

	public Double getSecurityCharge() {
		return securityCharge;
	}

	public void setSecurityCharge(Double securityCharge) {
		
		this.securityCharge = securityCharge;
		setGrandTotal( getGrandTotal() + securityCharge );
	}

	public Double getOfcCharge() {
		return ofcCharge;
	}

	public void setOfcCharge(Double ofcCharge) {
		this.ofcCharge = ofcCharge;
//		setGrandTotal( getGrandTotal() + ofcCharge );
	}

	public Double getLocalEndOFC() {
		return localEndOFC;
	}

	public void setLocalEndOFC(Double localEndOFC) {
		this.localEndOFC = localEndOFC;
		setGrandTotal( getGrandTotal() + localEndOFC );
	}

	public Double getRemoteEndOFC() {
		return remoteEndOFC;
	}

	public void setRemoteEndOFC(Double remoteEndOFC) {
		this.remoteEndOFC = remoteEndOFC;
		setGrandTotal( getGrandTotal() + remoteEndOFC );
	}

	public Double getBwCharge() {
		return bwCharge;
	}

	public void setBwCharge(Double bwCharge) {
		this.bwCharge = bwCharge;
		setGrandTotal( getGrandTotal() + bwCharge );
	}

	public String getLinkName() {
		return linkName;
	}

	public void setLinkName(String linkName) {
		this.linkName = linkName;
	}

	public Long getLliBillID() {
		return lliBillID;
	}

	public void setLliBillID(Long lliBillID) {
		this.lliBillID = lliBillID;
	}

	public Double getBwConnectionCharge() {
		return bwConnectionCharge;
	}

	public void setBwConnectionCharge(Double bwConnectionCharge) {
		this.bwConnectionCharge = bwConnectionCharge;
		setGrandTotal( getGrandTotal() + bwConnectionCharge );
	}

	public long getInvoiceID() {
		return super.getID();
	}

	public void setInvoiceID(long invoiceID) {
		this.invoiceID = invoiceID;
	}

	@Override
	public String toString() {
		return "LliBillDTO [bwConnectionCharge=" + bwConnectionCharge + ", ofcInstallationCharge="
				+ ofcInstallationCharge + ", ofcLayingCost=" + ofcLayingCost + ", establishmentCost="
				+ establishmentCost + ", mediaConverterPrice=" + mediaConverterPrice + ", sfpModuleCost="
				+ sfpModuleCost + ", others=" + others + ", securityCharge=" + securityCharge + ", ofcCharge="
				+ ofcCharge + ", localEndOFC=" + localEndOFC + ", remoteEndOFC=" + remoteEndOFC + ", bwCharge="
				+ bwCharge + "]";
	}

	@Override
	public void payBill(DatabaseConnection databaseConnection, Object...objects ) throws Exception {
	}
	
	@Override
	public Map<String, Object> getPdfParamMap(DatabaseConnection databaseConnection) throws Exception{
		
		Map<String, Object> params = new HashMap<>();
		
		params.put( "logo", "../../images/common/logo.png" );
		
		ClientDetailsDTO lliClientDTO = AllClientRepository.getInstance().getVpnClientByClientID( getClientID(), ModuleConstants.Module_ID_LLI );
		
		if( lliClientDTO != null ){
			
			List<ClientContactDetailsDTO> lliContactDetailsDTO = (List<ClientContactDetailsDTO>) new ClientService().getVpnContactDetailsListByClientID( lliClientDTO.getId() );
			
			if( lliContactDetailsDTO != null && lliContactDetailsDTO.size() > 0 ){
				
				ClientContactDetailsDTO contactDetailsDTO = lliContactDetailsDTO.get(0);
				
				params.put( "customerName", contactDetailsDTO.getRegistrantsName() + " " + contactDetailsDTO.getRegistrantsLastName() );
				params.put( "customerAddress", contactDetailsDTO.getAddress() );
				params.put( "customerType", RegistrantTypeConstants.LLI_REGISTRANT_TYPE.get( lliClientDTO.getRegistrantType() ) );
			}	
		}
		int billRequestType = getBillReqType();
		if( billRequestType == LliRequestTypeConstants.REQUEST_UPGRADE.SYSTEM_GENERATE_DEMAND_NOTE || billRequestType == LliRequestTypeConstants.REQUEST_DOWNGRADE.SYSTEM_GENERATE_DEMAND_NOTE) {
			
			LliLinkDTO lliLinkDTO = new LliLinkService().getLliLinkByLliLinkID(this.getEntityID() );
			LliBandWidthChangeRequestDTO lliBandWidthChangeRequestDTO = new LliLinkService().getLatestBandwidthChangeRequestByEntityAndEntityTypeID( lliLinkDTO.getID(), EntityTypeConstant.LLI_LINK );
			
			params.put( "prevBW", lliLinkDTO.getLliBandwidth() + " " + EntityTypeConstant.linkBandwidthTypeMap.get( lliLinkDTO.getLliBandwidthType() ) );
			params.put( "newBW", lliBandWidthChangeRequestDTO.getNewBandwidth() + " " + EntityTypeConstant.linkBandwidthTypeMap.get( lliBandWidthChangeRequestDTO.getNewBandwidthType() ) );
			
		}
		
		List<BillConfigurationDTO> billConfigurationDTOs = BillService.getBillConfiguration( ModuleConstants.Module_ID_LLI, getBillType() );
		
		for( BillConfigurationDTO billConfigurationDTO: billConfigurationDTOs ){
			
			switch ( billConfigurationDTO.getHeaderFooterID() ) {
			case BillConfiguration.FOOTER_TEXT_1:
				params.put( "footer_text_1", billConfigurationDTO.getText() );
				break;
			case BillConfiguration.FOOTER_TEXT_2:
				params.put( "footer_text_2", billConfigurationDTO.getText() );
				break;
			case BillConfiguration.FOOTER_TEXT_3:
				params.put( "footer_text_3", billConfigurationDTO.getText() );
				break;
			case BillConfiguration.HEADER_TEXT_1:
				params.put( "header_text_1", billConfigurationDTO.getText() );
				break;
			case BillConfiguration.HEADER_TEXT_2:
				params.put( "header_text_2", billConfigurationDTO.getText() );
				break;
			}
		}
		
		return params;
	}
	
	public Double getTotalOTC() {
		
		return 	getBwConnectionCharge() 
				+ getOfcInstallationCharge() 
				+ getOfcLayingCost() 
				+ getEstablishmentCost() 
				+ getMediaConverterPrice() 
				+ getSfpModuleCost() 
				+ getOthers() 
				+ getSecurityCharge(); 
//				+ getOfcCharge();
	}
	
	public Double getTotalMRC() {
		
		return 	getLocalEndOFC() 
				+ getRemoteEndOFC() 
				+ getBwCharge();
	}

	public static LliBillDTO getDummyBill( int docType ) {
		
		LliBillDTO lliBillDTO = new LliBillDTO();
		lliBillDTO.setBillType( docType );
		return lliBillDTO;
	}
}
