/**
 * 
 */
package lli.bill;

import java.util.HashMap;
import java.util.Map;

import common.bill.BillConstants;
import common.bill.BillDTO;
import util.BillTemplateLocator;
import lli.constants.LliRequestTypeConstants;

/**
 * @author Alam
 */
public class LliBillTemplateLocator implements BillTemplateLocator{

	public static Map<Integer, String> templatePath = new HashMap<>();
	
	static {
		
		templatePath.put( LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_GENERATE_DEMAND_NOTE , BillConstants.LLI_BILL_TEMPLATE_LOCATION );
		templatePath.put( LliRequestTypeConstants.REQUEST_UPGRADE.SYSTEM_GENERATE_DEMAND_NOTE , BillConstants.LLI_BW_CHANGE_UPGRADE_DEMAND_NOTE );
		templatePath.put( LliRequestTypeConstants.REQUEST_DOWNGRADE.SYSTEM_GENERATE_DEMAND_NOTE, BillConstants.LLI_BW_CHANGE_DOWNGRADE_DEMAND_NOTE);
		templatePath.put( LliRequestTypeConstants.REQUEST_POP_CHANGE.SYSTEM_GENERATE_DEMAND_NOTE , BillConstants.LLI_SHIFTING_DEMAND_NOTE );
		templatePath.put( LliRequestTypeConstants.REQUEST_IPADDRESS.SYSTEM_GENERATE_DEMAND_NOTE , BillConstants.LLI_IP_ADDRESS_DEMAND_NOTE );
	}
	
	@Override
	public String getTemplateFilename(BillDTO billDTO) {
		
		LliBillDTO lliBillDTO = (LliBillDTO)billDTO;
		
		if( lliBillDTO.getBillType() == BillConstants.DEMAND_NOTE && templatePath.containsKey( lliBillDTO.getBillReqType() ) )
			
			return templatePath.get( lliBillDTO.getBillReqType() );
		else
			
			return BillConstants.LLI_BILL_MONTHLY_TEMPLATE_LOCATION;

	}
}
