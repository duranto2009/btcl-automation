package lli.bill;

import java.io.File;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import annotation.AllowPdfGeneration;
import annotation.Transactional;
import common.EntityDTO;
import common.EntityTypeConstant;
import common.ModuleConstants;
import common.StringUtils;
import common.bill.BillConstants;
import common.bill.BillDTO;
import common.repository.AllClientRepository;
import connection.DatabaseConnection;
import file.FileDTO;
import file.FileService;
import file.FileTypeConstants;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;
import util.BillTemplateLocator;
import util.ModifiedSqlGenerator;
import util.SqlGenerator;
import vpn.ClientContactDetailsDTO;
import vpn.VpnDAO;
import vpn.VpnLinkSearchDAO;
import vpn.client.ClientDetailsDTO;
import vpn.client.ClientService;
import vpn.link.VpnLinkDTO;

public class PdfUtil {
	
	static Logger logger = Logger.getLogger( PdfUtil.class );
	
	/**
	 * This method returns the bill pdf location for given bill id. Point to be noted here is that, this method assumes
	 * There will be no two bill pdf with same name or id.
	 * @author Alam
	 * @param billID
	 * @return Bill pdf file location or empty string if not found.
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static String getPdfBillLocation( long billID ) throws Exception{
		
		DatabaseConnection databaseConnection = new DatabaseConnection();
		
		try{
			
			databaseConnection.dbOpen();
			
			List<FileDTO> files = SqlGenerator.getAllObjectList(
					FileDTO.class,
					databaseConnection,
					" where " + SqlGenerator.getColumnName( FileDTO.class, "docActualFileName" ) + " = '" + billID + ".pdf' " );
			
			if( files.size() == 0 ) return "";
			
			FileDTO fileDTO = (FileDTO)files.get(0);
			
			return fileDTO.getDocDirectoryPath() + File.separatorChar + fileDTO.getDocActualFileName();
			
		}
		catch( Exception e ){
			
			e.printStackTrace();
			throw e;
		}
		finally {
			
			databaseConnection.dbClose();
		}
	}
	
	/**
	 * This method write a pdf file for bill in designated folder. Also inserts an entry in database.
	 * @author Alam
	 * @param vpnLinkDTO LinkDTO for which bill is being generated
	 * @param billDTO Bill that is just inserted
	 * @param fileName File name. Bill id is expected.
	 * @param databaseConnection 
	 * @throws Exception
	 */
	public static void writePdfFileAndLogInDatabase( EntityDTO entityDTO, BillDTO billDTO,
			String fileName, long currentTime, DatabaseConnection databaseConnection ) throws Exception{
		
		FileDTO fileDTO = new FileDTO();
		
		fileDTO.setDocOwner( entityDTO.getClientID() );
		fileDTO.setDocEntityTypeID( EntityTypeConstant.VPN_LINK );
		fileDTO.setDocEntityID( entityDTO.getEntityID() );
		fileDTO.setLastModificationTime( currentTime );
		
		StringBuilder sb = new StringBuilder();
		
		sb.append( FileTypeConstants.BASE_PATH );
		sb.append( FileTypeConstants.FINAL_UPLOAD_DIR );
		sb.append( FileTypeConstants.BILL_DIRECTORY );
		sb.append( billDTO.getYear() + "/" + billDTO.getMonth() + "/" );
		
		String finalFileName = fileName + ".pdf";
		
		File dir = new File( sb.toString() );
		
     	if (!dir.exists()) {
            if (dir.mkdirs()) {
            	
            	logger.debug("dir: "+ sb.toString() +" is created successfully.");
            } else {
            	
            	logger.debug("dir: "+ sb.toString() +" is not created.");
            	throw new Exception( "Directory for bill pdf can't be created" );
            }
     	}
		
     	fileDTO.setDocTypeID( FileTypeConstants.GLOBAL.BILL + "" );
		fileDTO.setDocActualFileName( finalFileName );
		fileDTO.setDocLocalFileName( finalFileName );
		fileDTO.setDocSize( -1 );
		fileDTO.setDocDirectoryPath( dir.getPath() );
		
		new FileService().insert(fileDTO, databaseConnection);
		
		writeBillToPdfFile( fileDTO.getDocDirectoryPath() + File.separatorChar + fileDTO.getDocActualFileName(), billDTO );
	}
	
	public static void writeBillToPdfFile( String fileName, BillDTO billDTO ) throws Exception{
		
		List<BillDTO> bills = new ArrayList<>();
		bills.add( billDTO );
		
		writeBillToPdfFile( fileName, bills );
	}
	
	private static void writeBillToPdfFile( String fileName, List<BillDTO> bills ) throws Exception{
		
		if(bills== null||bills.isEmpty()){
			return;
		}
		
		String className = bills.get(0).getClassName(); 
		
		for(BillDTO bill: bills){
			if(!bill.getClassName().equals(className)){
				throw new Exception("Differnt type bills merging in pdf is not allowed");
			}
		}
		
		
		Class<?> billClassObject = Class.forName(className);
		
		Map<String, Object> params = bills.get( bills.size() - 1 ).getPdfParamMap( null );
		
		AllowPdfGeneration allowPdfGeneration = (AllowPdfGeneration)billClassObject.getAnnotation(AllowPdfGeneration.class);
		
		if(allowPdfGeneration==null){
			
			throw new Exception("Bill template annotation is not found");
		}
		
		// to avoid the dummy bill DTO at position 0, last index is used to get a bill
		String billTemplateLocation = allowPdfGeneration.billLocator().newInstance().getTemplateFilename(bills.get(bills.size()-1));
		
		/*Class<? extends BillTemplateLocator> vpnBillTemplateLocator = allowPdfGeneration.billLocator();
		Method m = vpnBillTemplateLocator.getMethod( "getTemplateFilename", BillDTO.class );
		String billTemplateLocation = (String)m.invoke( null, bills.get( bills.size() -1 ) );*/ 
		
		if(StringUtils.isBlank(billTemplateLocation)){
			throw new Exception("Invalid bill template location");
		}
		
		//If second param is passed as false, then the attributes name in DTO have to exactly same as
		//Field name in jasper template. if passed as true, we have to set custom jasper field and dto attribute 
		//mapping in jasper template. Currenlt we assume that no mapping is required.
		JRBeanCollectionDataSource itemsJRBean = new JRBeanCollectionDataSource( bills, false );
		
		InputStream inputStream = BillDTO.class.getClassLoader().getResourceAsStream( billTemplateLocation );
		
		JasperReport jasperReport = (JasperReport)JRLoader.loadObject( inputStream );
		
		JasperPrint jasperPrint = JasperFillManager.fillReport( jasperReport, params, itemsJRBean );
		
		JasperExportManager.exportReportToPdfFile( jasperPrint, fileName );
	}
	public static void writePdfFileAndLogInDatabase( EntityDTO entityDTO, BillDTO billDTO,
			String fileName ) throws Exception{
		
		DatabaseConnection databaseConnection = new DatabaseConnection();
		
		try {
			databaseConnection.dbOpen();
			writePdfFileAndLogInDatabase( entityDTO, billDTO, fileName, System.currentTimeMillis(), databaseConnection );
		}
		catch( Exception e ) {
			
			e.printStackTrace();
			throw e;
		}
		finally {
			
			databaseConnection.dbClose();
		}
			
	}
	public static void main( String[] args ) throws Exception{
		
		DatabaseConnection databaseConnection = new DatabaseConnection();
		
		databaseConnection.dbOpen();
		VpnDAO vpnDAO = new VpnDAO();
		
		VpnLinkDTO vpnLinkDTO = vpnDAO.getVpnLinkDTOByID( 47001, databaseConnection );
		BillDTO billDTO = vpnDAO.createBillDTOForVpnMonthlyBill(vpnLinkDTO, 02, 2015, 0, 0, databaseConnection);
		
		writePdfFileAndLogInDatabase( vpnLinkDTO, billDTO, "88002", System.currentTimeMillis(), databaseConnection );
		
		databaseConnection.dbClose();
	}
}
