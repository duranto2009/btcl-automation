package lli.bill;

import accounting.AccountType;
import accounting.AccountingIncident;
import accounting.AccountingIncidentBuilder;
import accounting.AccountingIncidentService;
import common.RequestFailureException;
import common.bill.BillDTO;
import lli.Application.LLIApplication;
import lli.Application.LLIApplicationService;
import lli.connection.LLIConnectionConstants;
import requestMapping.Service;

public class LLIBillCommonBusinessLogic {
	@Service
	AccountingIncidentService accountingIncidentService;
	
	@Service
	LLIApplicationService lliApplicationService;
	
	
	public void skip(BillDTO billDTO,AccountingIncidentBuilder accountingIncidentBuilder) throws Exception{
		String description = "invoice id "+billDTO.getID()+" skipped. ";
		AccountingIncident accountingIncident = accountingIncidentBuilder
				.description(description)
				.debit(AccountType.ACCOUNT_RECEIVEABLE_TD, billDTO.getNetPayable())
				.createAccountingIncident();
		accountingIncidentService.insertAccountingIncident(accountingIncident);
		lliApplicationService.setApplicationAsPaymentClearedByDemandNoteID(billDTO.getID());
	}
	public void verifyPayment(BillDTO billDTO,AccountingIncidentBuilder accountingIncidentBuilder) throws Exception{
	AccountingIncident accountingIncident ;
		
		String description = "invoice id "+billDTO.getID()+" payment verified. " ;
		
		if(billDTO.getPaymentStatus() == BillDTO.PAID_UNVERIFIED){
			accountingIncident = accountingIncidentBuilder
					.clearAccountingEntryList()
					.description(description)
					.debit(AccountType.CASH, billDTO.getNetPayable())
					.credit(AccountType.ACCOUNT_RECEIVEABLE_TD, billDTO.getNetPayable())
					.createAccountingIncident();
		}else{
			// first paid
			accountingIncident = accountingIncidentBuilder
					.description(description)
					.debit(AccountType.CASH, billDTO.getNetPayable())
					.createAccountingIncident();
		}
		accountingIncidentService.insertAccountingIncident(accountingIncident);
		lliApplicationService.setApplicationAsPaymentClearedByDemandNoteID(billDTO.getID());
	}
	public void unskip(BillDTO billDTO , AccountingIncidentBuilder accountingIncidentBuilder) throws Exception{

		LLIApplication lliApplication = lliApplicationService.getLLIApplicationByDemandNoteID(billDTO.getID());
		
		if(lliApplication != null && lliApplication.getStatus()==LLIConnectionConstants.STATUS_COMPLETED) {
			throw new RequestFailureException("This demand note with invoice ID "+billDTO.getID()
			+" can not be unskipped. The application is already completed.");
		}
		
		
		String description = "Bill id "+billDTO.getID()+" unskipped";
		AccountingIncident accountingIncident = accountingIncidentBuilder
				.description(description)
				.debit(AccountType.ACCOUNT_RECEIVEABLE_TD, billDTO.getNetPayable())
				.reverse()
				.createAccountingIncident();
		
		accountingIncidentService.insertAccountingIncident(accountingIncident);


		
		lliApplicationService.setApplicationAsDemandNoteGeneratedByDemandNoteID(billDTO.getID());

	}
	
	public boolean isSkipable(BillDTO billDTO) throws Exception{
		
		return billDTO.getPaymentStatus() == BillDTO.UNPAID;
	}
	public boolean isUnskipable(BillDTO billDTO) throws Exception{
		
		if(billDTO.getPaymentStatus() != BillDTO.SKIPPED){
			return false;
		}
		
		LLIApplication lliApplication = lliApplicationService.getLLIApplicationByDemandNoteID(billDTO.getID());
		
		if(lliApplication!=null && lliApplication.isServiceStarted()){
			return false;
		}
		
		return true;
	}
	
	
	public void cancalBill(BillDTO billDTO) throws Exception{
		LLIApplication lliApplication = lliApplicationService.getLLIApplicationByDemandNoteID(billDTO.getID());
		if(lliApplication!=null ){
			lliApplication.setDemandNoteID(null);
			lliApplication.setStatus(LLIConnectionConstants.STATUS_FINALIZED);
			lliApplicationService.updateApplicaton(lliApplication);
		}
	}
	
	
}
