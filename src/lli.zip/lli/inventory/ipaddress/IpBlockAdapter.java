package lli.inventory.ipaddress;

import java.lang.reflect.Type;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import ipaddress.IpAddressService;
import ipaddress.IpBlock;

public class IpBlockAdapter implements JsonSerializer<IpBlock> {

	@Override
	public JsonElement serialize(IpBlock ipBlock, Type arg1, JsonSerializationContext arg2) {
		JsonObject jsonObject = new JsonObject();
		
		jsonObject.addProperty("blockID",ipBlock.getIpBlockID());
		jsonObject.addProperty("from",IpAddressService.getIp4AddressStringRepresentationByIpAddressLong(ipBlock.getStartingIpAddress()));
		jsonObject.addProperty("to",IpAddressService.getIp4AddressStringRepresentationByIpAddressLong(ipBlock.getStartingIpAddress()+ipBlock.getBlockSize()-1));
		
		return jsonObject;
	}
	
}