package lli.inventory.ipaddress;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import com.google.gson.GsonBuilder;
import annotation.ForwardedAction;
import common.ClientDTO;
import common.ObjectPair;
import common.RequestFailureException;
import common.StringUtils;
import common.repository.AllClientRepository;
import inventory.InventoryConstants;
import ipaddress.AllocatedIpAddressService;
import ipaddress.IpAddressService;
import ipaddress.IpBlock;
import ipaddress.IpBlockTester;
import ipaddress.OriginalIpAddressService;
import login.LoginDTO;
import requestMapping.AnnotatedRequestMappingAction;
import requestMapping.RequestParameter;
import requestMapping.Service;
import requestMapping.annotation.ActionRequestMapping;
import requestMapping.annotation.RequestMapping;
import requestMapping.annotation.RequestMethod;
import sessionmanager.SessionConstants;
import util.RecordNavigationManager;

@ActionRequestMapping("lli/inventory/ipAddress/")
public class LliInventoryIPAddressAction extends AnnotatedRequestMappingAction {
	
	@Service
	IpAddressService ipAddressService;
	
	@Service 
	OriginalIpAddressService originalIpAddressService;
	
	@Service 
	AllocatedIpAddressService allocatedIpAddressService;
	
	@Override
	public GsonBuilder getGsonBuilder(){
		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.registerTypeAdapter(IpBlock.class, new IpBlockAdapter());
		return gsonBuilder;
		
	}
	
	@ForwardedAction
	@RequestMapping(mapping="original/search", requestMethod=RequestMethod.All) // isValid = 0
	public String searchIPAddressOriginal(HttpServletRequest request) throws Exception{
		LoginDTO loginDTO = (login.LoginDTO) request.getSession(true).getAttribute(SessionConstants.USER_LOGIN);
        RecordNavigationManager rnManager = null;
    	rnManager = new RecordNavigationManager(
			SessionConstants.NAV_LLI_ORIGINAL_IP, request, originalIpAddressService,
			SessionConstants.VIEW_LLI_ORIGINAL_IP,
			SessionConstants.SEARCH_LLI_ORIGINAL_IP
    	);
    	
		rnManager.doJob(loginDTO); 
		return "getIPAddressSearchOriginal";
        
	}
	@ForwardedAction
	@RequestMapping(mapping="allocated/search", requestMethod=RequestMethod.All) //isValid = 1
	public String searchIPAddressAllocated(HttpServletRequest request) throws Exception{
		LoginDTO loginDTO = (login.LoginDTO) request.getSession(true).getAttribute(SessionConstants.USER_LOGIN);
        
        RecordNavigationManager rnManager = null;
    	rnManager = new RecordNavigationManager(
			SessionConstants.NAV_LLI_ALLOCATION_IP, request, allocatedIpAddressService,
			SessionConstants.VIEW_LLI_ALLOCATION_IP,
			SessionConstants.SEARCH_LLI_ALLOCATION_IP
		);
        rnManager.doJob(loginDTO, request); 
		return "getIPAddressSearchAllocated";
        
	}
	@ForwardedAction
	@RequestMapping(mapping="add", requestMethod=RequestMethod.GET)
	public String getInsertIpBlockPage(){
		return "getIPAddressAdd";
	}
	@ForwardedAction
	@RequestMapping(mapping="getIPBlockTester", requestMethod=RequestMethod.GET)
	public String getIpBlockTesterFormPage(){
		return "getIPBlockTester";
	}
	
	@RequestMapping(mapping="insertIPAddress", requestMethod=RequestMethod.POST)
	public void insertIpBlock(@RequestParameter("startingIPAddressStr") String startingIpAddressString,
							@RequestParameter("blockSize") int blockSize,
							@RequestParameter("divisionID") int divisionID,
							@RequestParameter("usageType") int usageType) throws Exception{
		ipAddressService.insertIpAddressBlock(startingIpAddressString, blockSize, divisionID,usageType);
	}
	
	@RequestMapping(mapping="allocate", requestMethod = RequestMethod.POST)
	public void allocateIpBlock(IpBlockTester ipBlockTester,HttpServletRequest request) throws Exception{
		
		List<String> ipBlockRangeList = new ArrayList<>();
		
		String[] essentialIpRanges = request.getParameterValues("essentialIPRange"); 
		
		if(essentialIpRanges!=null){
			for(String ipRange: essentialIpRanges){
				ipBlockRangeList.add(ipRange);
			}
		}
		
		String[] additionalIpRanges = request.getParameterValues("additionalIPRange"); 
		
		if(additionalIpRanges!=null){
			for(String ipRange:additionalIpRanges){
				ipBlockRangeList.add(ipRange);
			}
		}

		ipAddressService.allocateIpBlocksByIpBlockStringList(ipBlockRangeList, ipBlockTester.getClientID()
				, ipBlockTester.getDivisionID(), ipBlockTester.getLliID()
				,ipBlockTester.getEssentialBlockSize(),ipBlockTester.getAdditionalBlockSize()
				, ipBlockTester.getExpirationDate());
		
	}
	
	@RequestMapping(mapping="deallocate", requestMethod = RequestMethod.All)
	public void deAllocateIpBlock(@RequestParameter("lliID")  long lliID) throws Exception{
		ipAddressService.deallocateIpByLLIID(lliID);
	}
	
	@RequestMapping(mapping="getEssentialIpBlockList", requestMethod = RequestMethod.GET)
	public List<?> getEssentialIpBlockList(){
		return ipAddressService.getEssentialIpBlockList();
	}
	
	@RequestMapping(mapping ="getAdditionalIpBlockList", requestMethod=RequestMethod.GET)
	public List<?> getAdditionalIpBlockList() throws Exception{
		return ipAddressService.getAdditionalIpBlockList();
	}
//	@RequestMapping(mapping ="getSuggestionForEssentialIpBlock", requestMethod=RequestMethod.GET)
//	public List<IpBlock> getSuggestionForEssentialIPBlock(@RequestParameter("divisionID")int divisionID
//			,@RequestParameter("essentialBlockSize") int essentialBlockSize) throws Exception{
//		return getSuggestionForAutocomplete(InventoryConstants.USAGE_ESSENTIAL, divisionID, essentialBlockSize, "");
//	}
//	@RequestMapping(mapping ="getSuggestionForAdditionalIpBlock", requestMethod=RequestMethod.GET)
//	public List<IpBlock> getSuggestionForAdditionalIPBlock(@RequestParameter("divisionID")int divisionID
//			,@RequestParameter("essentialIPRange") String essentialIPRange,@RequestParameter("essentialBlockSize") int essentialBlockSize
//			,@RequestParameter("additionalBlockSize") int additionalBlockSize) throws Exception{
//		System.out.println("divisionID: " + divisionID);
//		System.out.println("essentialIPRange: " + essentialIPRange);
//		System.out.println("essentialBlockSize: " + essentialBlockSize);
//		System.out.println("additionalBlockSize: " + additionalBlockSize);
//
//		IpBlock essentialIpBlock = new IpBlock(essentialIPRange);
////		return ipAddressService.getUnallocatedBlockByIpBlockRange(essentialIpBlock.getStartingIpAddress()
////				, essentialIpBlock.getEndingIpAddress(), additionalBlockSize, divisionID);
//		return null;
//	}
	
	@RequestMapping(mapping = "delete", requestMethod = RequestMethod.POST)
	public void deleteIPBlock(@RequestParameter("blockID") long blockID) throws Exception{
		ipAddressService.deleteIpBlockByIpBlockID(blockID);
	}
	@ForwardedAction
	@RequestMapping(mapping = "viewIPBlock", requestMethod = RequestMethod.GET)
	public String viewIPBlock( HttpServletRequest request
			,@RequestParameter("blockID") long blockID) throws Exception {
		IpBlock ipBlock = ipAddressService.getIPBlockByBlockID(blockID);
		request.setAttribute("ipBlock", ipBlock);
		return "getIPAddressAdd";
	}
	
	@RequestMapping(mapping="update", requestMethod=RequestMethod.POST)
	public void updateIpBlock(@RequestParameter("blockID") long ipBlockID,
							@RequestParameter("startingIPAddressStr") String startingIpAddressString,
							@RequestParameter("blockSize") int blockSize,
							@RequestParameter("divisionID") int divisionID, 
							@RequestParameter("usageType") int usageType) throws Exception{
		ipAddressService.updateIpBlock(ipBlockID, startingIpAddressString, blockSize, divisionID, usageType);
	}
	@RequestMapping(mapping="getSuggestion", requestMethod=RequestMethod.GET)
	public List<IpBlock> getSuggestionForAutocomplete(@RequestParameter("usageType") int usageType, @RequestParameter("divisionID") int divisionID, 
														@RequestParameter("blockSize") int blockSize, @RequestParameter("ipRanges") String ipRanges) throws Exception {
		
		
		List<String> prevIpRanges=getPreviouslySelectedIpBlocks(ipRanges);
		return ipAddressService.getSuggestionByPrevSelectedIpBlockAndRequestedBlockSizeAndUsageType(prevIpRanges, blockSize, usageType, divisionID);
	}
	@RequestMapping(mapping="getClient", requestMethod=RequestMethod.GET)
	public List<ObjectPair<Long, String>>getClientsForAutocomplete(@RequestParameter("partialName") String partialName, @RequestParameter("moduleID") int moduleID) throws Exception{
		List<ClientDTO> clients = AllClientRepository.getInstance().getClientDTOListBypartialNameAndModuleIDAndResultLimit(StringUtils.trim(partialName), moduleID);
		List<ObjectPair<Long, String>> clientIDNamePairs = new ArrayList<>();
		for(ClientDTO client : clients) {
			ObjectPair<Long, String> clientIDNamePair= new ObjectPair<>(client.getClientID(), client.getLoginName());
			clientIDNamePairs.add(clientIDNamePair);
		}
		return clientIDNamePairs;
	}
	
	
	
	private List<String> getPreviouslySelectedIpBlocks(String ipRanges) {
		String arrayOfIpRange [] = ipRanges.split(",", -1);
		List<String> ipRangeList= new ArrayList<>();
		for(String s: arrayOfIpRange) {
			s = StringUtils.trim(s);
			if(s.isEmpty() == false) {
				ipRangeList.add(s);
				System.err.println(s);
			}
			
		}
		return ipRangeList;
	}
}



