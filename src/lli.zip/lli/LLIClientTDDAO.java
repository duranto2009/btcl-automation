package lli;
import java.sql.ResultSet;
import java.util.*;

import common.ClientDTOConditionBuilder;
import login.LoginDTO;
import util.TimeConverter;

import static util.ModifiedSqlGenerator.*;
public class LLIClientTDDAO {
	
	Class<LLIClientTDStatus> classObject = LLIClientTDStatus.class;
	
	public List<LLIClientTDStatus> getDTOListByIDList(List<Long> idList) throws Exception{
		return getObjectListByIDList(classObject, idList);
	}
	public void updateClientTDStatus(LLIClientTDStatus lliClientTDStatus) throws Exception{
		updateEntity(lliClientTDStatus);
	}
	public void insertClientTDStatus(LLIClientTDStatus lliClientTDStatus) throws Exception{
		insert(lliClientTDStatus);
	}
	public boolean existsAnyClientTDStatusByClientID(long clientID) throws Exception{
		
		ResultSet rs = getResultSetBySqlPair(
				new LLIClientTDStatusConditionBuilder()
				.selectID()
				.fromLLIClientTDStatus()
				.Where()
				.clientIDEquals(clientID)
				.limit(1)
				.getSqlPair()
				);
		
		List<Long> idList = getSingleColumnListByResultSet(rs, Long.class);
		
		return idList.isEmpty()?false:true;
	}
	
	public List<Long> getIDsWithSearchCriteria(Hashtable<String, String> hashtable,LoginDTO loginDTO) throws Exception{
		
		ResultSet rs = getResultSetBySqlPair(
				new LLIClientTDStatusConditionBuilder()
				.selectID()
				.fromLLIClientTDStatus()
				.Where()
				.clientIDEquals(!loginDTO.getIsAdmin()?loginDTO.getAccountID():null)
				.clientIDInSqlPair(
						new ClientDTOConditionBuilder()
						.selectClientID()
						.fromClientDTO()
						.Where()
						.loginNameBothLike(hashtable.get("clientName"))
						.getNullableSqlPair()
						)
				.TDDateGreaterThanEquals( TimeConverter.getDateFromString( hashtable.get("fromDate")))
				.TDDateLessThan(TimeConverter.getNextDateFromString(hashtable.get("toDate")))
				.tdStatusEqualsString(hashtable.get("status"))
				.isDeleted(false)
				.getSqlPair()
				);
		
		return getSingleColumnListByResultSet(rs, Long.class);
	}
	
	public LLIClientTDStatus getLLIClientTDStatusByClientID(long clientID) throws Exception{
		List<LLIClientTDStatus> clientTDStatusList = getAllObjectList(classObject, 
				new LLIClientTDStatusConditionBuilder()
				.Where()
				.clientIDEquals(clientID)
				.limit(1)
				.getCondition()
				);
		
		return clientTDStatusList.isEmpty()?null: clientTDStatusList.get(0);
	}
	
	
}
