package lli;

import annotation.ForwardedAction;
import annotation.JsonPost;
import requestMapping.AnnotatedRequestMappingAction;
import requestMapping.RequestParameter;
import requestMapping.Service;
import requestMapping.annotation.ActionRequestMapping;
import requestMapping.annotation.RequestMapping;
import requestMapping.annotation.RequestMethod;
import util.TimeConverter;
@ActionRequestMapping("lli/bill")
public class LLIBillAction extends AnnotatedRequestMappingAction {
	@Service
	LLIMonthlyBillService lliMonthlyBillService;
	@ForwardedAction
	@RequestMapping(mapping="/create-monthly-bill", requestMethod=RequestMethod.GET)
	public String getMonthlyBillCreationPage() throws Exception {
		return "get-monthly-bill-creation-page";
	}
	
	
	@RequestMapping(mapping="/create-monthly-bill", requestMethod=RequestMethod.POST)
	public void createMonthlyBill(@RequestParameter("clientID") long clientID, @RequestParameter("fromDate") String fromDate, 
			@RequestParameter("toDate") String toDate) throws Exception {
		lliMonthlyBillService.createMonthlyBillByClientIDAndDateRange(clientID, TimeConverter.getTimeInMilliSec(fromDate, "dd/MM/yyyy"),
				TimeConverter.getTimeInMilliSec(toDate, "dd/MM/yyyy"));
	}
}
