package lli;

import annotation.ColumnName;
import annotation.PrimaryKey;
import annotation.TableName;
import common.EntityDTO;
import report.BillPaymentStatusConverter;
import report.Display;
import report.LLIConnectionStatusConverter;
import util.TimeConverter;

import java.util.*;
@TableName("at_lli_connection")
public class LLIConnectionInstance{
	
	public static final int CONNECTION_TYPE_REGULAR = 1;
	public static final int CONNECTION_TYPE_CACHE = 2;
	
	public static final int STATUS_ACTIVE = 1;
	public static final int STATUS_TD = 2;
	public static final int STATUS_CLOSED = 3;
	public static final int OWNERSHIP_CHANGED = 5;
	
	@SuppressWarnings({ "rawtypes", "unchecked", "serial" })
	public static Map<Integer, String> statusMap = new HashMap() {{
		put(STATUS_ACTIVE, "Active");
		put(STATUS_TD, "Temporarily Disconnected");
		put(STATUS_CLOSED, "Closed");
		put(OWNERSHIP_CHANGED, "Ownership Changed");
	}};
	
	@PrimaryKey
	@ColumnName("historyID")
	long historyID;
	@ColumnName("ID")
	long ID;
	@ColumnName("clientID")
	long clientID;
	@ColumnName("name")
	String name;
	@ColumnName("connectionType")
	int connectionType;
	@ColumnName("costChartID")
	long costChartID;
	@ColumnName("activeFrom")
	long activeFrom;
	@ColumnName("activeTo")
	long activeTo;
	@ColumnName("validFrom")
	long validFrom;
	@ColumnName("validTo")
	long validTo;
	@ColumnName("bandwidth")
	double bandwidth;
	@Display(LLIConnectionStatusConverter.class)
	@ColumnName("status")
	int status;
	@ColumnName("startDate")
	long startDate;
	@ColumnName("incident")
	int incident;
	
	public int getIncident() {
		return incident;
	}
	public void setIncident(int incident) {
		this.incident = incident;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public long getStartDate() {
		return startDate;
	}
	public void setStartDate(long startDate) {
		this.startDate = startDate;
	}
	List<LLIOffice> lliOffices ;
	public long getHistoryID() {
		return historyID;
	}
	public void setHistoryID(long historyID) {
		this.historyID = historyID;
	}
	public long getID() {
		return ID;
	}
	public void setID(long iD) {
		ID = iD;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getConnectionType() {
		return connectionType;
	}
	public void setConnectionType(int connectionType) {
		this.connectionType = connectionType;
	}
	public long getCostChartID() {
		return costChartID;
	}
	public void setCostChartID(long costChartID) {
		this.costChartID = costChartID;
	}
	public long getActiveFrom() {
		return activeFrom;
	}
	public void setActiveFrom(long activeFrom) {
		this.activeFrom = activeFrom;
	}
	public long getActiveTo() {
		return activeTo;
	}
	public void setActiveTo(long activeTo) {
		this.activeTo = activeTo;
	}
	public long getValidFrom() {
		return validFrom;
	}
	public void setValidFrom(long validFrom) {
		this.validFrom = validFrom;
	}
	public long getValidTo() {
		return validTo;
	}
	public void setValidTo(long validTo) {
		this.validTo = validTo;
	}
	public List<LLIOffice> getLliOffices() {
		return lliOffices;
	}
	public void setLliOffices(List<LLIOffice> lliOffices) {
		this.lliOffices = lliOffices;
	}
	
	public long getClientID() {
		return clientID;
	}
	public void setClientID(long clientID) {
		this.clientID = clientID;
	}
	public double getBandwidth() {
		return bandwidth;
	}
	public void setBandwidth(double bandwidth) {
		this.bandwidth = bandwidth;
	}
	
	
	@Override
	public String toString() {
		return "LLIConnectionInstance [historyID=" + historyID + ", ID=" + ID + ", name=" + name + ", connectionType="
				+ connectionType + ", costChartID=" + costChartID + ", activeFrom=" + TimeConverter.getDateTimeStringByMillisecAndDateFormat(activeFrom, "dd/MM/yyyy hh:mm a") + ", activeTo="
				+ TimeConverter.getDateTimeStringByMillisecAndDateFormat(activeTo, "dd/MM/yyyy hh:mm a") + ", validFrom=" + validFrom + ", validTo=" + validTo + ", lliOffices=" + lliOffices + "]";
	}
//	@Override
//	public String toString() {
//		return "LLIConnectionInstance [ID=" + ID + ", name=" + name + ", activeFrom=" + TimeConverter.getDateTimeStringByMillisecAndDateFormat(activeFrom, "dd/MM/yyyy hh:mm a") + ", activeTo="
//				+ TimeConverter.getDateTimeStringByMillisecAndDateFormat(activeTo, "dd/MM/yyyy hh:mm a") + "]";
//	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (ID ^ (ID >>> 32));
		long temp;
		temp = Double.doubleToLongBits(bandwidth);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((lliOffices == null) ? 0 : lliOffices.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LLIConnectionInstance other = (LLIConnectionInstance) obj;
		if (ID != other.ID)
			return false;
		if (Double.doubleToLongBits(bandwidth) != Double.doubleToLongBits(other.bandwidth))
			return false;
		if (lliOffices == null) {
			if (other.lliOffices != null)
				return false;
		} else if (!new HashSet<>(lliOffices).equals(new HashSet<>(other.getLliOffices())))
			return false;
		return true;
	}
	
	
	
	public static final int INCIDENT_NEW_CONNECTION = 1;
	public static final int INCIDENT_BANDWIDTH_UPGRADE = 2;
	public static final int INCIDENT_BANDWIDTH_DOWNGRADE = 3;
	public static final int INCIDENT_PORT_CHANGE = 4;
	public static final int INCIDENT_SWITCH_CHANGE = 5;
	public static final int INCIDENT_POP_SHIFT = 6;
	public static final int INCIDENT_OFFICE_SHIFT = 7;
	public static final int INCIDENT_NEW_LOCAL_LOOP = 8;
	public static final int INCIDENT_NEW_PORT = 9;
	
	@SuppressWarnings({ "rawtypes", "unchecked", "serial" })
	public static Map<Integer, String> incidentMap = new HashMap() {{
		put(INCIDENT_NEW_CONNECTION, "New Connection");
		put(INCIDENT_BANDWIDTH_UPGRADE, "Upgrade Bandwidth");
		put(INCIDENT_BANDWIDTH_DOWNGRADE, "Downgrade Bandwidth");
		put(INCIDENT_PORT_CHANGE, "Change Port");
		put(INCIDENT_SWITCH_CHANGE, "Change Switch/Router");
		put(INCIDENT_POP_SHIFT, "Shift PoP");
		put(INCIDENT_OFFICE_SHIFT, "Shift Office");
		put(INCIDENT_NEW_LOCAL_LOOP, "New Local Loop");
		put(INCIDENT_NEW_PORT, "New Port");
	}};

	
	
}
