package lli;


import static util.ModifiedSqlGenerator.getColumnName;
import static util.SqlGenerator.deleteEntity;
import static util.SqlGenerator.getAllObjectList;
import static util.SqlGenerator.getObjectByID;
import static util.SqlGenerator.getObjectFullyPopulatedByID;
import static util.SqlGenerator.getObjectFullyPopulatedByString;
import static util.SqlGenerator.getPrimaryKeyColumnName;
import static util.SqlGenerator.getTableName;
import static util.SqlGenerator.insert;
import static util.SqlGenerator.populateObjectFromDB;
import static util.SqlGenerator.updateEntity;
import static util.SqlGenerator.updateEntityByPropertyList;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionMapping;

import annotation.Transactional;
import client.ClientTypeService;
import client.RegistrantTypeConstants;
import common.CommonDAO;
import common.EntityTypeConstant;
import common.ModuleConstants;
import common.RequestFailureException;
import common.StringUtils;
import common.bill.BillConstants;
import common.bill.BillDAO;
import common.bill.BillDTO;
import common.note.CommonNote;
import common.note.CommonNoteConstants;
import common.note.CommonNoteService;
import common.repository.AllClientRepository;
import config.GlobalConfigConstants;
import connection.DatabaseConnection;
import costConfig.CostConfigService;
import costConfig.TableDTO;
import inventory.InventoryConstants;
import inventory.InventoryDAO;
import inventory.InventoryItem;
import inventory.InventoryService;
import ipaddress.IpAddressService;
import ipaddress.IpBlock;
import lli.bill.BillUtil;
import lli.bill.LliBillDTO;
import lli.configuration.LLICostConfigurationService;
import lli.configuration.LLIOTCConfigurationDTO;
import lli.constants.EndPointConstants;
import lli.constants.LliRequestTypeConstants;
import lli.link.LliBandWidthChangeRequestDTO;
import lli.link.LliEndPointDTO;
import lli.link.LliFRResponseExternalDTO;
import lli.link.LliFRResponseInternalDTO;
import lli.link.LliFarEndDTO;
import lli.link.LliInternalFRDataLocation;
import lli.link.LliLinkDTO;
import lli.link.LliLinkService;
import lli.link.LliLinkShiftDTO;
import lli.link.LliPOP;
import lli.link.LliRedundantFarEndDTO;
import login.LoginDTO;
import request.CommonRequestDTO;
import request.CommonRequestStatusDTO;
import request.RequestActionStateRepository;
import request.RequestDAO;
import request.RequestStatus;
import request.RequestUtilDAO;
import request.StateDTO;
import request.StateRepository;
import user.UserRepository;
import util.ActivityLogDTO;
import util.ColumnDTO;
import util.DateUtils;
import util.RowDTO;
import util.ServiceDAOFactory;
import util.SqlGenerator;
import util.TimeConverter;
import util.UtilService;
import vpn.client.ClientDetailsDTO;



public class LliDAO{
    static Logger logger = Logger.getLogger(LliDAO.class);
	RequestUtilDAO requestUtilDAO = new RequestUtilDAO();
	RequestDAO requestDAO = new RequestDAO();
	CommonDAO commonDAO = new CommonDAO();

	LliLinkSearchDAO lliLinkSearchDAO = new LliLinkSearchDAO();

	InventoryDAO inventoryDAO = new InventoryDAO();
	IpAddressService ipAddressService = ServiceDAOFactory.getService(IpAddressService.class);
	
	/*
	 * public void createLliEndPoint(LliEndPointDTO lliEndPoint,
	 * DatabaseConnection databaseConnection) throws Exception{
	 * 
	 * insert(lliEndPoint, classObject, databaseConnection); }
	 */
	public void createLliFarEnd(LliFarEndDTO lliFarEnd, DatabaseConnection databaseConnection) throws Exception {
		insert(lliFarEnd, lliFarEnd.getClass(), databaseConnection, true);
	}
	
	public void createLliRedundantFarEnd(LliRedundantFarEndDTO lliRedundandFarEndDTO, DatabaseConnection databaseConnection) throws Exception {
		insert(lliRedundandFarEndDTO, lliRedundandFarEndDTO.getClass(), databaseConnection, true);
	}

	public LliLinkDTO getLliLink(long lliLinkID,DatabaseConnection databaseConnection) throws Exception {
		return (LliLinkDTO)getObjectByID(LliLinkDTO.class, lliLinkID, databaseConnection);
	}

	public void deleteLliLink(LliLinkDTO lliLinkDTO, DatabaseConnection databaseConnection) throws Exception {

	}

	public void createLliConfugaration(LliConfigurationDTO lliConfugarationDTO) throws Exception {

	}

	public List<LliMonthlyChargeCell> getLliMonthlyChargeCellByTableID(long tableID, DatabaseConnection databaseConnection) throws Exception {
		List<LliMonthlyChargeCell> lliMonthlyChargeCells = new ArrayList<>();
		String tableName = SqlGenerator.getTableName(LliMonthlyChargeCell.class);
		String sql = "select * from " + tableName + " where tableID = " + tableID;
		PreparedStatement ps = databaseConnection.getNewPrepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			lliMonthlyChargeCells.add(createLliMonthlyChargeCell(rs));
		}
		return lliMonthlyChargeCells;
	}

	private LliMonthlyChargeCell createLliMonthlyChargeCell(ResultSet rs) throws Exception {
		LliMonthlyChargeCell lliMonthlyChargeCell = new LliMonthlyChargeCell();
		SqlGenerator.populateObjectFromDB(lliMonthlyChargeCell, rs);
		return lliMonthlyChargeCell;
	}

	public List<RowDTO> getRowListByTableID(long tableID, DatabaseConnection databaseConnection) throws Exception {
		List<RowDTO> rowList = new ArrayList<>();
		String tableName = SqlGenerator.getTableName(RowDTO.class);
		String sql = "select * from " + tableName + " where tableID = " + tableID;
		PreparedStatement ps = databaseConnection.getNewPrepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			rowList.add(cerateRowDTO(rs));
		}
		return rowList;
	}

	public LliMonthlyChargeTable getMonthlyChargeTableByID(long ID, DatabaseConnection databaseConnection) throws Exception {

		String tableName = SqlGenerator.getTableName(LliMonthlyChargeTable.class);
		String sql = "select * from " + tableName + " where ID = " + ID;
		PreparedStatement ps = databaseConnection.getNewPrepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			return createLliMonthlyChargeTable(rs);
		} else {
			throw new Exception("No table found with ID " + ID);
		}

	}

	public void addLliLink(LliLinkDTO lliLinkDTO, DatabaseConnection databaseConnection) throws Exception {
		insert(lliLinkDTO, lliLinkDTO.getClass(), databaseConnection, true);
	}

	public void updateLliLink(LliLinkDTO lliLinkDTO, DatabaseConnection databaseConnection) throws Exception {
		updateEntity(lliLinkDTO, lliLinkDTO.getClass(), databaseConnection, true,false);
	}

	private LliMonthlyChargeTable createLliMonthlyChargeTable(ResultSet rs) throws Exception {
		LliMonthlyChargeTable lliMonthlyChargeTable = new LliMonthlyChargeTable();
		SqlGenerator.populateObjectFromDB(lliMonthlyChargeTable, rs);
		return lliMonthlyChargeTable;
	}

	public List<ColumnDTO> getColumnListByTableID(long tableID, DatabaseConnection databaseConnection) throws Exception {
		List<ColumnDTO> columnList = new ArrayList<>();
		String tableName = SqlGenerator.getTableName(ColumnDTO.class);
		String sql = "select * from " + tableName + " where tableID = " + tableID;
		PreparedStatement ps = databaseConnection.getNewPrepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			columnList.add(createColumnDTO(rs));
		}
		return columnList;
	}

	private ColumnDTO createColumnDTO(ResultSet rs) throws Exception {
		ColumnDTO columnDTO = new ColumnDTO();
		SqlGenerator.populateObjectFromDB(columnDTO, rs);
		return columnDTO;
	}

	private ActivityLogDTO createActivityLogDTO(ResultSet rs) throws Exception {
		ActivityLogDTO activityLogDTO = new ActivityLogDTO();
		SqlGenerator.populateObjectFromDB(activityLogDTO, rs);
		return activityLogDTO;
	}

	private RowDTO cerateRowDTO(ResultSet rs) throws Exception {
		RowDTO rowDTO = new RowDTO();
		SqlGenerator.populateObjectFromDB(rowDTO, rs);
		return rowDTO;
	}

	public void insertLliMonthyChartTable(LliMonthlyChargeTable lliMonthlyChargeTable, DatabaseConnection databaseConnection) throws Exception {
		lliMonthlyChargeTable.setID(databaseConnection.getNextID(SqlGenerator.getTableName(lliMonthlyChargeTable.getClass())));
		SqlGenerator.insert(lliMonthlyChargeTable, lliMonthlyChargeTable.getClass(), databaseConnection, true);
	}

	public void insertTableRow(RowDTO rowDTO, DatabaseConnection databaseConnection) throws Exception {
		rowDTO.setID(databaseConnection.getNextID(SqlGenerator.getTableName(rowDTO.getClass())));
		SqlGenerator.insert(rowDTO, rowDTO.getClass(), databaseConnection, true);
	}

	public void insertTableColumn(ColumnDTO columnDTO, DatabaseConnection databaseConnection) throws Exception {
		columnDTO.setID(databaseConnection.getNextID(SqlGenerator.getTableName(columnDTO.getClass())));
		SqlGenerator.insert(columnDTO, columnDTO.getClass(), databaseConnection, true);
	}

	public void addPop(LliPOP lliPOP, DatabaseConnection databaseConnection) throws Exception {
		insert(lliPOP, lliPOP.getClass(), databaseConnection, true);
	}

	public void updatePop(LliPOP lliPOP, DatabaseConnection databaseConnection) throws Exception {
		updateEntity(lliPOP, lliPOP.getClass(), databaseConnection, true,false);
	}

	public void deletePop(LliPOP lliPop, DatabaseConnection databaseConnection) throws Exception {
		deleteEntity(lliPop, lliPop.getClass(), databaseConnection, true);
	}

	public LliPOP getLliPopByPopID(long popID, DatabaseConnection databaseConnection) throws Exception {
		LliPOP lliPOP = new LliPOP();
		String primaryKeyColumnName = getPrimaryKeyColumnName(LliPOP.class);
		String tableName = getTableName(LliPOP.class);
		String sql = "select * from " + tableName + " where " + primaryKeyColumnName + " = " + popID;
		PreparedStatement ps = databaseConnection.getNewPrepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			populateObjectFromDB(lliPOP, rs);
		}
		return lliPOP;
	}

	public void deleteFarEnd(long farEndID, DatabaseConnection databaseConnection) throws Exception {
		LliFarEndDTO lliFarEndDTO = LliConnectionRepository.getInstance().getFarEndByFarEndID(farEndID);
		deleteEntity(lliFarEndDTO, lliFarEndDTO.getClass(), databaseConnection, true);
	}

	public void deleteRedundantFarEnd(long redundantFarEndID, DatabaseConnection databaseConnection) throws Exception {
		LliRedundantFarEndDTO redundantFarEndDTO = LliConnectionRepository.getInstance().getLliRedundantFarEndByFarEndID(redundantFarEndID);
		deleteEntity(redundantFarEndDTO, redundantFarEndDTO.getClass(), databaseConnection, true);
	}

	public void updateLliFarEnd(LliFarEndDTO lliFarEndDTO, DatabaseConnection databaseConnection) throws Exception {
		updateEntity(lliFarEndDTO, lliFarEndDTO.getClass(), databaseConnection, true,false);
	}
	
	private LliLinkShiftDTO getLliLinkShiftDTOByLliLinkID(Long vpnLinkID, DatabaseConnection databaseConnection) throws Exception {
		List<LliLinkShiftDTO> vpnLinkShiftDTOListByLliLinkID = (List<LliLinkShiftDTO>) SqlGenerator.getAllObjectListFullyPopulated(LliLinkShiftDTO.class, databaseConnection, " where lliLinkID = "+vpnLinkID + " and shiftCompletionStatus = 0");
		return vpnLinkShiftDTOListByLliLinkID.get(vpnLinkShiftDTOListByLliLinkID.size()-1);
	}
	
	public CommonRequestStatusDTO getStateFromEntityID(DatabaseConnection databaseConnection, int entityTypeID, Long entityID) throws Exception {
		String conditionString = " where " + getColumnName(CommonRequestStatusDTO.class, "entityTypeID") + " = " + entityTypeID + " and " + getColumnName(CommonRequestStatusDTO.class, "entityID")
				+ " = " + entityID;

		ArrayList<CommonRequestStatusDTO> commonRequestStatusDTOs = (ArrayList<CommonRequestStatusDTO>) getAllObjectList(CommonRequestStatusDTO.class, databaseConnection, conditionString);
		return commonRequestStatusDTOs.get(0);
	}
	
	public ArrayList<Long> getSimilarFarEndpointIDsByEndpointID(long endPointID, DatabaseConnection databaseConnection) throws Exception{		
		String conditionString = " where parentEndPointID = " + endPointID + " or ID = " + endPointID;
		ArrayList<LliEndPointDTO> endpointDTOList = (ArrayList<LliEndPointDTO>) SqlGenerator.getAllObjectListFullyPopulated(LliEndPointDTO.class, databaseConnection, conditionString);
		StringBuilder stringBuilder = new StringBuilder("(");
		for(int i=0;i<endpointDTOList.size();i++){
			if(i!=0){
				stringBuilder.append(",");
			}
			stringBuilder.append(endpointDTOList.get(i).getLliEndPointID());
		}
		stringBuilder.append(")");
		String commaSeparated = stringBuilder.toString();
		conditionString = " where lliEPID in " + commaSeparated;
		ArrayList<Long> farEndIDList = (ArrayList<Long>) SqlGenerator.getAllIDList(LliFarEndDTO.class, databaseConnection, conditionString);
		return farEndIDList;
	}
	
	public LliFRResponseExternalDTO getLatestExternalFRForFarEnd(LliFarEndDTO farEndDTO, DatabaseConnection databaseConnection) throws Exception
	{
		ArrayList<Long> farEndIDList = getSimilarFarEndpointIDsByEndpointID(farEndDTO.getLliEndPointID(), databaseConnection);
		String commaSeparated = "";
		if(farEndIDList.size() > 0)
		{
			commaSeparated = StringUtils.getCommaSeparatedString(farEndIDList);
		}
		else
		{
			return null;
		}
		String conditionString = " where entityTypeID = " + EntityTypeConstant.LLI_LINK_FAR_END + " and nearOrFarEndpointID in " + commaSeparated + " order by ID desc limit 1";
		ArrayList<LliFRResponseExternalDTO> externalFRList = (ArrayList<LliFRResponseExternalDTO>) SqlGenerator.getAllObjectListFullyPopulated(LliFRResponseExternalDTO.class, databaseConnection, conditionString);
		if(externalFRList.size() > 0)
		{
			return externalFRList.get(0);
		}
		return null;		
	}
	
	public LliFRResponseExternalDTO getLatestExternalFRByEntityAndEntityTypeID(long entityID, int entityTypeID, DatabaseConnection databaseConnection) throws Exception
	{		   
		String conditionString = " where "+ getColumnName(LliFRResponseExternalDTO.class, "nearOrFarEndPointID")+"  = "+entityID+ " and "
				+ getColumnName(LliFRResponseExternalDTO.class, "entityTypeID") +" = "+entityTypeID+" and "
				+ getColumnName(LliFRResponseExternalDTO.class, "isDeleted") + " = 0 order by ID desc limit 1";
		ArrayList<LliFRResponseExternalDTO> lliFRResponseExternalDTOListLocal = (ArrayList<LliFRResponseExternalDTO>) SqlGenerator.getAllObjectListFullyPopulated(LliFRResponseExternalDTO.class, databaseConnection, conditionString);
		if(lliFRResponseExternalDTOListLocal.size() == 0) return null;
		return lliFRResponseExternalDTOListLocal.get(0);
	}
	
	public LliFRResponseInternalDTO getLatestInternalFRByEntityAndEntityTypeID(long entityID, int entityTypeID, DatabaseConnection databaseConnection) throws Exception
	{		   
/*		String conditionString = " where vresfrinLinkID = "+entityID+ " and vresfrinIsDeleted = 0 and vresfrinReportType = 1 order by vresfrinID desc limit 1";
		ArrayList<LliFRResponseInternalDTO> lliFRResponseInternalDTOListLocal = (ArrayList<LliFRResponseInternalDTO>) SqlGenerator.getAllObjectListFullyPopulated(LliFRResponseInternalDTO.class, databaseConnection, conditionString);
		if(lliFRResponseInternalDTOListLocal.size() == 0) return null;
		return lliFRResponseInternalDTOListLocal.get(0);*/
		ArrayList<Long> entityIDs = new ArrayList<Long>();
		entityIDs.add(entityID);
		return getLatestInternalFRByEntityAndEntityTypeIDs(entityIDs, entityTypeID, databaseConnection);
	}
	public LliFRResponseInternalDTO getLatestInternalFRByEntityAndEntityTypeIDs(ArrayList<Long> entityIDs, int entityTypeID, DatabaseConnection databaseConnection) throws Exception
	{		   		
		String conditionString = " where linkID in "+StringUtils.getCommaSeparatedString(entityIDs)+ " and isDeleted = 0 and reportType = 1 order by ID desc limit 1";
		ArrayList<LliFRResponseInternalDTO> lliFRResponseInternalDTOListLocal = (ArrayList<LliFRResponseInternalDTO>) SqlGenerator.getAllObjectListFullyPopulated(LliFRResponseInternalDTO.class, databaseConnection, conditionString);
		if(lliFRResponseInternalDTOListLocal.size() == 0) return null;
		return lliFRResponseInternalDTOListLocal.get(0);
	}
	
	public LliBandWidthChangeRequestDTO getLatestBandwidthChangeRequestByEntityAndEntityTypeID(long entityID, int entityTypeID, DatabaseConnection databaseConnection) throws Exception
	{		   
		String conditionString = " where lliLkID = "+entityID+ " and isDeleted = 0 order by ID desc limit 1";
		ArrayList<LliBandWidthChangeRequestDTO> lliBandWidthChangeRequestDTOs = (ArrayList<LliBandWidthChangeRequestDTO>) SqlGenerator.getAllObjectListFullyPopulated(LliBandWidthChangeRequestDTO.class, databaseConnection, conditionString);
		if(lliBandWidthChangeRequestDTOs.size() == 0) return null;
		return lliBandWidthChangeRequestDTOs.get(0);
	}
	
	public boolean isValid(LliEndPointDTO lliEndPointDTO,DatabaseConnection databaseConnection) throws Exception{
		return true;
	}

	/*public void updateLinkBottomRequest(CommonRequestDTO commonRequestDTO, CommonRequestDTO sourceRequestDTO, HttpServletRequest request, DatabaseConnection databaseConnection) throws Exception
	{
		RequestUtilDAO requestUtilDAO = new RequestUtilDAO();		
		Set<CommonRequestDTO> bottomRequestDTOSetLocal = requestUtilDAO.getRelatedEntityBottomRequestDTOs(commonRequestDTO, databaseConnection);
		logger.debug("bottomRequestDTOSetLocal " + bottomRequestDTOSetLocal);
		CommonRequestDTO linkBottomRequestDTO = null;
		for(CommonRequestDTO bottomRequestDTO: bottomRequestDTOSetLocal){
			if(bottomRequestDTO.getEntityTypeID() == EntityTypeConstant.LLI_LINK){
				linkBottomRequestDTO = bottomRequestDTO;
			}
		}
		logger.debug("linkBottomRequestDTO " + linkBottomRequestDTO);
		if(linkBottomRequestDTO != null){
			requestUtilDAO.updateRequestByRequestID(linkBottomRequestDTO.getReqID(), databaseConnection);
		}
	}*/
	
	/*@SuppressWarnings("unchecked")
	public boolean isPreparedToGenerateDemandNote(CommonRequestDTO commonRequestDTO, DatabaseConnection databaseConnection, Object... objects) throws Exception
	{
		RequestUtilDAO requestUtilDAO = new RequestUtilDAO();
		Set<CommonRequestDTO> bottomRequestDTOSetLocal = requestUtilDAO.getRelatedEntityBottomRequestDTOs(commonRequestDTO, databaseConnection);
		
		logger.debug("bottomRequestDTOSetLocal " + bottomRequestDTOSetLocal);
		
		boolean allOtherRelatedExternalFRAreAccepted = true;
		
		ArrayList<CommonRequestDTO> completedList = null;
		
		if(objects.length == 1)
		{
			completedList = (ArrayList<CommonRequestDTO>)objects[0];							
		}
		for(CommonRequestDTO bottomRequestDTO: bottomRequestDTOSetLocal)
		{					
			if(bottomRequestDTO.getEntityTypeID() != commonRequestDTO.getEntityTypeID())
			{
				boolean foundPending = false;
				if(
						bottomRequestDTO.getRequestTypeID() % EntityTypeConstant.MULTIPLIER2 == LliRequestTypeConstants.REMAINDERS.REM_SYSTEM_RESPONSE_EXTERNAL_FR_OF_FAR_END 
				)
				{					
					if(bottomRequestDTO.getCompletionStatus() == RequestStatus.PENDING)
					{
						allOtherRelatedExternalFRAreAccepted = false;
						foundPending = true;
					}
				}
				
				if(objects.length == 1 && !foundPending)
				{
					completedList.add(bottomRequestDTO);
				}

			}
			else
			{
				if(bottomRequestDTO.getCompletionStatus() != RequestStatus.PENDING)
				{
					throw new Exception("Wrong fr response trying to be accepted");
				}				
			}
		}
		return allOtherRelatedExternalFRAreAccepted;
	}*/
	
	public void getPreparedForDemandNoteGeneration(ActionMapping mapping, CommonRequestDTO commonRequestDTO, CommonRequestDTO sourceRequestDTO, HttpServletRequest request, HttpServletResponse response, LoginDTO loginDTO, DatabaseConnection databaseConnection) throws Exception {
		
		ArrayList<CommonRequestDTO> completedList = new ArrayList<CommonRequestDTO>();		
		long currentTime = System.currentTimeMillis();
	
		
		boolean allOtherRelatedExternalFRAreAccepted = false;
		boolean exactExternalFR = false;
		if(commonRequestDTO.getRequestTypeID() % EntityTypeConstant.MULTIPLIER2 == 67 || commonRequestDTO.getRequestTypeID() % EntityTypeConstant.MULTIPLIER2 == 68)
		{
			exactExternalFR = true;
		}

		logger.debug("completedList " + completedList);
		logger.debug("allOtherRelatedExternalFRAreAccepted " + allOtherRelatedExternalFRAreAccepted);
		
//		if(allOtherRelatedExternalFRAreAccepted)
		{
			RequestUtilDAO requestUtilDAO = new RequestUtilDAO();
			requestUtilDAO.updateRequestByRequestID(commonRequestDTO.getReqID(), databaseConnection);
			for(CommonRequestDTO completedRequestDTO: completedList)
			{
				requestUtilDAO.updateRequestByRequestID(completedRequestDTO.getReqID(), databaseConnection);
			}
									
			LliLinkDTO lliLinkDTO = getLliLink(commonRequestDTO.getRootEntityID(), databaseConnection);									
			CommonRequestDTO newCommonRequestDTO = new CommonRequestDTO();

			newCommonRequestDTO.setRequestTime(currentTime);
			newCommonRequestDTO.setLastModificationTime(currentTime);
			newCommonRequestDTO.setRequestByAccountID( -loginDTO.getUserID() );
			if(exactExternalFR)
			{
				newCommonRequestDTO.setRequestTypeID(LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_PREPARED_TO_GENERATE_MRC);
			}
			else
			{
				newCommonRequestDTO.setRequestTypeID(LliRequestTypeConstants.REQUEST_NEW_LINK.GET_PREPARED_TO_UPDATE_INTERNAL_FR);
			}
			newCommonRequestDTO.setRootReqID(commonRequestDTO.getRootReqID());
			newCommonRequestDTO.setClientID(commonRequestDTO.getClientID());
			newCommonRequestDTO.setEntityID(lliLinkDTO.getID());
			newCommonRequestDTO.setEntityTypeID(EntityTypeConstant.LLI_LINK);
			newCommonRequestDTO.setDescription( "" );
			
			/*If more then two source req id, then append them*/
			newCommonRequestDTO.setSourceRequestID( "" + commonRequestDTO.getReqID());
			if( completedList.size() != 0 )
				newCommonRequestDTO.setSourceRequestID( newCommonRequestDTO.getSourceRequestID() + "," + completedList.get(0).getReqID() );
			
			requestDAO.addRequest(newCommonRequestDTO, loginDTO.getLoginSourceIP(), databaseConnection);
		}
	}
	
	public CommonRequestDTO splitLinkToEnds(CommonRequestDTO commonRequestDTO, CommonRequestDTO sourceRequestDTO,  HttpServletRequest request, LoginDTO loginDTO, DatabaseConnection databaseConnection) throws Exception {
		long currentTime = System.currentTimeMillis();
		LliLinkDTO lliLinkDTO = getLliLinkDTOByID(commonRequestDTO.getEntityID(), databaseConnection);

		long farEndID = lliLinkDTO.getFarEndID();
		
		LliFarEndDTO lliFarEndDTO = getLliFarEndByID(farEndID, databaseConnection);
		int splittedCount = 0;
		UtilService utilService = new UtilService();
		if(lliFarEndDTO.getOfcProviderTypeID() == EndPointConstants.OFC_BTCL)
		{
			CommonRequestDTO farEndCommonRequestDTO = new CommonRequestDTO();;
			farEndCommonRequestDTO.setEntityTypeID(EntityTypeConstant.LLI_LINK_FAR_END);
			farEndCommonRequestDTO.setEntityID(farEndID);			
			farEndCommonRequestDTO.setClientID(commonRequestDTO.getClientID());
			farEndCommonRequestDTO.setRequestTime(commonRequestDTO.getRequestTime());
			farEndCommonRequestDTO.setLastModificationTime(commonRequestDTO.getLastModificationTime());
			farEndCommonRequestDTO.setDescription("");
			if(utilService.isCreativeRequest(commonRequestDTO.getRequestTypeID()))
			{
				farEndCommonRequestDTO.setRequestTypeID(LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_GET_PREPARED_FOR_EXTERNAL_FR_OF_FAR_END);
			}
			else
			{
				farEndCommonRequestDTO.setRequestTypeID(LliRequestTypeConstants.REQUEST_POP_CHANGE.SYSTEM_GET_PREPARED_FOR_EXTERNAL_FR_OF_FAR_END);
			}
			farEndCommonRequestDTO.setCompletionStatus(RequestStatus.PENDING);
//			farEndCommonRequestDTO.setRootReqID(null);
			farEndCommonRequestDTO.setRootReqID(commonRequestDTO.getRootReqID());
			farEndCommonRequestDTO.setParentReqID(commonRequestDTO.getReqID());
			farEndCommonRequestDTO.setSourceRequestID(""+commonRequestDTO.getReqID());
			farEndCommonRequestDTO.setRequestByAccountID(commonRequestDTO.getRequestByAccountID());
			requestDAO.addRequest(farEndCommonRequestDTO, loginDTO.getLoginSourceIP(), databaseConnection);

			splittedCount++;

			commonDAO.updateStatusByEntityIDAndEntityTypeID(farEndCommonRequestDTO, EntityTypeConstant.STATUS_CURRENT_AND_LATEST, databaseConnection);
		}

		if(splittedCount == 0)
		{
			CommonRequestDTO newCommonRequestDTO = new CommonRequestDTO();

			newCommonRequestDTO.setRequestTime(currentTime);
			newCommonRequestDTO.setLastModificationTime(currentTime);
			newCommonRequestDTO.setRequestByAccountID( -loginDTO.getUserID() );
			if(utilService.isCreativeRequest(commonRequestDTO.getRequestTypeID()))
			{	
				newCommonRequestDTO.setRequestTypeID(LliRequestTypeConstants.REQUEST_NEW_LINK.GET_PREPARED_TO_GENERATE_DEMAND_NOTE);						
			}
			else
			{
				newCommonRequestDTO.setRequestTypeID(LliRequestTypeConstants.REQUEST_POP_CHANGE.GET_PREPARED_TO_GENERATE_DEMAND_NOTE);
			}
			newCommonRequestDTO.setRootReqID(commonRequestDTO.getRootReqID());
			newCommonRequestDTO.setClientID(commonRequestDTO.getClientID());
			newCommonRequestDTO.setEntityID(commonRequestDTO.getEntityID());
			newCommonRequestDTO.setEntityTypeID(commonRequestDTO.getEntityTypeID());
			newCommonRequestDTO.setDescription("");
			newCommonRequestDTO.setSourceRequestID(""+commonRequestDTO.getReqID());
			
			SqlGenerator.insert(newCommonRequestDTO, CommonRequestDTO.class, databaseConnection, false);
		}
		
		return null;
	}
		
	
	 // jan means month 0, feb means month 1
	public boolean checkIfLliMonthlyBillCreatedByLinkIDAndMonthAndYear(LliLinkDTO lliLinkDTO,int month,int year,DatabaseConnection databaseConnection) throws Exception{
		long fromTime = DateUtils.getStartTimeOfMonth(month, year);		
		long toTime = DateUtils.getEndTimeOfMonth(month, year);
		
		String sql = "select blID from at_bill "; 
		sql += " where " + getColumnName(BillDTO.class, "activationTimeFrom") + " between " + fromTime + " and " + toTime;
		sql += " or " + getColumnName(BillDTO.class, "activationTimeTo") + " between " + fromTime + " and " + toTime;
		ResultSet resultSet = databaseConnection.getNewStatement().executeQuery(sql);
		if(resultSet.next())
		{
			return true;
		}
		return false;
	}
	
	//jan means month 0, feb means month 1
	public LliBillDTO createBillDTOForLliMonthlyBill(LliLinkDTO lliLinkDTO, int month,int year,double cost,double paidAmount,DatabaseConnection databaseConnection) throws Exception{
				
		double bandwidthCharge = BillUtil.getBandwidthCharge( lliLinkDTO );
		LLIOTCConfigurationDTO commonCharge = new LLICostConfigurationService().getCurrentActiveLLI_OTC_ConfigurationDTO();
		
		LliBillDTO billDTO = new LliBillDTO();
		LliFarEndDTO lliFarEndDTO = getLliFarEndByID(lliLinkDTO.getFarEndID(), databaseConnection);
		
		billDTO.setRemoteEndOFC(getOFCCost(lliLinkDTO, lliFarEndDTO, commonCharge));
		billDTO.setBwCharge( bandwidthCharge );
		
		double grandTotal = billDTO.getGrandTotal();
		double discount = Double.parseDouble( "0.0" );
		double totalPayable = grandTotal - discount;
		double vat = totalPayable * 0.15;
		
		billDTO.setVAT( BillDTO.setDecimalPlaces( vat, 2 ) );
		
		billDTO.setBillType( BillConstants.POSTPAID );
		billDTO.setDeleted(false);
		billDTO.setEntityID( lliLinkDTO.getID() );
		billDTO.setEntityTypeID( EntityTypeConstant.LLI_LINK );
		billDTO.setGenerationTime(lliLinkDTO.getCurrentTime());
		billDTO.setLastModificationTime(lliLinkDTO.getCurrentTime());
		billDTO.setClientID(lliLinkDTO.getClientID());
		billDTO.setClassName( LliBillDTO.class.getName() );
		
		billDTO.setMonth( month );
		billDTO.setYear( year );
		billDTO.setActivationTimeFrom( DateUtils.getStartTimeOfMonth( month, year ) );
		
		billDTO.setActivationTimeTo( DateUtils.getEndTimeOfMonth( month, year ) );
		
		billDTO.setBillReqType( LliRequestTypeConstants.REQUEST_NEW_LINK.CLIENT_APPLY );
		
		return billDTO;
	}
	
	public boolean checkIfLliLinkIsReadyForMonthlyBillGeneration(int currentStatus){
		if(currentStatus < 0 && Math.abs(currentStatus) % 1000 == 301 ) return false;
		return StateRepository.getInstance().getStateDTOByStateID(currentStatus).getActivationStatus()==EntityTypeConstant.STATUS_ACTIVE;
	}
	public void linkCreationComplete(ActionMapping mapping, CommonRequestDTO commonRequestDTO,
			CommonRequestDTO sourceRequestDTO, HttpServletRequest request, HttpServletResponse response,
			LoginDTO loginDTO, DatabaseConnection databaseConnection) throws Exception{
		// TODO Auto-generated method stub
		LliLinkDTO lliLinkDTO = getLliLink(commonRequestDTO.getEntityID(), databaseConnection);
		LliFarEndDTO lliFarEndDTO = getLliFarEndByID(lliLinkDTO.getFarEndID(), databaseConnection);
		
		long currentTime = System.currentTimeMillis();
		lliLinkDTO.setActivationDate(currentTime);
		lliLinkDTO.setLastModificationTime(currentTime);
				
		//lliLinkDTO.setLanIdNumbers(lliFRResponseInternalDTO.getMandatoryVLANComment() + "," + lliFRResponseInternalDTO.getAdditionalVLANComment());				
		SqlGenerator.updateEntity(lliLinkDTO, LliLinkDTO.class, databaseConnection, false, false);
		/*
		LliFRResponseInternalDTO lliFRResponseInternalDTO = getLatestInternalFRByEntityAndEntityTypeID(commonRequestDTO.getEntityID(), commonRequestDTO.getEntityTypeID(), databaseConnection);
		LliFRResponseExternalDTO lliFRResponseExternalDTOFarEnd = getLatestExternalFRByEntityAndEntityTypeID(lliFarEndDTO.getID(), EntityTypeConstant.LLI_LINK_FAR_END, databaseConnection);
		
		
		
		lliFarEndDTO.setPopID(lliFRResponseInternalDTO.getFePopID());
		lliFarEndDTO.setRouterID(lliFRResponseInternalDTO.getFeRouterID());
		lliFarEndDTO.setMandatoryVLanID(lliFRResponseInternalDTO.getFeMandatoryVlanID());
		lliFarEndDTO.setAdditionalVLanID(lliFRResponseInternalDTO.getFeAdditionalVlanIDs());
		lliFarEndDTO.setPortID(lliFRResponseInternalDTO.getFePortID());
		
		lliFarEndDTO.setLoopDistanceTotal(lliFRResponseExternalDTOFarEnd.getDistanceTotal());
		
		SqlGenerator.updateEntity(lliFarEndDTO, LliFarEndDTO.class, databaseConnection, true, false);
		*/
		LliFRResponseExternalDTO lliFRResponseExternalDTOFarEnd = getLatestExternalFRByEntityAndEntityTypeID(lliFarEndDTO.getID(), EntityTypeConstant.LLI_LINK_FAR_END, databaseConnection);
		if(lliFRResponseExternalDTOFarEnd != null)
		{
			lliFarEndDTO.setLoopDistanceTotal(lliFRResponseExternalDTOFarEnd.getDistanceTotal());
			SqlGenerator.updateEntity(lliFarEndDTO, LliFarEndDTO.class, databaseConnection, true, false);
		}		
	}
	
	public void bandwidthChangeComplete(ActionMapping mapping, CommonRequestDTO commonRequestDTO,
			CommonRequestDTO sourceRequestDTO, HttpServletRequest request, HttpServletResponse response,
			LoginDTO loginDTO, DatabaseConnection databaseConnection) throws Exception{
		// TODO Auto-generated method stub
		LliLinkDTO lliLinkDTO = getLliLink(commonRequestDTO.getEntityID(), databaseConnection);
		LliBandWidthChangeRequestDTO lliBandWidthChangeRequestDTO = getLliBandwidthChangeRequestDTOByRootRequestID(commonRequestDTO.getRootReqID(), databaseConnection);
		lliLinkDTO.setLliBandwidth(lliBandWidthChangeRequestDTO.getNewBandwidth());
		lliLinkDTO.setLliBandwidthType(lliBandWidthChangeRequestDTO.getNewBandwidthType());
		lliLinkDTO.setLastModificationTime(System.currentTimeMillis());
		SqlGenerator.updateEntity(lliLinkDTO, LliLinkDTO.class, databaseConnection, false, false);
		
		LliFarEndDTO lliFarEndDTO = getLliFarEndByID(lliLinkDTO.getFarEndID(), databaseConnection);
		if(lliFarEndDTO.getPortID() != lliBandWidthChangeRequestDTO.getNewFarPortID()) {
			InventoryService inventoryService = new InventoryService();
			inventoryService.markInventoryItemAsUnused(lliFarEndDTO.getPortID());
			
			lliFarEndDTO.setPortID(lliBandWidthChangeRequestDTO.getNewFarPortID());
			lliFarEndDTO.setPortType(lliBandWidthChangeRequestDTO.getNewFarPortType());
			SqlGenerator.updateEntity(lliFarEndDTO, LliFarEndDTO.class, databaseConnection, true, false);
			
//			inventoryService.markInventoryItemAsUsed(lliBandWidthChangeRequestDTO.getNewFarPortID(), lliFarEndDTO.getID(), EntityTypeConstant.LLI_LINK_FAR_END, lliLinkDTO.getClientID());
		}
	}
	
	public void updateLliLinkWithOptimisticLock(LliLinkDTO lliLinkDTO,long currentTime,
			DatabaseConnection databaseConnection) throws Exception{
		int numOfAffectedRows = updateEntity(lliLinkDTO, LliLinkDTO.class, databaseConnection, false, true, currentTime);
		if(numOfAffectedRows != 1){
			throw new RequestFailureException("lliLink update failed with ID "+lliLinkDTO.getID());
		}
	}

	public void processLinkRequestCancelledOrRejected(CommonRequestDTO commonRequestDTO,
			DatabaseConnection databaseConnection) throws Exception {
		// TODO Auto-generated method stub
		{
			String sql = "update " + LliFRResponseInternalDTO.getTablename() + " set " + getColumnName(LliFRResponseInternalDTO.class, "isDeleted") + "=1 where " + getColumnName(LliFRResponseInternalDTO.class, "vresfrinReqID") + "=" + commonRequestDTO.getRootReqID();
			Statement stmt = databaseConnection.getNewStatement();
			stmt.executeUpdate(sql);
		}
		{
			String sql = "update " + LliFRResponseExternalDTO.getTablename() + " set " + getColumnName(LliFRResponseExternalDTO.class, "isDeleted") + "=1 where " + getColumnName(LliFRResponseInternalDTO.class, "vresfrexReqID") + "=" + commonRequestDTO.getRootReqID();
			Statement stmt = databaseConnection.getNewStatement();
			stmt.executeUpdate(sql);
		}
	}

	public LliFarEndDTO getLliFarEndByID(long farEndID, DatabaseConnection databaseConnection) throws Exception {
		return (LliFarEndDTO)getObjectFullyPopulatedByID(LliFarEndDTO.class, databaseConnection,farEndID);
	}
	
	public void createInternalFRNoteForIPAddress(LliLinkDTO lliLinkDTO, int requestTypeID, LliFRResponseInternalDTO lliFRResponseInternalDTO, HttpServletRequest request, DatabaseConnection databaseConnection) throws Exception{
		
		CommonNote noteDTO = new CommonNote();
		InventoryDAO inventoryDAO = new InventoryDAO();
		noteDTO.setEntityId( lliFRResponseInternalDTO.getEntityID() );
		noteDTO.setEntityTypeId( lliFRResponseInternalDTO.getEntityTypeID() );
		noteDTO.setNoteTypeId( CommonNoteConstants.FR_RESPONSE.get( lliFRResponseInternalDTO.getRequestTypeID()) );
		noteDTO.setReqID(lliFRResponseInternalDTO.getReqID());
		
		String noteBody="Connection Name: <strong>" +lliLinkDTO.getName()+"</strong><br>";
		noteBody  +="From <strong>'" + UserRepository.getInstance().getUserDTOByUserID(-lliFRResponseInternalDTO.getRequestByAccountID()).getUsername() + "' </strong>  " +
				" : <strong>Internal FR  Report</strong> <br/>";
		
		noteDTO.setNoteBody( noteBody );
		noteDTO.startDescription("Item", "Comments");
		String statusStr = "";
		if(lliFRResponseInternalDTO.getAdditionalIPs().length() > 0)
		{
			statusStr = "<span style='color: green'> Available </span>";
			String[] splittedStr = lliFRResponseInternalDTO.getAdditionalIPs().split(",");
			for(int i = 0; i < splittedStr.length ; i++)
			{
				if(splittedStr[i].length() == 0)continue;
				IpBlock ipBlock = ipAddressService.getIPBlockByBlockID(Long.parseLong(splittedStr[i]));
				statusStr += "<br>" + IpAddressService.getIp4AddressStringRepresentationByIpAddressLong(ipBlock.getStartingIpAddress()) + " - " + IpAddressService.getIp4AddressStringRepresentationByIpAddressLong(ipBlock.getEndingIpAddress());
			}
		}
		else
		{
			statusStr = "<span style='color: red'> Not Available </span>" + " <br> Reason: "+lliFRResponseInternalDTO.getAdditionalIpUnavailabilityReason();
		}
		noteDTO.addRow("IP Address", statusStr);		
		noteDTO.endDescription();
		
		new CommonNoteService().insert( noteDTO, databaseConnection );
		
	}
	
	public String createInternalFRNote(LliLinkDTO lliLinkDTO, int requestTypeID, LliInternalFRDataLocation lliInternalFRDataLocation, LliFRResponseInternalDTO lliFRResponseInternalDTO, HttpServletRequest request, DatabaseConnection databaseConnection) throws Exception{
		
		CommonNote noteDTO = new CommonNote();
		InventoryDAO inventoryDAO = new InventoryDAO();
		LliLinkService lliLinkService = new LliLinkService();
		noteDTO.setEntityId( lliFRResponseInternalDTO.getEntityID() );
		noteDTO.setEntityTypeId( lliFRResponseInternalDTO.getEntityTypeID() );
		noteDTO.setNoteTypeId( CommonNoteConstants.FR_RESPONSE.get( lliFRResponseInternalDTO.getRequestTypeID()) );
		noteDTO.setReqID(lliFRResponseInternalDTO.getReqID());
		
		String noteBody="Connection Name: <strong>" +lliLinkDTO.getName()+"</strong><br>";
		noteBody  +="From <strong>'" + UserRepository.getInstance().getUserDTOByUserID(-lliFRResponseInternalDTO.getRequestByAccountID()).getUsername() + "' </strong>  " +
				" : <strong>Internal FR  Report</strong> <br/>";
		
		noteDTO.setNoteBody( noteBody );
		noteDTO.startDescription("Item", "Comments");
		noteDTO.addRow("Bandwidth ", lliFRResponseInternalDTO.getBandwidth() + " " + EntityTypeConstant.linkBandwidthTypeMap.get(lliFRResponseInternalDTO.getBandwidthType()));
		
		String statusStr=lliFRResponseInternalDTO.isBandWidthIsAvailable()?" <span style='color: green'> Available </span>":" <span style='color: red'> Not Available </span>";
		if(!lliFRResponseInternalDTO.isBandWidthIsAvailable()){
			statusStr=statusStr+" <br> Reason: "+lliFRResponseInternalDTO.getBandWidthComment(); 
			noteDTO.addRow("Bandwidth Availability", statusStr);
		}else{
			noteDTO.addRow("Bandwidth Availability", statusStr);
		}
		
		if(lliInternalFRDataLocation.mandatoryIPInFRResponse)
		{
			if(lliFRResponseInternalDTO.getMandatoryIPs() != null && lliFRResponseInternalDTO.getMandatoryIPs().length() > 0)
			{
				statusStr = "<span style='color: green'> Available </span>";
				String[] splittedStr = lliFRResponseInternalDTO.getMandatoryIPs().split(",");
				for(int i = 0; i < splittedStr.length ; i++)
				{
					if(splittedStr[i].length() == 0)continue;
					IpBlock ipBlock = ipAddressService.getIPBlockByBlockID(Long.parseLong(splittedStr[i]));
					statusStr += "<br>" + IpAddressService.getIp4AddressStringRepresentationByIpAddressLong(ipBlock.getStartingIpAddress()) + " - " + IpAddressService.getIp4AddressStringRepresentationByIpAddressLong(ipBlock.getEndingIpAddress());
				}
			}
			else
			{
				statusStr = "<span style='color: red'> Not Available </span>" + " <br> Reason: "+lliFRResponseInternalDTO.getMandatoryIpUnavailabilityReason();
			}
			noteDTO.addRow("Mandatory IP Address", statusStr);
		}
		
		
		
		if(lliInternalFRDataLocation.additionalIPInFRResponse)
		{
			if(lliLinkDTO.getAdditionalIPCount() == 0)
			{
				statusStr = "<span style='color: green'> Not Requested </span>";
			}
			else if(lliLinkDTO.getAdditionalIPCount() > 0 && lliFRResponseInternalDTO.getAdditionalIPs() != null && lliFRResponseInternalDTO.getAdditionalIPs().length() > 0)
			{
				statusStr = "<span style='color: green'> Available </span>";
				String[] splittedStr = lliFRResponseInternalDTO.getAdditionalIPs().split(",");
				for(int i = 0; i < splittedStr.length ; i++)
				{
					if(splittedStr[i].length() == 0)continue;
					IpBlock ipBlock = ipAddressService.getIPBlockByBlockID(Long.parseLong(splittedStr[i]));
					statusStr += "<br>" + IpAddressService.getIp4AddressStringRepresentationByIpAddressLong(ipBlock.getStartingIpAddress()) + " - " + IpAddressService.getIp4AddressStringRepresentationByIpAddressLong(ipBlock.getEndingIpAddress());
				}
			}
			else
			{
				statusStr = "<span style='color: red'> Not Available </span>" + " <br> Reason: "+lliFRResponseInternalDTO.getAdditionalIpUnavailabilityReason();
			}
			noteDTO.addRow("Additional IP Address", statusStr);
		}
		
		LliFarEndDTO feDTO = getLliFarEndByID(lliLinkDTO.getFarEndID(), databaseConnection);
		
//		LliFRResponseExternalDTO lliFRResponseExternalDTOForFarEnd = getLatestExternalFRForFarEnd(feDTO, databaseConnection);
		
		String districtFarEnd="-";
		String upazillaFarEnd = "-";
		String unionFarEnd = "-";
		String popFarEnd = "-";
		String portFarEnd = "-";
//		logger.debug("lliFRResponseExternalDTOForNearEnd " + lliFRResponseExternalDTOForNearEnd);
		logger.debug("lliFRResponseInternalDTO " + lliFRResponseInternalDTO);

		Boolean isValidByRequestTypeID = false;
		
		switch(requestTypeID){
		case LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_RESPONSE_WITH_INTERNAL_FR:
		case LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_RESPONSE_WITH_INTERNAL_FR_NEGATIVE:
		case LliRequestTypeConstants.REQUEST_NEW_LINK.GET_PREPARED_TO_GENERATE_DEMAND_NOTE:
		{
			LliFRResponseExternalDTO lliFRResponseExternalDTOForFarEnd = getLatestExternalFRForFarEnd(feDTO, databaseConnection);
			logger.debug("lliFRResponseExternalDTOForFarEnd " + lliFRResponseExternalDTOForFarEnd);
			logger.debug("lliFRResponseInternalDTO " + lliFRResponseInternalDTO);
			portFarEnd = lliFRResponseInternalDTO.getFePortTypeID();
			if(lliFRResponseExternalDTOForFarEnd != null){
				popFarEnd = "" + inventoryDAO.getInventoryItemByItemID(lliFRResponseExternalDTOForFarEnd.getPopIDSelected(), databaseConnection).getName();				
			}
			else if(lliFRResponseInternalDTO.getFePopID() > 0)
			{
				popFarEnd = inventoryDAO.getInventoryItemByItemID(lliFRResponseInternalDTO.getFePopID(), databaseConnection).getName();
			}
			break;
		}
		case LliRequestTypeConstants.REQUEST_UPGRADE.SYSTEM_RESPONSE_WITH_INTERNAL_FR:
		case LliRequestTypeConstants.REQUEST_DOWNGRADE.SYSTEM_RESPONSE_WITH_INTERNAL_FR:
		{						
			popFarEnd = "" + inventoryDAO.getInventoryItemByItemID(feDTO.getPopID(), databaseConnection).getName();
			portFarEnd = lliFRResponseInternalDTO.getFePortTypeID();
			isValidByRequestTypeID = true;
			break;
		}	
		case LliRequestTypeConstants.REQUEST_POP_CHANGE.SYSTEM_RESPONSE_WITH_INTERNAL_FR:
		case LliRequestTypeConstants.REQUEST_POP_CHANGE.SYSTEM_RESPONSE_WITH_INTERNAL_FR_NEGATIVE:
		case LliRequestTypeConstants.REQUEST_POP_CHANGE.GET_PREPARED_TO_GENERATE_DEMAND_NOTE:
		{
			break;
		}
		}
		
		noteDTO.addRow("Pop",popFarEnd);

		InventoryItem tempCommonItem = inventoryDAO.getInventoryItemByItemID(lliFRResponseInternalDTO.getFeRouterID(), databaseConnection);
		noteDTO.addRow("Router", (tempCommonItem==null)?"N/A":tempCommonItem.getName());

		
		if(StringUtils.isBlank(portFarEnd)){
			statusStr=" <span style='color: red'> Not Available </span>";
			noteDTO.addRow("Port Type",statusStr+"<br> Reason:"+lliFRResponseInternalDTO.getFePortTypeComment());
		}else{
			noteDTO.addRow("Port Type",portFarEnd);

		}
		
		tempCommonItem = inventoryDAO.getInventoryItemByItemID(lliFRResponseInternalDTO.getFePortID(), databaseConnection);
		noteDTO.addRow("Port", (tempCommonItem==null)?"N/A":tempCommonItem.getName());
		
		statusStr=" <span style='color: red'> Not Available </span>";
		if(lliFRResponseInternalDTO.isReportType()){//is positive
			statusStr="<span style='color: green'> <a> Available </b> </span>";
		}
		noteDTO.addRow("<b>Overall </b>","<b>"+statusStr+"</br>");
		noteDTO.endDescription();
		
		new CommonNoteService().insert( noteDTO, databaseConnection );
		
		String noteHyperlink = "<a target='_blank' href='../../common/reports/internalFrResponseReport.jsp?id=" + noteDTO.getId() + "'>View Internal FR Response</a>";
		return noteHyperlink;
	}
	
	public LliInternalFRDataLocation getInternalFRDataLocation(LliLinkDTO lliLinkDTO, LliFarEndDTO lliFarEndDTO, int requestTypeID)
	{
		LliInternalFRDataLocation lliInternalFRDataLocation = new LliInternalFRDataLocation();
		
		if(lliFarEndDTO.getOfcProviderTypeID() == EndPointConstants.OFC_CUSTOMER)
		{
			if(requestTypeID == LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_RESPONSE_WITH_INTERNAL_FR)
			{					
				lliInternalFRDataLocation.farEndPopInFRResponse = true;
				lliInternalFRDataLocation.farEndSlotInFRResponse = true;
				lliInternalFRDataLocation.farEndPortInFRResponse = true;
				
				lliInternalFRDataLocation.mandatoryIPInFRResponse = true;
				lliInternalFRDataLocation.additionalIPInFRResponse = true;
			}
			else if(requestTypeID == LliRequestTypeConstants.REQUEST_UPGRADE.SYSTEM_RESPONSE_WITH_INTERNAL_FR || requestTypeID == LliRequestTypeConstants.REQUEST_DOWNGRADE.SYSTEM_RESPONSE_WITH_INTERNAL_FR)
			{					
				lliInternalFRDataLocation.farEndPopInFRResponse = true;
				lliInternalFRDataLocation.farEndSlotInFRResponse = true;
				lliInternalFRDataLocation.farEndPortInFRResponse = true;
				
				lliInternalFRDataLocation.mandatoryIPInEndpointDTO = true;
				lliInternalFRDataLocation.additionalIPInEndpointDTO = true;
			}
		}
		else if(lliFarEndDTO.getOfcProviderTypeID() == EndPointConstants.OFC_BTCL)
		{
			if(requestTypeID == LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_RESPONSE_WITH_INTERNAL_FR)
			{
			}
			else if(requestTypeID == LliRequestTypeConstants.REQUEST_NEW_LINK.GET_PREPARED_TO_GENERATE_DEMAND_NOTE)
			{					
				lliInternalFRDataLocation.farEndPopInEndpointDTO = true;
				lliInternalFRDataLocation.farEndSlotInFRResponse = true;
				lliInternalFRDataLocation.farEndPortInFRResponse = true;
				
				lliInternalFRDataLocation.mandatoryIPInFRResponse = true;
				lliInternalFRDataLocation.additionalIPInFRResponse = true;
			}
			else if(requestTypeID == LliRequestTypeConstants.REQUEST_UPGRADE.SYSTEM_RESPONSE_WITH_INTERNAL_FR || requestTypeID == LliRequestTypeConstants.REQUEST_DOWNGRADE.SYSTEM_RESPONSE_WITH_INTERNAL_FR)
			{
				lliInternalFRDataLocation.farEndPopInEndpointDTO = true;
				lliInternalFRDataLocation.farEndSlotInFRResponse = true;
				lliInternalFRDataLocation.farEndPortInFRResponse = true;
				
				lliInternalFRDataLocation.mandatoryIPInEndpointDTO = true;
				lliInternalFRDataLocation.additionalIPInEndpointDTO = true;
			}
		}
//		
		return lliInternalFRDataLocation;
	}
	
	public LliInternalFRDataLocation getInternalFRDataLocationForEdit(LliLinkDTO lliLinkDTO, LliFarEndDTO lliFarEndDTO, int requestTypeID)
	{
		LliInternalFRDataLocation lliInternalFRDataLocation = new LliInternalFRDataLocation();
		
		StateDTO currentStateDTO = StateRepository.getInstance().getStateDTOByStateID(lliLinkDTO.getCurrentStatus());			
		boolean currentStatusActive = (currentStateDTO.getActivationStatus() == EntityTypeConstant.STATUS_ACTIVE);
		if(!currentStatusActive)
		{
			return lliInternalFRDataLocation;
		}
		lliInternalFRDataLocation.farEndPopInFRResponse = false;			
		lliInternalFRDataLocation.farEndPortInFRResponse = true;	
		lliInternalFRDataLocation.farEndSlotInFRResponse = true;
		return lliInternalFRDataLocation;
	}
	@Transactional
	public void processInternalFrResponseIPAddress(ActionMapping mapping, CommonRequestDTO commonRequestDTO, CommonRequestDTO sourceRequestDTO, HttpServletRequest request, HttpServletResponse response,
			LoginDTO loginDTO, DatabaseConnection databaseConnection) throws Exception {

		long currentTime = System.currentTimeMillis();
		LliLinkDTO lliLinkDTO = getLliLink(commonRequestDTO.getEntityID(), databaseConnection);			
		LliFarEndDTO lliFarEndDTO = getLliFarEndByID(lliLinkDTO.getFarEndID(), databaseConnection);

		requestUtilDAO.updateRequestByRequestID(sourceRequestDTO.getReqID(), databaseConnection);


		LliFRResponseInternalDTO lliFRResponseInternalDTO = new LliFRResponseInternalDTO();

		useIpAddressFromInternalFRIPAddress(lliFRResponseInternalDTO, lliLinkDTO, lliFarEndDTO, request, databaseConnection);

		CommonRequestDTO commonRequestDTOForEndPoint = new CommonRequestDTO(); 
		commonRequestDTOForEndPoint.setEntityTypeID(EntityTypeConstant.LLI_LINK_FAR_END);
		commonRequestDTOForEndPoint.setEntityID(lliFarEndDTO.getID());
		commonRequestDTOForEndPoint.setState(commonRequestDTO.getRequestTypeID());


		lliFRResponseInternalDTO.setRequestTime(currentTime);
		lliFRResponseInternalDTO.setLastModificationTime(currentTime);
		lliFRResponseInternalDTO.setRequestByAccountID(-loginDTO.getUserID());
		lliFRResponseInternalDTO.setRequestTypeID(commonRequestDTO.getRequestTypeID());
		lliFRResponseInternalDTO.setEntityTypeID(EntityTypeConstant.LLI_LINK);
		lliFRResponseInternalDTO.setEntityID(commonRequestDTO.getEntityID());
		lliFRResponseInternalDTO.setRootReqID(commonRequestDTO.getRootReqID());

		lliFRResponseInternalDTO.setParentReqID(null);
		lliFRResponseInternalDTO.setClientID(commonRequestDTO.getClientID());
		lliFRResponseInternalDTO.setSourceRequestID(""+sourceRequestDTO.getReqID());
		lliFRResponseInternalDTO.setLinkID(commonRequestDTO.getEntityID());

		lliFRResponseInternalDTO.setIP(loginDTO.getLoginSourceIP());
		String description = "";
		lliFRResponseInternalDTO.setDescription(description);
		lliFRResponseInternalDTO.setCompletionStatus(RequestStatus.PENDING);
		if (lliFRResponseInternalDTO.getExpireTime() == 0){
			long expireTime = commonDAO.getExpireTimeByRequestType(lliFRResponseInternalDTO.getRequestTypeID());
			lliFRResponseInternalDTO.setExpireTime(expireTime);
		}

		boolean isPositiveResponse = lliFRResponseInternalDTO.getAdditionalIPs().length() > 0 ? true : false;
		
		lliFRResponseInternalDTO.setReportType(isPositiveResponse);

		if(!isPositiveResponse){	

			lliFRResponseInternalDTO.setRequestTypeID(-lliFRResponseInternalDTO.getRequestTypeID());
			lliFRResponseInternalDTO.setCompletionStatus(RequestStatus.ALL_PROCESSED);
			SqlGenerator.insert(lliFRResponseInternalDTO, LliFRResponseInternalDTO.class, databaseConnection, true);
			requestUtilDAO.completeRequestByRootID(lliFRResponseInternalDTO.getRootReqID(), databaseConnection);
			logger.debug("updating status of link ****** with commonRequestDTO " + commonRequestDTO);
			commonDAO.updateStatusByEntityIDAndEntityTypeID(lliFRResponseInternalDTO, EntityTypeConstant.STATUS_CURRENT_AND_LATEST,  databaseConnection);
		}
		else{
			SqlGenerator.insert(lliFRResponseInternalDTO, LliFRResponseInternalDTO.class, databaseConnection, true);
			commonDAO.updateStatusByEntityIDAndEntityTypeID(commonRequestDTO, EntityTypeConstant.STATUS_LATEST,  databaseConnection);
		}

		createInternalFRNoteForIPAddress(lliLinkDTO, commonRequestDTO.getRequestTypeID(),  lliFRResponseInternalDTO, request, databaseConnection);

	}
	
	/*
	 * At first this function is called to insert with with request Type XX142
	 * After some steps again this function is called with the request type XX110
	 */
	@Transactional
	public void processInternalFrResponse(ActionMapping mapping, CommonRequestDTO commonRequestDTO, CommonRequestDTO sourceRequestDTO, HttpServletRequest request, HttpServletResponse response,
			LoginDTO loginDTO, DatabaseConnection databaseConnection) throws Exception {
		boolean isPositiveResponse = true;
		
		long currentTime = System.currentTimeMillis();
		LliLinkDTO lliLinkDTO = getLliLink(commonRequestDTO.getEntityID(), databaseConnection);			
		LliFarEndDTO lliFarEndDTO = getLliFarEndByID(lliLinkDTO.getFarEndID(), databaseConnection);
		
		//InventoryService inventoryService = new InventoryService();
		int requestTypeID = commonRequestDTO.getRequestTypeID();
		int requestTypePrefix = requestTypeID / EntityTypeConstant.MULTIPLIER2;
		int requestTypeSuffix = requestTypePrefix % 100;
		boolean isCreativeRequest = (requestTypeSuffix == 1);
		logger.debug("isCreativeRequest " + isCreativeRequest);
		
		String fePopID=null;
		
		if(lliFarEndDTO.getOfcProviderTypeID() == EndPointConstants.OFC_CUSTOMER){
			fePopID = request.getParameter("fePopID");
		}
		String feRouterID=request.getParameter("feRouterID");
		
		String fePortTypeID = request.getParameter("fePortType");			
		
		String fePortID = request.getParameter("fePortID");
		//long portID = Long.parseLong(fePortID);
		
		
		String feMandatoryVlanID=request.getParameter("feMandatoryVlanID");
		String feMandatoryVlanComment = request.getParameter("feMandatoryVLANComment");			
		
		String feAdditionalVLANComment=request.getParameter("feAdditionalVLANComment");
		String feAdditionalVlanIDs=request.getParameter("feAdditionalVlanIDs");
		
		String bandwidthAvailablity = request.getParameter("bandwidthAvailablity");
		String comment = org.apache.commons.lang3.StringUtils.trimToEmpty(request.getParameter("bandWidthComment")) ;
	
		requestUtilDAO.updateRequestByRequestID(sourceRequestDTO.getReqID(), databaseConnection);
		
		LliInternalFRDataLocation lliInternalFRDataLocation = getInternalFRDataLocation(lliLinkDTO, lliFarEndDTO, commonRequestDTO.getRequestTypeID());

		int remainder = ( Math.abs(commonRequestDTO.getRequestTypeID()) % EntityTypeConstant.MULTIPLIER2);
		
		logger.debug("farEndPopInEndpointDTO " + lliInternalFRDataLocation.farEndPopInEndpointDTO + " farEndPopInFRResponse " +lliInternalFRDataLocation.farEndPopInFRResponse + " farEndPortInEndpointDTO " + lliInternalFRDataLocation.farEndPortInEndpointDTO + " farEndPortInFRResponse " + lliInternalFRDataLocation.farEndPortInFRResponse);
		
		LliFRResponseInternalDTO lliFRResponseInternalDTO = new LliFRResponseInternalDTO();
		if((requestTypeID / EntityTypeConstant.MULTIPLIER2) % 100 == 9)//shifting
		{			
			if(!isLliLinkFarEndEligibleToShift(lliLinkDTO.getID(), databaseConnection))
			{
				lliInternalFRDataLocation.farEndPopInEndpointDTO = true;
				lliInternalFRDataLocation.farEndPortInEndpointDTO = true;
				lliInternalFRDataLocation.farEndSlotInEndpointDTO = true;
				
				lliInternalFRDataLocation.farEndPopInFRResponse = false;
				lliInternalFRDataLocation.farEndPortInFRResponse = false;
				lliInternalFRDataLocation.farEndSlotInFRResponse = false;
			}
			
		}
		/*
		 * Far end from dto
		 */
		
		lliFRResponseInternalDTO.setFePopID(lliFarEndDTO.getPopID());

		lliFRResponseInternalDTO.setFeRouterID(lliFarEndDTO.getRouterID());

		lliFRResponseInternalDTO.setFeMandatoryVlanID(lliFarEndDTO.getMandatoryVLanID());
		lliFRResponseInternalDTO.setFeMandatoryVlanComment("");
		lliFRResponseInternalDTO.setFeAdditionalVlanIDs(lliFarEndDTO.getAdditionalVLanID());
		lliFRResponseInternalDTO.setFeAdditionalVlanComment("");

		lliFRResponseInternalDTO.setFePortTypeID(lliFarEndDTO.getPortType());
		lliFRResponseInternalDTO.setFePortID(lliFarEndDTO.getPortID());
		
		lliFRResponseInternalDTO.setBandWidthIsAvailable("1".equals(bandwidthAvailablity)?true:false);
		lliFRResponseInternalDTO.setBandWidthComment(comment);
		lliFRResponseInternalDTO.setBandwidthType(lliLinkDTO.getLliBandwidthType());
		/*
		 * Far end from input
		 */
		if(lliInternalFRDataLocation.farEndPopInFRResponse){
			lliFRResponseInternalDTO.setFePopID(Long.parseLong(fePopID));
		}
		if(lliInternalFRDataLocation.farEndSlotInFRResponse){
			lliFRResponseInternalDTO.setFeRouterID((feRouterID.trim().length() > 0) ? Long.parseLong(feRouterID) : 0);

			lliFRResponseInternalDTO.setFeMandatoryVlanID(feMandatoryVlanID);
			lliFRResponseInternalDTO.setFeMandatoryVlanComment(feMandatoryVlanComment);
			lliFRResponseInternalDTO.setFeAdditionalVlanIDs(feAdditionalVlanIDs);
			lliFRResponseInternalDTO.setFeAdditionalVlanComment(feAdditionalVLANComment);
		}	
		if(lliInternalFRDataLocation.mandatoryIPInFRResponse)
		{
			useIpAddressFromInternalFR(lliFRResponseInternalDTO, lliLinkDTO, lliFarEndDTO, request, databaseConnection);
		}
		if(lliInternalFRDataLocation.farEndPortInFRResponse){
			lliFRResponseInternalDTO.setFePortTypeID(fePortTypeID);
			lliFRResponseInternalDTO.setFePortID(Long.parseLong(fePortID));		
			
			CommonRequestDTO commonRequestDTOForEndPoint = new CommonRequestDTO(); 
			commonRequestDTOForEndPoint.setEntityTypeID(EntityTypeConstant.LLI_LINK_FAR_END);
			commonRequestDTOForEndPoint.setEntityID(lliFarEndDTO.getID());
			int farEndStatus = (requestTypePrefix * EntityTypeConstant.MULTIPLIER2) + 70;				 
			commonRequestDTOForEndPoint.setState(farEndStatus);
			
			if(isCreativeRequest){
				commonDAO.updateStatusByEntityIDAndEntityTypeID(commonRequestDTOForEndPoint, EntityTypeConstant.STATUS_CURRENT_AND_LATEST,  databaseConnection);
				lliFarEndDTO.setCurrentStatus(farEndStatus);
				lliFarEndDTO.setLatestStatus(farEndStatus);
			}
			else{
				commonDAO.updateStatusByEntityIDAndEntityTypeID(commonRequestDTOForEndPoint, EntityTypeConstant.STATUS_LATEST,  databaseConnection);
			}
		}
		isPositiveResponse = isPositiveResponse(lliLinkDTO, lliFRResponseInternalDTO, lliInternalFRDataLocation);
		if(lliInternalFRDataLocation.farEndPortInFRResponse && isPositiveResponse){
			useInventoryItemFromInternalFR( requestTypeID, lliFRResponseInternalDTO, databaseConnection, lliLinkDTO, EntityTypeConstant.LLI_LINK_FAR_END, lliFarEndDTO, false, fePortID, feMandatoryVlanID, feAdditionalVlanIDs );
		}

		
		/*
		 * Bandwidth from input
		 */

		
		logger.debug("farEndPortType" + fePortTypeID);
		lliFRResponseInternalDTO.setRequestTime(currentTime);
		lliFRResponseInternalDTO.setLastModificationTime(currentTime);
		lliFRResponseInternalDTO.setRequestByAccountID(-loginDTO.getUserID());
		lliFRResponseInternalDTO.setRequestTypeID(commonRequestDTO.getRequestTypeID());
		lliFRResponseInternalDTO.setEntityTypeID(EntityTypeConstant.LLI_LINK);
		lliFRResponseInternalDTO.setEntityID(commonRequestDTO.getEntityID());
		lliFRResponseInternalDTO.setRootReqID(commonRequestDTO.getRootReqID());
		
		lliFRResponseInternalDTO.setRootReqIDInExtendedTable(lliFRResponseInternalDTO.getRootReqID());
		
		lliFRResponseInternalDTO.setParentReqID(null);
		lliFRResponseInternalDTO.setClientID(commonRequestDTO.getClientID());
		lliFRResponseInternalDTO.setSourceRequestID(""+sourceRequestDTO.getReqID());
		lliFRResponseInternalDTO.setLinkID(commonRequestDTO.getEntityID());
		
		
		lliFRResponseInternalDTO.setIP(loginDTO.getLoginSourceIP());
		String description = "";
		lliFRResponseInternalDTO.setDescription(description);
		
		if(commonRequestDTO.getRequestTypeID()==LliRequestTypeConstants.REQUEST_NEW_LINK.GET_PREPARED_TO_GENERATE_DEMAND_NOTE){
			lliFRResponseInternalDTO.setCompletionStatus(RequestStatus.PENDING);
		}
		else if(commonRequestDTO.getRequestTypeID()==LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_RESPONSE_WITH_INTERNAL_FR){
			lliFRResponseInternalDTO.setCompletionStatus(RequestStatus.SEMI_PROCESSED);
		}
		if (lliFRResponseInternalDTO.getExpireTime() == 0){
			long expireTime = commonDAO.getExpireTimeByRequestType(lliFRResponseInternalDTO.getRequestTypeID());
			lliFRResponseInternalDTO.setExpireTime(expireTime);
		}
		
		logger.debug("lliFRResponseInternalDTO " + lliFRResponseInternalDTO);

		logger.debug("isPositiveResponse " + isPositiveResponse);
		lliFRResponseInternalDTO.setReportType(isPositiveResponse);
		
		if(!isPositiveResponse){	
			
			lliFRResponseInternalDTO.setRequestTypeID(-lliFRResponseInternalDTO.getRequestTypeID());
			lliFRResponseInternalDTO.setCompletionStatus(RequestStatus.ALL_PROCESSED);
			SqlGenerator.insert(lliFRResponseInternalDTO, LliFRResponseInternalDTO.class, databaseConnection, true);
			requestUtilDAO.completeRequestByRootID(lliFRResponseInternalDTO.getRootReqID(), databaseConnection);
			logger.debug("updating status of link ****** with commonRequestDTO " + commonRequestDTO);
			commonDAO.updateStatusByEntityIDAndEntityTypeID(lliFRResponseInternalDTO, EntityTypeConstant.STATUS_CURRENT_AND_LATEST,  databaseConnection);
		}
		else
		{
			
			switch(requestTypeID)
			{
				case LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_RESPONSE_WITH_INTERNAL_FR:
				case LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_RESPONSE_WITH_INTERNAL_FR_NEGATIVE:
				case LliRequestTypeConstants.REQUEST_NEW_LINK.GET_PREPARED_TO_GENERATE_DEMAND_NOTE:
				{
					updateEndpointsForCreation(lliFarEndDTO, lliFRResponseInternalDTO, databaseConnection);
					updateLinkForCreation(lliLinkDTO, lliFRResponseInternalDTO, databaseConnection);
					break;
				}
				case LliRequestTypeConstants.REQUEST_UPGRADE.SYSTEM_RESPONSE_WITH_INTERNAL_FR:
				case LliRequestTypeConstants.REQUEST_DOWNGRADE.SYSTEM_RESPONSE_WITH_INTERNAL_FR:
				{						
					updateRequestForBandwidthChange(lliLinkDTO, lliFRResponseInternalDTO, databaseConnection);
					break;
				}	
				case LliRequestTypeConstants.REQUEST_POP_CHANGE.SYSTEM_RESPONSE_WITH_INTERNAL_FR:
				case LliRequestTypeConstants.REQUEST_POP_CHANGE.SYSTEM_RESPONSE_WITH_INTERNAL_FR_NEGATIVE:
				case LliRequestTypeConstants.REQUEST_POP_CHANGE.GET_PREPARED_TO_GENERATE_DEMAND_NOTE:
				{
					updateRequestForShifting(lliLinkDTO, lliFRResponseInternalDTO, databaseConnection);
					break;
				}
			}
						

			
			SqlGenerator.insert(lliFRResponseInternalDTO, LliFRResponseInternalDTO.class, databaseConnection, true);
			
			CommonRequestDTO commonRequestDTOTobeInserted = null;
			if(commonRequestDTO.getRequestTypeID()==LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_RESPONSE_WITH_INTERNAL_FR)
			{
				commonRequestDTOTobeInserted = splitLinkToEnds(lliFRResponseInternalDTO, sourceRequestDTO, request, loginDTO, databaseConnection);									
			}
			
			if(commonRequestDTOTobeInserted != null)
			{
				commonRequestDTOTobeInserted.setSourceRequestID(""+lliFRResponseInternalDTO.getReqID());
				SqlGenerator.insert(commonRequestDTOTobeInserted, CommonRequestDTO.class, databaseConnection, false);
			}
			if(commonRequestDTO.getRequestTypeID()==LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_RESPONSE_WITH_INTERNAL_FR)
			{
				logger.debug("updating status of link ****** with commonRequestDTO " + commonRequestDTO);
				commonDAO.updateStatusByEntityIDAndEntityTypeID(commonRequestDTO, EntityTypeConstant.STATUS_CURRENT_AND_LATEST,  databaseConnection);
			}
			else if(commonRequestDTO.getRequestTypeID()==LliRequestTypeConstants.REQUEST_UPGRADE.SYSTEM_RESPONSE_WITH_INTERNAL_FR)
			{
				commonDAO.updateStatusByEntityIDAndEntityTypeID(commonRequestDTO, EntityTypeConstant.STATUS_LATEST,  databaseConnection);
			}
		}
		
		createInternalFRNote(lliLinkDTO, requestTypeID, lliInternalFRDataLocation, lliFRResponseInternalDTO, request, databaseConnection);
		/*
		String noteHyperlink= createInternalFRNote(lliLinkDTO,  lliFRResponseInternalDTO, request, databaseConnection);
		description = noteHyperlink;
		 
		lliFRResponseInternalDTO.setDescription(description);
		SqlGenerator.updateEntity(lliFRResponseInternalDTO, LliFRResponseInternalDTO.class, databaseConnection, true, false);
		*/
		
//		SqlGenerator.updateEntityByPropertyList(lliFRResponseInternalDTO, LliFRResponseInternalDTO.class, databaseConnection, true, false, new String[]{"description, lastModificationTime"});
	}

	private String getCommaSeparatedStringFromArray(String[] array) {
		String str = "";
		if(array == null) {
			return str;
		}else {
			for(int i=0;i<array.length;i++) {
				if(i>0) {
					str += "," + array[i]; 
				}else {
					str += array[i];
				}
			}
		}
		return str;
	}

	private boolean isPositiveResponse(LliLinkDTO lliLinkDTO, LliFRResponseInternalDTO lliFRResponseInternalDTO, LliInternalFRDataLocation lliInternalFRDataLocation)
	{
		boolean isPositiveResponse = true;
		boolean checkPortAvailability = (lliInternalFRDataLocation.farEndPortInEndpointDTO || lliInternalFRDataLocation.farEndPortInFRResponse);
		boolean checkVLan = (lliInternalFRDataLocation.farEndSlotInEndpointDTO || lliInternalFRDataLocation.farEndSlotInFRResponse);
		boolean checkBandWidth = true;
		boolean checkMandatoryIP = lliInternalFRDataLocation.mandatoryIPInFRResponse;
		boolean checkAdditionalIP = lliInternalFRDataLocation.additionalIPInFRResponse;
		
		if(checkBandWidth){
			if(lliFRResponseInternalDTO.isBandWidthIsAvailable()){					
			}
			else{
				isPositiveResponse = false;
			}
		}
		/* VLAN is temporarily hidden
		if(checkVLan){
			if(lliFRResponseInternalDTO.getFeMandatoryVlanID().length() > 0){				
			}
			else{
				isPositiveResponse = false;
			}
		}
		*/
		if(checkMandatoryIP)
		{

			if(lliFRResponseInternalDTO.getMandatoryIPs().length() > 0)
			{
				
			}
			else
			{
				isPositiveResponse = false;
			}
		}
		
		if(checkAdditionalIP)
		{
			
			if(lliLinkDTO.getAdditionalIPCount() == 0)
			{
				
			}
			else if(lliLinkDTO.getAdditionalIPCount() > 0 && lliFRResponseInternalDTO.getAdditionalIPs().length() > 0)
			{
				
			}
			else
			{
				isPositiveResponse = false;
			}
		}		
		
		if(checkPortAvailability){
			if(lliFRResponseInternalDTO.getFePortID() > 0){				
			}
			else{
				isPositiveResponse = false;
			}
		}
		return isPositiveResponse;
	}
	
	@Transactional
	private void useIpAddressFromInternalFR(LliFRResponseInternalDTO lliFRResponseInternalDTO, LliLinkDTO lliLinkDTO, LliFarEndDTO lliFarEndDTO, HttpServletRequest request, DatabaseConnection databaseConnection) throws Exception
	{
		int mandatoryIPCount = 0;
		String mandatoryIpUnavailabilityReason = null;
		String[] mandatoryIpList = null;
		int additionalIPCount = 0;
		String additionalIpUnavailablityReason = null;
		String[] additionalIpList = null;
		

		mandatoryIPCount = Integer.parseInt(request.getParameter("mandatoryIpAvailableCount"));
		mandatoryIpUnavailabilityReason = request.getParameter("mandatoryIpUnavailabilityReason");
		mandatoryIpList = (String[])request.getParameterValues("mandatoryIpAvailableBlockID");
//		additionalIPCount = Integer.parseInt(request.getParameter("additionalIpAvailableCount"));
		additionalIpUnavailablityReason = request.getParameter("additionalIpUnavailabilityReason");
		additionalIpList = (String[])request.getParameterValues("additionalIpAvailableBlockID");
		
		
		lliFRResponseInternalDTO.setMandatoryIpUnavailabilityReason(mandatoryIpUnavailabilityReason);
		lliFRResponseInternalDTO.setAdditionalIpUnavailabilityReason(additionalIpUnavailablityReason);
		

		
		lliLinkDTO.setAdditionalIPCount(additionalIPCount);
//		List<InventoryItem> inventoryItemsFromRoot = inventoryDAO.getInventoryItemDetailsFromRootByItemID(lliFRResponseInternalDTO.getFePortID(), databaseConnection);
		List<String> ipRanges = new ArrayList<>();
		if(mandatoryIpList != null)
		{
			ipRanges.addAll(Arrays.asList(mandatoryIpList));
			/*
			if(mandatoryIpList.length > 0)
			{
				mandatoryIPCount = mandatoryIpList.length;
			}*/
		}		
		if(additionalIpList != null)
		{
			ipRanges.addAll(Arrays.asList(additionalIpList));
		}
		
		logger.debug("mandatoryIPCount " + mandatoryIPCount + " ipRanges " + ipRanges);
		
		int divisionID = new InventoryService().getDivisionOfInventoryItem(lliFRResponseInternalDTO.getFePopID());
		
		
		List<IpBlock> blockList = ipAddressService.allocateIpBlocksByIpBlockStringList(ipRanges, lliLinkDTO.getClientID(), 
				divisionID, lliLinkDTO.getID(), mandatoryIPCount, 
				additionalIPCount, 0); // for now  expiration time is set 0
		String ipStringMandatory = "";
		String ipStringAdditional = "";
		if(blockList != null)
		{								
			int ipCount = 0;
			for(IpBlock ipBlock: blockList)
			{
				if(ipBlock.getUsageType() == InventoryConstants.USAGE_ESSENTIAL)
				{
					ipStringMandatory += ipBlock.getIpBlockID(); 
				}
				else
				{
					ipStringAdditional += ipBlock.getIpBlockID();
				}
				if(++ipCount == blockList.size())
				{
					break;
				}
				ipStringMandatory += ",";
			}
		}
		
		lliFRResponseInternalDTO.setMandatoryIPs (ipStringMandatory);
		lliFRResponseInternalDTO.setAdditionalIPs (ipStringAdditional);
	}
	
	@Transactional
	private void useIpAddressFromInternalFRIPAddress(LliFRResponseInternalDTO lliFRResponseInternalDTO, LliLinkDTO lliLinkDTO, LliFarEndDTO lliFarEndDTO, HttpServletRequest request, DatabaseConnection databaseConnection) throws Exception
	{
		int mandatoryIPCount = 0;
		int additionalIPCount = 0;
		String additionalIpUnavailablityReason = null;
		String[] additionalIpList = null;
		

		additionalIPCount = Integer.parseInt(request.getParameter("additionalIpAvailableCount"));
		additionalIpUnavailablityReason = request.getParameter("additionalIpUnavailabilityReason");
		additionalIpList = (String[])request.getParameterValues("additionalIpAvailableBlockID");
		
		lliFRResponseInternalDTO.setAdditionalIpAvailableCount(additionalIPCount);
		lliFRResponseInternalDTO.setAdditionalIpUnavailabilityReason(additionalIpUnavailablityReason);
				
		logger.debug("additionalIPCount " + additionalIPCount);
		lliLinkDTO.setAdditionalIPCount(additionalIPCount);
		List<String> ipRanges = new ArrayList<>();
		if(additionalIpList != null) {
			ipRanges.addAll(Arrays.asList(additionalIpList));
		}
		logger.debug("ipRanges " + ipRanges);
		
		long expirationTime = TimeConverter.getStartTimeOfTheNextNthDay(System.currentTimeMillis(), 1) + TimeConverter.MILLISECONDS_IN_YEAR;
		expirationTime--;
		List<IpBlock> blockList = ipAddressService.allocateIpBlocksByIpBlockStringList(ipRanges, lliLinkDTO.getClientID(), 
				InventoryConstants.districtToDivisionMap.get(lliFarEndDTO.getDistrictID()), lliLinkDTO.getID(), mandatoryIPCount, 
				additionalIPCount,  expirationTime); // for now  expiration time is set 0
		String ipStringAdditional = "";
		if(blockList != null) {								
			int ipCount = 0;
			for(IpBlock ipBlock: blockList)	{
				ipStringAdditional += ipBlock.getIpBlockID();
				if(++ipCount == blockList.size()) {
					break;
				}
				ipStringAdditional += ",";
			}
		}
		
		lliFRResponseInternalDTO.setAdditionalIPs (ipStringAdditional);
	}
			
	/**
	 * @author dhrubo
	 */
	private void useInventoryItemFromInternalFR(
			int requestTypeID, 
			LliFRResponseInternalDTO lliFRResponseInternalDTO, 
			DatabaseConnection databaseConnection, 
			LliLinkDTO lliLinkDTO, 
			Integer entityTypeID,
			LliFarEndDTO farEndDTO, 
			Boolean isNear, 
			String portID, 
			String mandatoryVlanID, 
			String additionalVlanIDs) throws Exception {
		
		if (requestTypeID == LliRequestTypeConstants.REQUEST_UPGRADE.SYSTEM_RESPONSE_WITH_INTERNAL_FR ||
				requestTypeID == LliRequestTypeConstants.REQUEST_DOWNGRADE.SYSTEM_RESPONSE_WITH_INTERNAL_FR) {
			
			Long alreadyUsedPort = farEndDTO.getPortID();
			if(!alreadyUsedPort.equals(lliFRResponseInternalDTO.getFePortID())){
				inventoryDAO.markInventoryItemAsUsedByItemID(Long.parseLong(portID), farEndDTO.getID(), entityTypeID, lliLinkDTO.getClientID(), databaseConnection);
		
			}
		}
		else {
			inventoryDAO.markInventoryItemAsUsedByItemID(Long.parseLong(portID), farEndDTO.getID(), entityTypeID, lliLinkDTO.getClientID(), databaseConnection);

			/* VLAN Hidden for now
			inventoryDAO.markInventoryItemAsUsedByItemID(Long.parseLong(mandatoryVlanID), farEndDTO.getID(), entityTypeID, lliLinkDTO.getClientID(), databaseConnection);
			if(additionalVlanIDs.length()>0) {
				for(String neAdditionalVlanId : additionalVlanIDs.split(",")) {
					if(null == neAdditionalVlanId) { throw new RequestFailureException("Invalid Additional VLAN"); }
					long neAdditionalVlanIdLong = Long.parseLong(neAdditionalVlanId.trim());
					inventoryDAO.markInventoryItemAsUsedByItemID(neAdditionalVlanIdLong, farEndDTO.getID(), entityTypeID, lliLinkDTO.getClientID(), databaseConnection);
				}
			}
			*/
		}
	}
	
	private void updateEndpointsForCreation(LliFarEndDTO lliFarEndDTO, LliFRResponseInternalDTO lliFRResponseInternalDTO, DatabaseConnection databaseConnection) throws Exception
	{
		LliFRResponseExternalDTO lliFRResponseExternalDTOFarEnd = getLatestExternalFRByEntityAndEntityTypeID(lliFarEndDTO.getID(), EntityTypeConstant.LLI_LINK_FAR_END, databaseConnection);	
		
		lliFarEndDTO.setPopID(lliFRResponseInternalDTO.getFePopID());					
		lliFarEndDTO.setRouterID(lliFRResponseInternalDTO.getFeRouterID());
		lliFarEndDTO.setPortCategoryType(lliFRResponseInternalDTO.getFePortTypeID());
		lliFarEndDTO.setPortID(lliFRResponseInternalDTO.getFePortID());
		if(lliFRResponseExternalDTOFarEnd != null)
		{
			lliFarEndDTO.setLoopDistanceTotal(lliFRResponseExternalDTOFarEnd.getDistanceTotal());
		}
		lliFarEndDTO.setMandatoryVLanID("0");
		/* same
		lliFarEndDTO.setMandatoryVLanID(lliFRResponseInternalDTO.getFeMandatoryVlanID());
		lliFarEndDTO.setAdditionalVLanID(lliFRResponseInternalDTO.getFeAdditionalVlanIDs());
		*/		
					
		updateEntity(lliFarEndDTO, LliFarEndDTO.class, databaseConnection, true, false);
	}
	
	private void updateLinkForCreation(LliLinkDTO lliLinkDTO, LliFRResponseInternalDTO lliFRResponseInternalDTO, DatabaseConnection databaseConnection) throws Exception
	{
		lliFRResponseInternalDTO.setBandwidth((int)lliLinkDTO.getLliBandwidth());
		lliFRResponseInternalDTO.setBandwidthType(lliLinkDTO.getLliBandwidthType());
	}
	/**
	 * @author dhrubo
	 */
	private void updateRequestForBandwidthChange(LliLinkDTO lliLinkDTO, LliFRResponseInternalDTO lliFRResponseInternalDTO, DatabaseConnection databaseConnection) throws Exception {

		LliBandWidthChangeRequestDTO lliBandWidthChangeRequestDTO = getLliBandwidthChangeRequestDTOByLliLinkID(lliLinkDTO.getID(), databaseConnection);

		lliFRResponseInternalDTO.setBandwidth((int)lliBandWidthChangeRequestDTO.getNewBandwidth());
		lliFRResponseInternalDTO.setBandwidthType(lliBandWidthChangeRequestDTO.getNewBandwidthType());
		
		lliBandWidthChangeRequestDTO.setNewFarPortID(lliFRResponseInternalDTO.getFePortID());
		lliBandWidthChangeRequestDTO.setNewFarPortType(lliFRResponseInternalDTO.getFePortTypeID());

		SqlGenerator.updateEntity(lliBandWidthChangeRequestDTO, LliBandWidthChangeRequestDTO.class, databaseConnection, false, false);
	}
	

	/**
	 * @author dhrubo
	 */
	private void updateRequestForShifting(LliLinkDTO lliLinkDTO, LliFRResponseInternalDTO lliFRResponseInternalDTO, DatabaseConnection databaseConnection) throws Exception {
		LliLinkShiftDTO lliLinkShiftDTO = getLliLinkShiftDTOByLliLinkID(lliLinkDTO.getID(), databaseConnection);

		switch (lliLinkShiftDTO.getFeShiftMode()) {
		case 1:
			break;
		case 2:
			lliLinkShiftDTO.setFePopID(lliFRResponseInternalDTO.getFePopID());
			lliLinkShiftDTO.setFeRouterID(lliFRResponseInternalDTO.getFeRouterID());
			lliLinkShiftDTO.setFePortID(lliFRResponseInternalDTO.getFePortID());
			/*
			lliLinkShiftDTO.setFeMandatoryVLanID(lliFRResponseInternalDTO.getFeMandatoryVlanID());
			lliLinkShiftDTO.setFeAdditionalVLanID(lliFRResponseInternalDTO.getFeAdditionalVlanIDs());
			*/
			break;
		}
		SqlGenerator.updateEntity(lliLinkShiftDTO, LliLinkShiftDTO.class, databaseConnection, false, false);		
	}

	public Long getLliLinkIDByNearEndID(long nearEndID, DatabaseConnection databaseConnection) throws Exception{
		
		Class<LliLinkDTO> classObject = LliLinkDTO.class;
		String sql = "select " + getColumnName(classObject, "ID")
					+ " from "+getTableName(classObject) 
					+ " where "+getColumnName(classObject, "nearEndID")
					+ "="+nearEndID; 
		PreparedStatement ps = databaseConnection.getNewPrepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		if(rs.next()){
			return rs.getLong(1);
		}else{
			return null;
		}
	}
	
	public Long getLliLinkIDByFarEndID(long farEndID, DatabaseConnection databaseConnection) throws Exception{
		
		Class<LliLinkDTO> classObject = LliLinkDTO.class;
		String sql = "select " + getColumnName(classObject, "ID")
					+ " from "+getTableName(classObject) 
					+ " where "+getColumnName(classObject, "farEndID") + "=" + farEndID;
		
		PreparedStatement ps = databaseConnection.getNewPrepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		if(rs.next()){
			return rs.getLong(1);
		}else{
			return null;
		}
	}
	
	public void updateOutsourcingCompanyOfEndPoints(CommonRequestDTO commonRequestDTO, CommonRequestDTO sourceRequestDTO, HttpServletRequest request, DatabaseConnection databaseConnection) throws Exception
	{
		switch(commonRequestDTO.getRequestTypeID())
		{
			case LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_REQUEST_EXTERNAL_FR_FOR_FAR_END:
			{
				LliFarEndDTO lliFarEndDTO = (LliFarEndDTO)getObjectByID(LliFarEndDTO.class, commonRequestDTO.getEntityID(), databaseConnection);
				lliFarEndDTO.setOfcProviderID(Math.abs(commonRequestDTO.getRequestToAccountID()));
				lliFarEndDTO.setLastModificationTime(commonRequestDTO.getRequestTime());
				updateEntityByPropertyList(lliFarEndDTO, LliFarEndDTO.class, databaseConnection, true, false, new String[]{"lastModificationTime", "ofcProviderID"});				
				break;
			}						
		}
	}
	
	public LliLinkDTO getLliLinkDTOByID(long id, DatabaseConnection databaseConnection)	throws Exception {
		LliLinkDTO	lliLinkDTO= ((LliLinkDTO) getObjectByID(LliLinkDTO.class, id, databaseConnection));
		return lliLinkDTO;
	}
	
	public List<LliLinkDTO> getLliLinkDTOByLinkNamePrefix( Object[] values, String[] columnNames,  DatabaseConnection databaseConnection) throws Exception {
		String conditionString="";
		List<LliLinkDTO> list=  getObjectFullyPopulatedByString(LliLinkDTO.class,  databaseConnection, values,  columnNames, conditionString);
		return list;

	}

	/**
	 * @author Alam
	 * @param commonRequestDTO
	 * @param sourceRequestDTO
	 * @param request
	 * @param loginDTO
	 * @param databaseConnection
	 */
	public int splitLinkToEndsForExactExternalFR(CommonRequestDTO commonRequestDTO, CommonRequestDTO sourceRequestDTO,  HttpServletRequest request, LoginDTO loginDTO, DatabaseConnection databaseConnection) throws Exception {
		
		long currentTime = System.currentTimeMillis();
		LliLinkDTO lliLinkDTO = getLliLinkDTOByID(commonRequestDTO.getEntityID(), databaseConnection);

		long farEndID = lliLinkDTO.getFarEndID();
		
		LliFarEndDTO lliFarEndDTO = getLliFarEndByID(farEndID, databaseConnection);
		int splittedCount = 0;
		
		

		if(lliFarEndDTO.getOfcProviderTypeID() == EndPointConstants.OFC_BTCL)
		{
			CommonRequestDTO farEndCommonRequestDTO = new CommonRequestDTO();;
			farEndCommonRequestDTO.setEntityTypeID(EntityTypeConstant.LLI_LINK_FAR_END);
			farEndCommonRequestDTO.setEntityID(farEndID);			
			farEndCommonRequestDTO.setClientID(commonRequestDTO.getClientID());
			farEndCommonRequestDTO.setRequestTime(commonRequestDTO.getRequestTime());
			farEndCommonRequestDTO.setLastModificationTime(commonRequestDTO.getLastModificationTime());
			farEndCommonRequestDTO.setDescription("");
			farEndCommonRequestDTO.setRequestTypeID(LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_PREPARED_TO_REQUEST_EXACT_EXTERNAL_FR_FOR_FAR_END);
			farEndCommonRequestDTO.setCompletionStatus(RequestStatus.PENDING);
//			farEndCommonRequestDTO.setRootReqID(null);
			farEndCommonRequestDTO.setRootReqID(commonRequestDTO.getRootReqID());
			farEndCommonRequestDTO.setParentReqID(commonRequestDTO.getReqID());
			farEndCommonRequestDTO.setSourceRequestID(""+commonRequestDTO.getReqID());
			farEndCommonRequestDTO.setRequestByAccountID(commonRequestDTO.getRequestByAccountID());
			requestDAO.addRequest(farEndCommonRequestDTO, loginDTO.getLoginSourceIP(), databaseConnection);
			splittedCount++;

		}
		
		
		
		if(splittedCount == 0)
		{
			CommonRequestDTO newCommonRequestDTO = new CommonRequestDTO();

			newCommonRequestDTO.setRequestTime(currentTime);
			newCommonRequestDTO.setLastModificationTime(currentTime);
			newCommonRequestDTO.setRequestByAccountID( -loginDTO.getUserID() );
			newCommonRequestDTO.setRequestTypeID( LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_PREPARED_TO_GENERATE_MRC );						
			newCommonRequestDTO.setRootReqID(commonRequestDTO.getRootReqID());
			newCommonRequestDTO.setClientID(commonRequestDTO.getClientID());
			newCommonRequestDTO.setEntityID(commonRequestDTO.getEntityID());
			newCommonRequestDTO.setEntityTypeID(commonRequestDTO.getEntityTypeID());
			newCommonRequestDTO.setDescription("");
			newCommonRequestDTO.setSourceRequestID(""+commonRequestDTO.getReqID());
			
			SqlGenerator.insert(newCommonRequestDTO, CommonRequestDTO.class, databaseConnection, false);
		}
		
		return splittedCount;
	}

	/**
	 * @author Alam
	 * @param lliFarEndDTO
	 * @param i
	 * @param databaseConnection
	 * @return
	 */
	public LliFRResponseExternalDTO getLatestExternalFRForFarEnd(LliFarEndDTO farEndDTO, int versionID, DatabaseConnection databaseConnection) throws Exception {	
		
		ArrayList<Long> farEndIDList = getSimilarFarEndpointIDsByEndpointID( farEndDTO.getLliEndPointID(), databaseConnection);
		String commaSeparated = "";
		if(farEndIDList.size() > 0)
		{
			commaSeparated = StringUtils.getCommaSeparatedString(farEndIDList);
		}
		else
		{
			return null;
		}
		String conditionString = " where entityTypeID = " + EntityTypeConstant.LLI_LINK_FAR_END  + " and reportVersionID = " + versionID + " and nearOrFarEndpointID in " + commaSeparated + " order by ID desc limit 1";
		ArrayList<LliFRResponseExternalDTO> externalFRList = (ArrayList<LliFRResponseExternalDTO>) SqlGenerator.getAllObjectListFullyPopulated(LliFRResponseExternalDTO.class, databaseConnection, conditionString);
		if(externalFRList.size() > 0)
		{
			return externalFRList.get(0);
		}
		return null;
		
	}	
	
	public long getOutsourcingCompanyID(CommonRequestDTO commonRequestDTO, CommonRequestDTO sourceRequestDTO, HttpServletRequest request, DatabaseConnection databaseConnection) throws Exception
	{
		long outsourcingCompanyID = -1;
		switch(commonRequestDTO.getRequestTypeID())
		{
			case LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_REQUEST_EXACT_EXTERNAL_FR_FOR_FAR_END:
			{				
				LliFarEndDTO lliFarEndDTO = getLliFarEndByID(commonRequestDTO.getEntityID(), databaseConnection);
				return lliFarEndDTO.getOfcProviderID();
			}
		}
		return outsourcingCompanyID;
	}

	/**
	 * @author Alam
	 * @param commonRequestDTO
	 * @param sourceRequestDTO
	 * @param databaseConnection
	 * @throws Exception 
	 */
	public void updateActivationTimeOfMrc(CommonRequestDTO commonRequestDTO, 
			CommonRequestDTO sourceRequestDTO, DatabaseConnection databaseConnection) throws Exception {
			
		logger.debug("Starting LLI Link service, but updating link balance and activation time of MRC before that");
				
		Long rootReqID = sourceRequestDTO.getReqID();
		if(sourceRequestDTO.getRootReqID() != null)
		{
			rootReqID = sourceRequestDTO.getRootReqID();
		}
		
		List<BillDTO> billList = new BillDAO().getBillsByRootReqID( rootReqID, databaseConnection );

		logger.debug( "List of bill created for this lli link " + billList );
		
		int monthOfFirstBill = -1;
		int yearOfFirstBill = -1;
		
		for( BillDTO billDTO: billList ) {
			
			if( billDTO.getBillType() == BillConstants.PREPAID_AND_POSTPAID ) {
				
				Calendar c = Calendar.getInstance();
				
				c.setTimeInMillis( billDTO.getActivationTimeFrom() );
				
				monthOfFirstBill = c.get(Calendar.MONTH);
				yearOfFirstBill = c.get( Calendar.YEAR );
				
				int daysOfMonth = c.get( Calendar.DATE );
				int numOfDays = c.getActualMaximum( Calendar.DATE );
				
				double fractionDontHaveToPay = ( daysOfMonth - 1 )/ (double)numOfDays;
				
				logger.debug( "Mix bill found, monthOfBill " + monthOfFirstBill + ", year of bill " + yearOfFirstBill 
							  + ", day of the month " + daysOfMonth + ", num of days in month " + numOfDays 
							  + ", fractionDontHavetoPay " + fractionDontHaveToPay );
				
				ArrayList<LliBillDTO> lliBillDtos = (ArrayList<LliBillDTO>)SqlGenerator.getAllObjectList(LliBillDTO.class, databaseConnection,
						" where " + SqlGenerator.getForeignKeyColumnName( LliBillDTO.class ) + " = " + billDTO.getID());
				
				logger.debug( "corresponding LLI bills " + lliBillDtos );
				
				if( lliBillDtos != null && lliBillDtos.size() > 0 ){
					
					LliBillDTO lliBillDTO = lliBillDtos.get(0);
					
					double bwChargeDontHaveToPay = lliBillDTO.getBwCharge() * fractionDontHaveToPay;
					
					logger.debug( "actual bandwidth charge - " + lliBillDTO.getBwCharge() + ", Bandwidth charge that wont have to pay " + bwChargeDontHaveToPay );
					
					LliLinkDTO lliLinkDTO = getLliLinkDTOByID( billDTO.getEntityID(), databaseConnection );
					
					lliLinkDTO.setBalance( lliLinkDTO.getBalance() + bwChargeDontHaveToPay );
					
					logger.debug( "Lli link after updating balance " + lliLinkDTO );
					
					SqlGenerator.updateEntity( lliLinkDTO, LliLinkDTO.class, databaseConnection, false, false );
				}
				break;
			}
		}
			
		Calendar c = Calendar.getInstance();
		c.setTimeInMillis( System.currentTimeMillis() );
		
		for( BillDTO billDTO: billList ){
			
			if( billDTO.getBillType() == BillConstants.PREPAID_AND_POSTPAID )
				continue;
			
			else if( billDTO.getBillType() == BillConstants.POSTPAID ){

				if( c.get(Calendar.MONTH) == monthOfFirstBill && c.get( Calendar.YEAR) == yearOfFirstBill ) {
					
					c.add( Calendar.MONTH, 1 );
				}
			
				billDTO.setActivationTimeFrom( DateUtils.getStartTimeOfMonth( c.get(Calendar.MONTH ), c.get(Calendar.YEAR ) ) );
				billDTO.setActivationTimeTo( DateUtils.getEndTimeOfMonth( c.get( Calendar.MONTH ), c.get( Calendar.YEAR ) ) );
				
				c.add( Calendar.MONTH, 1 );
				
				SqlGenerator.updateEntity( billDTO, BillDTO.class, databaseConnection, false, false );
			}	
		}
	}
	
	public void adjustBalanceForBandwidthChange( long linkID, long rootRequestID, DatabaseConnection databaseConnection) throws Exception {
		
		LliBillDTO lliBillDTO = new BillDAO().getExtendedBillByRootReqID( LliBillDTO.class, rootRequestID, databaseConnection );
		if(lliBillDTO == null)
		{
			return;
		}
		LliLinkDTO lliLinkDTO = getLliLink( linkID , databaseConnection );
		
//		double distanceBetweenDistricts = ((APIUtil)ServiceDAOFactory.getService(APIUtil.class)).getDistanceByLinkID( linkID ).getDistance();
//		double popToPopDistance = lliLinkDTO.getPopToPopDistance();
		int year = EndPointConstants.yearConnectionTypeMapping.get( lliLinkDTO.getConnectionType() );
		double bandwidthChargeInDemandNote = lliBillDTO.getBwCharge();
		
		/*
		 * Whether in same month or not, it doesn't matter
		 */
		LliBandWidthChangeRequestDTO lliBandWidthChangeRequestDTO = getLliBandwidthChangeRequestDTOByRootRequestID(rootRequestID, databaseConnection);
		
		double bandwidth = lliBandWidthChangeRequestDTO.getNewBandwidth();
		int bandwidthType = lliBandWidthChangeRequestDTO.getNewBandwidthType();
		
		if( bandwidthType == EntityTypeConstant.BANDWIDTH_TYPE_GB )
			bandwidth *= 1024; //Converting to MB		
		
		CostConfigService costConfigService = ServiceDAOFactory.getService(CostConfigService.class);
		int categoryID = new ClientTypeService().getClientCategoryByModuleIDAndClientID( EntityTypeConstant.LLI_LINK / EntityTypeConstant.MULTIPLIER2, lliLinkDTO.getClientID());
		TableDTO costTableDTO = costConfigService.getCostTableDTOForSpecificTimeByModuleIDAndCategoryID(System.currentTimeMillis()
				, ModuleConstants.Module_ID_LLI, categoryID);
		
		logger.debug("bandwidth " + bandwidth + " year " + year);
		double currentFullMonthBandwidthCharge = costTableDTO.getCostByRowValueAndColumnValue(bandwidth, year);
		
		Calendar c = Calendar.getInstance();
		int currentDay = c.get(Calendar.DAY_OF_MONTH);
		int daysRemainingInCurrentMonthIncToday = DateUtils.getDaysInCurrentMonth() - currentDay + 1;
		double currentFractionalMonthBandwidthCharge = currentFullMonthBandwidthCharge * ((double)daysRemainingInCurrentMonthIncToday/DateUtils.getDaysInCurrentMonth());
		
		double extraPaidAmount = ( bandwidthChargeInDemandNote - currentFractionalMonthBandwidthCharge);
		
		
		lliLinkDTO.setBalance( lliLinkDTO.getBalance() + extraPaidAmount);
		
		updateLliLink( lliLinkDTO, databaseConnection );
	}
	
	public void adjustmentAtLinkCreation(CommonRequestDTO commonRequestDTO, CommonRequestDTO sourceRequestDTO, DatabaseConnection databaseConnection) throws Exception {
		
		
		long lliLinkID = commonRequestDTO.getEntityID();
		
		LliLinkDTO lliLinkDTO = getLliLinkDTOByID(lliLinkID, databaseConnection);
		
		if(lliLinkDTO.getIsMigrated())
		{
			return;
		}
		
		if(lliLinkDTO.getConnectionType() == EndPointConstants.CONNECTION_TYPE_TEMPORARY_)
		{
			return;
		}
		
		LliBillDTO lliBillDTO = new BillDAO().getExtendedBillByRootReqID(LliBillDTO.class, commonRequestDTO.getRootReqID(), databaseConnection);
		
		if(lliBillDTO != null && !lliBillDTO.isMinimumOFCUsed())
		{
			return;
		}
		
		LliFarEndDTO farEndDTO = getLliFarEndByID( lliLinkDTO.getFarEndID(), databaseConnection);
		
		int farEndBTCLLoopDistance = farEndDTO.getLoopDistanceBTCL();
		
		LLIOTCConfigurationDTO commonCharge = new LLICostConfigurationService().getCurrentActiveLLI_OTC_ConfigurationDTO();
		
		BillDAO billDAO = new BillDAO();
		List<BillDTO> bills = billDAO.getBillsByRootReqID(sourceRequestDTO.getRootReqID(), databaseConnection );
		
		int numOfMonthBillIsPaid = bills.size();
		
		double balanceFarEnd = 0;
		
		if(farEndDTO.getOfcProviderTypeID() == EndPointConstants.OFC_BTCL)
		{
			balanceFarEnd = (farEndBTCLLoopDistance * commonCharge.getOFChargePerMeter( farEndDTO.getDistrictID() )) - 1000;
			
			if( balanceFarEnd < 0 ) balanceFarEnd = 0;
			
			balanceFarEnd = numOfMonthBillIsPaid * balanceFarEnd;
		}		
				
		lliLinkDTO.setBalance( lliLinkDTO.getBalance() - (balanceFarEnd));
		
		/*
		 * Fractional MRC adjustment start
		 */
		BillDTO demandNote = null;
		for(BillDTO billDTO:bills)
		{
			if(billDTO.getBillType() == BillConstants.DEMAND_NOTE)
			{
				demandNote = billDTO;
				break;
			}
		}
		
		LliBillDTO lliBillDemandNote = billDAO.getLliBillDTOByBillID(demandNote.getID(), databaseConnection);
		
		double mrcInDemandNote = lliBillDemandNote.getTotalMRC();
		
		Calendar c = Calendar.getInstance();
		int currentDay = c.get(Calendar.DAY_OF_MONTH);
		int daysRemainingInCurrentMonthIncToday = DateUtils.getDaysInCurrentMonth() - currentDay + 1;
		double fractionalMRC = mrcInDemandNote * ((double)daysRemainingInCurrentMonthIncToday/DateUtils.getDaysInCurrentMonth());
		
		double extraPaidAmount = ( mrcInDemandNote - fractionalMRC);
		
		lliLinkDTO.setBalance( lliLinkDTO.getBalance() + extraPaidAmount);
		
		/*
		 * Fractional MRC adjustment end
		 */
		
		lliLinkDTO.setSecurityMoney(lliBillDemandNote.getSecurityCharge());
		SqlGenerator.updateEntity( lliLinkDTO, LliLinkDTO.class, databaseConnection, false, false );					
	}
	
	public Boolean isLliLinkFarEndEligibleToShift(Long lliLinkID, DatabaseConnection databaseConnection) throws Exception {
		CommonRequestDTO mostRecentLinkShiftRequest = getMostRecentRequestByEntityIDandEntityTypeIDandRequestTypeID(lliLinkID, EntityTypeConstant.LLI_LINK, LliRequestTypeConstants.REQUEST_POP_CHANGE.SYSTEM_REQUEST_WITH_INTERNAL_FR, databaseConnection);
		if(mostRecentLinkShiftRequest != null) {
			LliLinkShiftDTO lliLinkShiftDTO = getLliLinkShiftDTOByRootRequestID(mostRecentLinkShiftRequest.getRootReqID(), databaseConnection);
			if(lliLinkShiftDTO.getFeID()==-1L) {
				return false;
			}else {
				return true;
			}
		}
		return false;
	}
	/**
	 * @author dhrubo
	 */
	public CommonRequestDTO getMostRecentRequestByEntityIDandEntityTypeIDandRequestTypeID(Long entityID, int entityTypeID,
			int requestTypeID, DatabaseConnection databaseConnection) throws Exception {
		List<CommonRequestDTO> mostRecentRequestList = SqlGenerator.getAllObjectListFullyPopulated(CommonRequestDTO.class, databaseConnection, 
				" where arEntityID = " + entityID
				+ " and arEntityTypeID = " + entityTypeID
				+ " and arRequestTypeID = " + requestTypeID
				+ " order by arID desc");
		return mostRecentRequestList.get(0);
	}
	public LliLinkShiftDTO getLliLinkShiftDTOByRootRequestID(Long rootReqID, DatabaseConnection databaseConnection) throws Exception {
		List<LliLinkShiftDTO> lliLinkShiftDTOListByRootRequestID = SqlGenerator.getAllObjectList(LliLinkShiftDTO.class, databaseConnection, 
				" where reqID = " + rootReqID);
		return lliLinkShiftDTOListByRootRequestID.get(0);
	}
	/**
	 * @author dhrubo
	 */
	public LliBandWidthChangeRequestDTO getLliBandwidthChangeRequestDTOByRootRequestID(Long rootReqID, DatabaseConnection databaseConnection) throws Exception {
		List<LliBandWidthChangeRequestDTO> lliLinkBandwidthChangeRequestDTOListByRootRequestID = SqlGenerator.getAllObjectList(LliBandWidthChangeRequestDTO.class, databaseConnection, 
				" where " + SqlGenerator.getForeignKeyColumnName(LliBandWidthChangeRequestDTO.class)+ " = " + rootReqID);
		return lliLinkBandwidthChangeRequestDTOListByRootRequestID.get(0);

	}
	public void rollBackRequest(CommonRequestDTO sourceRequestDTO, HttpServletRequest request, LoginDTO loginDTO, DatabaseConnection databaseConnection) throws Exception {
		if((sourceRequestDTO.getRequestTypeID() % 100) == 42 || (sourceRequestDTO.getRequestTypeID() % 100) == 10)//rollback internal fr
		{
			String sql = "update " + LliFRResponseInternalDTO.getTablename() + " set " + getColumnName(LliFRResponseInternalDTO.class, "isDeleted") + "=1 where " + "reqID" + "=" + sourceRequestDTO.getReqID();		
			logger.debug("sql " + sql);
			Statement stmt = databaseConnection.getNewStatement();
			stmt.executeUpdate(sql);
		}
		else if((sourceRequestDTO.getRequestTypeID() % 100) == 57 || (sourceRequestDTO.getRequestTypeID() % 100) == 58)//rollback external fr
		{
			String sql = "update " + LliFRResponseExternalDTO.getTablename() + " set " + getColumnName(LliFRResponseExternalDTO.class, "isDeleted") + "=1 where " + "reqID" + "=" + sourceRequestDTO.getReqID();			
			logger.debug("sql " + sql);
			Statement stmt = databaseConnection.getNewStatement();
			stmt.executeUpdate(sql);
		}
	}
	public boolean isOfficeNameAvailable(String officeName, DatabaseConnection databaseConnection) throws Exception {
		List<Long> matchingIdList = new ArrayList<Long>();
		matchingIdList = SqlGenerator.getAllIDList(LliLinkDTO.class, databaseConnection, " where name = ?", officeName);
		if(matchingIdList.size()>0) {
			return false;
		}
		return true;
	}

	public LliEndPointDTO getLliEndPointDTOByLliEndPointID(long endPointID, DatabaseConnection databaseConnection) throws Exception {
		LliEndPointDTO	lliEndPointDTO= ((LliEndPointDTO) getObjectByID(LliEndPointDTO.class, endPointID, databaseConnection));
		return lliEndPointDTO;
	}
	
	public List<LliLinkDTO> getLliLinkDTOListByClientIDAndPartialName(long clientID, String partialName, DatabaseConnection databaseConnection) throws Exception {
		List<Integer> forbiddenStatusList = StateRepository.getInstance().getStatusListByActivationStatus(EntityTypeConstant.STATUS_ACTIVE);
		String commaSeparatedString =  StringUtils.getCommaSeparatedString(forbiddenStatusList);
		return (List<LliLinkDTO>) SqlGenerator.getAllObjectList(LliLinkDTO.class, databaseConnection, " where clientID = " + clientID + " and name like '%" + partialName + "%' and currentStatus < 0 and currentStatus in "+commaSeparatedString+" and latestStatus < 0 and isDeleted = 0" );
//		return (List<LliLinkDTO>) SqlGenerator.getAllObjectList( LliLinkDTO.class, databaseConnection, " where clientID = " + clientID + " and name like '%" + partialName + "%' and currentStatus like '%20' and latestStatus like '%20'" );
	}
	
	public List<LliLinkDTO> getDisabledLliLinkDTOListByClientIDAndPartialName(long clientID, String partialName, DatabaseConnection databaseConnection) throws Exception {
		List<Integer> forbiddenStatusList = StateRepository.getInstance().getStatusListByActivationStatus(EntityTypeConstant.STATUS_ACTIVE);
		String commaSeparatedString =  StringUtils.getCommaSeparatedString(forbiddenStatusList);
//		return (List<LliLinkDTO>) SqlGenerator.getAllObjectList(LliLinkDTO.class, databaseConnection, " where clientID = " + clientID + " and name like '%" + partialName + "%' and currentStatus in "+commaSeparatedString+" and latestStatus = currentStatus" );
		return (List<LliLinkDTO>) SqlGenerator.getAllObjectList( LliLinkDTO.class, databaseConnection, " where clientID = " + clientID + " and name like '%" + partialName + "%' and currentStatus < 0 and (currentStatus like '%301' or currentStatus like '%403' or currentStatus like '%402') and latestStatus < 0" );
	}
	
	public boolean isRemoteEndOfficeNameAvailable(String officeName, String clientID, DatabaseConnection databaseConnection) throws Exception {
		String sql = "select name from at_lli_ep where isDeleted = 0 and name = ? and clientID = ?";
		PreparedStatement preparedStatement = databaseConnection.getNewPrepareStatement(sql);
		preparedStatement.setString(1, officeName);
		preparedStatement.setLong(2, Long.parseLong(clientID));
		ResultSet resultSet = preparedStatement.executeQuery();
		if(resultSet.next()) {
			return false;
		}
		return true;
	}


	public Boolean isLliLinkEstablished(Long lliLinkID, DatabaseConnection databaseConnection) throws SQLException {
		String sql = "select exists ("
				+"select * from at_lli_link where ID = " + lliLinkID + " and currentStatus like '%20' and currentStatus < 0"
				+")";
		ResultSet rs = null;
		try {
			rs = databaseConnection.getNewStatement().executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			rs.next();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs.getInt(1)==1;
	}
	
	/**
	 * @author dhrubo
	 */
	public LliBandWidthChangeRequestDTO getLliBandwidthChangeRequestDTOByLliLinkID(Long lliLinkID, DatabaseConnection databaseConnection) throws Exception {
		CommonRequestDTO bandwidthChangeRequestDTO = getMostRecentRequestByEntityIDandEntityTypeIDandRequestTypeID(lliLinkID, EntityTypeConstant.LLI_LINK, LliRequestTypeConstants.REQUEST_UPGRADE.SYSTEM_REQUEST_WITH_INTERNAL_FR, databaseConnection);
		return getLliBandwidthChangeRequestDTOByRootRequestID(bandwidthChangeRequestDTO.getRootReqID(), databaseConnection);
	}
	public void processLinkTermination(CommonRequestDTO commonRequestDTO, LoginDTO loginDTO, DatabaseConnection databaseConnection ) throws Exception{		
		LliLinkDTO lliLinkDTO = getLliLink(commonRequestDTO.getEntityID(), databaseConnection);		
		BillDTO billDTO = new BillDAO().getBillByReqID( commonRequestDTO.getRootReqID(), databaseConnection );						
		
		if( billDTO == null || billDTO.getPaymentID() == null ){
			
		}
		else
		{
			throw new RequestFailureException("Link bill is already paid. So process can not be terminated.");
		}
		switch(commonRequestDTO.getRequestTypeID())
		{
			case LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_REJECT_APPLICATION:
			case LliRequestTypeConstants.REQUEST_NEW_LINK.CLIENT_CANCEL_APPLICATION:
			case LliRequestTypeConstants.REQUEST_LINK_CLOSE.SYSTEM_COMPLETE_CLOSE_LINK:
			{
				terminateLliLinkCreation(commonRequestDTO, databaseConnection);
				break;
			}			
			case LliRequestTypeConstants.REQUEST_UPGRADE.SYSTEM_REJECT_APPLICATION:
			case LliRequestTypeConstants.REQUEST_UPGRADE.CLIENT_CANCEL_APPLICATION:
			case LliRequestTypeConstants.REQUEST_DOWNGRADE.SYSTEM_REJECT_APPLICATION:
			case LliRequestTypeConstants.REQUEST_DOWNGRADE.CLIENT_CANCEL_APPLICATION:
			case LliRequestTypeConstants.REQUEST_POP_CHANGE.SYSTEM_REJECT_APPLICATION:
			case LliRequestTypeConstants.REQUEST_POP_CHANGE.CLIENT_CANCEL_APPLICATION:				
			{
				terminateLliLinkForBandwidthChange(commonRequestDTO, databaseConnection);
				break;
			}			
		}
	}
	public void terminateLliLinkCreation(CommonRequestDTO commonRequestDTO, DatabaseConnection databaseConnection ) throws Exception{
		
		LliLinkDTO lliLinkDTO = getLliLink(commonRequestDTO.getEntityID(), databaseConnection);
		int stateID = RequestActionStateRepository.getInstance().getActionStateDTOActionTypeID(commonRequestDTO.getRequestTypeID()).getNextStateID();
		lliLinkDTO.setCurrentStatus(stateID);
		lliLinkDTO.setLatestStatus(stateID);
		lliLinkDTO.setDeleted(true);
		SqlGenerator.updateEntity(lliLinkDTO, LliLinkDTO.class, databaseConnection, true, false);
		
		/*String conditionString = " where " + SqlGenerator.getColumnName(CommonRequestDTO.class, "requestTypeID") + " like '%42' and " + SqlGenerator.getColumnName(CommonRequestDTO.class, "rootReqID") + " = " + commonRequestDTO.getRootReqID() + " order by " + SqlGenerator.getPrimaryKeyColumnName(CommonRequestDTO.class) + " desc limit 1";
		List<CommonRequestDTO> internalFRRequestDTOList = SqlGenerator.getAllUndeletedObjectList(CommonRequestDTO.class, databaseConnection, conditionString);
		CommonRequestDTO requestDTO = internalFRRequestDTOList.get(0);
		
		LliFRResponseInternalDTO lliFRResponseInternalDTO = requestUtilDAO.getExtendedRequestByRootReqID(LliFRResponseInternalDTO.class, requestDTO.getReqID(), databaseConnection);
		String mandatoryIPBlockIDs =  lliFRResponseInternalDTO.getMandatoryIPs();
		String additionalIPBlockIDs =  lliFRResponseInternalDTO.getAdditionalIPs();*/
		IpAddressService ipAddressService = ServiceDAOFactory.getService(IpAddressService.class);
		List<IpBlock> ipList = ipAddressService.getIPAddressByEntityID(lliLinkDTO.getID());
		List<Long> idList = new ArrayList<Long>();
		for(IpBlock ipBlock: ipList)
		{
			idList.add(ipBlock.getIpBlockID());
		}
		ipAddressService.deallocateIpBlocksByIDs(idList); 
		
		terminateFarEndForCreation( lliLinkDTO, databaseConnection );
		processDeletionOfInternalFrOfLink( lliLinkDTO.getID(), databaseConnection );		
	
	}
	

	/**
	 * 
	 * @author Alam
	 * @param lliLinkDTO
	 * @param databaseConnection
	 * @throws Exception
	 */
	public void terminateFarEndForCreation( LliLinkDTO lliLinkDTO, DatabaseConnection databaseConnection ) throws Exception{										
		LliFarEndDTO farEndDTO = getLliFarEndByID(lliLinkDTO.getFarEndID(), databaseConnection );
		
		InventoryDAO inventoryDAO = new InventoryDAO();
		inventoryDAO.makeResourceFreeByOccupierID(lliLinkDTO.getFarEndID(), EntityTypeConstant.LLI_LINK_FAR_END, databaseConnection);
		
		farEndDTO.setLatestStatus(lliLinkDTO.getLatestStatus());
		farEndDTO.setCurrentStatus(lliLinkDTO.getCurrentStatus());
		farEndDTO.setDeleted(true);
		
		SqlGenerator.updateEntity( farEndDTO, LliFarEndDTO.class, databaseConnection, true, false );
		
		deleteExternalFRByNearOrFarEndID( lliLinkDTO.getFarEndID(), EntityTypeConstant.LLI_LINK_FAR_END, databaseConnection );
	}

	
	public void terminateFarEndForBandwidthChange( LliLinkDTO lliLinkDTO, LliFRResponseInternalDTO lliFRResponseInternalDTO, DatabaseConnection databaseConnection ) throws Exception
	{			 			
		InventoryDAO inventoryDAO = new InventoryDAO();
		inventoryDAO.makeResourceFreeByInventoryItemID(lliFRResponseInternalDTO.getFePortID(), databaseConnection);
		inventoryDAO.makeResourceFreeByInventoryItemIDs(lliFRResponseInternalDTO.getFeMandatoryVlanID(), databaseConnection);
		inventoryDAO.makeResourceFreeByInventoryItemIDs(lliFRResponseInternalDTO.getFeAdditionalVlanIDs(), databaseConnection);

		int requestTypePrefix = lliFRResponseInternalDTO.getRequestTypeID() / EntityTypeConstant.MULTIPLIER2;
		int requestTypeSuffix = requestTypePrefix % 100;
		
		int requestTypePrefixShifting = LliRequestTypeConstants.REQUEST_POP_CHANGE.CLIENT_APPLY / EntityTypeConstant.MULTIPLIER2;
		int requestTypeSuffixShifting = requestTypePrefixShifting % 100;
		
		if(requestTypeSuffix == requestTypeSuffixShifting)
		{
			deleteExternalFRByNearOrFarEndID( lliLinkDTO.getFarEndID(), EntityTypeConstant.LLI_LINK_FAR_END, databaseConnection );
		}
		
		LliFarEndDTO farEndDTO = getLliFarEndByID(lliLinkDTO.getFarEndID(), databaseConnection);
		farEndDTO.setLatestStatus(farEndDTO.getCurrentStatus());			
		SqlGenerator.updateEntity( farEndDTO, LliFarEndDTO.class, databaseConnection, true, false );		
	}	

	
		
	

	
	private void processDeletionOfInternalFrOfLink( long linkID, DatabaseConnection databaseConnection ) throws Exception{
		
		String conditionString = " where " + SqlGenerator.getColumnName( LliFRResponseInternalDTO.class, "linkID") + " = " + linkID;
		
		List<Long> frResponseIntIDs = SqlGenerator.getAllIDList( LliFRResponseInternalDTO.class, databaseConnection, conditionString );
		
		logger.debug( "Lli internal fr response ids with link id = " + linkID );
		
		for( Long id: frResponseIntIDs ){
			
			logger.debug( "Deleting Internal FR with Fr ID " + id );
			SqlGenerator.deleteEntityByID( LliFRResponseInternalDTO.class, id, System.currentTimeMillis(), databaseConnection );
		}
	}
	
	/**
	 * @author Alam
	 * @param bottom 
	 * @param lliLinkDTO.getID()
	 * @param databaseConnection
	 * @throws Exception 
	 */
	
	public void terminateLliLinkForBandwidthChange(CommonRequestDTO commonRequestDTO, DatabaseConnection databaseConnection ) throws Exception{
		LliLinkDTO lliLinkDTO = getLliLink(commonRequestDTO.getEntityID(), databaseConnection);
		
		LliBandWidthChangeRequestDTO lliBandWidthChangeRequestDTO = getLliBandwidthChangeRequestDTOByRootRequestID(commonRequestDTO.getRootReqID(), databaseConnection);
		LliFRResponseInternalDTO lliFRResponseInternalDTO = requestUtilDAO.getExtendedRequestByRootReqID(LliFRResponseInternalDTO.class, commonRequestDTO.getRootReqID(), databaseConnection);
		
		terminateFarEndForBandwidthChange( lliLinkDTO, lliFRResponseInternalDTO, databaseConnection );
		
		lliFRResponseInternalDTO.setDeleted(true);
		updateEntity(lliFRResponseInternalDTO, LliFRResponseInternalDTO.class, databaseConnection, false, false);	
		
		lliLinkDTO.setLatestStatus(lliLinkDTO.getCurrentStatus());
		SqlGenerator.updateEntity(lliLinkDTO, LliLinkDTO.class, databaseConnection, true, false);		
	}

	
	
		public void deleteExternalFRByNearOrFarEndID( long nearOrFarEndId, int entityType, DatabaseConnection databaseConnection ) throws Exception{
		
		String sql = "update "
				+ SqlGenerator.getTableName( LliFRResponseExternalDTO.class ) 
				+ " set " + SqlGenerator.getColumnName( LliFRResponseExternalDTO.class, "isDeleted" ) + " = 1, "
				+ SqlGenerator.getColumnName( LliFRResponseExternalDTO.class, "lastModificationTime") + " = " + System.currentTimeMillis()
				+ " where " + SqlGenerator.getColumnName( LliFRResponseExternalDTO.class, "nearOrFarEndPointID") + " = " + nearOrFarEndId
				+ " and " + SqlGenerator.getColumnName( LliFRResponseExternalDTO.class, "entityTypeID") + " = " + entityType
				+ " and " + SqlGenerator.getColumnName( LliFRResponseExternalDTO.class, "isDeleted") + " = 0";
		
		SqlGenerator.runUpdateQuery( sql, databaseConnection );
	}
		
		public void generateDemandNoteIPAddress(ActionMapping mapping, CommonRequestDTO commonRequestDTO, CommonRequestDTO sourceRequestDTO, HttpServletRequest request, HttpServletResponse response, LoginDTO loginDTO, DatabaseConnection databaseConnection) throws Exception
		{
			String conditionString = " where " + SqlGenerator.getColumnName(CommonRequestDTO.class, "requestTypeID") + " like '%442' and " + SqlGenerator.getColumnName(CommonRequestDTO.class, "rootReqID") + " = " + commonRequestDTO.getRootReqID() + " order by " + SqlGenerator.getPrimaryKeyColumnName(CommonRequestDTO.class) + " desc limit 1";
			List<CommonRequestDTO> internalFRRequestDTOList = SqlGenerator.getAllUndeletedObjectList(CommonRequestDTO.class, databaseConnection, conditionString);
			CommonRequestDTO requestDTO = internalFRRequestDTOList.get(0);
			LliFRResponseInternalDTO lliFRResponseInternalDTO = requestUtilDAO.getExtendedRequestByRootReqID(LliFRResponseInternalDTO.class, requestDTO.getReqID(), databaseConnection);
			double ipAddressCost = BillUtil.getCostForIpAddress(lliFRResponseInternalDTO.getAdditionalIpAvailableCount());
			LliLinkDTO lliLinkDTO = new LliDAO().getLliLink(commonRequestDTO.getEntityID(), databaseConnection);
			
			LliBillDTO billDTO = new LliBillDTO();
			
			billDTO.setIpAddressCost( ipAddressCost );
			
			double grandTotal = billDTO.getGrandTotal();
			double discount = 0;
			double totalPayable = grandTotal - discount;
			double vat = ( totalPayable ) * 0.15;
			
			billDTO.setVAT( BillDTO.setDecimalPlaces( vat, 2 ) );
			billDTO.setGrandTotal( grandTotal );
			billDTO.setTotalPayable( totalPayable );
			billDTO.setNetPayable( totalPayable + vat );
			
			billDTO.setGenerationTime( System.currentTimeMillis() );
			billDTO.setBillType( BillConstants.DEMAND_NOTE );
			billDTO.setDeleted(false);
			billDTO.setEntityID(lliLinkDTO.getID());
			billDTO.setEntityTypeID(EntityTypeConstant.LLI_LINK);
			billDTO.setReqID( commonRequestDTO.getReqID() );
			billDTO.setGenerationTime(lliLinkDTO.getCurrentTime());
			billDTO.setLastModificationTime(lliLinkDTO.getCurrentTime());
			billDTO.setLastPaymentDate(commonRequestDTO.getExpireTime());
			billDTO.setClientID(lliLinkDTO.getClientID());
			billDTO.setClassName( LliBillDTO.class.getName() );
			billDTO.setBillReqType( LliRequestTypeConstants.REQUEST_IPADDRESS.SYSTEM_GENERATE_DEMAND_NOTE );
			
			billDTO.setActivationTimeFrom( System.currentTimeMillis() );
			
			Calendar calendar = Calendar.getInstance();
			calendar.setTimeInMillis( System.currentTimeMillis() );
			
			
			billDTO.setActivationTimeFrom( System.currentTimeMillis() );
			billDTO.setMonth( calendar.get( Calendar.MONTH ) );
			billDTO.setYear( calendar.get( Calendar.YEAR ) );
			
//			billDTO.setActivationTimeTo( DateUtils.getEndTimeOfMonth( calendar.get( Calendar.MONTH ), calendar.get( Calendar.YEAR ) ) );
				
//			billDTO.setLastPaymentDate( DateUtils.getEndTimeOfMonth( calendar.get( Calendar.MONTH ), calendar.get( Calendar.YEAR ) ) );
			
			new BillDAO().insertLliBill( billDTO, databaseConnection );
		}

		public LliLinkDTO getLliLinkDTOByFarEndID(Long farEndID, DatabaseConnection databaseConnection) throws Exception {
			List<LliLinkDTO> lliLinkDTOListByFarEndID = SqlGenerator.getAllObjectList(LliLinkDTO.class, databaseConnection, " where " + getColumnName(LliLinkDTO.class, "farEndID")+ " = " + farEndID + " and " + getColumnName(LliLinkDTO.class, "isDeleted") + " = 0");
			LliLinkDTO lliLinkDTO = lliLinkDTOListByFarEndID.size()>0 ? lliLinkDTOListByFarEndID.get(0) : null;
			return lliLinkDTO;
		}

		public boolean checkIfDemandNoteSkippable(CommonRequestDTO commonRequestDTO,	DatabaseConnection databaseConnection) throws Exception {
			// TODO Auto-generated method stub
			ClientDetailsDTO clientDetailsDTO = AllClientRepository.getInstance().getVpnClientByClientID(commonRequestDTO.getClientID(), commonRequestDTO.getModuleID());
			if(clientDetailsDTO.getRegistrantType() == RegistrantTypeConstants.GOVT || clientDetailsDTO.getRegistrantType() == RegistrantTypeConstants.MILITARY)
			{
				return true;
			}
			LliLinkDTO lliLinkDTO = getLliLink(commonRequestDTO.getEntityID(), databaseConnection);
			if(lliLinkDTO.getServicePurpose() == 1)
			{
				return true;
			}
			return false;
		}
		
		public double getOFCCost(LliLinkDTO lliLinkDTO, LliEndPointDTO lliEndPointDTO, LLIOTCConfigurationDTO commonCharge) throws Exception
		{
			double layer3Multipler = 1.0;
			
			int loopDistance = lliEndPointDTO.getLoopDistanceTotal(); 
			int numOfCore = lliEndPointDTO.getCoreType();
			double ofcCost = 0;
			
			if (lliEndPointDTO.getOfcProviderTypeID() == EndPointConstants.OFC_BTCL)
			{			
				if( loopDistance > 500 )
					ofcCost = ( 1000 + ( loopDistance - 500 ) * commonCharge.getOFChargePerMeter( lliEndPointDTO.getDistrictID() ) ) * numOfCore * layer3Multipler;
				else
					ofcCost = 1000 * numOfCore;
				if( ofcCost < 1000 ) 
					ofcCost = 1000;
			}
			else
			{
				ofcCost = 0;
			}
			return ofcCost;
		}
}

