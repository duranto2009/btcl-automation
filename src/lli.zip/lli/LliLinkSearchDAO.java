package lli;

import static util.SqlGenerator.getAllIDList;
import static util.SqlGenerator.getAllObjectList;
import static util.SqlGenerator.getAllObjectListFullyPopulated;
import static util.SqlGenerator.getAllUndeletedObjectList;
import static util.SqlGenerator.getColumnName;
import static util.SqlGenerator.getObjectFullyPopulatedByID;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Hashtable;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import annotation.DAO;
import client.ClientTypeService;
import common.CommonDAO;
import common.EntityTypeConstant;
import common.ModuleConstants;
import common.RequestFailureException;
import common.StringUtils;
import common.bill.BillConstants;
import common.bill.BillDAO;
import common.bill.BillDTO;
import connection.DatabaseConnection;
import costConfig.CostConfigDAO;
import inventory.InventoryDAO;
import inventory.InventoryItemDetails;
import inventory.InventoryService;
import lli.bill.LliBillDTO;
import lli.configuration.LLICostConfigurationDAO;
import lli.configuration.LLIOTCConfigurationDTO;
import lli.constants.EndPointConstants;
import lli.constants.LliRequestTypeConstants;
import lli.link.LliEndPointDTO;
import lli.link.LliFarEndDTO;
import lli.link.LliLinkDTO;
import login.LoginDTO;
import request.CommonRequestDTO;
import request.RequestActionStateRepository;
import request.RequestUtilDAO;
import request.StateRepository;
import util.DateUtils;
import util.ModifiedSqlGenerator;
import util.SqlGenerator;
import vpn.bill.PdfUtil;
import vpn.link.VpnLinkDTO;

public class LliLinkSearchDAO {
	Logger logger = Logger.getLogger(getClass());

	@DAO
	LliDAO lliDAO;
	BillDAO billDAO = new BillDAO();
	InventoryDAO inventoryDAO = new InventoryDAO();
	CommonDAO commonDAO = new CommonDAO();
	RequestUtilDAO requestUtilDAO = new RequestUtilDAO();
	long currentTime;
	
	public Collection<Long> getLliLinkIDs(DatabaseConnection databaseConnection) throws Exception  {
	
		Collection<Long> LliLinkIDs = new ArrayList<Long>();

	
			ArrayList<LliLinkDTO> allLliLinkDTO = (ArrayList<LliLinkDTO>) getAllObjectList(LliLinkDTO.class,databaseConnection, "");
			for (LliLinkDTO dto : allLliLinkDTO) {
				LliLinkIDs.add(dto.getID());
			}
		
		return LliLinkIDs;
	}
	
	
	public List<LliLinkDTO> getActiveLliLinks(DatabaseConnection databaseConnection) throws Exception{
		Class<LliLinkDTO> classObject = LliLinkDTO.class;
		List<Integer> activeStatusList = StateRepository.getInstance()
				.getStatusListByModuleIDAndActivationStatus(ModuleConstants.Module_ID_LLI, EntityTypeConstant.STATUS_ACTIVE);
		String conditionString = " where "+getColumnName(classObject, "currentStatus")+" IN "+StringUtils
				.getCommaSeparatedString(activeStatusList)+ " and " + getColumnName(classObject, "isDeleted") + " = 0";
		return (List<LliLinkDTO>)getAllUndeletedObjectList(classObject, databaseConnection,conditionString);
	}

	public Collection<Long> getLliLinkIDs(DatabaseConnection databaseConnection, String conditionStr) throws Exception  {
		
		Collection<Long> LliLinkIDs = new ArrayList<Long>();
	
			ArrayList<LliLinkDTO> allLliLinkDTO = (ArrayList<LliLinkDTO>) getAllObjectList(LliLinkDTO.class,databaseConnection,conditionStr );
			for (LliLinkDTO dto : allLliLinkDTO) {
				LliLinkIDs.add(dto.getID());
			}
		
		return LliLinkIDs;
	}
	/*oboslete
	public Collection<LliLinkDTO> getLliLinkDTOs(Collection<Long> recordIDs, DatabaseConnection databaseConnection)
			throws Exception {
		return getObjectListByIDList(LliLinkDTO.class, recordIDs, databaseConnection);
	}
	*/
	public Collection<LliLinkDTO> getLliLinkDTOs (Collection <Long> recordIDs) throws Exception {
		return ModifiedSqlGenerator.getObjectListByIDList(LliLinkDTO.class, recordIDs);
	}
	public Collection <Long> getLliLinkIDsFromSearchCriteria(Hashtable <String, String> searchCriteria, LoginDTO loginDTO) throws Exception {
		String isDeletedValue = searchCriteria.get("showDeleted");
		if("1".equals(isDeletedValue)) {
			searchCriteria.remove("showDeleted");
		}else if("0".equals(isDeletedValue) || isDeletedValue == null) { // null case will arise from hyperlink.
			searchCriteria.put("showDeleted", "0");
		}
//		String farEndVal =  searchCriteria.get("farEnd");
//				
//		if(!StringUtils.isBlank(farEndVal)) {
//			searchCriteria.put("farEnd", "-->%" + farEndVal);
//		}
//		
		if(!loginDTO.getIsAdmin()){
			searchCriteria.put("clientID", ""+loginDTO.getAccountID());
		}
		String toDateInputName = "activationDateTo";
		if(!StringUtils.isBlank(searchCriteria.get(toDateInputName))){
			searchCriteria.put(toDateInputName, ""+DateUtils.getEndTimeOfDayByDateString(searchCriteria.get(toDateInputName)));
		}
		String bwFrom = searchCriteria.get("bwFrom");
		String bwTo = searchCriteria.get("bwTo");
		String fixedCondition = "";
		
		if(!StringUtils.isBlank(bwFrom)) {
			fixedCondition += "((lliBW >= " + bwFrom + " and lliBWT=1) or (lliBW>=" 
					+ bwFrom +"/1024.0 and lliBWT=2))"; 
		}
		if(!StringUtils.isBlank(bwTo)) {
			fixedCondition += " and ((lliBW <= " + bwTo + " and lliBWT=1) or (lliBW<=" 
					+ bwTo +"/1024.0 and lliBWT=2))";
		}
		String [] keys = 			{"name"		/*, "farEnd"	*/,  "activationDateFrom", "activationDateTo", "status", 		"showDeleted", "clientID"};
		String [] operators = 		{"LIKE"		/*, "LIKE"	*/,  ">="				  , "<="              , "IN",			"="          , "="};
		String [] dtoColumnNames = 	{"linkName" /*, "linkName"*/,  "activationDate"	  , "activationDate"  , "currentStatus","isDeleted"  , "clientID"};
		return ModifiedSqlGenerator.getIDListFromSearchCriteria(LliLinkDTO.class, keys, operators, dtoColumnNames, searchCriteria, fixedCondition);
	} 
	public ArrayList<Long> getLliFarEndIDsFromAddress(DatabaseConnection databaseConnection, String address) {
		ArrayList<Long> LliFarEndIDs = new ArrayList<Long>();
		ArrayList<Long> LliFarEndPointIDs = new ArrayList<Long>();
		ArrayList<LliFarEndDTO> allLliFarEndDTOs = new ArrayList<LliFarEndDTO>();
		
		try {
			String lliEndPointIDColumnName = getColumnName(LliEndPointDTO.class, "address");
			String conditionString = " where " + lliEndPointIDColumnName + " like '%" + address + "%' ";
			ArrayList<LliEndPointDTO> allLliEndPointDTOs = (ArrayList<LliEndPointDTO>) getAllObjectList(LliEndPointDTO.class,
					databaseConnection, conditionString);
			for (LliEndPointDTO dto : allLliEndPointDTOs) {
				LliFarEndPointIDs.add(dto.getLliEndPointID());
			}
			allLliFarEndDTOs = (ArrayList<LliFarEndDTO>) getAllObjectList(LliFarEndDTO.class, databaseConnection, "");
			for(LliFarEndDTO farEndDTO: allLliFarEndDTOs){
				if(LliFarEndPointIDs.contains(farEndDTO.getLliEndPointID())){
					LliFarEndIDs.add(farEndDTO.getID());
				}
			}
			
		} catch (Exception e) {
			logger.debug(e);
		}

		return LliFarEndIDs;
	}

	public LliFarEndDTO getLliFarEndByID(long farEndID, DatabaseConnection databaseConnection) throws Exception {
		
		return (LliFarEndDTO)getObjectFullyPopulatedByID(LliFarEndDTO.class, databaseConnection,farEndID);
	}
	
	
	public List<LliFarEndDTO> getLliFarEndByName(Object []values, String[] columnNames, DatabaseConnection databaseConnection) throws Exception {
		ArrayList<LliFarEndDTO> lliFarEndDTOs = new ArrayList<LliFarEndDTO>();
		try {
			String conditionStr=" where ";
			
			for(int i=0; i < columnNames.length; i++){
				if(i==0){
					conditionStr+=getColumnName(LliEndPointDTO.class, columnNames[i]) +" like '%"+ values[i] +"%'";
				}else{
					conditionStr+=" AND "+getColumnName(LliEndPointDTO.class, columnNames[i]) +" = "+ values[i];
				}
			}
			conditionStr+=" AND  "+ getColumnName(LliEndPointDTO.class, "parentEndPointID") +" = 0";
			
			List<Long> endPointIDList =getAllIDList(LliEndPointDTO.class, databaseConnection, conditionStr) ;
			if(endPointIDList.isEmpty()){
				return lliFarEndDTOs;
			}
			
			String columnName = getColumnName(LliFarEndDTO.class, "lliEndPointID");
			String conditionString = " where " + columnName + " in "+StringUtils.getCommaSeparatedString(endPointIDList)+" ";
			lliFarEndDTOs= (ArrayList<LliFarEndDTO>)getAllObjectListFullyPopulated(LliFarEndDTO.class, databaseConnection, conditionString);
			
		} catch (Exception e) {
			logger.fatal("fatal: ",e);
		}
		

		return lliFarEndDTOs;
	}
	
	public long issueDemanNoteForNewLink( CommonRequestDTO commonRequestDTO, DatabaseConnection databaseConnection ) throws Exception
	{
		
		return issueDemanNoteForNewLink(commonRequestDTO, databaseConnection, null );
	}
	
	public long issueDemanNoteForLinkUpgrade(CommonRequestDTO commonRequestDTO, DatabaseConnection databaseConnection, HttpServletRequest request) throws Exception
	{
		
		LliBillDTO lliBillDTO = createDemandNoteForLinkUpgrade( request, commonRequestDTO );
		
		BillDAO billDAO = new BillDAO();
		
		try{
			
			billDAO.insertLliBill( lliBillDTO, databaseConnection );
			
			/*There is some issue on generating pdf file, some content not showing. So currently file generation is stopped and bill is loading dynamically on demand*/
			
			//PdfUtil.writePdfFileAndLogInDatabase( lliLinkDTO, lliBillDTO, Long.toString( lliBillDTO.getID() ), System.currentTimeMillis(), databaseConnection );
		}
		catch( Exception e ){
			
			throw new RequestFailureException( e.getMessage() );
		}
		
		return lliBillDTO.getID();
	}
	
	public long issueDemanNoteForLinkDowngrade(CommonRequestDTO commonRequestDTO, DatabaseConnection databaseConnection, HttpServletRequest request) {
		LliBillDTO lliBillDTO = createDemandNoteForLinkDowngrade( request, commonRequestDTO );
		
		BillDAO billDAO = new BillDAO();
		
		try{
			
			billDAO.insertLliBill( lliBillDTO, databaseConnection );
			
			/*There is some issue on generating pdf file, some content not showing. So currently file generation is stopped and bill is loading dynamically on demand*/
			
			//PdfUtil.writePdfFileAndLogInDatabase( lliLinkDTO, lliBillDTO, Long.toString( lliBillDTO.getID() ), System.currentTimeMillis(), databaseConnection );
		}
		catch( Exception e ){
			
			throw new RequestFailureException( e.getMessage() );
		}
		
		return lliBillDTO.getID();
		
	}

	private LliBillDTO createDemandNoteForLinkDowngrade(HttpServletRequest request, CommonRequestDTO commonRequestDTO) {
		LliBillDTO lliBillDTO = new LliBillDTO();
		
		double farEndOFCCharge = 0;
		
		double upgradationCharge = 5000.0;
		double securityCharge = 0.0;
		double existingSecurityMoney = 0.0;
		
		double bandwidthCharge = 0.0;
		
		long expirationDate = 0L;
		if(commonRequestDTO.getExpireTime() == 0)
		{
			int nextState = RequestActionStateRepository.getInstance().getActionStateDTOActionTypeID(commonRequestDTO.getRequestTypeID()).getNextStateID();
			expirationDate = System.currentTimeMillis() +  StateRepository.getInstance().getStateDTOByStateID(nextState).getDurationInMillis();			
		}
		
		Calendar c = Calendar.getInstance();
		
		lliBillDTO.setUpgradationCharge( upgradationCharge );
		lliBillDTO.setSecurityCharge( securityCharge );
		lliBillDTO.setExistingSecurityMoney( existingSecurityMoney );
		
		//lliBillDTO.setRemoteEndOFC( farEndOFCCharge );
		lliBillDTO.setBwCharge( bandwidthCharge );
		
		double securityMoneyGiven = lliBillDTO.getSecurityCharge() - lliBillDTO.getExistingSecurityMoney();
		
		double grandTotal = lliBillDTO.getGrandTotal();
		double discount = Double.parseDouble( "0.0" );
		
		if( request.getParameter( "discount" ) != null )
			discount = 0;
		
		double totalPayable = grandTotal - discount;
		double vat = 0; //( totalPayable - securityMoneyGiven ) * 0.15;
		
		lliBillDTO.setGrandTotal( grandTotal );
		lliBillDTO.setTotalPayable( totalPayable );
		lliBillDTO.setVAT( vat );
		lliBillDTO.setNetPayable( totalPayable + vat );
		lliBillDTO.setVAT( BillDTO.setDecimalPlaces( vat, 2 ) );
		
		lliBillDTO.setBillType( BillConstants.PREPAID_AND_POSTPAID );
		lliBillDTO.setDeleted( false );
		lliBillDTO.setEntityID( commonRequestDTO.getEntityID() );
		lliBillDTO.setEntityTypeID( EntityTypeConstant.LLI_LINK );
		lliBillDTO.setReqID( commonRequestDTO.getReqID() );
		lliBillDTO.setGenerationTime( System.currentTimeMillis() );
		lliBillDTO.setLastModificationTime( System.currentTimeMillis() );
		lliBillDTO.setLastPaymentDate( expirationDate );
		lliBillDTO.setClientID( commonRequestDTO.getClientID() );
		lliBillDTO.setClassName( LliBillDTO.class.getName() );
		lliBillDTO.setBillReqType( commonRequestDTO.getRequestTypeID() );
		lliBillDTO.setYear( c.get( Calendar.YEAR ) );
		lliBillDTO.setMonth( c.get( Calendar.MONTH ) );
		
		lliBillDTO.setActivationTimeFrom( DateUtils.getStartTimeOfMonth( c.get(Calendar.MONTH), c.get( Calendar.YEAR) ) );
		
		lliBillDTO.setActivationTimeTo( DateUtils.getEndTimeOfMonth( c.get(Calendar.MONTH), c.get( Calendar.YEAR) ) );
		
		return lliBillDTO;
	}


	public long issueDemanNoteForNewLink(CommonRequestDTO commonRequestDTO, DatabaseConnection databaseConnection, HttpServletRequest request) throws Exception
	{
		
		LliLinkDTO lliLinkDTO = new LliDAO().getLliLinkDTOByID(commonRequestDTO.getEntityID(), databaseConnection);
		long lliFarEndID = lliLinkDTO.getFarEndID();
		
		LliFarEndDTO lliFarEndDTO = getLliFarEndByID(lliFarEndID, databaseConnection);
		if(lliFarEndDTO == null){
			throw new RequestFailureException("No Lli Far End found with ID "+lliFarEndID);
		}
		
		long expirationDate = commonRequestDTO.getExpireTime();
		
		logger.debug("expirationDate " + expirationDate);
		
		lliLinkDTO.setCurrentTime(System.currentTimeMillis());
		
		Long	requestID = commonRequestDTO.getReqID();
		
		LliBillDTO billDTO = new LliBillDTO();
		
		if( commonRequestDTO.getRequestTypeID() != LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_GENERATE_MIGRATION_DEMAND_NOTE
			|| ( commonRequestDTO.getRequestTypeID() == LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_GENERATE_MIGRATION_DEMAND_NOTE
			&& request.getParameter( "otc_mrc" ).equals( "OTC" ) ) ){
				
			billDTO = createDemandNoteForNewLliLink(lliLinkDTO, lliFarEndDTO, expirationDate, requestID, request, databaseConnection);
			
			billDAO.insertLliBill( billDTO, databaseConnection );
			
			if( request.getParameter( "discountPercentage" ) != null ) {
				
				lliLinkDTO.setPercentageOfDiscountGiven( Double.parseDouble( request.getParameter( "discountPercentage" ) ) );
				SqlGenerator.updateEntity( lliLinkDTO, LliLinkDTO.class, databaseConnection, false, false );
			}
		}
			
		if( commonRequestDTO.getRequestTypeID() == LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_GENERATE_MIGRATION_DEMAND_NOTE
				&& request.getParameter( "otc_mrc" ).equals("MRC") ){
			
			LliBillDTO lliBillDTO = new LliBillDTO();
			int rootReqRequestTypeID = LliRequestTypeConstants.REQUEST_NEW_LINK.CLIENT_APPLY;
			Calendar c = Calendar.getInstance();
			
			long lastPaymentDate = DateUtils.getTimestampFromDateStr( request.getParameter( "lastPaymentDate" ) );
			
			populateMRCBill( lliBillDTO, c, lliLinkDTO, lastPaymentDate,requestID, request );
			
			lliBillDTO.setBillReqType( rootReqRequestTypeID );
			lliBillDTO.setBillType( BillConstants.MONTHLY_BILL_ADVANCED );
			
			lliBillDTO.setActivationTimeFrom( DateUtils.getTimestampFromDateStr( request.getParameter( "activationDateFrom" ) ) );
			lliBillDTO.setActivationTimeTo( DateUtils.getTimestampFromDateStr( request.getParameter( "activationDateTo" ) ) );
			
			billDAO.insertLliBill( lliBillDTO, databaseConnection );
		}
		
		if( commonRequestDTO.getRequestTypeID() != LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_GENERATE_MIGRATION_DEMAND_NOTE )
			PdfUtil.writePdfFileAndLogInDatabase( lliLinkDTO, billDTO, Long.toString( billDTO.getID() ), System.currentTimeMillis(), databaseConnection );
		
		int rootReqRequestTypeID = LliRequestTypeConstants.REQUEST_NEW_LINK.CLIENT_APPLY;
		
		if( requestID != null && requestID > 0 )
			rootReqRequestTypeID = ((CommonRequestDTO) SqlGenerator.getObjectByID(CommonRequestDTO.class, requestID, databaseConnection )).getRequestTypeID();
		
		try{
			
			int noOfMonth = Integer.parseInt( request.getParameter( "month" ) );
			
			Calendar c = Calendar.getInstance();
			
			//Add one month to get the next month.
			c.add( Calendar.MONTH, 1 );
			
			for( int i = 2; i <= noOfMonth; i++ ){
				
				LliBillDTO lliBillDTO = new LliBillDTO();
				populateMRCBill( lliBillDTO, c, lliLinkDTO, expirationDate,requestID, request );
				
				lliBillDTO.setBillReqType( rootReqRequestTypeID );
				lliBillDTO.setLinkName( lliLinkDTO.getLinkName() );
				
				billDAO.insertLliBill( lliBillDTO, databaseConnection );
				c.add( Calendar.MONTH, 1 );
			}
		}
		catch( Exception e ){
			
			logger.debug( "No month given, so just ignoring to generate MRC bill" );
		}
		
		return billDTO.getID();
	}	

	public LliBillDTO generateMRCBill( LliLinkDTO lliLinkDTO,LliFarEndDTO farEndDTO
			,long fromTime, long toTime, double discount,double ofcChargePerMeter
			,double bandwidthCharge){
		
		int farEndBTCLLoopDistance = farEndDTO.getLoopDistanceBTCL();
		
		double farEndOFCCharge = farEndBTCLLoopDistance * ofcChargePerMeter;
		
		if( farEndOFCCharge < 1000 ) 
			farEndOFCCharge = 1000;
		
		/*if( farEndDTO.getParentEndPointID() == 0 && farEndDTO.getOfcProviderTypeID() == EndPointConstants.OFC_BTCL )
			farEndOFCCharge = 0;*/
		
		if(farEndDTO.getOfcProviderTypeID() == EndPointConstants.OFC_CUSTOMER)
		{
			farEndOFCCharge = 0;
		}
		
		LliBillDTO billDTO = new LliBillDTO();
		
		billDTO.setRemoteEndOFC( farEndOFCCharge );
		billDTO.setBwCharge( bandwidthCharge );
		
		double grandTotal = billDTO.getGrandTotal();
		
		double totalPayable = grandTotal - discount;
		double vat = totalPayable * 0.15;
		
		billDTO.setVAT( BillDTO.setDecimalPlaces( vat, 2 ) );
		
		billDTO.setBillType( BillConstants.MONTHLY_BILL );
		billDTO.setDeleted(false);
		billDTO.setEntityID( lliLinkDTO.getID() );
		billDTO.setEntityTypeID( EntityTypeConstant.LLI_LINK );
		billDTO.setGenerationTime(System.currentTimeMillis());
		billDTO.setLastModificationTime(System.currentTimeMillis());
		
		billDTO.setLastPaymentDate( fromTime + BillConstants.NUMBER_OF_DAY_BEFORE_BILL_IS_EXPIRED_IN_MILLIS );
		billDTO.setClientID(lliLinkDTO.getClientID());
		billDTO.setClassName( LliBillDTO.class.getName() );
		
		billDTO.setAdjustmentAmount( Math.round( -lliLinkDTO.getBalance() ) );
		
		billDTO.setGrandTotal( grandTotal );
		billDTO.setTotalPayable( totalPayable );
		billDTO.setVAT( vat );
		billDTO.setNetPayable( totalPayable + vat );
		billDTO.setDiscount( discount );
		
		billDTO.setActivationTimeFrom( fromTime );
		
		billDTO.setActivationTimeTo( toTime );
		
		return billDTO;
	}
	
	/**
	 * Populate Monthly bill
	 * @author Alam
	 * @param billDTO
	 * @param c Calendar object containing month and year of the bill to be generated
	 * @param expirationDate 
	 * @param reqID 
	 * @param request
	 */
	private void populateMRCBill( LliBillDTO billDTO, Calendar c, LliLinkDTO lliLinkDTO, long expirationDate, long reqID, HttpServletRequest request ){
		
		double farEndOFCCharge = Double.parseDouble( request.getParameter("farEndOFCCharge") );
		
		billDTO.setRemoteEndOFC( farEndOFCCharge );
		billDTO.setBwCharge( Double.parseDouble( request.getParameter( "bwCharge" ) ) );
		
		double grandTotal = billDTO.getGrandTotal();
		
		double discount = 0.0;
		
		if( request.getAttribute( "discountIsAlreadyGiven") == null  
				&& !org.apache.commons.lang.StringUtils.isEmpty( request.getParameter( "discount" ) ) ){
			
			discount = Double.parseDouble( request.getParameter( "discount" ) );
		}
		
		double totalPayable = grandTotal - discount;
		double vat = totalPayable * 0.15;
		
		billDTO.setVAT( BillDTO.setDecimalPlaces( vat, 2 ) );
		
		billDTO.setBillType( BillConstants.POSTPAID );
		billDTO.setDeleted(false);
		billDTO.setEntityID( lliLinkDTO.getID() );
		billDTO.setEntityTypeID( EntityTypeConstant.LLI_LINK );
		billDTO.setReqID( reqID );
		billDTO.setGenerationTime(lliLinkDTO.getCurrentTime());
		billDTO.setLastModificationTime(lliLinkDTO.getCurrentTime());
		billDTO.setLastPaymentDate(expirationDate);
		billDTO.setClientID(lliLinkDTO.getClientID());
		billDTO.setClassName( LliBillDTO.class.getName() );
		billDTO.setGrandTotal( grandTotal );
		billDTO.setTotalPayable( totalPayable );
		billDTO.setVAT( vat );
		billDTO.setNetPayable( totalPayable + vat );
		
		billDTO.setActivationTimeFrom( null );
		billDTO.setGenerationTime(System.currentTimeMillis());
		billDTO.setActivationTimeTo( null );
	}
	
	/**
	 * This method make a bill combining OTC and MRC for one month
	 * @author Alam
	 * @param lliBillDTO
	 * @param request
	 */
	private void populateMixBill( LliBillDTO billDTO, HttpServletRequest request ){
		
		int noOfMediaConverter_remote = 0;
		double pricePerMediaConverter_remote = 0.0;
		int noOfSFPModule_remote = 0;
		double pricePerSFPModule_remote = 0.0;
		
		double establishmentCost_remote = 0.0;
		double ofcLayingCost_remote = 0.0;
		
		if( request.getParameter( "remoteEndOFCProvidedByBTCL" ) != null ){
			
			establishmentCost_remote = Double.parseDouble( request.getParameter( "establishmentCost_remote" ) );
			ofcLayingCost_remote = Double.parseDouble( request.getParameter( "ofcLayingCost_remote") );
		}
		
		if( request.getParameter( "remoteEndProvidedByBTCL" ) != null ){
			
			noOfMediaConverter_remote=  Integer.parseInt( request.getParameter( "mediaConverterPiece_remote" ) );
			pricePerMediaConverter_remote= Double.parseDouble( request.getParameter( "mediaConverterPrice_remote" ) );
			
			noOfSFPModule_remote =  Integer.parseInt( request.getParameter( "sfpModulePiece_remote" ) );
			pricePerSFPModule_remote = Double.parseDouble( request.getParameter( "sfpModulePrice_remote" ) );
		}
		
		double mediaConverterPrice = noOfMediaConverter_remote*pricePerMediaConverter_remote;
		double SFPModulePrice = noOfSFPModule_remote * pricePerSFPModule_remote;
		
		int noOFCore =  Integer.parseInt( request.getParameter( "noOfOFCore" ) );
		double pricePerOFCore = Double.parseDouble( request.getParameter( "OFCoreCharge" ) );
		
		double farEndOFCCharge = Double.parseDouble( request.getParameter("farEndOFCCharge") );
		
		
		
		double establishmentCost = establishmentCost_remote;
		double ofclayingCost = ofcLayingCost_remote;
		
		billDTO.setBwConnectionCharge( Double.parseDouble( request.getParameter( "bwConnectionCharge" ) ) );
		billDTO.setOfcInstallationCharge( Double.parseDouble( request.getParameter( "ofcInstallationCharge" ) ) );
		billDTO.setOfcLayingCost( ofclayingCost );
		billDTO.setEstablishmentCost( establishmentCost );
		billDTO.setMediaConverterPrice( mediaConverterPrice );
		billDTO.setSfpModuleCost( SFPModulePrice );
		billDTO.setOthers( Double.parseDouble( request.getParameter( "others" ) ) );
		billDTO.setSecurityCharge( Double.parseDouble( request.getParameter( "securityCharge" ) ) );
		billDTO.setIpAddressCost( Double.parseDouble( request.getParameter( "ipAddressCost" ) ) );
		
		billDTO.setOfcCharge( pricePerOFCore );
		
		if( request.getParameter( "useMinOFCCharge" ) != null && request.getParameter( "useMinOFCCharge" ).equals( "on" ) )
			billDTO.setMinimumOFCUsed( true );
		else
			billDTO.setMinimumOFCUsed( false );
		
		billDTO.setRemoteEndOFC( farEndOFCCharge );
		billDTO.setBwCharge( Double.parseDouble( request.getParameter( "bwCharge" ) ) );
		billDTO.setDiscount( Double.parseDouble( request.getParameter( "discount" ) ) );
		
		double grandTotal = billDTO.getGrandTotal();
		double discount = Double.parseDouble( request.getParameter( "discount" ) );
		double totalPayable = grandTotal - discount;
		double vat = ( totalPayable - billDTO.getSecurityCharge() ) * 0.15;
		
		billDTO.setVAT( BillDTO.setDecimalPlaces( vat, 2 ) );
		billDTO.setGrandTotal( grandTotal );
		billDTO.setTotalPayable( totalPayable );
		billDTO.setNetPayable( totalPayable + vat );
		
		request.setAttribute( "discountIsAlreadyGiven", true ); //This so that this discount is not considered later in this flow
	}
	
	private LliBillDTO createDemandNoteForLinkUpgrade( HttpServletRequest request, CommonRequestDTO commonRequestDTO ){
		
		LliBillDTO lliBillDTO = new LliBillDTO();
		
		double farEndOFCCharge = Double.parseDouble( request.getParameter("farEndOFCCharge") );
		
		double upgradationCharge = Double.parseDouble( request.getParameter("bwUpgradationCharge") );
		double securityCharge = Double.parseDouble( request.getParameter("securityCharge") );
		double existingSecurityMoney = Double.parseDouble( request.getParameter("existingSecurityMoney") );
		
		double bandwidthCharge = Double.parseDouble( request.getParameter("bwCharge") );
		
		long expirationDate = 0L;
		if(commonRequestDTO.getExpireTime() == 0)
		{
			int nextState = RequestActionStateRepository.getInstance().getActionStateDTOActionTypeID(commonRequestDTO.getRequestTypeID()).getNextStateID();
			expirationDate = System.currentTimeMillis() +  StateRepository.getInstance().getStateDTOByStateID(nextState).getDurationInMillis();			
		}
		
		Calendar c = Calendar.getInstance();
		
		lliBillDTO.setUpgradationCharge( upgradationCharge );
		lliBillDTO.setSecurityCharge( securityCharge );
		lliBillDTO.setExistingSecurityMoney( existingSecurityMoney );
		
//		lliBillDTO.setRemoteEndOFC( farEndOFCCharge );
		lliBillDTO.setBwCharge( bandwidthCharge );
		
		double securityMoneyGiven = lliBillDTO.getSecurityCharge() - lliBillDTO.getExistingSecurityMoney();
		
		double grandTotal = lliBillDTO.getGrandTotal();
		double discount = Double.parseDouble( "0.0" );
		
		if( request.getParameter( "discount" ) != null )
			discount = Double.parseDouble( request.getParameter( "discount" ) );
		
		double totalPayable = grandTotal - discount;
		double vat = ( totalPayable - securityMoneyGiven ) * 0.15;
		
		lliBillDTO.setGrandTotal( grandTotal );
		lliBillDTO.setTotalPayable( totalPayable );
		lliBillDTO.setVAT( vat );
		lliBillDTO.setNetPayable( totalPayable + vat );
		lliBillDTO.setVAT( BillDTO.setDecimalPlaces( vat, 2 ) );
		
		lliBillDTO.setBillType( BillConstants.PREPAID_AND_POSTPAID );
		lliBillDTO.setDeleted( false );
		lliBillDTO.setEntityID( commonRequestDTO.getEntityID() );
		lliBillDTO.setEntityTypeID( EntityTypeConstant.LLI_LINK );
		lliBillDTO.setReqID( commonRequestDTO.getReqID() );
		lliBillDTO.setGenerationTime( System.currentTimeMillis() );
		lliBillDTO.setLastModificationTime( System.currentTimeMillis() );
		lliBillDTO.setLastPaymentDate( expirationDate );
		lliBillDTO.setClientID( commonRequestDTO.getClientID() );
		lliBillDTO.setClassName( LliBillDTO.class.getName() );
		lliBillDTO.setBillReqType( commonRequestDTO.getRequestTypeID() );
		lliBillDTO.setYear( c.get( Calendar.YEAR ) );
		lliBillDTO.setMonth( c.get( Calendar.MONTH ) );
		
		lliBillDTO.setActivationTimeFrom( DateUtils.getStartTimeOfMonth( c.get(Calendar.MONTH), c.get( Calendar.YEAR) ) );
		
		lliBillDTO.setActivationTimeTo( DateUtils.getEndTimeOfMonth( c.get(Calendar.MONTH), c.get( Calendar.YEAR) ) );
		
		return lliBillDTO;
	}
	
	private LliBillDTO createDemandNoteForNewLliLink(LliLinkDTO lliLinkDTO, LliFarEndDTO lliFarEndDTO,
			long expirationDate, long reqID, HttpServletRequest request, DatabaseConnection databaseConnection) throws Exception{
		
		String rentalCostColumnName = "Monthly Rental Cost";
		String maintanceCostColumnName = "Maintenace Cost";
		String sellingCostColumnName = "Selling Cost";
		LLICostConfigurationDAO lliCommonChargeConfigDAO = new LLICostConfigurationDAO();
		LLIOTCConfigurationDTO commonChargeDTO = lliCommonChargeConfigDAO.getCurrentActiveCommonChargeDTO(databaseConnection); 
		
		double monthlyCostPerMonth = getMonthlyCostForLliLink(lliLinkDTO,lliFarEndDTO, databaseConnection);	
		
		CommonRequestDTO commonRequestDTO = (CommonRequestDTO) SqlGenerator.getObjectByID(CommonRequestDTO.class, reqID, databaseConnection);
		
		LliBillDTO billDTO = new LliBillDTO();
		
		if( commonRequestDTO == null 
			|| commonRequestDTO.getRequestTypeID() == LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_GENERATE_DEMAND_NOTE
			|| commonRequestDTO.getRequestTypeID() == LliRequestTypeConstants.REQUEST_NEW_LINK.SYSTEM_GENERATE_MIGRATION_DEMAND_NOTE)
		{
			populateMixBill( billDTO, request );
		}
		
		billDTO.setLinkName( lliLinkDTO.getLinkName() );
		
		double monthlyCost = monthlyCostPerMonth;
	
		List<LliTerminalDeviceMapper> terminalDeviceMappersForFarEnd = getTerminalDeviceMappersByEndPointID(lliFarEndDTO.getLliEndPointID(), databaseConnection);
		for(LliTerminalDeviceMapper terminalDeviceMapper:terminalDeviceMappersForFarEnd){
			long terminalDeviceID = terminalDeviceMapper.getTerminalDeviceID();
			InventoryItemDetails inventoryItemDetails = new InventoryService().getInventoryItemDetailsByItemID(terminalDeviceID);
			if(!terminalDeviceMapper.isRented()){
				// one time cost
				String sellingCostString = inventoryItemDetails.getValueByAttributeName(sellingCostColumnName);
				double oneTimeSellingCost = Double.parseDouble(sellingCostString);
				billDTO.addRow("Far end terminal device selling cost ("+inventoryItemDetails.getInventoryItem().getName()+")", oneTimeSellingCost);
			}else{
				String rentCostString = inventoryItemDetails.getValueByAttributeName(rentalCostColumnName);
				monthlyCost+= Double.parseDouble(rentCostString);
			}
			
			
			if(terminalDeviceMapper.isMaintanedByBTCL()){
				String maintanceCostString = inventoryItemDetails.getValueByAttributeName(maintanceCostColumnName);
				double maintanceCost = Double.parseDouble(maintanceCostString);
				//billDTO.addRow("Far end terminal device maintaince cost ("+inventoryItemDetails.getInventoryItem().getName()+")", maintanceCost);
				monthlyCost+=maintanceCost;
			}
		}
		if(lliFarEndDTO.isOFCProvidedByBTCL() && !lliFarEndDTO.isOpticalFibreRented()){
			
			double opticalFibreSellingCost = (lliFarEndDTO.getFibreType()==EndPointConstants.FIBRE_TYPE_LLC?
					commonChargeDTO.getLLCSellCost():commonChargeDTO.getDarkSellCost());
			billDTO.addRow("Far end optical fibre selling cost", opticalFibreSellingCost);
		}else if(lliFarEndDTO.isOFCProvidedByBTCL() && lliFarEndDTO.isOpticalFibreRented()){
			
			double opticalFibreRentalCost = (lliFarEndDTO.getFibreType()==EndPointConstants.FIBRE_TYPE_LLC?
					commonChargeDTO.getLLCRentCost():commonChargeDTO.getDarkRentCost());
			
			monthlyCost+=opticalFibreRentalCost;
		}

		if(lliFarEndDTO.isOpticalFibreLaidByBTCL()){
			
			billDTO.addRow("Far end optical fibre laying cost", commonChargeDTO.getFibreLayingCost());
		}
		
		billDTO.setBillType( BillConstants.PREPAID_AND_POSTPAID );
		billDTO.setDeleted(false);
		billDTO.setEntityID(lliLinkDTO.getID());
		billDTO.setEntityTypeID(EntityTypeConstant.LLI_LINK);
		billDTO.setReqID(reqID);
		billDTO.setGenerationTime(lliLinkDTO.getCurrentTime());
		billDTO.setLastModificationTime(lliLinkDTO.getCurrentTime());
		billDTO.setLastPaymentDate(expirationDate);
		billDTO.setClientID(lliLinkDTO.getClientID());
		billDTO.setClassName( LliBillDTO.class.getName() );
		billDTO.setGenerationTime( System.currentTimeMillis() );
		billDTO.setBillReqType( commonRequestDTO==null? LliRequestTypeConstants.REQUEST_NEW_LINK.CLIENT_APPLY : commonRequestDTO.getRequestTypeID() );
		
		billDTO.setActivationTimeFrom( System.currentTimeMillis() );
		
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis( System.currentTimeMillis() );
		
		if( !org.apache.commons.lang.StringUtils.isEmpty( request.getParameter( "activationDateFrom" ) ) ){
			
			billDTO.setActivationTimeFromStr( request.getParameter( "activationDateFrom" ) );
			
			billDTO.setMonth( DateUtils.getMonthFromDateString( request.getParameter( "activationDateFrom" ) ) );
			billDTO.setYear( DateUtils.getYearFromDateString( request.getParameter( "activationDateFrom" ) ) );
		}
		else
		{
			billDTO.setActivationTimeFrom( System.currentTimeMillis() );
			billDTO.setMonth( calendar.get( Calendar.MONTH ) );
			billDTO.setYear( calendar.get( Calendar.YEAR ) );
		}
		
		if( !org.apache.commons.lang.StringUtils.isEmpty( request.getParameter( "activationDateTo" ) ) ){
			
			billDTO.setActivationTimeToStr( request.getParameter( "activationDateTo" ) );
		}
		else{
			
			billDTO.setActivationTimeTo( DateUtils.getEndTimeOfMonth( calendar.get( Calendar.MONTH ), calendar.get( Calendar.YEAR ) ) );
		}
		
		if( !org.apache.commons.lang.StringUtils.isEmpty( request.getParameter( "lastPaymentDate" ) ) ){
			
			billDTO.setLastPaymentDateStr( request.getParameter( "lastPaymentDate" ) );
		}
		else{
			
			billDTO.setLastPaymentDate( DateUtils.getEndTimeOfMonth( calendar.get( Calendar.MONTH ), calendar.get( Calendar.YEAR ) ) );
		}
		
		return billDTO;
	}
	
	private double getTeminalDeviceCost(){
		return 0.0;
	}
	private double getOpticalFibreCost(){
		return 0.0;
	}
	
	private double getMonthlyCostForLliLink( LliLinkDTO lliLinkDTO, LliFarEndDTO lliFarEndDTO,DatabaseConnection databaseConnection)
			throws Exception {
		
		double bandwidth = lliLinkDTO.getLliBandwidth();
		int bandwidthType = lliLinkDTO.getLliBandwidthType();
		
		if( bandwidthType == EntityTypeConstant.BANDWIDTH_TYPE_GB )
			bandwidth *= 1024; //Converting to MB
		
		CostConfigDAO costConfigDAO = new CostConfigDAO();
		int year = EndPointConstants.yearConnectionTypeMapping.get( lliLinkDTO.getConnectionType() );
		
		int categoryID = new ClientTypeService().getClientCategoryByModuleIDAndClientID( ModuleConstants.Module_ID_LLI, lliLinkDTO.getClientID() );
		
		double cost = costConfigDAO.getCalculatedCostLLI( databaseConnection, bandwidth, year, ModuleConstants.Module_ID_LLI, categoryID );
		
		return cost;
	}
	
	public List<LliTerminalDeviceMapper> getTerminalDeviceMappersByEndPointID(long lliEndPointID,DatabaseConnection databaseConnection) throws Exception{
		Class<LliTerminalDeviceMapper> classObject = LliTerminalDeviceMapper.class;
		String endPointIDColumnName = getColumnName(classObject, "endPointID");
		String conditionString = " where "+endPointIDColumnName+" = "+lliEndPointID;
		List<LliTerminalDeviceMapper> terminalDeviceMappers = getAllObjectList(classObject, databaseConnection, conditionString);
		return terminalDeviceMappers;
	}

	public void updateDistance(long combinedDistance, long entityID, DatabaseConnection databaseConnection) {
		// TODO Auto-generated method stub
		
	}


	

}
