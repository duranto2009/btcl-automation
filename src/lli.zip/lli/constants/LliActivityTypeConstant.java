package lli.constants;
/*
 * These constants will be used in activity log
 * 
 */
public class LliActivityTypeConstant{
	
	/*
	 * 
	 * ActivityTypeConstant holds the activities those are not a request or a subrequest but an action instead
	 * 
	 */
	
}
