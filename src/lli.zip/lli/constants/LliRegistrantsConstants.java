package lli.constants;

public class LliRegistrantsConstants {

	//Content will be added when needed
	
}
