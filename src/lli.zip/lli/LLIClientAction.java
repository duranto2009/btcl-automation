package lli;

import java.util.ArrayList;
import java.util.List;

import annotation.ForwardedAction;
import login.LoginDTO;
import requestMapping.AnnotatedRequestMappingAction;
import requestMapping.RequestParameter;
import requestMapping.Service;
import requestMapping.annotation.ActionRequestMapping;
import requestMapping.annotation.RequestMapping;
import requestMapping.annotation.RequestMethod;
import user.UserDTO;
import user.UserService;


@ActionRequestMapping("lli/client")
public class LLIClientAction extends AnnotatedRequestMappingAction{
	
	@Service
	LLIClientService lliClientService ;
	@Service
	UserService userService;
	
	@RequestMapping(mapping="/get-client", requestMethod=RequestMethod.All)
	public List<LLIDropdownPair> getLLIClient(@RequestParameter("val") String partialName, LoginDTO loginDTO) throws Exception{
		return lliClientService.getClientListByPartialName(partialName, loginDTO);
	}
	
	@RequestMapping(mapping="/get-client-by-id", requestMethod=RequestMethod.All)
	public LLIDropdownPair getLLIClientByID(@RequestParameter("id") Long clientID, LoginDTO loginDTO) throws Exception{
		return lliClientService.getClientByID(clientID, loginDTO);
	}
	
	@RequestMapping(mapping="/get-user", requestMethod=RequestMethod.All)
	public List<LLIDropdownPair> getUserList(@RequestParameter("val") String partialName, LoginDTO loginDTO) throws Exception{
		return lliClientService.getUserListByPartialName(partialName, loginDTO);
	}
	
	@RequestMapping(mapping="/get-loop-provider", requestMethod=RequestMethod.All)
	public List<LLIDropdownPair> getLoopProviderList() throws Exception{
		List<LLIDropdownPair> list = new ArrayList<>();
		List<UserDTO> listOfUserDTO = userService.getLocalLoopProviderList();
		for(UserDTO userDTO : listOfUserDTO) {
			list.add(new LLIDropdownPair(userDTO.getUserID(), userDTO.getUsername()));
		}
		return list;
	}
	
	/*LLI Client Dashboard Begins*/
	@ForwardedAction
	@RequestMapping(mapping="/board", requestMethod=RequestMethod.All)
	public String getLongTermNew() throws Exception {
		return "lli-client-board";
	}
	/*LLI Client Dashboard Ends*/
}