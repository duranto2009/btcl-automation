package lli;

public class LliConfigurationDTO {

}
