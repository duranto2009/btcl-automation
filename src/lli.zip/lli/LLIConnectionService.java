package lli;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;
import static lli.LLIMonthlyBillService.differenceExists;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;

import annotation.DAO;
import annotation.Transactional;
import common.EntityTypeConstant;
import common.RequestFailureException;
import inventory.InventoryItem;
import inventory.InventoryService;
import lli.connection.LLIConnectionConstants;
import login.LoginDTO;
import requestMapping.Service;
import user.UserService;
import util.CurrentTimeFactory;
import util.DatabaseConnectionFactory;
import util.DateUtils;
import util.ModifiedSqlGenerator;
import util.NavigationService;
import util.ServiceDAOFactory;
import util.TimeConverter;
import util.TransactionType;


public class LLIConnectionService implements NavigationService{
	@DAO
	LLIConnectionDAO lliConnectionDAO;
	@Service
	LLIOfficeService lliOfficeService;
	@Service
	LLILocalLoopService lliLocalLoopService;
	@Service
	InventoryService inventoryService;
	@Service
	LLILongTermService lliLongTermService;
	
	@Transactional
	public long insertNewLLIConnection(LLIConnectionInstance connectionInstance) throws Exception{
		long connectionID = DatabaseConnectionFactory.getCurrentDatabaseConnection()
				.getNextIDWithoutIncrementing(
						ModifiedSqlGenerator.getTableName(LLIConnectionInstance.class));
		
		connectionInstance.setID(connectionID);
		connectionInstance.setStartDate(System.currentTimeMillis());
		connectionInstance.setStatus(LLIConnectionInstance.STATUS_ACTIVE);
		insertLLIConnectionSnapshot(connectionInstance);
		
		List<Long> vlanIDsToBeAllocated = getVlanIDListByConnectionInstance(connectionInstance);
		allocateVlansByVlanIDListAndClientIDAndConnectionID(vlanIDsToBeAllocated,connectionInstance.getClientID(),connectionInstance.getID());
		
		return connectionInstance.getID();
	}
	
	
	private void allocateIpAddresses(List<?> ipList) throws Exception{
		
	}
	
	private void deallocateIpAddress(List<?> ipList) throws Exception{
		
	}
	
	private List<?> getIpAddressListByConnectionInstance(LLIConnectionInstance lliConnectionInstance) throws Exception{
		return Collections.emptyList();
	} 
	
	@SuppressWarnings("unused")
	private void updateIpAddressByNewConnectionInstanceAndLastConnectionInstance(LLIConnectionInstance newConnectionInstance,
			LLIConnectionInstance lastConnectionInstance) throws Exception{
		List<?> newIpAddresses = getIpAddressListByConnectionInstance(newConnectionInstance);
		List<?> lastAllocatedIpAddresses = getIpAddressListByConnectionInstance(lastConnectionInstance);
		
		List<?> ipAddressesToBeAllocated = (List<?>) CollectionUtils.subtract(lastAllocatedIpAddresses, newIpAddresses);
		List<?> ipAddressesToBeDeallocated = (List<?>) CollectionUtils.subtract(lastAllocatedIpAddresses, newIpAddresses);
		allocateIpAddresses(ipAddressesToBeAllocated);
		deallocateIpAddress(ipAddressesToBeDeallocated);
		
	}
	
	
	private void allocateVlansByVlanIDListAndClientIDAndConnectionID(List<Long> vlanIDs,long clientID,long connectionID) throws Exception{
		// to be implemented later
		
		InventoryService inventoryService = new InventoryService();
		
		for(long vlanID: vlanIDs){
			if(vlanID==-1) {
				continue;
			}
			inventoryService.markInventoryItemAsUsedByOccupierInformation(vlanID, connectionID,
					EntityTypeConstant.LLI_LINK, clientID, DatabaseConnectionFactory.getCurrentDatabaseConnection());
		}
		
		
		
	}
	
	private void deallocateVlansByVlanIDList(List<Long> vlanIDs) throws Exception{
		// to be implemented later
		
		InventoryService inventoryService = new InventoryService();
		for(long vlanID: vlanIDs){
			inventoryService.markInventoryItemAsUnusedByItemID(vlanID, DatabaseConnectionFactory.getCurrentDatabaseConnection());
		}
		
		
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void updateVlanIDsByNewConnectionInstanceAndLastInstance(LLIConnectionInstance newConnectionInstance
			, LLIConnectionInstance lastConnectionInstance) throws Exception{
		List<Long> newVlanIDs = getVlanIDListByConnectionInstance(newConnectionInstance);
		List<Long> lastAllocatedVlanIDs = getVlanIDListByConnectionInstance(lastConnectionInstance);
		
		List<Long> vlansToBeAllocated = (List)CollectionUtils.subtract(newVlanIDs, lastAllocatedVlanIDs);
		List<Long> vlansToBeDeallocated = (List)CollectionUtils.subtract(lastAllocatedVlanIDs, newVlanIDs);
		allocateVlansByVlanIDListAndClientIDAndConnectionID(vlansToBeAllocated, lastConnectionInstance.getClientID(), lastConnectionInstance.getID());
		deallocateVlansByVlanIDList(vlansToBeDeallocated);
		
	}
	
	private List<Long> getVlanIDListByConnectionInstance(LLIConnectionInstance connectionInstance) throws Exception{

		return connectionInstance
				.getLliOffices()
				.stream()
				.flatMap(
							e->e.getLocalLoops()
							.stream()
							.map(LLILocalLoop::getVlanID)
						)
				.collect(toList());
	}
	
	
	
	private long insertLLIConnectionSnapshot(LLIConnectionInstance connectionInstance) throws Exception{
		
		connectionInstance.setActiveTo(Long.MAX_VALUE);
		connectionInstance.setValidFrom(CurrentTimeFactory.getCurrentTime());
		connectionInstance.setValidTo(Long.MAX_VALUE);
		
		lliConnectionDAO.insertLLIConnection(connectionInstance);
		for(LLIOffice lliOffice: connectionInstance.getLliOffices()){
			lliOffice.setConnectionHistoryID(connectionInstance.getHistoryID());
			if(lliOffice.getID() == 0){
				lliOfficeService.insertNewLLIOffice(lliOffice);
			}else{
				lliOfficeService.updateLLIOffice(lliOffice);
			}
		}
		/*
		List<Long> newSnapshotVlanIDList = getVlanIDListByConnectionInstance(connectionInstance);
		List<Long> currentVlanIDList = lliLocalLoopService.getCurrentyOccupiedLocalLoopIDListByLLIConnectionID(connectionInstance.getID());
		
		
		List<Long> obsoleteVlanIDList = getObsoleteVlanIDList(currentVlanIDList, newSnapshotVlanIDList);
		List<Long> newlyOccupiedVlanIDList = getNewlyOccupiedVlanIDList(currentVlanIDList, newSnapshotVlanIDList);
*/
		// remove obsolete
		// occupy new vlans
		
		return connectionInstance.getHistoryID();
	}
	@Transactional
	public void reconnectionConnectionByClientID(long clientID) throws Exception{
		List<LLIConnectionInstance> lliConnectionInstances = getLLIConnectionInstanceListByClientID(clientID);
		List<Long> connectionIDList = lliConnectionInstances
				.stream()
				.map(LLIConnectionInstance::getID)
				.collect(Collectors.toList());
		
		
		if(connectionIDList.isEmpty()){
			throw new RequestFailureException("This client has no connection for reconnection");
		}
		
		for(long connectionID: connectionIDList){
			reconnectConnection(connectionID);
		}
		
	}
	
	@Transactional
	public void tdLLIConnectionByClientID(long clientID) throws Exception{
		List<Long> tdConnectionIDList = lliConnectionDAO.getCurrentConnectionIDListByClientID(clientID);
		
		if(tdConnectionIDList.isEmpty()){
			throw new RequestFailureException("This client has no lli connection for TD.");
		}
		
		for(long connectionID: tdConnectionIDList){
			tdConnection(connectionID);
		}
	}
	
	@Transactional
	private long updateLLIConnection(LLIConnectionInstance connectionInstance) throws Exception{
		LLIConnectionInstance lastConnectionInstance = markLastConnectionAsHistroy(connectionInstance);
		
		if(lastConnectionInstance.getStatus()==LLIConnectionInstance.STATUS_CLOSED){
			throw new RequestFailureException("No update is possible on connection with connection ID "+lastConnectionInstance.getID()
			+" as the connection is already closed.");
		}
		if(	lastConnectionInstance.getStatus() == LLIConnectionInstance.OWNERSHIP_CHANGED){
			throw new RequestFailureException("No update is possible on connection with connection ID "+lastConnectionInstance.getID()
			+" as the ownership of the connection has already been changed.");
		}
		
		setImmutablePropertiesFromLastInstance(lastConnectionInstance, connectionInstance);
		
		validateOfficeIDAndLocalLoopID(connectionInstance,lastConnectionInstance);
		updateVlanIDsByNewConnectionInstanceAndLastInstance(connectionInstance, lastConnectionInstance);
		return insertLLIConnectionSnapshot(connectionInstance);
	}
	
	
	private void validateOfficeIDAndLocalLoopID(LLIConnectionInstance newConnectionInstance
			,LLIConnectionInstance previousConnectionInstance) throws Exception{
		
		Map<Long,LLIOffice> mapOfOfficeToOfficeID = previousConnectionInstance
				.getLliOffices()
				.stream()
				.collect(toMap(LLIOffice::getID, Function.identity()));
		
		
		Map<Long,LLILocalLoop> mapOfLocalLoopToLocalLoopID = mapOfOfficeToOfficeID
				.values()
				.stream()
				.flatMap(
							office->office.getLocalLoops()
							.stream()
						)
				.collect(toMap(LLILocalLoop::getID,Function.identity()));
		
		
		
		
		for(LLIOffice lliOffice: newConnectionInstance.getLliOffices()){
			
			if(lliOffice.getID() == 0) {
				continue;
			}
			
			LLIOffice prevOffice = mapOfOfficeToOfficeID.get(lliOffice.getID());
			
			if(prevOffice == null){
				throw new RequestFailureException(""); // Good readable message
			}
			
			for(LLILocalLoop lliLocalLoop:lliOffice.getLocalLoops()){
				if(lliLocalLoop.getID()!=0){
					if(!mapOfLocalLoopToLocalLoopID.containsKey(lliLocalLoop.getID())){
						throw new RequestFailureException("");
					}
					if(mapOfLocalLoopToLocalLoopID.get(lliLocalLoop.getID()).getLliOfficeHistoryID()!=prevOffice.getHistoryID()){
						throw new RequestFailureException("");
					}
				}
			}
		}
	}
	
	private void setImmutablePropertiesFromLastInstance(LLIConnectionInstance lastConnectionInstance
			, LLIConnectionInstance newConnectionInstance){
		newConnectionInstance.setClientID(lastConnectionInstance.getClientID());
		newConnectionInstance.setID(lastConnectionInstance.getID());
		newConnectionInstance.setConnectionType(lastConnectionInstance.getConnectionType());
		// check connectionID and local loop id
	}
	
	
	private void populateLLIConnectionInstanceWithOfficeAndLocalLoop(LLIConnectionInstance connectionInstance) throws Exception{

		List<LLIOffice> officeList = lliOfficeService.getLLIOfficeListByConnectionHistoryID(connectionInstance.getHistoryID());
		
		
		/*List<Long> officeHistoryIDs = new ArrayList<>();
		for(LLIOffice lliOffice: officeList){
			officeHistoryIDs.add(lliOffice.getHistoryID());
		}*/
		List<Long> officeHistoryIDs = officeList
							.stream()
							.map(LLIOffice::getHistoryID)
							.collect(toList());
		
		
		List<LLILocalLoop> lliLocalLoopList = lliLocalLoopService.getLocalLoopListByOfficeHistoryIDList(officeHistoryIDs); 
		
		Map<Long,List<LLILocalLoop>> mapOfLocalLoopListToOfficeID = lliLocalLoopList
				.stream()
				.collect(groupingBy(LLILocalLoop::getLliOfficeHistoryID));
		
		for(LLIOffice office:officeList){
			office.setLocalLoops(mapOfLocalLoopListToOfficeID.getOrDefault(office.getHistoryID(), Collections.emptyList()));
		}
		
		
		connectionInstance.setLliOffices(officeList);
	}
	
	@Transactional(transactionType = TransactionType.READONLY)
	public LLIConnectionInstance getLLLIConnectionInstanceByConnectionHistoryID(long historyID) throws Exception{
		LLIConnectionInstance connectionInstance = lliConnectionDAO.getConnectionInstanceByConnectionHistoryID(historyID);
		if(connectionInstance == null) {
			return null;
		}
		populateLLIConnectionInstanceWithOfficeAndLocalLoop(connectionInstance);
		return connectionInstance;
	}
	
	@Transactional(transactionType = TransactionType.READONLY)
	public LLIConnectionInstance getLLIConnectionByConnectionID(long connectionID) throws Exception{
		
		LLIConnectionInstance connectionInstance = lliConnectionDAO.getCurrentLLIConnectionInstanceByConnectionID(connectionID);
		if(connectionInstance == null) {
			return null;
		}
		populateLLIConnectionInstanceWithOfficeAndLocalLoop(connectionInstance);
		return connectionInstance;
		
	}
	private LLIConnectionInstance markLastConnectionAsHistroy(LLIConnectionInstance newConnectionInstance) throws Exception{
		LLIConnectionInstance currentConnectionInstance = lliConnectionDAO
				.getCurrentLLIConnectionInstanceByConnectionID(newConnectionInstance.getID());
		if(currentConnectionInstance == null){
			throw new RequestFailureException("No LLIConnection Found with connection ID "+newConnectionInstance.getID());
		}
		if(currentConnectionInstance.getActiveFrom()>=newConnectionInstance.getActiveFrom()){
			throw new RequestFailureException("Current connection entry is active from "
					+TimeConverter.getTimeStringByDateFormat(currentConnectionInstance.getActiveFrom(), TimeConverter.dateFormatWithTimeString)
					+". So the current entry's activation from time must be after this time.");
		}
		
		currentConnectionInstance.setActiveTo(newConnectionInstance.getActiveFrom());
		lliConnectionDAO.updateLLIConnectionInstance(currentConnectionInstance);
		populateLLIConnectionInstanceWithOfficeAndLocalLoop(currentConnectionInstance);
		return currentConnectionInstance;
	}
	@SuppressWarnings("rawtypes")
	@Override
	@Transactional(transactionType = TransactionType.READONLY)
	public Collection getIDs(LoginDTO loginDTO, Object... objects) throws Exception {
		return getIDsWithSearchCriteria(new Hashtable(), loginDTO, objects);
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	@Transactional(transactionType = TransactionType.READONLY)
	public Collection getIDsWithSearchCriteria(Hashtable searchCriteria, LoginDTO loginDTO, Object... objects) throws Exception {
		return lliConnectionDAO.getIDsWithSearchCriteria(searchCriteria,loginDTO);
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	@Transactional(transactionType = TransactionType.READONLY)
	public Collection getDTOs(Collection recordIDs, Object... objects) throws Exception {
		return lliConnectionDAO.getLLIConnectionListByConnectionIDList((List)recordIDs);
	} 
	
	@Transactional(transactionType = TransactionType.READONLY)
	public List<LLIDropdownPair> getLLIConnectionNameIDPairListByClient(long clientID) throws Exception{
		return lliConnectionDAO.getConnectionNameIDPairListByClientID(clientID);
	}
	@Transactional(transactionType = TransactionType.READONLY)
	public List<LLIDropdownPair> getLLIConnectionOfficeNameIDPairListByConnectionID(long connectionID) throws Exception{
		long connectionHistoryID = getLLIConnectionByConnectionID(connectionID).getHistoryID();
		return lliConnectionDAO.getLLIConnectionOfficeNameIDPairListByConnectionID(connectionHistoryID);
	}
	
	// history method
	@Transactional(transactionType = TransactionType.READONLY)
	public List<LLIConnectionInstance> getLLIConnectionInstanceListByClientIDAndDateRange(long clientID,
			long fromDate,long toDate) throws Exception{
		List<LLILocalLoop> lliLocalLoopList = lliLocalLoopService.getLocalLoopListByClientIDAndDateRange(clientID
				, fromDate, toDate);
		
		Map<Long,List<LLILocalLoop>> mapOfLocalLoopListToOfficeHistoryID = getMapOfLocalLoopListToOfficeIHistoryID(lliLocalLoopList);
		
		List<LLIOffice> lliOffices = lliOfficeService.getLLIOfficeListByClientIDAndDateInstance(clientID
				, fromDate, toDate);
		for(LLIOffice lliOffice: lliOffices) {
			lliOffice.setLocalLoops(mapOfLocalLoopListToOfficeHistoryID.get(lliOffice.getHistoryID()));
		}
		Map<Long,List<LLIOffice>> mapOfOfficeListToConnectionHistoryID = getMapOfOfficeListToConnectionHistoryID(lliOffices, 
				mapOfLocalLoopListToOfficeHistoryID);
		
		List<LLIConnectionInstance> lliConnectionInstances = lliConnectionDAO.getConnectionListByClientIDAndDateRange(clientID
				,fromDate,toDate);
		
		for(LLIConnectionInstance lliConnectionInstance: lliConnectionInstances){
			lliConnectionInstance.setLliOffices(mapOfOfficeListToConnectionHistoryID.get(lliConnectionInstance.getHistoryID()));
		}
		
		return lliConnectionInstances;
		
	}

	private Map<Long, List<LLIOffice>> getMapOfOfficeListToConnectionHistoryID(List<LLIOffice> lliOffices,
			Map<Long, List<LLILocalLoop>> mapOfLocalLoopListToOfficeID) {
		return lliOffices
				.stream()
				.collect(groupingBy(LLIOffice::getConnectionHistoryID));
	}

	private Map<Long, List<LLILocalLoop>> getMapOfLocalLoopListToOfficeIHistoryID(List<LLILocalLoop> lliLocalLoopList) {
		return lliLocalLoopList
				.stream()
				.collect(Collectors.groupingBy(LLILocalLoop::getLliOfficeHistoryID));
	}
	/*
	private List<Long> getNewlyOccupiedVlanIDList(List<Long> currentVlanList,List<Long> newVlanList){
		Set<Long> currentVlans = new HashSet<>(currentVlanList);
		List<Long> newlyOccupiedVlanIDList = new ArrayList<>();
		for(Long newVlanID: newVlanList){
			if(!currentVlans.contains(newVlanID)){
				currentVlans.add(newVlanID);
			}
		}
		return newlyOccupiedVlanIDList;
	}
	private List<Long> getObsoleteVlanIDList(List<Long> currentVlanList,List<Long> newVlanList){
		Set<Long> newVlans = new HashSet<>(newVlanList);
		List<Long> obsoleteVlanIDList = new ArrayList<>();
		for(Long currentVlanID: currentVlanList){
			if(!newVlans.contains(currentVlanID)){
				obsoleteVlanIDList.add(currentVlanID);
			}
		}
		return obsoleteVlanIDList;
	}*/

	@Transactional(transactionType=TransactionType.READONLY)
	public List<LLIConnectionInstance> getConnectionHistoryListByConnectionID(long connectionID) throws Exception{
		return lliConnectionDAO.getConnectionHistoryByConnectionID(connectionID);
	}
	@Transactional(transactionType=TransactionType.READONLY)
	public LLIConnectionInstance getConnectionInstanceByConnectionIDAndHistoryID(long connectionID
			,long historyID) throws Exception{
		return lliConnectionDAO.getConnectionHistoryByConnectionIDAndHistoryID(connectionID,historyID);
	}
	@Transactional(transactionType=TransactionType.READONLY)
	public Map<Long, List<LLIConnectionInstance>> getMapOfLLIConnectionInstanceListByConnectionIDOfAClient(long clientID, long fromDate,
			long toDate) throws Exception {
		List<LLILocalLoop> lliLocalLoopList = lliLocalLoopService.getLocalLoopListByClientIDAndDateRange(clientID
				, fromDate, toDate);
		
		Map<Long,List<LLILocalLoop>> mapOfLocalLoopListToOfficeHistoryID = getMapOfLocalLoopListToOfficeIHistoryID(lliLocalLoopList);
		
		List<LLIOffice> lliOffices = lliOfficeService.getLLIOfficeListByClientIDAndDateInstance(clientID
				, fromDate, toDate);
		for(LLIOffice lliOffice: lliOffices) {
			lliOffice.setLocalLoops(mapOfLocalLoopListToOfficeHistoryID.get(lliOffice.getHistoryID()));
		}
		Map<Long,List<LLIOffice>> mapOfOfficeListToConnectionHistoryID = getMapOfOfficeListToConnectionHistoryID(lliOffices, 
				mapOfLocalLoopListToOfficeHistoryID);
		
		List<LLIConnectionInstance> lliConnectionInstances = 
				lliConnectionDAO.getConnectionListByClientIDAndDateRange(clientID,fromDate,toDate);
				
		for(LLIConnectionInstance lliConnectionInstance: lliConnectionInstances){
			lliConnectionInstance.setLliOffices(mapOfOfficeListToConnectionHistoryID.get(lliConnectionInstance.getHistoryID()));
		}
		Map<Long, List<LLIConnectionInstance>> mapOfInstanceListByConnectionID =  lliConnectionInstances
				.stream()
				.collect(groupingBy(LLIConnectionInstance::getID));
		for(Entry<Long, List<LLIConnectionInstance>> e : mapOfInstanceListByConnectionID.entrySet()) {
			e.setValue(getFilteredInstanceList(e.getValue()));
		}
		return mapOfInstanceListByConnectionID;
	}

	
	public List<LLIConnectionInstance> getFilteredInstanceList(
			List<LLIConnectionInstance> connectionList) throws Exception {
		List<LLIConnectionInstance> filteredList = new ArrayList<>();
		LLIConnectionInstance lliInstance, lastFilteredInstance;
		for(int i=0;i<connectionList.size();i++) {
			lliInstance = connectionList.get(i);
			if(i==0) {
				filteredList.add(lliInstance);
			}else {
				lastFilteredInstance = filteredList.get(filteredList.size()-1);
				if(DateUtils.isOnSameDay(lliInstance.getActiveFrom(), lastFilteredInstance.getActiveFrom())) {
					filteredList.remove(filteredList.size()-1);
					filteredList.add(lliInstance);
				}  else {
					if(differenceExists(lastFilteredInstance, lliInstance)) {
						filteredList.add(lliInstance);
					}
				}
			}
		}
		adjustTimeline(filteredList);
		return filteredList;
	}


	private void  adjustTimeline(List<LLIConnectionInstance> filteredList) {
		filteredList.forEach(instance-> {
			instance.setActiveFrom(TimeConverter.getStartTimeOfTheDay(instance.getActiveFrom()));
		});
		LLIConnectionInstance prev, now;
		for(int i=1;i<filteredList.size();i++) {
			 prev = filteredList.get(i-1);
			 now = filteredList.get(i);
			 prev.setActiveTo(now.getActiveFrom());
		}
		
	}


	/**
	 * @author Dhrubo
	 */
	public String getOcDetails(Long id) throws Exception {
		UserService userService = ServiceDAOFactory.getService(UserService.class);
		String ocDetails = "";
		try {
			ocDetails = "Name: " + userService.getUserDTOByUserID(id).getUsername();
		} catch (Exception e) {
			ocDetails = "Warning: Invalid O/C";
		}
		return ocDetails;
	}
	
	@Transactional
	public void deleteLastConnectionInstanceByConnectionID(long connectionID) throws Exception{
		LLIConnectionInstance lastConnectionInstance = getLLIConnectionByConnectionID(connectionID);
		if(lastConnectionInstance == null){
			throw new RequestFailureException(""); // good readable message
		}
		LLIConnectionInstance newCurrentLLIConnectionInstance = lliConnectionDAO.getLLICOnnectionInstanceByActiveToTime(lastConnectionInstance.getActiveFrom());
		
		
		if(newCurrentLLIConnectionInstance == null){
			// this is the first entry. so this deletion will delete the whole lli connection-+
			lastConnectionInstance.setValidTo(CurrentTimeFactory.getCurrentTime());
			lliConnectionDAO.updateLLIConnectionInstance(lastConnectionInstance);
			
			List<Long> vlansToBeDeallocated = getVlanIDListByConnectionInstance(lastConnectionInstance);
			deallocateVlansByVlanIDList(vlansToBeDeallocated);
			
			List<?> ipAddressesToBeDeallocated = getIpAddressListByConnectionInstance(lastConnectionInstance);
			deallocateIpAddress(ipAddressesToBeDeallocated);
			
		}else{
			//
			
			populateLLIConnectionInstanceWithOfficeAndLocalLoop(newCurrentLLIConnectionInstance);
			
			updateVlanIDsByNewConnectionInstanceAndLastInstance(newCurrentLLIConnectionInstance, lastConnectionInstance);
			updateIpAddressByNewConnectionInstanceAndLastConnectionInstance(newCurrentLLIConnectionInstance, lastConnectionInstance);
			
			newCurrentLLIConnectionInstance.setActiveTo(Long.MAX_VALUE);
			lliConnectionDAO.updateLLIConnectionInstance(newCurrentLLIConnectionInstance);
			
			
			lastConnectionInstance.setActiveTo(CurrentTimeFactory.getCurrentTime());
			lastConnectionInstance.setValidTo(CurrentTimeFactory.getCurrentTime());
			lliConnectionDAO.updateLLIConnectionInstance(lastConnectionInstance);
		
			
			
		}
	}
	
	@Transactional
	public void changeOwnerShip(long prevClientID,long newClientID,long ownerShipChangeDate) throws Exception{
		
		List<Long> connectionIDList = lliConnectionDAO.getConnectionIDListByClientID(prevClientID);
		changeOwnerShip(prevClientID, newClientID, connectionIDList, ownerShipChangeDate);
		lliLongTermService.changeOwnerShip(prevClientID, newClientID, ownerShipChangeDate);
	}
	
	@Transactional
	public void reviseConnection(LLIConnectionInstance lliConnectionInstance) throws Exception{
		LLIConnectionInstance lastLLIConnectionInstance = getLLIConnectionByConnectionID(lliConnectionInstance.getID());
		if(lastLLIConnectionInstance == null) {
			// throw exception 
		}
		lliConnectionInstance.setStatus(lastLLIConnectionInstance.getStatus());
		updateLLIConnection(lliConnectionInstance);
	}
	@Transactional
	public void tdConnection(long lliConnectionID) throws Exception{
		LLIConnectionInstance lastLLIConnectionInstance = getLLIConnectionByConnectionID(lliConnectionID);
		if(lastLLIConnectionInstance == null) {
			// throw exception 
		}
		lastLLIConnectionInstance.setStatus(LLIConnectionInstance.STATUS_TD);
		updateLLIConnection(lastLLIConnectionInstance);
	}
	@Transactional
	public void reconnectConnection(long lliConnectionID) throws Exception{
		LLIConnectionInstance lastLLIConnectionInstance = getLLIConnectionByConnectionID(lliConnectionID);
		if(lastLLIConnectionInstance == null) {
			// throw exception 
		}
		lastLLIConnectionInstance.setStatus(LLIConnectionInstance.STATUS_ACTIVE);
		updateLLIConnection(lastLLIConnectionInstance);
	}
	private List<LLITotalRegularBandwidthSummary> mergeTotalBandwidthSummary(List<LLITotalRegularBandwidthSummary> list) throws Exception{
		if(list.isEmpty()){
			return list;
		}
		return mergeTotalBandwidthSummary(list, 0, list.size()-1);
	}
	
	private List<LLITotalRegularBandwidthSummary> mergeTotalBandwidthSummary(List<LLITotalRegularBandwidthSummary> list,int L,int R) throws Exception{
		
		if(L>R){
			throw new Exception("L must be less than or equal R");
		}
		if(R>=list.size()){
			throw new Exception("R must be less than list.size()");
		}
		
		if(L>R){
			return Collections.emptyList();
		}
		if(L==R){
			List<LLITotalRegularBandwidthSummary> resultList = new ArrayList<>();
			resultList.add(list.get(L));
			return resultList;
		}
		
		
		int mid = (L+R)/2;
		
		
		List<LLITotalRegularBandwidthSummary> list1 = mergeTotalBandwidthSummary(list, L, mid);
		List<LLITotalRegularBandwidthSummary> list2 = mergeTotalBandwidthSummary(list, mid+1, R);
		
		
		int p = 0;
		int q = 0;
		List<LLITotalRegularBandwidthSummary> summaryList = new ArrayList<>();
		while(p!=list1.size() && q!=list2.size()){
			if(p == list1.size()){
				summaryList.add(list2.get(q++));
				continue;
			}
			if(q == list2.size()){
				summaryList.add(list1.get(p++));
				continue;
			}
			
			LLITotalRegularBandwidthSummary firstSummary = list1.get(p);
			LLITotalRegularBandwidthSummary secondSummary = list2.get(q);
			
			if(firstSummary.fromDate<secondSummary.fromDate){
				p++;
			}else{
				q++;
			}
			long newFromTime = Math.max(firstSummary.fromDate, secondSummary.fromDate);
			long newToTime = Math.min(firstSummary.toDate, secondSummary.toDate);
			if(newFromTime<newToTime){
				double newTotalBandwidth = firstSummary.totalBandwidth+ secondSummary.totalBandwidth;
				
				summaryList.add(new LLITotalRegularBandwidthSummary(newFromTime, newToTime, newTotalBandwidth));
			}
		}
		
		return summaryList;
	}
	
	
	
	public static void checkLongTermContractAndLLIConnectionSummary(List<LLILongTermContractSummary> contractSummaryList,
			List<LLITotalRegularBandwidthSummary> lliTotalBandwidthSummaryList) throws Exception{
		
		int p = 0;
		int q = 0;
		while(p!=contractSummaryList.size() && q!=lliTotalBandwidthSummaryList.size()){
			if(p==contractSummaryList.size()){
				break;
			}
			if(q==lliTotalBandwidthSummaryList.size()){
				break;
			}
			LLILongTermContractSummary lliLongTermContractSummary = contractSummaryList.get(p);
			LLITotalRegularBandwidthSummary lliTotalRegularBandwidthSummary = lliTotalBandwidthSummaryList.get(q);
			
			if(lliLongTermContractSummary.toDate<lliTotalRegularBandwidthSummary.toDate){
				p++;
			}else{
				q++;
			}
			if(Math.max(lliLongTermContractSummary.fromDate, lliTotalRegularBandwidthSummary.fromDate)<Math.min(lliLongTermContractSummary.toDate, lliTotalRegularBandwidthSummary.toDate)){
				if(lliLongTermContractSummary.totalBandwidthContract<lliTotalRegularBandwidthSummary.totalBandwidth){
					long dateInLong = Math.max(lliLongTermContractSummary.fromDate, lliTotalRegularBandwidthSummary.fromDate);
					throw new RequestFailureException("LLI long tern contract mismatch on "+TimeConverter.getDateTimeStringFromDateTime(dateInLong));
				}
			}
			
		}
		
	}
	@Transactional(transactionType = TransactionType.READONLY)
	public List<LLIConnectionInstance> getLLIConnectionInstanceListByClientID(long clientID) throws Exception{
		List<LLIConnectionInstance> lliConnectionInstanceList = lliConnectionDAO.getConnectionListByClientID(clientID);
		
		for(LLIConnectionInstance lliConnectionInstance: lliConnectionInstanceList){
			populateLLIConnectionInstanceWithOfficeAndLocalLoop(lliConnectionInstance);
		}
		
		
		return lliConnectionInstanceList;
	}
	
	public List<LLITotalRegularBandwidthSummary> getTotalBandwidthSummaryByClientIDAndFromDateAndToDate(long clientID,long fromDate,long toDate) throws Exception{
		List<LLITotalRegularBandwidthSummary> lliTotalRegularBandwidthSummaries = lliConnectionDAO.getLLITotalBandwidthSummaryByFromDateAndToDate(fromDate, toDate);
		List<LLITotalRegularBandwidthSummary> mergedLLITotalRegularSummary = mergeTotalBandwidthSummary(lliTotalRegularBandwidthSummaries);
		return mergedLLITotalRegularSummary;
	}
	
	@Transactional
	public void closeConnectionByConnectionID(long connectionID,long closingDate) throws Exception{
		LLIConnectionInstance lliConnectionInstance = getLLIConnectionByConnectionID(connectionID);
		if(lliConnectionInstance == null){
			throw new RequestFailureException("No connectin found with connection ID "+connectionID);
		}
		if(lliConnectionInstance.getStatus()!=LLIConnectionInstance.STATUS_ACTIVE 
				&& lliConnectionInstance.getStatus()!=LLIConnectionInstance.STATUS_TD){
			throw new RequestFailureException("This connection is not in a status to be closed");
		}
		
		
		// deallocate ip address
		lliConnectionInstance.setActiveFrom(closingDate);
		lliConnectionInstance.setStatus(LLIConnectionInstance.STATUS_CLOSED);
		lliConnectionInstance.setIncident(LLIConnectionConstants.CLOSE_CONNECTION);
		lliConnectionInstance.setLliOffices(new ArrayList<>());
		
		updateLLIConnection(lliConnectionInstance);
		
	}
	
	@Transactional
	private void changeOwnerShip(long currentOwnerID,long nextOwnerID,List<Long> connectionIDList,long ownerShipChangeDate) throws Exception{
		List<LLIConnectionInstance> lliConnectionInstances = (List<LLIConnectionInstance>) getDTOs(connectionIDList);
		for(LLIConnectionInstance lliConnectionInstance: lliConnectionInstances){
			
			if(lliConnectionInstance.getStatus()!=LLIConnectionInstance.STATUS_ACTIVE
					&& lliConnectionInstance.getStatus()!=LLIConnectionInstance.STATUS_TD){
				continue;
			}
			
			
			
			populateLLIConnectionInstanceWithOfficeAndLocalLoop(lliConnectionInstance);
			
			List<LLIOffice> previousOfficeList = lliConnectionInstance.getLliOffices();
			
			
			// deallocate ip addresses
			
			lliConnectionInstance.setStatus(LLIConnectionInstance.OWNERSHIP_CHANGED);
			lliConnectionInstance.setActiveFrom(ownerShipChangeDate);
			lliConnectionInstance.setIncident(LLIConnectionConstants.CHANGE_OWNERSHIP);
			updateLLIConnection(lliConnectionInstance);
			
			lliConnectionInstance.setStatus(LLIConnectionInstance.STATUS_ACTIVE);
			lliConnectionInstance.setClientID(nextOwnerID);
			lliConnectionInstance.setLliOffices(previousOfficeList);
			insertNewLLIConnection(lliConnectionInstance);
			
		}
		
	}
	@Transactional(transactionType = TransactionType.READONLY)
	public List<InventoryItem> getPopListByConnectionIDAndOfficeID(long connectionID,long officeID) throws Exception{
		
		
		
		return Collections.emptyList();
	}
	
	@Transactional(transactionType=TransactionType.READONLY)
	public int getBTCLProvidedLocalLoopCount(LLIConnectionInstance lliConnectionInstance) throws Exception{
		int btclProvidedLocalLoopCount = 0;
		
		for(LLIOffice lliOffice : lliConnectionInstance.getLliOffices()) {
			for(LLILocalLoop lliLocalLoop : lliOffice.getLocalLoops()) {
				if(lliLocalLoop.getBtclDistance() + lliLocalLoop.getOCDistance() > 0) {
					btclProvidedLocalLoopCount++;
				}
			}
		}
		return btclProvidedLocalLoopCount;
	}
	
}
