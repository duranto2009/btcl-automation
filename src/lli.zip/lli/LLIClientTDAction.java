package lli;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import annotation.JsonPost;
import login.LoginDTO;
import requestMapping.AnnotatedRequestMappingAction;
import requestMapping.RequestParameter;
import requestMapping.Service;
import requestMapping.annotation.ActionRequestMapping;
import requestMapping.annotation.RequestMapping;
import requestMapping.annotation.RequestMethod;
import sessionmanager.SessionConstants;
import util.RecordNavigationManager;
@ActionRequestMapping("lli/td/")
public class LLIClientTDAction extends AnnotatedRequestMappingAction {
	@Service
	LLIClientTDService lliClientTDService;
	@RequestMapping(mapping="search", requestMethod=RequestMethod.All)
	public ActionForward getSearchDNSDomainPage(ActionMapping mapping, HttpServletRequest request, LoginDTO loginDTO) throws Exception {
		RecordNavigationManager recordNavigationManager = new RecordNavigationManager(
				SessionConstants.NAV_CLIENT_TD_STATUS, request, lliClientTDService, 
				SessionConstants.VIEW_CLIENT_TD_STATUS, 
				SessionConstants.SEARCH_CLIENT_TD_STATUS
		);
		recordNavigationManager.doJob(loginDTO);
		return mapping.findForward("search-client-td-status");
	}
	@JsonPost
	@RequestMapping(mapping="td", requestMethod=RequestMethod.POST)
	public void TDByClientID(@RequestParameter(isJsonBody=true, value="id") long clientID) throws Exception {
		lliClientTDService.tempDisconnectClientByClientID(clientID);
	}
	
}
