package lli;

public class LLICoreCostChart {
	public final static int SINGLE_CORE = 1;
	public final static int DUAL_CORE = 2;
	
	public double getCoreCostByNumberOfCoreAndDistance(int numberOfCore, double distance) throws Exception {
		return 25.0;
	}
}
