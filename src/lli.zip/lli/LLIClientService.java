package lli;

import java.util.ArrayList;
import java.util.List;

import common.ClientDTO;
import common.EntityTypeConstant;
import common.ModuleConstants;
import common.repository.AllClientRepository;
import login.LoginDTO;
import request.StateRepository;
import user.UserDTO;
import user.UserRepository;
import vpn.client.ClientDetailsDTO;

public class LLIClientService {

	@SuppressWarnings("serial")
	public List<LLIDropdownPair> getClientListByPartialName(String partialName, LoginDTO loginDTO) {
		if(loginDTO.getIsAdmin()) {
			List<LLIDropdownPair> clientList = new ArrayList<LLIDropdownPair>();
			
			ArrayList<ClientDetailsDTO> allClientDetailsDTOList = AllClientRepository.getInstance().getAllVpnCleint();
			for(ClientDetailsDTO clientDetailsDTO : allClientDetailsDTOList) {
				if(clientDetailsDTO.getLoginName().startsWith(partialName)
						&& isActiveLLIClient(clientDetailsDTO)
						&& isActiveClient(clientDetailsDTO)
						&& clientDetailsDTO.getModuleID() == ModuleConstants.Module_ID_LLI) {
					clientList.add(new LLIDropdownPair(clientDetailsDTO.getClientID(), clientDetailsDTO.getLoginName()));
				}
			}
			return clientList;
		} else {
			return new ArrayList<LLIDropdownPair>(new ArrayList<LLIDropdownPair>() {{
				add(new LLIDropdownPair(loginDTO.getAccountID(), loginDTO.getUsername()));
			}});
		}
	}

	private boolean isActiveClient(ClientDTO clientDTO) {
		if (StateRepository.getInstance().getStateDTOByStateID(clientDTO.getCurrentStatus())
				.getActivationStatus() == EntityTypeConstant.STATUS_ACTIVE) {
			return true;
		}
		return false;
	}

	private boolean isActiveLLIClient(ClientDTO clientDTO) {
		ClientDetailsDTO clientDetailsDTO = AllClientRepository.getInstance().getModuleClientByClientIDAndModuleID(clientDTO.getClientID(), ModuleConstants.Module_ID_LLI);
		if (clientDetailsDTO != null) {
			if (StateRepository.getInstance().getStateDTOByStateID(clientDetailsDTO.getCurrentStatus())
					.getActivationStatus() == EntityTypeConstant.STATUS_ACTIVE) {
				return true;
			}
			return false;
		}
		return false;
	}

	public List<LLIDropdownPair> getUserListByPartialName(String partialName, LoginDTO loginDTO) {
		List<LLIDropdownPair> userList = new ArrayList<LLIDropdownPair>();
		List<UserDTO> allUserList = UserRepository.getInstance().getUserList();
		
		for(UserDTO user : allUserList) {
			userList.add(new LLIDropdownPair(user.getUserID(), user.getUsername()));
		}
		
		return userList;
	}
	
	public LLIDropdownPair getClientByID(Long clientID, LoginDTO loginDTO) {
		if(!loginDTO.getIsAdmin() || clientID == null) {
			return new LLIDropdownPair(loginDTO.getAccountID(), loginDTO.getUsername());
		}
		return new LLIDropdownPair(clientID, AllClientRepository.getInstance().getClientByClientID(clientID).getLoginName());
	}

}
