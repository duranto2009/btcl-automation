package lli.Application.DowngradeBandwidth;

import java.lang.reflect.Type;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import lli.Application.LLIApplication;
import util.ModifiedSqlGenerator;

public class LLIDowngradeBandwidthApplicationDeserializer implements JsonDeserializer<LLIDowngradeBandwidthApplication>{

	@Override
	public LLIDowngradeBandwidthApplication deserialize(JsonElement jsonElement, Type arg1, JsonDeserializationContext context) throws JsonParseException {
		LLIDowngradeBandwidthApplication lliDowngradeBandwidthApplication = new LLIDowngradeBandwidthApplication();
		
		//Receive JSON
		JsonObject jsonObject = jsonElement.getAsJsonObject();
		
		//Deserialize Specific LLI New Connection Application
		lliDowngradeBandwidthApplication.setExtendedApplicationID(jsonObject.get("extendedApplicationID") != null ? jsonObject.get("extendedApplicationID").getAsLong() : 0);
		
		lliDowngradeBandwidthApplication.setConnectionID(jsonObject.get("connection").getAsJsonObject().get("ID").getAsLong());
		lliDowngradeBandwidthApplication.setBandwidth(jsonObject.get("bandwidth").getAsDouble());
		
		lliDowngradeBandwidthApplication.setSuggestedDate(jsonObject.get("suggestedDate").getAsLong());
		
		//Deserialize Common LLI Application
		LLIApplication lliApplication = context.deserialize(jsonElement, LLIApplication.class);
		ModifiedSqlGenerator.populateObjectFromOtherObject(lliApplication, lliDowngradeBandwidthApplication, LLIApplication.class);
		
		return lliDowngradeBandwidthApplication;
	}



}
