package lli.Application;
import static util.ModifiedSqlGenerator.*;

import java.sql.ResultSet;
import java.util.Hashtable;
import java.util.List;


import common.ClientDTOConditionBuilder;
import lli.connection.LLIConnectionConstants;
import login.LoginDTO;
import util.ModifiedSqlGenerator;
import util.SqlGenerator;
import util.TimeConverter;
public class LLIApplicationDAO {
	Class<LLIApplication> classObject = LLIApplication.class;
	
	
	
	public void updateLLIApplication(LLIApplication lliApplication) throws Exception{
		ModifiedSqlGenerator.updateEntity(lliApplication);
	}
	
	public LLIApplication getLLIApplicationByID(long applicationID) throws Exception{
		
		LLIApplication lliApplication = getObjectByID(LLIApplication.class, applicationID);
		
		Class<? extends LLIApplication> childApplicationClass = LLIConnectionConstants.applicationTypeClassnameMap.get(lliApplication.getApplicationType()); 
		
		String conditionString = " where "+SqlGenerator.getForeignKeyColumnName(childApplicationClass)+" = "+lliApplication.getApplicationID()+" limit 1";
		
		List<? extends LLIApplication> childApplications = getAllObjectList(childApplicationClass, conditionString);
		
		LLIApplication childApplication = (childApplications.isEmpty()?null:childApplications.get(0));
		
		if(childApplication != null) {
			ModifiedSqlGenerator.populateObjectFromOtherObject(lliApplication, childApplication, LLIApplication.class);
		}
		
		return childApplication; 
	}
	
	
	
	public LLIApplication getChildLLIApplicationByForeignKey(long foreignKey,Class<? extends LLIApplication> childClassObject) throws Exception{
		String conditionString = " where "+SqlGenerator.getForeignKeyColumnName(childClassObject)+" = "+foreignKey+" limit 1";
		
		List<? extends LLIApplication> childApplications = getAllObjectList(childClassObject, conditionString);
		
		LLIApplication childApplication = (childApplications.isEmpty()?null:childApplications.get(0));
		
		return childApplication;
	}
	
	
	public void insertLLIApplication(LLIApplication lliApplication) throws Exception{
		insert(lliApplication);
	}
	
	public List<Long> getIDsWithSearchCriteria(Hashtable<String, String> criteria,LoginDTO loginDTO) throws Exception{
		
		ResultSet rs = getResultSetBySqlPair(
				new LLIApplicationConditionBuilder()
				.selectApplicationID()
				.fromLLIApplication()
				.Where()
				.applicationIDEqualsString(criteria.get("applicationID"))
				.submissionDateGreaterThanEquals(TimeConverter.getDateFromString( criteria.get("fromDate")))
				.submissionDateLessThanEquals(TimeConverter.getDateFromString(criteria.get("toDate")))
				.applicationTypeEqualsString(criteria.get("applicationType"))
				.clientIDInSqlPair(
						new ClientDTOConditionBuilder()
						.selectClientID()
						.fromClientDTO()
						.Where()
						.loginNameBothLike(criteria.get("clientName"))
						.getNullableSqlPair()
						)
				.clientIDEqualsString(criteria.get("clientID"))
				.statusEqualsString(criteria.get("applicationStatus"))
				.demandNoteIDEqualsString(criteria.get("invoiceID"))
				.isServiceStartedLike(criteria.get("serviceStarted"))
				.clientIDEquals(loginDTO.getIsAdmin()?null:loginDTO.getAccountID())
				.getSqlPair()
				);
		
		
		List<Long> idList = getSingleColumnListByResultSet(rs, Long.class); 
		
		return idList;
	}
	
	public List<LLIApplication> getLLIApplicationListByIDList(List<Long> applicationIDList) throws Exception{
		return getAllObjectList(classObject, new LLIApplicationConditionBuilder()
				.Where()
				.applicationIDIn(applicationIDList)
				.getCondition());
	}

	public LLIApplication getLLIApplicationByDemandNoteID(long demandNoteID) throws Exception{

		List<LLIApplication> lliApplications = getAllObjectList(classObject, new LLIApplicationConditionBuilder()
				.Where()
				.demandNoteIDEquals(demandNoteID)
				.getCondition());
		
		return lliApplications.isEmpty()?null:lliApplications.get(0);
	}
	
	
}
