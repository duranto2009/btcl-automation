package lli.Application;

public interface DoubleConnectionApplication extends SingleConnectionApplication{
	public long getSecondConnectionID();
}
