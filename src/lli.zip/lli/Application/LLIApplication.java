package lli.Application;

import annotation.ColumnName;
import annotation.PrimaryKey;
import annotation.TableName;
import annotation.Transactional;
import common.RequestFailureException;
import lli.LLIConnectionInstance;
import lli.LLIConnectionService;
import lli.connection.LLIConnectionConstants;
import util.ServiceDAOFactory;

@TableName("at_lli_application")
public class LLIApplication {
	@PrimaryKey
	@ColumnName("applicationID")
	long applicationID;
	@ColumnName("applicationType")
	int applicationType;
	@ColumnName("submissionDate")
	long submissionDate;
	@ColumnName("clientID")
	long clientID;
	@ColumnName("userID")
	Long userID;
	@ColumnName("status")
	int status;
	@ColumnName("content")
	String content;
	@ColumnName("demandNoteID")
	Long demandNoteID;
	@ColumnName("isDemandNoteNeeded")
	boolean isDemandNoteNeeded;
	@ColumnName("isServiceStarted")
	boolean isServiceStarted;
	@ColumnName("comment")
	String comment;
	@ColumnName("description")
	String description;
	@ColumnName("requestForCorrectionComment")
	String requestForCorrectionComment;
	@ColumnName("rejectionComment")
	String rejectionComment;
	String [] documents;
	
	public long getApplicationID() {
		return applicationID;
	}
	public void setApplicationID(long applicationID) {
		this.applicationID = applicationID;
	}
	public int getApplicationType() {
		return applicationType;
	}
	public void setApplicationType(int applicationType) {
		this.applicationType = applicationType;
	}
	public long getSubmissionDate() {
		return submissionDate;
	}
	public void setSubmissionDate(long submissionDate) {
		this.submissionDate = submissionDate;
	}
	public long getClientID() {
		return clientID;
	}
	public void setClientID(long clientID) {
		this.clientID = clientID;
	}
	public Long getUserID() {
		return userID;
	}
	public void setUserID(Long userID) {
		this.userID = userID;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Long getDemandNoteID() {
		return demandNoteID;
	}
	public void setDemandNoteID(Long demandNoteID) {
		this.demandNoteID = demandNoteID;
	}
	public boolean isServiceStarted() {
		return isServiceStarted;
	}
	public void setServiceStarted(boolean isServiceStarted) {
		this.isServiceStarted = isServiceStarted;
	}
	public boolean isDemandNoteNeeded() {
		return isDemandNoteNeeded;
	}
	public void setDemandNoteNeeded(boolean isDemandNoteNeeded) {
		this.isDemandNoteNeeded = isDemandNoteNeeded;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getRejectionComment() {
		return rejectionComment;
	}
	public void setRejectionComment(String rejectionComment) {
		this.rejectionComment = rejectionComment;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRequestForCorrectionComment() {
		return requestForCorrectionComment;
	}
	public void setRequestForCorrectionComment(String requestForCorrectionComment) {
		this.requestForCorrectionComment = requestForCorrectionComment;
	}
	
	
	@Transactional
	public void insertApplication() throws Exception {
		
		if(this instanceof SingleConnectionApplication){
			SingleConnectionApplication singleConnectionApplication = (SingleConnectionApplication)this;
			long connectionID = singleConnectionApplication.getConnectionID();
			LLIConnectionService lliConnectionService = ServiceDAOFactory.getService(LLIConnectionService.class);
			LLIConnectionInstance lliConnectionInstance = lliConnectionService.getLLIConnectionByConnectionID(connectionID);
			if(lliConnectionInstance == null){
				throw new RequestFailureException("No connection found with connection ID "+connectionID);
			}
			if(lliConnectionInstance.getStatus() == LLIConnectionInstance.STATUS_CLOSED || lliConnectionInstance.getStatus() == LLIConnectionInstance.OWNERSHIP_CHANGED){
				throw new RequestFailureException("The connection with connection ID "+lliConnectionInstance.getID()+" is not a valid connection anymore.");
			}
			if(lliConnectionInstance.getClientID() != this.clientID){
				throw new RequestFailureException("This client is not the owner of the connection with Connection ID "+connectionID);
			}
		}
		
		
		this.setSubmissionDate(System.currentTimeMillis());
		this.setStatus(LLIConnectionConstants.STATUS_APPLIED);
	}
	
	public void setImmutablePropertyWhileProcessing(LLIApplication lastApplicationSnapshot) throws Exception{
	}
	
	@Transactional
	public void completeApplication() throws Exception {
	}
	public String[] getDocuments() {
		return documents;
	}
	public void setDocuments(String[] documents) {
		this.documents = documents;
	}
	
	
	
}
