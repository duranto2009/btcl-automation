package lli.Application.ShiftBandwidth;

import java.lang.reflect.Type;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import lli.Application.LLIApplication;
import util.ModifiedSqlGenerator;

public class LLIShiftBandwidthApplicationDeserializer implements JsonDeserializer<LLIShiftBandwidthApplication>{

	@Override
	public LLIShiftBandwidthApplication deserialize(JsonElement jsonElement, Type arg1, JsonDeserializationContext context) throws JsonParseException {
		LLIShiftBandwidthApplication lliShiftBandwidthApplication = new LLIShiftBandwidthApplication();
		
		//Receive JSON
		JsonObject jsonObject = jsonElement.getAsJsonObject();
		
		//Deserialize Specific LLI New Connection Application
		lliShiftBandwidthApplication.setExtendedApplicationID(jsonObject.get("extendedApplicationID") != null ? jsonObject.get("extendedApplicationID").getAsLong() : 0);
		
		lliShiftBandwidthApplication.setConnectionID(jsonObject.get("connectionID").getAsLong());
		lliShiftBandwidthApplication.setDestinationConnectionID(jsonObject.get("destinationConnectionID").getAsLong());
		lliShiftBandwidthApplication.setBandwidth(jsonObject.get("bandwidth").getAsDouble());
		lliShiftBandwidthApplication.setDescription(jsonObject.get("description").getAsString());
		lliShiftBandwidthApplication.setSuggestedDate(jsonObject.get("suggestedDate").getAsLong());
		
		//Deserialize Common LLI Application
		LLIApplication lliApplication = context.deserialize(jsonElement, LLIApplication.class);
		ModifiedSqlGenerator.populateObjectFromOtherObject(lliApplication, lliShiftBandwidthApplication, LLIApplication.class);
		
		return lliShiftBandwidthApplication;
	}



}
