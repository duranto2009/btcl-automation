package lli.Application;

import java.lang.reflect.Type;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

public class LLIApplicationDeserializer implements JsonDeserializer<LLIApplication>{

	@Override
	public LLIApplication deserialize(JsonElement jsonElement, Type arg1, JsonDeserializationContext context) throws JsonParseException {
		LLIApplication lliApplication = new LLIApplication();
		
		//Receive JSON
		JsonObject jsonObject = jsonElement.getAsJsonObject();
		
		//Deserialize Common LLI Application
		lliApplication.setApplicationID(jsonObject.get("applicationID") != null ? jsonObject.get("applicationID").getAsLong() : 0);
		lliApplication.setClientID(jsonObject.get("client").getAsJsonObject().get("ID").getAsLong());
		lliApplication.setUserID(jsonObject.get("userID") != null ? jsonObject.get("userID").getAsLong() : null);
		lliApplication.setSubmissionDate(jsonObject.get("submissionDate") != null ? jsonObject.get("submissionDate").getAsLong() : 0);
		lliApplication.setStatus(jsonObject.get("status") != null ? jsonObject.get("status").getAsJsonObject().get("ID").getAsInt() : 0);
		lliApplication.setContent(jsonObject.get("content") != null ? jsonObject.get("content").getAsString() : "");
		lliApplication.setDemandNoteID(jsonObject.get("demandNoteID") != null ? jsonObject.get("demandNoteID").getAsLong() : null);
		lliApplication.setApplicationType(jsonObject.get("applicationType") != null ? jsonObject.get("applicationType").getAsJsonObject().get("ID").getAsInt() : 0);
		
		lliApplication.setComment(jsonObject.get("comment")!= null ? jsonObject.get("comment").getAsString() : "");
		lliApplication.setDescription(jsonObject.get("description")!= null ? jsonObject.get("description").getAsString() : "");
		lliApplication.setRequestForCorrectionComment(jsonObject.get("requestForCorrectionComment")!= null ? jsonObject.get("requestForCorrectionComment").getAsString() : "");
		lliApplication.setRejectionComment(jsonObject.get("rejectionComment")!=null ? jsonObject.get("rejectionComment").getAsString() : null);
		return lliApplication;
	}

}
