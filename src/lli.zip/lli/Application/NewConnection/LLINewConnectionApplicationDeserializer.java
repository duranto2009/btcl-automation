package lli.Application.NewConnection;

import java.lang.reflect.Type;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import lli.Application.LLIApplication;
import util.ModifiedSqlGenerator;

public class LLINewConnectionApplicationDeserializer implements JsonDeserializer<LLINewConnectionApplication>{

	@Override
	public LLINewConnectionApplication deserialize(JsonElement jsonElement, Type arg1, JsonDeserializationContext context) throws JsonParseException {
		LLINewConnectionApplication lliNewConnectionApplication = new LLINewConnectionApplication();
		
		//Receive JSON
		JsonObject jsonObject = jsonElement.getAsJsonObject();
		
		//Deserialize Specific LLI New Connection Application
		lliNewConnectionApplication.setExtendedApplicationID(jsonObject.get("extendedApplicationID") != null ? jsonObject.get("extendedApplicationID").getAsLong() : 0);

		lliNewConnectionApplication.setBandwidth(jsonObject.get("bandwidth").getAsDouble());
		lliNewConnectionApplication.setConnectionType(jsonObject.get("connectionType").getAsJsonObject().get("ID").getAsInt());
		lliNewConnectionApplication.setAddress(jsonObject.get("address").getAsString());
		lliNewConnectionApplication.setLoopProvider((jsonObject.get("loopProvider").getAsJsonObject().get("ID").getAsInt()));
		lliNewConnectionApplication.setDuration(jsonObject.get("duration") != null ? jsonObject.get("duration").getAsInt() : 0);

		lliNewConnectionApplication.setSuggestedDate(jsonObject.get("suggestedDate").getAsLong());
		
		//Deserialize Common LLI Application
		LLIApplication lliApplication = context.deserialize(jsonElement, LLIApplication.class);
		ModifiedSqlGenerator.populateObjectFromOtherObject(lliApplication, lliNewConnectionApplication, LLIApplication.class);
		
		return lliNewConnectionApplication;
	}



}
