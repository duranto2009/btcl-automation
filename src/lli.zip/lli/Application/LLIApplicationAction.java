package lli.Application;


import java.util.List;
import javax.servlet.http.HttpServletRequest;
import com.google.gson.GsonBuilder;

import annotation.ForwardedAction;
import annotation.JsonPost;
import common.RequestFailureException;
import lli.LLIActionButton;
import lli.LLIConnectionDeserializer;
import lli.LLIConnectionInstance;
import lli.LLIConnectionInstanceSerizalizer;
import lli.LLIConnectionService;
import lli.LLILocalLoop;
import lli.LLILocalLoopDeserializer;
import lli.LLILocalLoopSerizalizer;
import lli.LLIOffice;
import lli.LLIOfficeDeserializer;
import lli.LLIOfficeSerizalizer;
import lli.Application.AdditionalConnectionAddress.LLIAdditionalConnectionAddressApplication;
import lli.Application.AdditionalConnectionAddress.LLIAdditionalConnectionAddressApplicationDeserializer;
import lli.Application.AdditionalConnectionAddress.LLIAdditionalConnectionAddressApplicationSerializer;
import lli.Application.AdditionalIP.LLIAdditionalIPApplication;
import lli.Application.AdditionalLocalLoop.LLIAdditionalLocalLoopApplication;
import lli.Application.AdditionalLocalLoop.LLIAdditionalLocalLoopApplicationDeserializer;
import lli.Application.AdditionalLocalLoop.LLIAdditionalLocalLoopApplicationSerializer;
import lli.Application.AdditionalPort.LLIAdditionalPortApplication;
import lli.Application.AdditionalPort.LLIAdditionalPortApplicationDeserializer;
import lli.Application.AdditionalPort.LLIAdditionalPortApplicationSerializer;
import lli.Application.BreakLongTerm.LLIBreakLongTermApplication;
import lli.Application.BreakLongTerm.LLIBreakLongTermApplicationDeserializer;
import lli.Application.BreakLongTerm.LLIBreakLongTermApplicationSerializer;
import lli.Application.ChangeBillingAddress.LLIChangeBillingAddressApplication;
import lli.Application.ChangeBillingAddress.LLIChangeBillingAddressApplicationDeserializer;
import lli.Application.ChangeBillingAddress.LLIChangeBillingAddressApplicationSerializer;
import lli.Application.ChangeOwnership.LLIChangeOwnershipApplication;
import lli.Application.ChangeOwnership.LLIChangeOwnershipApplicationDeserializer;
import lli.Application.ChangeOwnership.LLIChangeOwnershipApplicationSerializer;
import lli.Application.CloseConnection.LLICloseConnectionApplication;
import lli.Application.CloseConnection.LLICloseConnectionApplicationDeserializer;
import lli.Application.CloseConnection.LLICloseConnectionApplicationSerializer;
import lli.Application.DowngradeBandwidth.LLIDowngradeBandwidthApplication;
import lli.Application.DowngradeBandwidth.LLIDowngradeBandwidthApplicationDeserializer;
import lli.Application.DowngradeBandwidth.LLIDowngradeBandwidthApplicationSerializer;
import lli.Application.NewConnection.LLINewConnectionApplication;
import lli.Application.NewConnection.LLINewConnectionApplicationDeserializer;
import lli.Application.NewConnection.LLINewConnectionApplicationSerializer;
import lli.Application.NewLongTerm.LLINewLongTermApplication;
import lli.Application.NewLongTerm.LLINewLongTermApplicationDeserializer;
import lli.Application.NewLongTerm.LLINewLongTermApplicationSerializer;
import lli.Application.Reconnect.LLIReconnectApplication;
import lli.Application.Reconnect.LLIReconnectApplicationDeserializer;
import lli.Application.Reconnect.LLIReconnectApplicationSerializer;
import lli.Application.ReleaseConnectionAddress.LLIReleaseConnectionAddressApplication;
import lli.Application.ReleaseConnectionAddress.LLIReleaseConnectionAddressApplicationDeserializer;
import lli.Application.ReleaseConnectionAddress.LLIReleaseConnectionAddressApplicationSerializer;
import lli.Application.ReleaseIP.LLIReleaseIPApplication;
import lli.Application.ReleaseLocalLoop.LLIReleaseLocalLoopApplication;
import lli.Application.ReleaseLocalLoop.LLIReleaseLocalLoopApplicationDeserializer;
import lli.Application.ReleaseLocalLoop.LLIReleaseLocalLoopApplicationSerializer;
import lli.Application.ReleasePort.LLIReleasePortApplication;
import lli.Application.ReleasePort.LLIReleasePortApplicationDeserializer;
import lli.Application.ReleasePort.LLIReleasePortApplicationSerializer;
import lli.Application.ShiftAddress.LLIShiftAddressApplication;
import lli.Application.ShiftAddress.LLIShiftAddressApplicationDeserializer;
import lli.Application.ShiftAddress.LLIShiftAddressApplicationSerializer;
import lli.Application.ShiftBandwidth.LLIShiftBandwidthApplication;
import lli.Application.ShiftBandwidth.LLIShiftBandwidthApplicationDeserializer;
import lli.Application.ShiftBandwidth.LLIShiftBandwidthApplicationSerializer;
import lli.Application.ShiftPop.LLIShiftPopApplication;
import lli.Application.ShiftPop.LLIShiftPopApplicationDeserializer;
import lli.Application.ShiftPop.LLIShiftPopApplicationSerializer;
import lli.Application.TemporaryUpgradeBandwidth.LLITemporaryUpgradeBandwidthApplication;
import lli.Application.TemporaryUpgradeBandwidth.LLITemporaryUpgradeBandwidthApplicationDeserializer;
import lli.Application.TemporaryUpgradeBandwidth.LLITemporaryUpgradeBandwidthApplicationSerializer;
import lli.Application.upgradeBandwidth.LLIUpgradeBandwidthApplication;
import lli.Application.upgradeBandwidth.LLIUpgradeBandwidthApplicationDeserializer;
import lli.Application.upgradeBandwidth.LLIUpgradeBandwidthApplicationSerializer;
import login.LoginDTO;
import requestMapping.AnnotatedRequestMappingAction;
import requestMapping.RequestParameter;
import requestMapping.Service;
import requestMapping.annotation.ActionRequestMapping;
import requestMapping.annotation.RequestMapping;
import requestMapping.annotation.RequestMethod;
import sessionmanager.SessionConstants;
import util.RecordNavigationManager;

@ActionRequestMapping("lli/application")
public class LLIApplicationAction extends AnnotatedRequestMappingAction{
	
	@Service
	LLIApplicationService lliApplicationService ;
	@Service
	LLIConnectionService lliConnectionService ;
	
	@Override
	public GsonBuilder getGsonBuilder(){
		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder
			//LLI Application
			.registerTypeAdapter(LLIApplication.class, new LLIApplicationSerializer())
			.registerTypeAdapter(LLIApplication.class, new LLIApplicationDeserializer())
			//1
			.registerTypeAdapter(LLINewConnectionApplication.class, new LLINewConnectionApplicationSerializer())
			.registerTypeAdapter(LLINewConnectionApplication.class, new LLINewConnectionApplicationDeserializer())
			//2
			.registerTypeAdapter(LLIUpgradeBandwidthApplication.class, new LLIUpgradeBandwidthApplicationSerializer())
			.registerTypeAdapter(LLIUpgradeBandwidthApplication.class, new LLIUpgradeBandwidthApplicationDeserializer())
			//3
			.registerTypeAdapter(LLIDowngradeBandwidthApplication.class, new LLIDowngradeBandwidthApplicationSerializer())
			.registerTypeAdapter(LLIDowngradeBandwidthApplication.class, new LLIDowngradeBandwidthApplicationDeserializer())
			//4
			.registerTypeAdapter(LLITemporaryUpgradeBandwidthApplication.class, new LLITemporaryUpgradeBandwidthApplicationSerializer())
			.registerTypeAdapter(LLITemporaryUpgradeBandwidthApplication.class, new LLITemporaryUpgradeBandwidthApplicationDeserializer())
			//5
			.registerTypeAdapter(LLIAdditionalPortApplication.class, new LLIAdditionalPortApplicationSerializer())
			.registerTypeAdapter(LLIAdditionalPortApplication.class, new LLIAdditionalPortApplicationDeserializer())	
			//6
			.registerTypeAdapter(LLIReleasePortApplication.class, new LLIReleasePortApplicationSerializer())
			.registerTypeAdapter(LLIReleasePortApplication.class, new LLIReleasePortApplicationDeserializer())
			//7
			.registerTypeAdapter(LLIAdditionalLocalLoopApplication.class, new LLIAdditionalLocalLoopApplicationSerializer())
			.registerTypeAdapter(LLIAdditionalLocalLoopApplication.class, new LLIAdditionalLocalLoopApplicationDeserializer())
			//8
			.registerTypeAdapter(LLIReleaseLocalLoopApplication.class, new LLIReleaseLocalLoopApplicationSerializer())
			.registerTypeAdapter(LLIReleaseLocalLoopApplication.class, new LLIReleaseLocalLoopApplicationDeserializer())
			
			//11
			.registerTypeAdapter(LLIAdditionalConnectionAddressApplication.class, new LLIAdditionalConnectionAddressApplicationSerializer())
			.registerTypeAdapter(LLIAdditionalConnectionAddressApplication.class, new LLIAdditionalConnectionAddressApplicationDeserializer())
			//12
			.registerTypeAdapter(LLIShiftAddressApplication.class, new LLIShiftAddressApplicationSerializer())
			.registerTypeAdapter(LLIShiftAddressApplication.class, new LLIShiftAddressApplicationDeserializer())
			//13
			.registerTypeAdapter(LLIReleaseConnectionAddressApplication.class, new LLIReleaseConnectionAddressApplicationSerializer())
			.registerTypeAdapter(LLIReleaseConnectionAddressApplication.class, new LLIReleaseConnectionAddressApplicationDeserializer())
			//14
			.registerTypeAdapter(LLIShiftPopApplication.class, new LLIShiftPopApplicationSerializer())
			.registerTypeAdapter(LLIShiftPopApplication.class, new LLIShiftPopApplicationDeserializer())
			//15
			.registerTypeAdapter(LLINewLongTermApplication.class, new LLINewLongTermApplicationSerializer())
			.registerTypeAdapter(LLINewLongTermApplication.class, new LLINewLongTermApplicationDeserializer())
			//16
			.registerTypeAdapter(LLIBreakLongTermApplication.class, new LLIBreakLongTermApplicationSerializer())
			.registerTypeAdapter(LLIBreakLongTermApplication.class, new LLIBreakLongTermApplicationDeserializer())			
			//17
			.registerTypeAdapter(LLIShiftBandwidthApplication.class, new LLIShiftBandwidthApplicationSerializer())
			.registerTypeAdapter(LLIShiftBandwidthApplication.class, new LLIShiftBandwidthApplicationDeserializer())			
			//18
			.registerTypeAdapter(LLIChangeOwnershipApplication.class, new LLIChangeOwnershipApplicationSerializer())
			.registerTypeAdapter(LLIChangeOwnershipApplication.class, new LLIChangeOwnershipApplicationDeserializer())	
			//19
			.registerTypeAdapter(LLIReconnectApplication.class, new LLIReconnectApplicationDeserializer())
			.registerTypeAdapter(LLIReconnectApplication.class, new LLIReconnectApplicationSerializer())
			//20
			.registerTypeAdapter(LLIChangeBillingAddressApplication.class, new LLIChangeBillingAddressApplicationSerializer())
			.registerTypeAdapter(LLIChangeBillingAddressApplication.class, new LLIChangeBillingAddressApplicationDeserializer())
			//21
			.registerTypeAdapter(LLICloseConnectionApplication.class, new LLICloseConnectionApplicationSerializer())
			.registerTypeAdapter(LLICloseConnectionApplication.class, new LLICloseConnectionApplicationDeserializer())	
			
			//Connection Instance
			.registerTypeAdapter(LLIConnectionInstance.class, new LLIConnectionInstanceSerizalizer())
			.registerTypeAdapter(LLIOffice.class, new LLIOfficeSerizalizer())
			.registerTypeAdapter(LLILocalLoop.class, new LLILocalLoopSerizalizer())
			.registerTypeAdapter(LLIConnectionInstance.class, new LLIConnectionDeserializer())
			.registerTypeAdapter(LLIOffice.class, new LLIOfficeDeserializer())
			.registerTypeAdapter(LLILocalLoop.class, new LLILocalLoopDeserializer())
			;
		return gsonBuilder;
	}
	
	
	/*Application Independent of ApplicationType Begins*/
	//Application View Page
	@ForwardedAction
	@RequestMapping(mapping="/view", requestMethod=RequestMethod.All)
	public String getApplicationView(@RequestParameter("id") long applicationID) throws Exception{
		return lliApplicationService.viewApplicationMappingForwardName(applicationID);
	}
	//Application Search Page
	@ForwardedAction
	@RequestMapping(mapping="/search", requestMethod=RequestMethod.All)
	public String searchLLIConnection(LoginDTO loginDTO, HttpServletRequest request) throws Exception {
		RecordNavigationManager rnManager = new RecordNavigationManager(SessionConstants.NAV_LLI_APPLICATION, request,
				lliApplicationService, SessionConstants.VIEW_LLI_APPLICATION, SessionConstants.SEARCH_LLI_APPLICATION);
		rnManager.doJob(loginDTO);
		return "lli-application-search";
	}
	//Get Application Data by Application ID
	@RequestMapping(mapping="/new-connection-get", requestMethod=RequestMethod.All)
	public LLIApplication getNewConnectionData(@RequestParameter("id") long applicationID) throws Exception{
		return lliApplicationService.getLLIApplicationByApplicationID(applicationID);
	}
	
	//Get Application Data by Demand Note ID
	@RequestMapping(mapping="/get-app", requestMethod=RequestMethod.GET)
	public LLIApplication getLLIApplication(@RequestParameter("dnID") long id) throws Exception {
		LLIApplication lliApplication = lliApplicationService.getLLIApplicationByDemandNoteID(id);
		if(lliApplication == null) {
			throw new RequestFailureException("No Application Found with application ID " + id);
		}
		return lliApplication;
		
	}
	/*Application Independent of ApplicationType Ends*/
	
	
	/*Application Action Begins*/
	@RequestMapping(mapping="/get-actions", requestMethod=RequestMethod.All)
	public List<LLIActionButton> getActions(@RequestParameter("id") long applicationID, LoginDTO loginDTO) throws Exception{
		return lliApplicationService.getAvailableActions(applicationID, loginDTO);
	}
	@RequestMapping(mapping="/application-verify", requestMethod=RequestMethod.All)
	public void verifyApplication(@RequestParameter("id") long applicationID) throws Exception{
		lliApplicationService.verifyApplication(applicationID);
	}
	@ForwardedAction
	@RequestMapping(mapping="/application-request-for-correction", requestMethod=RequestMethod.All)
	public String requestForCorrectionApplication(@RequestParameter("id") long applicationID) throws Exception{
		//lliApplicationService.requestForCorrectionApplication(applicationID);
		return "lli-application-request-for-correction";
	}
	@ForwardedAction
	@RequestMapping(mapping="/application-edit", requestMethod=RequestMethod.All)
	public String editApplication(@RequestParameter("id") long applicationID) throws Exception{
		return lliApplicationService.editApplicationMappingForwardName(applicationID);
	}
	@ForwardedAction
	@RequestMapping(mapping="/application-reject", requestMethod=RequestMethod.All)
	public String rejectApplication(@RequestParameter("id") long applicationID) throws Exception{
		//lliApplicationService.rejectApplication(applicationID);
		return "lli-application-reject";
	}
	@ForwardedAction
	@RequestMapping(mapping="/application-process", requestMethod=RequestMethod.All)
	public String processApplication(@RequestParameter("id") long applicationID) throws Exception{
		return lliApplicationService.processApplicationMappingForwardName(applicationID);
	}
	@RequestMapping(mapping="/application-finalize", requestMethod=RequestMethod.All)
	public void finalizeApplication(@RequestParameter("id") long applicationID) throws Exception{
		lliApplicationService.finalizeApplication(applicationID);
	}
	@ForwardedAction
	@RequestMapping(mapping="/application-complete-request", requestMethod=RequestMethod.All)
	public String completeRequestApplication(@RequestParameter("id") long applicationID) throws Exception{
		return lliApplicationService.completeApplicationMappingForwardName(applicationID);
	}
	/*Application Action Ends*/
	
	
	
	
	
	
	/* ============================================================================================================== */
	/* ============================================================================================================== */
	/* ============================================================================================================== */
	/*Application New Connection Begins*/
	@ForwardedAction @RequestMapping(mapping="/new-connection", requestMethod=RequestMethod.GET)
	public String getNewConnectionApplicationForm() throws Exception {
		return "lli-application-new-connection";
	}
	@JsonPost @RequestMapping(mapping="/new-connection", requestMethod=RequestMethod.POST)
	public long postNewConnectionApplicationForm(@RequestParameter(isJsonBody = true,value = "application") LLINewConnectionApplication lliNewConnectionApplication, LoginDTO loginDTO, HttpServletRequest request) throws Exception{
		if(loginDTO.getIsAdmin()) lliNewConnectionApplication.setUserID(loginDTO.getUserID());
		lliNewConnectionApplication.setDocuments(request.getParameterValues("documents"));
		lliApplicationService.insertApplication(lliNewConnectionApplication,loginDTO);
		return lliNewConnectionApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/new-connection-edit", requestMethod=RequestMethod.POST)
	public long postNewConnectionEdit(@RequestParameter(isJsonBody = true,value = "application") LLINewConnectionApplication lliNewConnectionApplication) throws Exception{
		lliApplicationService.editApplication(lliNewConnectionApplication);
		return lliNewConnectionApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/new-connection-process", requestMethod=RequestMethod.POST)
	public void postNewConnectionProcess(@RequestParameter(isJsonBody = true,value = "application") LLINewConnectionApplication lliNewConnectionApplication) throws Exception{
		lliApplicationService.processApplication(lliNewConnectionApplication);
	}
	@JsonPost @RequestMapping(mapping="/new-connection-complete", requestMethod=RequestMethod.POST)
	public void postNewConnectionCompletion(@RequestParameter(isJsonBody = true,value = "application") LLINewConnectionApplication lliNewConnectionApplication) throws Exception{
		lliApplicationService.completeApplication(lliNewConnectionApplication);
	}
	/*Application New Connection Ends*/
	/* ============================================================================================================== */
	/*Application Upgrade Bandwidth Begins*/
	@ForwardedAction @RequestMapping(mapping="/upgrade-bandwidth", requestMethod=RequestMethod.GET)
	public String getUpgradeBandwidthApplicationForm() throws Exception {
		return "lli-application-upgrade-bandwidth";
	}
	@JsonPost @RequestMapping(mapping="/upgrade-bandwidth", requestMethod=RequestMethod.POST)
	public long postUpgradeBandwidthApplicationForm(@RequestParameter(isJsonBody = true,value = "application") LLIUpgradeBandwidthApplication lliUpgradeBandwidthApplication, LoginDTO loginDTO) throws Exception{
		if(loginDTO.getIsAdmin()) lliUpgradeBandwidthApplication.setUserID(loginDTO.getUserID());
		lliApplicationService.insertApplication(lliUpgradeBandwidthApplication,loginDTO);
		return lliUpgradeBandwidthApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/upgrade-bandwidth-edit", requestMethod=RequestMethod.POST)
	public long postUpgradeBandwidthEdit(@RequestParameter(isJsonBody = true,value = "application") LLIUpgradeBandwidthApplication lliUpgradeBandwidthApplication) throws Exception{
		lliApplicationService.editApplication(lliUpgradeBandwidthApplication);
		return lliUpgradeBandwidthApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/upgrade-bandwidth-process", requestMethod=RequestMethod.POST)
	public void postUpgradeBandwidthProcess(@RequestParameter(isJsonBody = true,value = "application") LLIUpgradeBandwidthApplication lliUpgradeBandwidthApplication) throws Exception{
		lliApplicationService.processApplication(lliUpgradeBandwidthApplication);
	}
	@JsonPost @RequestMapping(mapping="/upgrade-bandwidth-complete", requestMethod=RequestMethod.POST)
	public void postUpgradeBandwidthCompletion(@RequestParameter(isJsonBody = true,value = "application") LLIUpgradeBandwidthApplication lliUpgradeBandwidthApplication) throws Exception{
		lliApplicationService.completeApplication(lliUpgradeBandwidthApplication);
	}
	/*Application Upgrade Bandwidth Ends*/
	/* ============================================================================================================== */
	/*Application Downgrade Bandwidth Begins*/
	@ForwardedAction @RequestMapping(mapping="/downgrade-bandwidth", requestMethod=RequestMethod.GET)
	public String getDowngradeBandwidthApplicationForm() throws Exception {
		return "lli-application-downgrade-bandwidth";
	}
	@JsonPost @RequestMapping(mapping="/downgrade-bandwidth", requestMethod=RequestMethod.POST)
	public long postDowngradeBandwidthApplicationForm(@RequestParameter(isJsonBody = true,value = "application") LLIDowngradeBandwidthApplication extendedLLIApplication, LoginDTO loginDTO) throws Exception{
		if(loginDTO.getIsAdmin()) extendedLLIApplication.setUserID(loginDTO.getUserID());
		lliApplicationService.insertApplication(extendedLLIApplication,loginDTO);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/downgrade-bandwidth-edit", requestMethod=RequestMethod.POST)
	public long postDowngradeBandwidthEdit(@RequestParameter(isJsonBody = true,value = "application") LLIDowngradeBandwidthApplication extendedLLIApplication) throws Exception{
		lliApplicationService.editApplication(extendedLLIApplication);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/downgrade-bandwidth-process", requestMethod=RequestMethod.POST)
	public void postDowngradeBandwidthProcess(@RequestParameter(isJsonBody = true,value = "application") LLIDowngradeBandwidthApplication extendedLLIApplication) throws Exception{
		lliApplicationService.processApplication(extendedLLIApplication);
	}
	@JsonPost @RequestMapping(mapping="/downgrade-bandwidth-complete", requestMethod=RequestMethod.POST)
	public void postDowngradeBandwidthCompletion(@RequestParameter(isJsonBody = true,value = "application") LLIDowngradeBandwidthApplication extendedLLIApplication) throws Exception{
		lliApplicationService.completeApplication(extendedLLIApplication);
	}
	/*Application Downgrade Bandwidth Ends*/
	/* ============================================================================================================== */
	/*Application TemporaryUpgrade Bandwidth Begins*/
	@ForwardedAction @RequestMapping(mapping="/temporary-upgrade-bandwidth", requestMethod=RequestMethod.GET)
	public String getTemporaryUpgradeBandwidthApplicationForm() throws Exception {
		return "lli-application-temporary-upgrade-bandwidth";
	}
	@JsonPost @RequestMapping(mapping="/temporary-upgrade-bandwidth", requestMethod=RequestMethod.POST)
	public long postTemporaryUpgradeBandwidthApplicationForm(@RequestParameter(isJsonBody = true,value = "application") LLITemporaryUpgradeBandwidthApplication extendedLLIApplication, LoginDTO loginDTO) throws Exception{
		if(loginDTO.getIsAdmin()) extendedLLIApplication.setUserID(loginDTO.getUserID());
		lliApplicationService.insertApplication(extendedLLIApplication,loginDTO);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/temporary-upgrade-bandwidth-edit", requestMethod=RequestMethod.POST)
	public long postTemporaryUpgradeBandwidthEdit(@RequestParameter(isJsonBody = true,value = "application") LLITemporaryUpgradeBandwidthApplication extendedLLIApplication) throws Exception{
		lliApplicationService.editApplication(extendedLLIApplication);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/temporary-upgrade-bandwidth-process", requestMethod=RequestMethod.POST)
	public void postTemporaryUpgradeBandwidthProcess(@RequestParameter(isJsonBody = true,value = "application") LLITemporaryUpgradeBandwidthApplication extendedLLIApplication) throws Exception{
		lliApplicationService.processApplication(extendedLLIApplication);
	}
	@JsonPost @RequestMapping(mapping="/temporary-upgrade-bandwidth-complete", requestMethod=RequestMethod.POST)
	public void postTemporaryUpgradeBandwidthCompletion(@RequestParameter(isJsonBody = true,value = "application") LLITemporaryUpgradeBandwidthApplication extendedLLIApplication) throws Exception{
		lliApplicationService.completeApplication(extendedLLIApplication);
	}
	/*Application TemporaryUpgrade Bandwidth Ends*/
	/* ============================================================================================================== */
	/*Application Additional Port Begins*/
	@ForwardedAction @RequestMapping(mapping="/additional-port", requestMethod=RequestMethod.GET)
	public String getAdditionalPortApplicationForm() throws Exception {
		return "lli-application-additional-port";
	}
	@JsonPost @RequestMapping(mapping="/additional-port", requestMethod=RequestMethod.POST)
	public long postAdditionalPortApplicationForm(@RequestParameter(isJsonBody = true,value = "application") LLIAdditionalPortApplication extendedLLIApplication, LoginDTO loginDTO) throws Exception{
		if(loginDTO.getIsAdmin()) extendedLLIApplication.setUserID(loginDTO.getUserID());
		lliApplicationService.insertApplication(extendedLLIApplication,loginDTO);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/additional-port-edit", requestMethod=RequestMethod.POST)
	public long postAdditionalPortEdit(@RequestParameter(isJsonBody = true,value = "application") LLIAdditionalPortApplication extendedLLIApplication) throws Exception{
		lliApplicationService.editApplication(extendedLLIApplication);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/additional-port-process", requestMethod=RequestMethod.POST)
	public void postAdditionalPortProcess(@RequestParameter(isJsonBody = true,value = "application") LLIAdditionalPortApplication extendedLLIApplication) throws Exception{
		lliApplicationService.processApplication(extendedLLIApplication);
	}
	@JsonPost @RequestMapping(mapping="/additional-port-complete", requestMethod=RequestMethod.POST)
	public void postAdditionalPortCompletion(@RequestParameter(isJsonBody = true,value = "application") LLIAdditionalPortApplication extendedLLIApplication) throws Exception{
		lliApplicationService.completeApplication(extendedLLIApplication);
	}
	/*Application Additional Port Ends*/
	/* ============================================================================================================== */
	/*Application Release Port Begins*/
	@ForwardedAction @RequestMapping(mapping="/release-port", requestMethod=RequestMethod.GET)
	public String getReleasePortApplicationForm() throws Exception {
		return "lli-application-release-port";
	}
	@JsonPost @RequestMapping(mapping="/release-port", requestMethod=RequestMethod.POST)
	public long postReleasePortApplicationForm(@RequestParameter(isJsonBody = true,value = "application") LLIReleasePortApplication extendedLLIApplication, LoginDTO loginDTO) throws Exception{
		if(loginDTO.getIsAdmin()) extendedLLIApplication.setUserID(loginDTO.getUserID());
		lliApplicationService.insertApplication(extendedLLIApplication,loginDTO);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/release-port-edit", requestMethod=RequestMethod.POST)
	public long postReleasePortEdit(@RequestParameter(isJsonBody = true,value = "application") LLIReleasePortApplication extendedLLIApplication) throws Exception{
		lliApplicationService.editApplication(extendedLLIApplication);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/release-port-process", requestMethod=RequestMethod.POST)
	public void postReleasePortProcess(@RequestParameter(isJsonBody = true,value = "application") LLIReleasePortApplication extendedLLIApplication) throws Exception{
		lliApplicationService.processApplication(extendedLLIApplication);
	}
	@JsonPost @RequestMapping(mapping="/release-port-complete", requestMethod=RequestMethod.POST)
	public void postReleasePortCompletion(@RequestParameter(isJsonBody = true,value = "application") LLIReleasePortApplication extendedLLIApplication) throws Exception{
		lliApplicationService.completeApplication(extendedLLIApplication);
	}
	/*Application Release Port Ends*/
	/* ============================================================================================================== */
	/*Application Additional Local Loop Begins*/
	@ForwardedAction @RequestMapping(mapping="/additional-local-loop", requestMethod=RequestMethod.GET)
	public String getAdditionalLocalLoopApplicationForm() throws Exception {
		return "lli-application-additional-local-loop";
	}
	@JsonPost @RequestMapping(mapping="/additional-local-loop", requestMethod=RequestMethod.POST)
	public long postAdditionalLocalLoopApplicationForm(@RequestParameter(isJsonBody = true,value = "application") LLIAdditionalLocalLoopApplication extendedLLIApplication, LoginDTO loginDTO) throws Exception{
		if(loginDTO.getIsAdmin()) extendedLLIApplication.setUserID(loginDTO.getUserID());
		lliApplicationService.insertApplication(extendedLLIApplication,loginDTO);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/additional-local-loop-edit", requestMethod=RequestMethod.POST)
	public long postAdditionalLocalLoopEdit(@RequestParameter(isJsonBody = true,value = "application") LLIAdditionalLocalLoopApplication extendedLLIApplication) throws Exception{
		lliApplicationService.editApplication(extendedLLIApplication);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/additional-local-loop-process", requestMethod=RequestMethod.POST)
	public void postAdditionalLocalLoopProcess(@RequestParameter(isJsonBody = true,value = "application") LLIAdditionalLocalLoopApplication extendedLLIApplication) throws Exception{
		lliApplicationService.processApplication(extendedLLIApplication);
	}
	@JsonPost @RequestMapping(mapping="/additional-local-loop-complete", requestMethod=RequestMethod.POST)
	public void postAdditionalLocalLoopCompletion(@RequestParameter(isJsonBody = true,value = "application") LLIAdditionalLocalLoopApplication extendedLLIApplication) throws Exception{
		lliApplicationService.completeApplication(extendedLLIApplication);
	}
	/*Application Additional Local Loop Ends*/
	/* ============================================================================================================== */
	/*Application Release Local Loop Begins*/
	@ForwardedAction @RequestMapping(mapping="/release-local-loop", requestMethod=RequestMethod.GET)
	public String getReleaseLocalLoopApplicationForm() throws Exception {
		return "lli-application-release-local-loop";
	}
	@JsonPost @RequestMapping(mapping="/release-local-loop", requestMethod=RequestMethod.POST)
	public long postReleaseLocalLoopApplicationForm(@RequestParameter(isJsonBody = true,value = "application") LLIReleaseLocalLoopApplication extendedLLIApplication, LoginDTO loginDTO) throws Exception{
		if(loginDTO.getIsAdmin()) extendedLLIApplication.setUserID(loginDTO.getUserID());
		lliApplicationService.insertApplication(extendedLLIApplication,loginDTO);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/release-local-loop-edit", requestMethod=RequestMethod.POST)
	public long postReleaseLocalLoopEdit(@RequestParameter(isJsonBody = true,value = "application") LLIReleaseLocalLoopApplication extendedLLIApplication) throws Exception{
		lliApplicationService.editApplication(extendedLLIApplication);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/release-local-loop-process", requestMethod=RequestMethod.POST)
	public void postReleaseLocalLoopProcess(@RequestParameter(isJsonBody = true,value = "application") LLIReleaseLocalLoopApplication extendedLLIApplication) throws Exception{
		lliApplicationService.processApplication(extendedLLIApplication);
	}
	@JsonPost @RequestMapping(mapping="/release-local-loop-complete", requestMethod=RequestMethod.POST)
	public void postReleaseLocalLoopCompletion(@RequestParameter(isJsonBody = true,value = "application") LLIReleaseLocalLoopApplication extendedLLIApplication) throws Exception{
		lliApplicationService.completeApplication(extendedLLIApplication);
	}
	/*Application Release Local Loop Ends*/
	/* ============================================================================================================== */
	/*Application Additional IP Begins*/
	@ForwardedAction @RequestMapping(mapping="/additional-ip", requestMethod=RequestMethod.GET)
	public String getAdditionalIPApplicationForm() throws Exception {
		return "lli-application-additional-ip";
	}
	@JsonPost @RequestMapping(mapping="/additional-ip", requestMethod=RequestMethod.POST)
	public long postAdditionalIPApplicationForm(@RequestParameter(isJsonBody = true,value = "application") LLIAdditionalIPApplication extendedLLIApplication, LoginDTO loginDTO) throws Exception{
		if(loginDTO.getIsAdmin()) extendedLLIApplication.setUserID(loginDTO.getUserID());
		lliApplicationService.insertApplication(extendedLLIApplication,loginDTO);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/additional-ip-edit", requestMethod=RequestMethod.POST)
	public long postAdditionalIPEdit(@RequestParameter(isJsonBody = true,value = "application") LLIAdditionalIPApplication extendedLLIApplication) throws Exception{
		lliApplicationService.editApplication(extendedLLIApplication);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/additional-ip-process", requestMethod=RequestMethod.POST)
	public void postAdditionalIPProcess(@RequestParameter(isJsonBody = true,value = "application") LLIAdditionalIPApplication extendedLLIApplication) throws Exception{
		lliApplicationService.processApplication(extendedLLIApplication);
	}
	@JsonPost @RequestMapping(mapping="/additional-ip-complete", requestMethod=RequestMethod.POST)
	public void postAdditionalIPCompletion(@RequestParameter(isJsonBody = true,value = "application") LLIAdditionalIPApplication extendedLLIApplication) throws Exception{
		lliApplicationService.completeApplication(extendedLLIApplication);
	}
	/*Application Additional IP Ends*/
	/* ============================================================================================================== */
	/*Application Release IP Begins*/
	@ForwardedAction @RequestMapping(mapping="/release-ip", requestMethod=RequestMethod.GET)
	public String getReleaseIPApplicationForm() throws Exception {
		return "lli-application-release-ip";
	}
	@JsonPost @RequestMapping(mapping="/release-ip", requestMethod=RequestMethod.POST)
	public long postReleaseIPApplicationForm(@RequestParameter(isJsonBody = true,value = "application") LLIReleaseIPApplication extendedLLIApplication, LoginDTO loginDTO) throws Exception{
		if(loginDTO.getIsAdmin()) extendedLLIApplication.setUserID(loginDTO.getUserID());
		lliApplicationService.insertApplication(extendedLLIApplication,loginDTO);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/release-ip-edit", requestMethod=RequestMethod.POST)
	public long postReleaseIPEdit(@RequestParameter(isJsonBody = true,value = "application") LLIReleaseIPApplication extendedLLIApplication) throws Exception{
		lliApplicationService.editApplication(extendedLLIApplication);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/release-ip-process", requestMethod=RequestMethod.POST)
	public void postReleaseIPProcess(@RequestParameter(isJsonBody = true,value = "application") LLIReleaseIPApplication extendedLLIApplication) throws Exception{
		lliApplicationService.processApplication(extendedLLIApplication);
	}
	@JsonPost @RequestMapping(mapping="/release-ip-complete", requestMethod=RequestMethod.POST)
	public void postReleaseIPCompletion(@RequestParameter(isJsonBody = true,value = "application") LLIReleaseIPApplication extendedLLIApplication) throws Exception{
		lliApplicationService.completeApplication(extendedLLIApplication);
	}
	/*Application Release IP Ends*/
	/* ============================================================================================================== */
	/*Application Additional Connection Address Begins*/
	@ForwardedAction @RequestMapping(mapping="/additional-connection-address", requestMethod=RequestMethod.GET)
	public String getAdditionalConnectionAddressApplicationForm() throws Exception {
		return "lli-application-additional-connection-address";
	}
	@JsonPost @RequestMapping(mapping="/additional-connection-address", requestMethod=RequestMethod.POST)
	public long postAdditionalConnectionAddressApplicationForm(@RequestParameter(isJsonBody = true,value = "application") LLIAdditionalConnectionAddressApplication extendedLLIApplication, LoginDTO loginDTO) throws Exception{
		if(loginDTO.getIsAdmin()) extendedLLIApplication.setUserID(loginDTO.getUserID());
		lliApplicationService.insertApplication(extendedLLIApplication,loginDTO);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/additional-connection-address-edit", requestMethod=RequestMethod.POST)
	public long postAdditionalConnectionAddressEdit(@RequestParameter(isJsonBody = true,value = "application") LLIAdditionalConnectionAddressApplication extendedLLIApplication) throws Exception{
		lliApplicationService.editApplication(extendedLLIApplication);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/additional-connection-address-process", requestMethod=RequestMethod.POST)
	public void postAdditionalConnectionAddressProcess(@RequestParameter(isJsonBody = true,value = "application") LLIAdditionalConnectionAddressApplication extendedLLIApplication) throws Exception{
		lliApplicationService.processApplication(extendedLLIApplication);
	}
	@JsonPost @RequestMapping(mapping="/additional-connection-address-complete", requestMethod=RequestMethod.POST)
	public void postAdditionalConnectionAddressCompletion(@RequestParameter(isJsonBody = true,value = "application") LLIAdditionalConnectionAddressApplication extendedLLIApplication) throws Exception{
		lliApplicationService.completeApplication(extendedLLIApplication);
	}
	/*Application Additional Connection Address Ends*/
	/* ============================================================================================================== */
	/*Application Shift Address Begins*/
	@ForwardedAction @RequestMapping(mapping="/shift-address", requestMethod=RequestMethod.GET)
	public String getShiftAddressApplicationForm() throws Exception {
		return "lli-application-shift-address";
	}
	@JsonPost @RequestMapping(mapping="/shift-address", requestMethod=RequestMethod.POST)
	public long postShiftAddressApplicationForm(@RequestParameter(isJsonBody = true,value = "application") LLIShiftAddressApplication lliShiftAddressApplication, LoginDTO loginDTO) throws Exception{
		if(loginDTO.getIsAdmin()) lliShiftAddressApplication.setUserID(loginDTO.getUserID());
		lliApplicationService.insertApplication(lliShiftAddressApplication,loginDTO);
		return lliShiftAddressApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/shift-address-edit", requestMethod=RequestMethod.POST)
	public long postShiftAddressEdit(@RequestParameter(isJsonBody = true,value = "application") LLIShiftAddressApplication extendedLLIApplication) throws Exception{
		lliApplicationService.editApplication(extendedLLIApplication);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/shift-address-process", requestMethod=RequestMethod.POST)
	public void postShiftAddressProcess(@RequestParameter(isJsonBody = true,value = "application") LLIShiftAddressApplication lliShiftAddressApplication) throws Exception{
		lliApplicationService.processApplication(lliShiftAddressApplication);
	}
	@JsonPost @RequestMapping(mapping="/shift-address-complete", requestMethod=RequestMethod.POST)
	public void postShiftAddressCompletion(@RequestParameter(isJsonBody = true,value = "application") LLIShiftAddressApplication lliShiftAddressApplication) throws Exception{
		lliApplicationService.completeApplication(lliShiftAddressApplication);
	}
	/*Application Shift Address Ends*/
	/* ============================================================================================================== */
	/*Application Release Connection Address Begins*/
	@ForwardedAction @RequestMapping(mapping="/release-connection-address", requestMethod=RequestMethod.GET)
	public String getReleaseConnectionAddressApplicationForm() throws Exception {
		return "lli-application-release-connection-address";
	}
	@JsonPost @RequestMapping(mapping="/release-connection-address", requestMethod=RequestMethod.POST)
	public long postReleaseConnectionAddressApplicationForm(@RequestParameter(isJsonBody = true,value = "application") LLIReleaseConnectionAddressApplication extendedLLIApplication, LoginDTO loginDTO) throws Exception{
		if(loginDTO.getIsAdmin()) extendedLLIApplication.setUserID(loginDTO.getUserID());
		lliApplicationService.insertApplication(extendedLLIApplication,loginDTO);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/release-connection-address-edit", requestMethod=RequestMethod.POST)
	public long postReleaseConnectionAddressEdit(@RequestParameter(isJsonBody = true,value = "application") LLIReleaseConnectionAddressApplication extendedLLIApplication) throws Exception{
		lliApplicationService.editApplication(extendedLLIApplication);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/release-connection-address-process", requestMethod=RequestMethod.POST)
	public void postReleaseConnectionAddressProcess(@RequestParameter(isJsonBody = true,value = "application") LLIReleaseConnectionAddressApplication extendedLLIApplication) throws Exception{
		lliApplicationService.processApplication(extendedLLIApplication);
	}
	@JsonPost @RequestMapping(mapping="/release-connection-address-complete", requestMethod=RequestMethod.POST)
	public void postReleaseConnectionAddressCompletion(@RequestParameter(isJsonBody = true,value = "application") LLIReleaseConnectionAddressApplication extendedLLIApplication) throws Exception{
		lliApplicationService.completeApplication(extendedLLIApplication);
	}
	/*Application Release Connection Address Ends*/
	/* ============================================================================================================== */
	/*Application Shift Pop Begins*/
	@ForwardedAction @RequestMapping(mapping="/shift-pop", requestMethod=RequestMethod.GET)
	public String getShiftPopApplicationForm() throws Exception {
		return "lli-application-shift-pop";
	}
	@JsonPost @RequestMapping(mapping="/shift-pop", requestMethod=RequestMethod.POST)
	public long postShiftPopApplicationForm(@RequestParameter(isJsonBody = true,value = "application") LLIShiftPopApplication lliShiftPopApplication, LoginDTO loginDTO) throws Exception{
		if(loginDTO.getIsAdmin()) lliShiftPopApplication.setUserID(loginDTO.getUserID());
		lliApplicationService.insertApplication(lliShiftPopApplication,loginDTO);
		return lliShiftPopApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/shift-pop-edit", requestMethod=RequestMethod.POST)
	public long postShiftPopEdit(@RequestParameter(isJsonBody = true,value = "application") LLIShiftPopApplication extendedLLIApplication) throws Exception{
		lliApplicationService.editApplication(extendedLLIApplication);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/shift-pop-process", requestMethod=RequestMethod.POST)
	public void postShiftPopProcess(@RequestParameter(isJsonBody = true,value = "application") LLIShiftPopApplication lliShiftPopApplication) throws Exception{
		lliApplicationService.processApplication(lliShiftPopApplication);
	}
	//Application Completion Post
	@JsonPost @RequestMapping(mapping="/shift-pop-complete", requestMethod=RequestMethod.POST)
	public void postShiftPopCompletion(@RequestParameter(isJsonBody = true,value = "application") LLIShiftPopApplication lliShiftPopApplication) throws Exception{
		lliApplicationService.completeApplication(lliShiftPopApplication);
	}
	/*Application Shift Pop Ends*/
	/* ============================================================================================================== */
	/*Application New Long Term Begins*/
	@ForwardedAction @RequestMapping(mapping="/new-long-term", requestMethod=RequestMethod.GET)
	public String getNewLongTermApplicationForm() throws Exception {
		return "lli-application-new-long-term";
	}
	@JsonPost @RequestMapping(mapping="/new-long-term", requestMethod=RequestMethod.POST)
	public long postNewLongTermApplicationForm(@RequestParameter(isJsonBody = true,value = "application") LLINewLongTermApplication lliNewLongTermApplication, LoginDTO loginDTO) throws Exception{
		if(loginDTO.getIsAdmin()) lliNewLongTermApplication.setUserID(loginDTO.getUserID());
		lliApplicationService.insertApplication(lliNewLongTermApplication,loginDTO);
		return lliNewLongTermApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/new-long-term-edit", requestMethod=RequestMethod.POST)
	public long postNewLongTermEdit(@RequestParameter(isJsonBody = true,value = "application") LLINewLongTermApplication extendedLLIApplication) throws Exception{
		lliApplicationService.editApplication(extendedLLIApplication);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/new-long-term-process", requestMethod=RequestMethod.POST)
	public void postNewLongTermProcess(@RequestParameter(isJsonBody = true,value = "application") LLINewLongTermApplication lliNewLongTermApplication) throws Exception{
		lliApplicationService.processApplication(lliNewLongTermApplication);
	}
	@JsonPost @RequestMapping(mapping="/new-long-term-complete", requestMethod=RequestMethod.POST)
	public void postNewLongTermCompletion(@RequestParameter(isJsonBody = true,value = "application") LLINewLongTermApplication lliNewLongTermApplication) throws Exception{
		lliApplicationService.completeApplication(lliNewLongTermApplication);
	}
	/*Application New Long Term Ends*/
	/* ============================================================================================================== */
	/*Application Break Long Term Begins*/
	@ForwardedAction @RequestMapping(mapping="/break-long-term", requestMethod=RequestMethod.GET)
	public String getBreakLongTermApplicationForm() throws Exception {
		return "lli-application-break-long-term";
	}
	@JsonPost @RequestMapping(mapping="/break-long-term", requestMethod=RequestMethod.POST)
	public long postBreakLongTermApplicationForm(@RequestParameter(isJsonBody = true,value = "application") LLIBreakLongTermApplication lliBreakLongTermApplication, LoginDTO loginDTO) throws Exception{
		if(loginDTO.getIsAdmin()) lliBreakLongTermApplication.setUserID(loginDTO.getUserID());
		lliApplicationService.insertApplication(lliBreakLongTermApplication,loginDTO);
		return lliBreakLongTermApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/break-long-term-edit", requestMethod=RequestMethod.POST)
	public long postBreakLongTermEdit(@RequestParameter(isJsonBody = true,value = "application") LLIBreakLongTermApplication extendedLLIApplication) throws Exception{
		lliApplicationService.editApplication(extendedLLIApplication);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/break-long-term-process", requestMethod=RequestMethod.POST)
	public void postBreakLongTermProcess(@RequestParameter(isJsonBody = true,value = "application") LLIBreakLongTermApplication lliBreakLongTermApplication) throws Exception{
		lliApplicationService.processApplication(lliBreakLongTermApplication);
	}
	@JsonPost @RequestMapping(mapping="/break-long-term-complete", requestMethod=RequestMethod.POST)
	public void postBreakLongTermCompletion(@RequestParameter(isJsonBody = true,value = "application") LLIBreakLongTermApplication lliBreakLongTermApplication) throws Exception{
		lliApplicationService.completeApplication(lliBreakLongTermApplication);
	}
	/*Application Break Long Term Ends*/	
	/* ============================================================================================================== */
	/*Application Shift Bandwidth Begins*/
	@ForwardedAction @RequestMapping(mapping="/shift-bandwidth", requestMethod=RequestMethod.GET)
	public String getShiftBandwidthApplicationForm() throws Exception {
		return "lli-application-shift-bandwidth";
	}
	@JsonPost @RequestMapping(mapping="/shift-bandwidth", requestMethod=RequestMethod.POST)
	public long postShiftBandwidthApplicationForm(@RequestParameter(isJsonBody = true,value = "application") LLIShiftBandwidthApplication lliShiftBandwidthApplication, LoginDTO loginDTO) throws Exception{
		if(loginDTO.getIsAdmin()) lliShiftBandwidthApplication.setUserID(loginDTO.getUserID());
		lliApplicationService.insertApplication(lliShiftBandwidthApplication,loginDTO);
		return lliShiftBandwidthApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/shift-bandwidth-edit", requestMethod=RequestMethod.POST)
	public long postShiftBandwidthEdit(@RequestParameter(isJsonBody = true,value = "application") LLIShiftBandwidthApplication extendedLLIApplication) throws Exception{
		lliApplicationService.editApplication(extendedLLIApplication);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/shift-bandwidth-process", requestMethod=RequestMethod.POST)
	public void postShiftBandwidthProcess(@RequestParameter(isJsonBody = true,value = "application") LLIShiftBandwidthApplication lliShiftBandwidthApplication) throws Exception{
		lliApplicationService.processApplication(lliShiftBandwidthApplication);
	}
	@JsonPost @RequestMapping(mapping="/shift-bandwidth-complete", requestMethod=RequestMethod.POST)
	public void postShiftBandwidthCompletion(@RequestParameter(isJsonBody = true,value = "application") LLIShiftBandwidthApplication lliShiftBandwidthApplication) throws Exception{
		lliApplicationService.completeApplication(lliShiftBandwidthApplication);
	}
	/*Application Shift Bandwidth Ends*/
	/* ============================================================================================================== */
	/*Application Change Ownership Begins*/
	@ForwardedAction @RequestMapping(mapping="/change-ownership", requestMethod=RequestMethod.GET)
	public String getChangeOwnershipApplicationForm() throws Exception {
		return "lli-application-change-ownership";
	}
	@JsonPost @RequestMapping(mapping="/change-ownership", requestMethod=RequestMethod.POST)
	public long postChangeOwnershipApplicationForm(@RequestParameter(isJsonBody = true,value = "application") LLIChangeOwnershipApplication lliChangeOwnershipApplication, LoginDTO loginDTO) throws Exception{
		if(loginDTO.getIsAdmin()) lliChangeOwnershipApplication.setUserID(loginDTO.getUserID());
		lliApplicationService.insertApplication(lliChangeOwnershipApplication,loginDTO);
		return lliChangeOwnershipApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/change-ownership-edit", requestMethod=RequestMethod.POST)
	public long postChangeOwnershipEdit(@RequestParameter(isJsonBody = true,value = "application") LLIChangeOwnershipApplication extendedLLIApplication) throws Exception{
		lliApplicationService.editApplication(extendedLLIApplication);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/change-ownership-process", requestMethod=RequestMethod.POST)
	public void postChangeOwnershipProcess(@RequestParameter(isJsonBody = true,value = "application") LLIChangeOwnershipApplication lliChangeOwnershipApplication) throws Exception{
		lliApplicationService.processApplication(lliChangeOwnershipApplication);
	}
	@JsonPost @RequestMapping(mapping="/change-ownership-complete", requestMethod=RequestMethod.POST)
	public void postChangeOwnershipCompletion(@RequestParameter(isJsonBody = true,value = "application") LLIChangeOwnershipApplication lliChangeOwnershipApplication) throws Exception{
		lliApplicationService.completeApplication(lliChangeOwnershipApplication);
	}
	/*Application Change Ownership Ends*/
	/* ============================================================================================================== */
	/*Application Reconnect Begins*/
	@ForwardedAction @RequestMapping(mapping="/reconnect", requestMethod=RequestMethod.GET)
	public String getReconnectApplicationForm() throws Exception {
		return "lli-application-reconnect";
	}
	@JsonPost @RequestMapping(mapping="/reconnect", requestMethod=RequestMethod.POST)
	public long postReconnectApplicationForm(@RequestParameter(isJsonBody = true,value = "application") LLIReconnectApplication lliReconnectApplication, LoginDTO loginDTO) throws Exception{
		if(loginDTO.getIsAdmin()) lliReconnectApplication.setUserID(loginDTO.getUserID());
		lliApplicationService.insertApplication(lliReconnectApplication,loginDTO);
		return lliReconnectApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/reconnect-edit", requestMethod=RequestMethod.POST)
	public long postReconnectEdit(@RequestParameter(isJsonBody = true,value = "application") LLIReconnectApplication extendedLLIApplication) throws Exception{
		lliApplicationService.editApplication(extendedLLIApplication);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/reconnect-process", requestMethod=RequestMethod.POST)
	public void postReconnectProcess(@RequestParameter(isJsonBody = true,value = "application") LLIReconnectApplication lliReconnectApplication) throws Exception{
		lliApplicationService.processApplication(lliReconnectApplication);
	}
	@JsonPost @RequestMapping(mapping="/reconnect-complete", requestMethod=RequestMethod.POST)
	public void postReconnectCompletion(@RequestParameter(isJsonBody = true,value = "application") LLIReconnectApplication lliReconnectApplication) throws Exception{
		lliApplicationService.completeApplication(lliReconnectApplication);
	}
	/*Application Reconnect Ends*/
	/* ============================================================================================================== */
	/*Application Change Billing Address Begins*/
	@ForwardedAction @RequestMapping(mapping="/change-billing-address", requestMethod=RequestMethod.GET)
	public String getChangeBillingAddressApplicationForm() throws Exception {
		return "lli-application-change-billing-address";
	}
	@JsonPost @RequestMapping(mapping="/change-billing-address", requestMethod=RequestMethod.POST)
	public long postChangeBillingAddressApplicationForm(@RequestParameter(isJsonBody = true,value = "application") LLIChangeBillingAddressApplication lliChangeBillingAddressApplication, LoginDTO loginDTO) throws Exception{
		if(loginDTO.getIsAdmin()) lliChangeBillingAddressApplication.setUserID(loginDTO.getUserID());
		lliApplicationService.insertApplication(lliChangeBillingAddressApplication,loginDTO);
		return lliChangeBillingAddressApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/change-billing-address-edit", requestMethod=RequestMethod.POST)
	public long postChangeBillingAddressEdit(@RequestParameter(isJsonBody = true,value = "application") LLIChangeBillingAddressApplication extendedLLIApplication) throws Exception{
		lliApplicationService.editApplication(extendedLLIApplication);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/change-billing-address-process", requestMethod=RequestMethod.POST)
	public void postChangeBillingAddressProcess(@RequestParameter(isJsonBody = true,value = "application") LLIChangeBillingAddressApplication lliChangeBillingAddressApplication) throws Exception{
		lliApplicationService.processApplication(lliChangeBillingAddressApplication);
	}
	@JsonPost @RequestMapping(mapping="/change-billing-address-complete", requestMethod=RequestMethod.POST)
	public void postChangeBillingAddressCompletion(@RequestParameter(isJsonBody = true,value = "application") LLIChangeBillingAddressApplication lliChangeBillingAddressApplication) throws Exception{
		lliApplicationService.completeApplication(lliChangeBillingAddressApplication);
	}
	/*Application Change Billing Address Ends*/
	/* ============================================================================================================== */
	/*Application Close Connection Begins*/
	@ForwardedAction @RequestMapping(mapping="/close-connection", requestMethod=RequestMethod.GET)
	public String getCloseConnectionApplicationForm() throws Exception {
		return "lli-application-close-connection";
	}
	@JsonPost @RequestMapping(mapping="/close-connection", requestMethod=RequestMethod.POST)
	public long postCloseConnectionApplicationForm(@RequestParameter(isJsonBody = true,value = "application") LLICloseConnectionApplication lliCloseConnectionApplication, LoginDTO loginDTO) throws Exception{
		if(loginDTO.getIsAdmin()) lliCloseConnectionApplication.setUserID(loginDTO.getUserID());
		lliApplicationService.insertApplication(lliCloseConnectionApplication,loginDTO);
		return lliCloseConnectionApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/close-connection-edit", requestMethod=RequestMethod.POST)
	public long postCloseConnectionEdit(@RequestParameter(isJsonBody = true,value = "application") LLICloseConnectionApplication extendedLLIApplication) throws Exception{
		lliApplicationService.editApplication(extendedLLIApplication);
		return extendedLLIApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/close-connection-process", requestMethod=RequestMethod.POST)
	public void postCloseConnectionProcess(@RequestParameter(isJsonBody = true,value = "application") LLICloseConnectionApplication lliCloseConnectionApplication) throws Exception{
		lliApplicationService.processApplication(lliCloseConnectionApplication);
	}
	@JsonPost @RequestMapping(mapping="/close-connection-complete", requestMethod=RequestMethod.POST)
	public void postCloseConnectionCompletion(@RequestParameter(isJsonBody = true,value = "application") LLICloseConnectionApplication lliCloseConnectionApplication) throws Exception{
		lliApplicationService.completeApplication(lliCloseConnectionApplication);
	}
	/*Application Close Connection Ends*/
	/* ============================================================================================================== */
	/*Application Global Actions Begins*/
	@JsonPost @RequestMapping(mapping="/request-for-correction", requestMethod=RequestMethod.POST)
	public long requestForCorrectionApplication(@RequestParameter(isJsonBody = true,value = "application") LLIApplication lliApplication) throws Exception{
		lliApplicationService.requestForCorrectionApplication(lliApplication);
		return lliApplication.getApplicationID();
	}
	@JsonPost @RequestMapping(mapping="/reject", requestMethod=RequestMethod.POST)
	public long rejectApplication(@RequestParameter(isJsonBody = true,value = "application") LLIApplication lliApplication) throws Exception{
		lliApplicationService.rejectApplication(lliApplication);
		return lliApplication.getApplicationID();
	}
	/*Application Global Actions Ends*/
	/* ============================================================================================================== */
	/* ============================================================================================================== */
	/* ============================================================================================================== */
	
}

