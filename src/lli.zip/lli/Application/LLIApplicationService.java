package lli.Application;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.List;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import annotation.DAO;
import annotation.Transactional;
import common.RequestFailureException;
import common.bill.BillDTO;
import common.bill.BillService;
import lli.LLIActionButton;
import lli.LLIConnectionDeserializer;
import lli.LLIConnectionInstance;
import lli.LLIConnectionService;
import lli.LLILocalLoop;
import lli.LLILocalLoopDeserializer;
import lli.LLIOffice;
import lli.LLIOfficeDeserializer;
import lli.connection.LLIConnectionConstants;
import login.LoginDTO;
import requestMapping.Service;
import util.ModifiedSqlGenerator;
import util.NavigationService;
import util.TransactionType;


public class LLIApplicationService implements NavigationService {

	@DAO
	LLIApplicationDAO lliApplicationDAO;
	@Service
	LLIConnectionService lliConnectionService;
	@Service
	BillService billService;
	@Transactional
	public void setDemandNoteIDInLLIApplicationByDemandNoteIDAndApplicationID(long demandNoteID,long applicationID) throws Exception{
		LLIApplication lliApplication = getLLIApplicationByApplicationID(applicationID);
		if(lliApplication == null){
			throw new RequestFailureException("No lli application found with application ID "+applicationID);
		}
		if(!lliApplication.isDemandNoteNeeded()){
			throw new RequestFailureException("No demand note is needed for applicaton with application ID "+applicationID);
		}
		if(lliApplication.getDemandNoteID() != null){
			throw new RequestFailureException("Demand note has already been created for application with application ID "+applicationID);
		}
		lliApplication.setDemandNoteID(demandNoteID);
		lliApplication.setStatus(LLIConnectionConstants.STATUS_DEMAND_NOTE_GENERATED);
		lliApplicationDAO.updateLLIApplication(lliApplication);
		
	}
	
	/*Handles submission of the forms which come after redirection from view page*/
	@Transactional
	public void insertApplication(LLIApplication lliApplication,LoginDTO loginDTO) throws Exception {
		
		if(!loginDTO.getIsAdmin() && lliApplication.getClientID()!=loginDTO.getAccountID()){
			throw new RequestFailureException("You can not submit other client's application.");
		}
		
		lliApplication.setSubmissionDate(System.currentTimeMillis());
		lliApplication.setStatus(LLIConnectionConstants.STATUS_APPLIED);
		lliApplication.insertApplication(); //written in extended application dto
		lliApplicationDAO.insertLLIApplication(lliApplication);
		
		
//		LliUtil.uploadDocument(lliApplication.getDocuments(), 2, loginDTO, DatabaseConnectionFactory.getCurrentDatabaseConnection());
	}
	@Transactional
	public void requestForCorrectionApplication(LLIApplication lliApplication) throws Exception {
		LLIApplication existingLLIApplication = getLLIApplicationByApplicationID(lliApplication.getApplicationID());
		existingLLIApplication.setStatus(LLIConnectionConstants.STATUS_REQUESTED_FOR_CORRECTION);
		existingLLIApplication.setRequestForCorrectionComment(lliApplication.getRequestForCorrectionComment());
		ModifiedSqlGenerator.updateEntity(existingLLIApplication);
	}
	@Transactional
	public void rejectApplication(LLIApplication lliApplication) throws Exception {
		LLIApplication existingLliApplication = getLLIApplicationByApplicationID(lliApplication.getApplicationID());
		existingLliApplication.setStatus(LLIConnectionConstants.STATUS_REJECTED);
		existingLliApplication.setRejectionComment(lliApplication.getRejectionComment());
		ModifiedSqlGenerator.updateEntity(existingLliApplication);
	}
	
	private void setImmutablePropertiesForApplicationEdit(LLIApplication lliApplication,LLIApplication lastExistingApplication) {
		
		lliApplication.setApplicationID(lastExistingApplication.getApplicationID());
		lliApplication.setClientID(lastExistingApplication.getClientID());
		lliApplication.setUserID(lastExistingApplication.getUserID());
		lliApplication.setContent(lastExistingApplication.getContent());
		lliApplication.setSubmissionDate(lastExistingApplication.getSubmissionDate());
		lliApplication.setApplicationType(lastExistingApplication.getApplicationType());
		lliApplication.setDemandNoteID(lastExistingApplication.getDemandNoteID());
		lliApplication.setDemandNoteNeeded(lastExistingApplication.isDemandNoteNeeded);
		lliApplication.setServiceStarted(lastExistingApplication.isServiceStarted());
		lliApplication.setRejectionComment(lastExistingApplication.getRejectionComment());
		lliApplication.setRequestForCorrectionComment(lastExistingApplication.getRequestForCorrectionComment());
		
	}
	
	@Transactional
	public void editApplication(LLIApplication lliApplication) throws Exception{
		LLIApplication lastLLIApplicationInstance = getLLIApplicationByApplicationID(lliApplication.getApplicationID());
		setImmutablePropertiesForApplicationEdit(lliApplication, lastLLIApplicationInstance);
		
		lliApplication.setStatus(LLIConnectionConstants.STATUS_APPLIED);
		lliApplicationDAO.updateLLIApplication(lliApplication);
	}
	@Transactional
	public void processApplication(LLIApplication lliApplication) throws Exception{
		LLIApplication lastLLIApplicationInstance = getLLIApplicationByApplicationID(lliApplication.getApplicationID());
		
		if(lastLLIApplicationInstance == null){
			throw new RequestFailureException("No application found with application ID "+lastLLIApplicationInstance.getApplicationID());
		}
	//	if()
		
		lliApplication.setImmutablePropertyWhileProcessing(lastLLIApplicationInstance); //written in extended application dto
		lliApplication.setStatus(LLIConnectionConstants.STATUS_PROCESSED);
		lliApplicationDAO.updateLLIApplication(lliApplication);
	}
	@Transactional
	public void completeApplication(LLIApplication lliApplication) throws Exception{
		if(lliApplication.isDemandNoteNeeded() ) {
			if(lliApplication.getDemandNoteID() == null) {
				throw new RequestFailureException("No Demand Note has been generated");
			}
			BillDTO demandNote = billService.getBillByBillID(lliApplication.getDemandNoteID());
			if(demandNote == null) {
				throw new RequestFailureException("Invalid Demand Note");
			}
			if(demandNote.getPaymentStatus() != BillDTO.PAID_VERIFIED &&
					demandNote.getPaymentStatus() != BillDTO.SKIPPED) {
				throw new RequestFailureException("Demand Note has not been paid/skipped");
			}
		}
		
		lliApplication.setStatus(LLIConnectionConstants.STATUS_COMPLETED);
		lliApplication.setServiceStarted(true);
		lliApplication.completeApplication(); //written in extended application dto
		lliApplicationDAO.updateLLIApplication(lliApplication);
	}
	/*Handles submission of the forms which come after redirection from view page*/
	
	
	
	/*Fetch LLI Application begins*/
	@Transactional(transactionType=TransactionType.READONLY)
	public LLIApplication getLLIApplicationByApplicationID(long applicationID) throws Exception {
		LLIApplication lliApplication = lliApplicationDAO.getLLIApplicationByID(applicationID);
		if(lliApplication == null) {
			throw new RequestFailureException("No Application found with ID " + applicationID);
		}
		return lliApplication;
	}
	@Transactional(transactionType=TransactionType.READONLY)
	public LLIApplication getLLIApplicationByDemandNoteID(long demandNoteID) throws Exception{
		LLIApplication lliApplication = lliApplicationDAO.getLLIApplicationByDemandNoteID(demandNoteID);
		
		if(lliApplication == null){
			return null;
		}
		
		int applicationType = lliApplication.getApplicationType();
		Class<? extends LLIApplication> childClassObject = LLIConnectionConstants.applicationTypeClassnameMap.get(applicationType);
		
		if(childClassObject == null){
			throw new RequestFailureException("No application type found "
					+ "in appllication with application ID "+lliApplication.getApplicationID());
		}
		
		LLIApplication childApplication = lliApplicationDAO.getChildLLIApplicationByForeignKey(lliApplication.getApplicationID(), childClassObject);
		
		if(childApplication == null){
			throw new RequestFailureException("No applcation specific data found.");
		}
		
		ModifiedSqlGenerator.populateObjectFromOtherObject(lliApplication, childApplication, LLIApplication.class);
		
		return childApplication;
	}
	/*Fetch LLI Application ends*/

	
	
	
	/*Search Application begins*/
	@SuppressWarnings("rawtypes")
	@Transactional(transactionType = TransactionType.READONLY)
	@Override
	public Collection getIDs(LoginDTO loginDTO, Object... objects) throws Exception {
		return getIDsWithSearchCriteria(new Hashtable<>(), loginDTO, objects);
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transactional(transactionType = TransactionType.READONLY)
	@Override
	public Collection getIDsWithSearchCriteria(Hashtable searchCriteria, LoginDTO loginDTO, Object... objects)
			throws Exception {

		return lliApplicationDAO.getIDsWithSearchCriteria(searchCriteria, loginDTO);
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transactional(transactionType = TransactionType.READONLY)
	@Override
	public Collection getDTOs(Collection recordIDs, Object... objects) throws Exception {
		return lliApplicationDAO.getLLIApplicationListByIDList((List<Long>) recordIDs);
	}
	/*Search Application ends*/
	
	
	
	
	
	/*State Action begins*/
	public List<LLIActionButton> getAvailableActions(long applicationID, LoginDTO loginDTO) throws Exception {
		LLIApplication lliApplication = getLLIApplicationByApplicationID(applicationID);
		int status = lliApplication.getStatus();
		
		
		List<LLIActionButton> buttonList = new ArrayList<LLIActionButton>();
		
		if(loginDTO.getIsAdmin()) {
			List<LLIActionButton> listOfActionButtons = LLIConnectionConstants.applicationActionMap.getOrDefault(status,new ArrayList<>());
			buttonList = new ArrayList<>(listOfActionButtons);
			
			if(status == LLIConnectionConstants.STATUS_FINALIZED) {
				if(lliApplication.isDemandNoteNeeded()) {
					if(lliApplication.getApplicationType() == LLIConnectionConstants.BREAK_LONG_TERM) {
						buttonList.add(new LLIActionButton("Generate Short Bill", "lli/dn/new.do", true));
					} else {
						buttonList.add(new LLIActionButton("Generate Demand Note", "lli/dn/new.do", true));
					}
				}else {
					buttonList.add(new LLIActionButton("Complete Request", "lli/application/application-complete-request.do", true));
				}
			}
		} else {
			if(status == LLIConnectionConstants.STATUS_REQUESTED_FOR_CORRECTION) {
				buttonList.add(new LLIActionButton("Edit", "lli/application/application-edit.do", true));
			}
		}
		
		
		return buttonList;
	}

	@Transactional
	public void verifyApplication(long applicationID) throws Exception {
		LLIApplication lliApplication = getLLIApplicationByApplicationID(applicationID);
		lliApplication.setStatus(LLIConnectionConstants.STATUS_VERIFIED);
		ModifiedSqlGenerator.updateEntity(lliApplication);
	}
	@Transactional
	public void finalizeApplication(long applicationID) throws Exception {
		LLIApplication lliApplication = getLLIApplicationByApplicationID(applicationID);
		lliApplication.setStatus(LLIConnectionConstants.STATUS_FINALIZED);
		ModifiedSqlGenerator.updateEntity(lliApplication);
	}
	@Transactional
	public void setApplicationStatusToDemandNoteGenerated(long applicationID) throws Exception {
		LLIApplication lliApplication = getLLIApplicationByApplicationID(applicationID);
		lliApplication.setStatus(LLIConnectionConstants.STATUS_DEMAND_NOTE_GENERATED);
		ModifiedSqlGenerator.updateEntity(lliApplication);
	}
	@Transactional
	public void setApplicationStatusToDemandNotePaid(long applicationID) throws Exception {
		LLIApplication lliApplication = getLLIApplicationByApplicationID(applicationID);
		lliApplication.setStatus(LLIConnectionConstants.STATUS_PAYMENT_CLEARED);
		ModifiedSqlGenerator.updateEntity(lliApplication);
	}
	@Transactional
	public void completeRequestApplication(long applicationID) throws Exception {
		LLIApplication lliApplication = getLLIApplicationByApplicationID(applicationID);
		lliApplication.setStatus(LLIConnectionConstants.STATUS_COMPLETED);
		ModifiedSqlGenerator.updateEntity(lliApplication);
	}
	/*State Action ends*/
	
	
	
	/*Mapping Name Forwarding begins*/
	public String editApplicationMappingForwardName(long applicationID) throws Exception {
		int applicationType = getLLIApplicationByApplicationID(applicationID).getApplicationType();
		return "lli-application-" + LLIConnectionConstants.applicationTypeHyphenSeperatedMap.get(applicationType) + "-edit";
	}
	public String processApplicationMappingForwardName(long applicationID) throws Exception {
		int applicationType = getLLIApplicationByApplicationID(applicationID).getApplicationType();
		return "lli-application-" + LLIConnectionConstants.applicationTypeHyphenSeperatedMap.get(applicationType) + "-process";
	}
	public String viewApplicationMappingForwardName(long applicationID) throws Exception {
		int applicationType = getLLIApplicationByApplicationID(applicationID).getApplicationType();
		return "lli-application-" + LLIConnectionConstants.applicationTypeHyphenSeperatedMap.get(applicationType) + "-view";
	}
	public String completeApplicationMappingForwardName(long applicationID) throws Exception {
		int applicationType = getLLIApplicationByApplicationID(applicationID).getApplicationType();
		return "lli-application-" + LLIConnectionConstants.applicationTypeHyphenSeperatedMap.get(applicationType) + "-completion";
	}
	

	/*Mapping Name Forwarding ends*/
	
	
	/*Content Analysis Begins*/
	public static LLIConnectionInstance getLLIConnectionFromApplicationContent(LLIApplication lliApplication) {
		String content = lliApplication.getContent();
		JsonObject jsonObject = new JsonParser().parse(content).getAsJsonObject();
		LLIConnectionInstance lliConnectionInstance =
					new GsonBuilder()
					.registerTypeAdapter(LLIConnectionInstance.class, new LLIConnectionDeserializer())
					.registerTypeAdapter(LLIOffice.class, new LLIOfficeDeserializer())
					.registerTypeAdapter(LLILocalLoop.class, new LLILocalLoopDeserializer())
					.create()
					.fromJson(jsonObject, LLIConnectionInstance.class);
			
		return lliConnectionInstance;
		
	}
	/*Content Analysis ends*/
	
	@Transactional
	public void setApplicationAsPaymentClearedByDemandNoteID(long demandNoteID) throws Exception{
		LLIApplication lliApplication = getLLIApplicationByDemandNoteID(demandNoteID);
		if(lliApplication == null) {
			throw new RequestFailureException("No Such LLI Application found");
		}
		lliApplication.setStatus(LLIConnectionConstants.STATUS_PAYMENT_CLEARED);
		lliApplicationDAO.updateLLIApplication(lliApplication);
	}
	@Transactional
	public void setApplicationAsDemandNoteGeneratedByDemandNoteID(long demandNoteID) throws Exception{
		LLIApplication lliApplication = getLLIApplicationByDemandNoteID(demandNoteID);
		if(lliApplication == null) {
			throw new RequestFailureException("No Such LLI Application found");
		}
		lliApplication.setStatus(LLIConnectionConstants.STATUS_DEMAND_NOTE_GENERATED);
		lliApplicationDAO.updateLLIApplication(lliApplication);
		
	}
	@Transactional
	public int getApplicationTypeByApplicationID (long applicationID) throws Exception {
		LLIApplication lliApplication = getLLIApplicationByApplicationID(applicationID);
		return lliApplication.getApplicationType();
	}
	@Transactional
	public void updateApplicaton(LLIApplication lliApplication) throws Exception{
		lliApplicationDAO.updateLLIApplication(lliApplication);
	}
	
	
}
