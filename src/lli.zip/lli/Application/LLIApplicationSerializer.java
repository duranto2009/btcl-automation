package lli.Application;

import java.lang.reflect.Type;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import common.repository.AllClientRepository;
import lli.LLIDropdownPair;
import lli.connection.LLIConnectionConstants;
import user.UserRepository;

public class LLIApplicationSerializer implements JsonSerializer<LLIApplication>{

	public static JsonObject getCommonPart(LLIApplication lliApplication, JsonObject jsonObject, JsonSerializationContext context) {
		//Serialize Common LLI Application
		jsonObject.addProperty("applicationID", lliApplication.getApplicationID());
		jsonObject.add("client", context.serialize( new LLIDropdownPair(lliApplication.getClientID(), AllClientRepository.getInstance().getClientByClientID(lliApplication.getClientID()).getLoginName() ) ));
		jsonObject.add("user", lliApplication.getUserID() != null ? context.serialize( new LLIDropdownPair(lliApplication.getUserID(), UserRepository.getInstance().getUserDTOByUserID(lliApplication.getUserID()).getUsername() ) ) : context.serialize(null));

		jsonObject.addProperty("submissionDate", lliApplication.getSubmissionDate());
		jsonObject.add("status", context.serialize( new LLIDropdownPair(lliApplication.getStatus(), LLIConnectionConstants.applicationStatusMap.get(lliApplication.getStatus())) ));
		jsonObject.addProperty("content", lliApplication.getContent());
		jsonObject.addProperty("demandNoteID", lliApplication.getDemandNoteID());
		jsonObject.add("applicationType", context.serialize( new LLIDropdownPair(lliApplication.getApplicationType(), LLIConnectionConstants.applicationTypeNameMap.get(lliApplication.getApplicationType()) ) ));
		
		jsonObject.addProperty("comment", lliApplication.getComment());
		jsonObject.addProperty("rejectionComment", lliApplication.getRejectionComment());
		jsonObject.addProperty("description", lliApplication.getDescription());
		jsonObject.addProperty("requestForCorrectionComment", lliApplication.getRequestForCorrectionComment());
		return jsonObject;
	}

	@Override
	public JsonElement serialize(LLIApplication arg0, Type arg1, JsonSerializationContext arg2) {
		return null;
	}
	

}
