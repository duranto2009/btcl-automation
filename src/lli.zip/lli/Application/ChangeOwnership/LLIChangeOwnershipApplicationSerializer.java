package lli.Application.ChangeOwnership;

import java.lang.reflect.Type;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import common.repository.AllClientRepository;
import lli.LLIConnectionService;
import lli.LLIDropdownPair;
import lli.Application.LLIApplicationSerializer;
import util.ServiceDAOFactory;

public class LLIChangeOwnershipApplicationSerializer implements JsonSerializer<LLIChangeOwnershipApplication>{
	
	LLIConnectionService lliConnectionService = ServiceDAOFactory.getService(LLIConnectionService.class);

	@Override
	public JsonElement serialize(LLIChangeOwnershipApplication lliChangeOwnershipApplication, Type arg1, JsonSerializationContext context) {
		JsonObject jsonObject = new JsonObject();

		//Serialize Specific LLI New Connection Application
		jsonObject.addProperty("extendedApplicationID", lliChangeOwnershipApplication.getExtendedApplicationID());

		jsonObject.addProperty("connectionID", lliChangeOwnershipApplication.getConnectionID());
		try {
			jsonObject.add("destinationClient", context.serialize(new LLIDropdownPair(lliChangeOwnershipApplication.getDestinationClient(), AllClientRepository.getInstance().getClientByClientID(lliChangeOwnershipApplication.getDestinationClient()).getName())));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		jsonObject.addProperty("suggestedDate", lliChangeOwnershipApplication.getSuggestedDate());
		
		jsonObject = LLIApplicationSerializer.getCommonPart(lliChangeOwnershipApplication, jsonObject, context);
		
		return jsonObject;
	}

}
