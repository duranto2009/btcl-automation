package lli.Application.ChangeOwnership;

import java.lang.reflect.Type;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import lli.Application.LLIApplication;
import util.ModifiedSqlGenerator;

public class LLIChangeOwnershipApplicationDeserializer implements JsonDeserializer<LLIChangeOwnershipApplication>{

	@Override
	public LLIChangeOwnershipApplication deserialize(JsonElement jsonElement, Type arg1, JsonDeserializationContext context) throws JsonParseException {
		LLIChangeOwnershipApplication lliChangeOwnershipApplication = new LLIChangeOwnershipApplication();
		
		//Receive JSON
		JsonObject jsonObject = jsonElement.getAsJsonObject();
		
		//Deserialize Specific LLI New Connection Application
		lliChangeOwnershipApplication.setExtendedApplicationID(jsonObject.get("extendedApplicationID") != null ? jsonObject.get("extendedApplicationID").getAsLong() : 0);
		
		lliChangeOwnershipApplication.setConnectionID(jsonObject.get("connectionID").getAsLong());
		lliChangeOwnershipApplication.setDestinationClient(jsonObject.get("destinationClient").getAsJsonObject().get("ID").getAsLong());
		
		lliChangeOwnershipApplication.setSuggestedDate(jsonObject.get("suggestedDate").getAsLong());
		
		//Deserialize Common LLI Application
		LLIApplication lliApplication = context.deserialize(jsonElement, LLIApplication.class);
		ModifiedSqlGenerator.populateObjectFromOtherObject(lliApplication, lliChangeOwnershipApplication, LLIApplication.class);
		
		return lliChangeOwnershipApplication;
	}



}
