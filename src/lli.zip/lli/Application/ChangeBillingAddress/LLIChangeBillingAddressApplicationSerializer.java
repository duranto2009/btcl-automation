package lli.Application.ChangeBillingAddress;

import java.lang.reflect.Type;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import lli.LLIDropdownPair;
import lli.Application.LLIApplicationSerializer;
import lli.connection.LLIConnectionConstants;

public class LLIChangeBillingAddressApplicationSerializer implements JsonSerializer<LLIChangeBillingAddressApplication>{

	@Override
	public JsonElement serialize(LLIChangeBillingAddressApplication lliChangeBillingAddressApplication, Type arg1, JsonSerializationContext context) {
		JsonObject jsonObject = new JsonObject();

		//Serialize Specific LLI New Connection Application
		jsonObject.addProperty("extendedApplicationID", lliChangeBillingAddressApplication.getExtendedApplicationID());
		jsonObject.addProperty("billingAddress", lliChangeBillingAddressApplication.getBillingAddress());
		jsonObject.addProperty("description", lliChangeBillingAddressApplication.getDescription());
		jsonObject.addProperty("suggestedDate", lliChangeBillingAddressApplication.getSuggestedDate());
		
		//Serialize Common LLI Application
		/*
		JsonElement jsonElement = context.serialize(lliChangeBillingAddressApplication, LLIApplication.class);
		Iterator<Entry<String, JsonElement>> iterator = jsonElement.getAsJsonObject().entrySet().iterator();
		while(iterator.hasNext()) {
			Entry entry = iterator.next();
			jsonObject.addProperty(entry.getKey().toString(), entry.getValue().toString());
		}
		*/
		jsonObject = LLIApplicationSerializer.getCommonPart(lliChangeBillingAddressApplication, jsonObject, context);
		
		return jsonObject;
	}

}
