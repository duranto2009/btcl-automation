package lli.Application;

public interface SingleConnectionApplication {
	public long getConnectionID();
}
