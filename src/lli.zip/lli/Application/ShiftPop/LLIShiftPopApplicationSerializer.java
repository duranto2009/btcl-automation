package lli.Application.ShiftPop;

import java.lang.reflect.Type;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import lli.LLIDropdownPair;
import lli.Application.LLIApplicationSerializer;
import lli.connection.LLIConnectionConstants;

public class LLIShiftPopApplicationSerializer implements JsonSerializer<LLIShiftPopApplication>{

	@Override
	public JsonElement serialize(LLIShiftPopApplication lliShiftPopApplication, Type arg1, JsonSerializationContext context) {
		JsonObject jsonObject = new JsonObject();

		//Serialize Specific LLI New Connection Application
		jsonObject.addProperty("extendedApplicationID", lliShiftPopApplication.getExtendedApplicationID());
		jsonObject.addProperty("connectionID", lliShiftPopApplication.getConnectionID());
		jsonObject.addProperty("officeID", lliShiftPopApplication.getOfficeID());
		jsonObject.addProperty("popID", lliShiftPopApplication.getPopID());
		jsonObject.addProperty("description", lliShiftPopApplication.getDescription());
		jsonObject.add("loopProvider", context.serialize( new LLIDropdownPair(lliShiftPopApplication.getLoopProvider(), LLIConnectionConstants.loopProviderMap.get(lliShiftPopApplication.getLoopProvider()) ) ));
		jsonObject.addProperty("suggestedDate", lliShiftPopApplication.getSuggestedDate());
		
		//Serialize Common LLI Application
		/*
		JsonElement jsonElement = context.serialize(lliShiftPopApplication, LLIApplication.class);
		Iterator<Entry<String, JsonElement>> iterator = jsonElement.getAsJsonObject().entrySet().iterator();
		while(iterator.hasNext()) {
			Entry entry = iterator.next();
			jsonObject.addProperty(entry.getKey().toString(), entry.getValue().toString());
		}
		*/
		jsonObject = LLIApplicationSerializer.getCommonPart(lliShiftPopApplication, jsonObject, context);
		
		return jsonObject;
	}

}
