package lli.Application.ShiftPop;

import java.lang.reflect.Type;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import lli.Application.LLIApplication;
import util.ModifiedSqlGenerator;

public class LLIShiftPopApplicationDeserializer implements JsonDeserializer<LLIShiftPopApplication>{

	@Override
	public LLIShiftPopApplication deserialize(JsonElement jsonElement, Type arg1, JsonDeserializationContext context) throws JsonParseException {
		LLIShiftPopApplication lliShiftPopApplication = new LLIShiftPopApplication();
		
		//Receive JSON
		JsonObject jsonObject = jsonElement.getAsJsonObject();
		
		//Deserialize Specific LLI New Connection Application
		lliShiftPopApplication.setExtendedApplicationID(jsonObject.get("extendedApplicationID") != null ? jsonObject.get("extendedApplicationID").getAsLong() : 0);
		lliShiftPopApplication.setConnectionID(jsonObject.get("connectionID").getAsLong());
		lliShiftPopApplication.setOfficeID(jsonObject.get("officeID").getAsLong());
		lliShiftPopApplication.setPopID(jsonObject.get("popID").getAsLong());		
		lliShiftPopApplication.setLoopProvider((jsonObject.get("loopProvider").getAsJsonObject().get("ID").getAsInt()));		
		lliShiftPopApplication.setSuggestedDate(jsonObject.get("suggestedDate").getAsLong());
		lliShiftPopApplication.setDescription(jsonObject.get("description").getAsString());
		
		//Deserialize Common LLI Application
		LLIApplication lliApplication = context.deserialize(jsonElement, LLIApplication.class);
		ModifiedSqlGenerator.populateObjectFromOtherObject(lliApplication, lliShiftPopApplication, LLIApplication.class);
		
		return lliShiftPopApplication;
	}



}
